/**
 * Cache utilities for JobApAI Chrome Extension
 * Implements IndexedDB caching for CV profiles and session storage for hot data
 */

// IndexedDB for persistent cache
const DB_NAME = 'jobapai-cache';
const DB_VERSION = 1;
const STORES = {
  CV_PROFILES: 'cv-profiles',
  JD_CACHE: 'jd-cache',
  RESPONSES: 'responses',
};

let dbInstance = null;

async function getDB() {
  if (dbInstance) return dbInstance;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(dbInstance);
    };

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // CV Profiles store (keyed by hash of CV text)
      if (!db.objectStoreNames.contains(STORES.CV_PROFILES)) {
        const cvStore = db.createObjectStore(STORES.CV_PROFILES, {
          keyPath: 'hash',
        });
        cvStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      // JD Cache store (keyed by hash of JD text)
      if (!db.objectStoreNames.contains(STORES.JD_CACHE)) {
        const jdStore = db.createObjectStore(STORES.JD_CACHE, {
          keyPath: 'hash',
        });
        jdStore.createIndex('timestamp', 'timestamp', { unique: false });
        jdStore.createIndex('expiry', 'expiry', { unique: false });
      }

      // Response cache (keyed by composite hash)
      if (!db.objectStoreNames.contains(STORES.RESPONSES)) {
        const respStore = db.createObjectStore(STORES.RESPONSES, {
          keyPath: 'hash',
        });
        respStore.createIndex('timestamp', 'timestamp', { unique: false });
        respStore.createIndex('expiry', 'expiry', { unique: false });
      }
    };
  });
}

// Simple hash function for cache keys
async function hashText(text) {
  const normalized = text.trim().toLowerCase().replace(/\s+/g, ' ');
  const encoder = new TextEncoder();
  const data = encoder.encode(normalized);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * CV Profile Cache
 */
export async function getCVProfile(cvText) {
  try {
    const db = await getDB();
    const hash = await hashText(cvText);
    const tx = db.transaction(STORES.CV_PROFILES, 'readonly');
    const store = tx.objectStore(STORES.CV_PROFILES);
    const request = store.get(hash);

    return new Promise((resolve) => {
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => resolve(null);
    });
  } catch (e) {
    console.error('[Cache] getCVProfile error:', e);
    return null;
  }
}

export async function setCVProfile(cvText, profile) {
  try {
    const db = await getDB();
    const hash = await hashText(cvText);
    const tx = db.transaction(STORES.CV_PROFILES, 'readwrite');
    const store = tx.objectStore(STORES.CV_PROFILES);

    const data = {
      hash,
      cvText,
      summary: profile.summary,
      skills: profile.skills,
      experience: profile.experience,
      timestamp: Date.now(),
    };

    store.put(data);
    return new Promise((resolve) => {
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch (e) {
    console.error('[Cache] setCVProfile error:', e);
    return false;
  }
}

/**
 * JD Cache (with TTL)
 */
export async function getJDCache(jdText, ttlMs = 30 * 60 * 1000) {
  try {
    const db = await getDB();
    const hash = await hashText(jdText);
    const tx = db.transaction(STORES.JD_CACHE, 'readonly');
    const store = tx.objectStore(STORES.JD_CACHE);
    const request = store.get(hash);

    return new Promise((resolve) => {
      request.onsuccess = () => {
        const result = request.result;
        if (!result) {
          resolve(null);
          return;
        }
        // Check expiry
        if (Date.now() > result.expiry) {
          resolve(null);
          return;
        }
        resolve(result.data);
      };
      request.onerror = () => resolve(null);
    });
  } catch (e) {
    console.error('[Cache] getJDCache error:', e);
    return null;
  }
}

export async function setJDCache(jdText, data, ttlMs = 30 * 60 * 1000) {
  try {
    const db = await getDB();
    const hash = await hashText(jdText);
    const tx = db.transaction(STORES.JD_CACHE, 'readwrite');
    const store = tx.objectStore(STORES.JD_CACHE);

    const cacheData = {
      hash,
      data,
      timestamp: Date.now(),
      expiry: Date.now() + ttlMs,
    };

    store.put(cacheData);
    return new Promise((resolve) => {
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch (e) {
    console.error('[Cache] setJDCache error:', e);
    return false;
  }
}

/**
 * Response Cache (for complete analysis results)
 */
export async function getResponseCache(
  cvText,
  jdText,
  formText,
  ttlMs = 5 * 60 * 1000
) {
  try {
    const db = await getDB();
    const compositeKey = cvText + '|||' + jdText + '|||' + formText;
    const hash = await hashText(compositeKey);
    const tx = db.transaction(STORES.RESPONSES, 'readonly');
    const store = tx.objectStore(STORES.RESPONSES);
    const request = store.get(hash);

    return new Promise((resolve) => {
      request.onsuccess = () => {
        const result = request.result;
        if (!result) {
          resolve(null);
          return;
        }
        // Check expiry
        if (Date.now() > result.expiry) {
          resolve(null);
          return;
        }
        resolve(result.data);
      };
      request.onerror = () => resolve(null);
    });
  } catch (e) {
    console.error('[Cache] getResponseCache error:', e);
    return null;
  }
}

export async function setResponseCache(
  cvText,
  jdText,
  formText,
  data,
  ttlMs = 5 * 60 * 1000
) {
  try {
    const db = await getDB();
    const compositeKey = cvText + '|||' + jdText + '|||' + formText;
    const hash = await hashText(compositeKey);
    const tx = db.transaction(STORES.RESPONSES, 'readwrite');
    const store = tx.objectStore(STORES.RESPONSES);

    const cacheData = {
      hash,
      data,
      timestamp: Date.now(),
      expiry: Date.now() + ttlMs,
    };

    store.put(cacheData);
    return new Promise((resolve) => {
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch (e) {
    console.error('[Cache] setResponseCache error:', e);
    return false;
  }
}

/**
 * Session storage for hot caches (faster than IndexedDB)
 */
export async function getSessionCache(key) {
  try {
    if (chrome?.storage?.session) {
      const result = await chrome.storage.session.get(key);
      if (result[key]) {
        // Check expiry
        if (result[key].expiry && Date.now() > result[key].expiry) {
          await chrome.storage.session.remove(key);
          return null;
        }
        return result[key].data;
      }
    }
    return null;
  } catch (e) {
    console.error('[Cache] getSessionCache error:', e);
    return null;
  }
}

export async function setSessionCache(key, data, ttlMs = 5 * 60 * 1000) {
  try {
    if (chrome?.storage?.session) {
      const cacheData = {
        data,
        expiry: Date.now() + ttlMs,
      };
      await chrome.storage.session.set({ [key]: cacheData });
      return true;
    }
    return false;
  } catch (e) {
    console.error('[Cache] setSessionCache error:', e);
    return false;
  }
}

/**
 * Cleanup expired entries
 */
export async function cleanupExpiredCache() {
  try {
    const db = await getDB();
    const now = Date.now();

    // Cleanup JD Cache
    const jdTx = db.transaction(STORES.JD_CACHE, 'readwrite');
    const jdStore = jdTx.objectStore(STORES.JD_CACHE);
    const jdIndex = jdStore.index('expiry');
    const jdRange = IDBKeyRange.upperBound(now);
    const jdCursor = jdIndex.openCursor(jdRange);

    jdCursor.onsuccess = (e) => {
      const cursor = e.target.result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };

    // Cleanup Response Cache
    const respTx = db.transaction(STORES.RESPONSES, 'readwrite');
    const respStore = respTx.objectStore(STORES.RESPONSES);
    const respIndex = respStore.index('expiry');
    const respRange = IDBKeyRange.upperBound(now);
    const respCursor = respIndex.openCursor(respRange);

    respCursor.onsuccess = (e) => {
      const cursor = e.target.result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };
  } catch (e) {
    console.error('[Cache] cleanupExpiredCache error:', e);
  }
}

// Run cleanup on load
if (typeof window !== 'undefined') {
  cleanupExpiredCache();
}
