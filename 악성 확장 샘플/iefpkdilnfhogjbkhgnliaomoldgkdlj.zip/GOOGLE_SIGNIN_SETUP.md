# Google Sign-In with Firebase Auth - SETUP GUIDE

## ✅ What Was Changed

### 1. Created `firebase-auth-bg.js` (Background Script)

- Loads Firebase SDK via `importScripts()` (allowed in service workers)
- Handles all Firebase Auth operations in the background
- Uses Chrome Identity API + Firebase for Google Sign-In
- Listens for messages from sidepanel/content scripts

### 2. Updated `background.js`

- Imports `firebase-auth-bg.js` at startup
- Provides Firebase Auth to the entire extension

### 3. Updated `sidepanel.js` - `handleGoogleSignIn()`

- Sends message to background script: `{ type: 'FIREBASE_AUTH', action: 'SIGN_IN_GOOGLE' }`
- Background handles OAuth with Chrome Identity API
- No more external script imports from sidepanel!

### 4. Updated `manifest.json`

- Added `"identity"` permission for Chrome Identity API
- Required for Google Sign-In

---

## 🔧 Step 1: Enable Google Sign-In in Firebase Console

1. Go to [Firebase Console - Authentication](https://console.firebase.google.com/project/jobapai/authentication/providers)

2. Click **"Google"** in the Sign-in providers list

3. **Enable** the toggle

4. Set **Project public-facing name**: `JobApAI`

5. Set **Support email**: `clientservice@ancillaco.com`

6. Click **Save**

---

## 🔧 Step 2: Get Your Extension ID

1. Go to `chrome://extensions/`

2. Enable **"Developer mode"** (top right)

3. Load your extension (if not already loaded)

4. **Copy the Extension ID** (looks like: `abcdefghijklmnopqrstuvwxyz123456`)

---

## 🔧 Step 3: Configure OAuth in Google Cloud Console

1. Go to [Google Cloud Console - Credentials](https://console.cloud.google.com/apis/credentials?project=323731579339)

2. Click **"+ CREATE CREDENTIALS"** → **"OAuth client ID"**

3. Select **Application type**: **"Chrome extension"**

4. Set **Name**: `JobApAI Extension`

5. Set **Item ID**: Paste your Extension ID from Step 2

6. Click **Create**

7. **Copy the Client ID** (format: `XXXXX.apps.googleusercontent.com`)

---

## 🔧 Step 4: Add OAuth Config to manifest.json

Add this section to your `manifest.json` (after the `"icons"` section):

```json
  "oauth2": {
    "client_id": "YOUR_CLIENT_ID_HERE.apps.googleusercontent.com",
    "scopes": [
      "https://www.googleapis.com/auth/userinfo.email",
      "https://www.googleapis.com/auth/userinfo.profile"
    ]
  },
```

**Replace `YOUR_CLIENT_ID_HERE` with the Client ID from Step 3!**

---

## 🧪 Step 5: Test Google Sign-In

1. **Reload extension** in Chrome (`chrome://extensions/` → Click "Reload")

2. Open extension and click **"Continue with Google"**

3. Chrome Identity API will open Google account picker

4. Select your Google account

5. Grant permissions

6. You should be signed in! ✅

---

## 🔍 How It Works

```
User clicks "Continue with Google"
  ↓
Sidepanel sends message to background.js
  ↓
Background uses Chrome Identity API to get Google token
  ↓
Background exchanges token for Firebase credential
  ↓
Background stores Firebase ID token in Chrome storage
  ↓
Sidepanel receives user data
  ↓
User is authenticated!
```

---

## ✅ Benefits

1. **Manifest V3 compliant**: No external script imports
2. **Native Google Sign-In**: Uses Chrome Identity API
3. **Secure**: All auth in background service worker
4. **No redirects**: Seamless experience

---

## 📝 Files Changed

- ✅ `firebase-auth-bg.js` (NEW) - Background Firebase Auth handler
- ✅ `background.js` - Imports firebase-auth-bg.js
- ✅ `manifest.json` - Added "identity" permission
- ✅ `sidepanel.js` - Sends messages to background for auth

---

## ⚠️ Troubleshooting

### "Error: OAuth2 client ID missing"

- Add `oauth2` section to `manifest.json` (Step 4)
- Make sure Client ID is correct

### "Error: Redirect URI mismatch"

- Make sure Extension ID in Google Cloud matches actual extension ID
- Reload extension after changing manifest.json

### "Failed to fetch dynamically imported module"

- Fixed! Firebase now loads in background.js only
- Reload extension to apply changes

