# Migration from Supabase to Google Cloud Platform

## Overview

This guide walks through replacing Supabase with Google Cloud services:

- **Supabase Database** → **Cloud SQL (PostgreSQL)**
- **Supabase Auth** → **Identity Platform (Firebase Auth)**
- **Supabase Storage** → **Cloud Storage**

---

## Phase 1: Cloud SQL Setup

### 1.1 Create Cloud SQL Instance

```bash
# Set your project
gcloud config set project YOUR_PROJECT_ID

# Create Cloud SQL instance (PostgreSQL 15)
gcloud sql instances create jobapai-db \
  --database-version=POSTGRES_15 \
  --tier=db-f1-micro \
  --region=us-south1 \
  --root-password=YOUR_SECURE_PASSWORD \
  --storage-type=SSD \
  --storage-size=10GB \
  --backup \
  --backup-start-time=03:00

# Create database
gcloud sql databases create jobapai --instance=jobapai-db

# Create app user
gcloud sql users create jobapai-app \
  --instance=jobapai-db \
  --password=YOUR_APP_PASSWORD
```

### 1.2 Configure Cloud SQL Proxy for Local Development

```bash
# Download Cloud SQL Proxy
curl -o cloud-sql-proxy https://storage.googleapis.com/cloud-sql-connectors/cloud-sql-proxy/v2.8.0/cloud-sql-proxy.linux.amd64
chmod +x cloud-sql-proxy

# Get connection name
gcloud sql instances describe jobapai-db --format="value(connectionName)"
# Output: YOUR_PROJECT_ID:us-south1:jobapai-db

# Start proxy (keep running in separate terminal)
./cloud-sql-proxy YOUR_PROJECT_ID:us-south1:jobapai-db
```

### 1.3 Run Database Schema

```bash
# Connect via proxy
psql "host=127.0.0.1 port=5432 dbname=jobapai user=jobapai-app password=YOUR_APP_PASSWORD"

# Once connected, run the schema files:
\i vercel-backend/user_profiles.sql
\i vercel-backend/tracker.sql
\i vercel-backend/supabase.sql

# Verify setup
\i vercel-backend/verify_supabase_setup.sql
```

### 1.4 Enable Cloud SQL Admin API

```bash
gcloud services enable sqladmin.googleapis.com
```

---

## Phase 2: Identity Platform (Firebase Auth)

### 2.1 Enable Identity Platform

```bash
# Enable Identity Platform
gcloud services enable identitytoolkit.googleapis.com

# Or via Console:
# 1. Go to https://console.cloud.google.com/customer-identity
# 2. Click "Enable"
# 3. Choose "Identity Platform" (not Firebase Auth legacy)
```

### 2.2 Configure Authentication Methods

Via Console (https://console.cloud.google.com/customer-identity/providers):

1. Enable **Email/Password** provider
2. Enable **Google** provider (for OAuth)
3. Add authorized domains:
   - `localhost`
   - `127.0.0.1`
   - `chrome-extension://YOUR_EXTENSION_ID`
   - Your Cloud Run domain

### 2.3 Get Firebase Config

Via Console (https://console.firebase.google.com):

1. Add a Web App to your project
2. Copy the Firebase config object:

```javascript
const firebaseConfig = {
  apiKey: 'AIza...',
  authDomain: 'YOUR_PROJECT.firebaseapp.com',
  projectId: 'YOUR_PROJECT_ID',
  storageBucket: 'YOUR_PROJECT.appspot.com',
  messagingSenderId: '...',
  appId: '1:...:web:...',
};
```

---

## Phase 3: Cloud Storage Setup

### 3.1 Create Storage Bucket

```bash
# Create bucket for user files
gsutil mb -l us-south1 gs://jobapai-user-files

# Set lifecycle policy (auto-delete old CVs after 90 days)
cat > lifecycle.json << EOF
{
  "lifecycle": {
    "rule": [
      {
        "action": {"type": "Delete"},
        "condition": {"age": 90}
      }
    ]
  }
}
EOF

gsutil lifecycle set lifecycle.json gs://jobapai-user-files

# Set CORS for extension access
cat > cors.json << EOF
[
  {
    "origin": ["chrome-extension://*"],
    "method": ["GET", "PUT", "POST"],
    "responseHeader": ["Content-Type"],
    "maxAgeSeconds": 3600
  }
]
EOF

gsutil cors set cors.json gs://jobapai-user-files
```

---

## Phase 4: Update Backend Code

### 4.1 Install Dependencies

```bash
cd vercel-backend
npm install pg firebase-admin @google-cloud/storage
npm uninstall @supabase/supabase-js
```

### 4.2 Create Database Connection Module

**File:** `vercel-backend/lib/db.ts`

```typescript
import { Pool } from 'pg';

const pool = new Pool({
  user: process.env.DB_USER || 'jobapai-app',
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'jobapai',
  host: process.env.DB_HOST || '/cloudsql/YOUR_PROJECT:us-south1:jobapai-db',
  port: parseInt(process.env.DB_PORT || '5432'),
  max: 10,
  idleTimeoutMillis: 30000,
});

export default pool;

export async function query(text: string, params?: any[]) {
  const start = Date.now();
  const res = await pool.query(text, params);
  const duration = Date.now() - start;
  console.log('Executed query', { text, duration, rows: res.rowCount });
  return res;
}
```

### 4.3 Create Firebase Admin Module

**File:** `vercel-backend/lib/firebase-admin.ts`

```typescript
import * as admin from 'firebase-admin';

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(),
    projectId: process.env.GOOGLE_CLOUD_PROJECT,
  });
}

export const auth = admin.auth();
export const storage = admin.storage();

export async function verifyIdToken(token: string) {
  try {
    const decodedToken = await auth.verifyIdToken(token);
    return { user: decodedToken, error: null };
  } catch (error) {
    return { user: null, error };
  }
}
```

---

## Phase 5: Update Frontend (Chrome Extension)

### 5.1 Replace Supabase Client Files

**Delete:**

- `supabase-global.js`

**Create:** `firebase-auth.js`

```javascript
// Firebase Auth Configuration
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';

const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'YOUR_PROJECT.firebaseapp.com',
  projectId: 'YOUR_PROJECT_ID',
  storageBucket: 'YOUR_PROJECT.appspot.com',
  messagingSenderId: 'YOUR_SENDER_ID',
  appId: 'YOUR_APP_ID',
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export {
  auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
};
```

### 5.2 Update manifest.json

```json
{
  "content_security_policy": {
    "extension_pages": "script-src 'self' https://www.gstatic.com; object-src 'self'"
  },
  "host_permissions": [
    "https://identitytoolkit.googleapis.com/*",
    "https://securetoken.googleapis.com/*",
    "https://YOUR_PROJECT.firebaseapp.com/*"
  ]
}
```

---

## Phase 6: Update Environment Variables

### 6.1 Cloud Run Environment Variables

Set in Cloud Run console or via command:

```bash
gcloud run services update jobapai \
  --region=us-south1 \
  --set-env-vars="DB_HOST=/cloudsql/YOUR_PROJECT:us-south1:jobapai-db" \
  --set-env-vars="DB_USER=jobapai-app" \
  --set-env-vars="DB_NAME=jobapai" \
  --set-secrets="DB_PASSWORD=db-password:latest" \
  --add-cloudsql-instances=YOUR_PROJECT:us-south1:jobapai-db
```

### 6.2 Create Secret for Database Password

```bash
# Create secret
echo -n "YOUR_APP_PASSWORD" | gcloud secrets create db-password --data-file=-

# Grant Cloud Run access
gcloud secrets add-iam-policy-binding db-password \
  --member="serviceAccount:YOUR_SERVICE_ACCOUNT@YOUR_PROJECT.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"
```

---

## Phase 7: Update API Routes

### 7.1 Example: Profile Sync Route

**Before (Supabase):**

```typescript
import { createClient } from '@supabase/supabase-js';
const supabase = createClient(supabaseUrl, supabaseKey);
const { data } = await supabase.from('user_profiles').select('*');
```

**After (Cloud SQL):**

```typescript
import { query } from '../../lib/db';
import { verifyIdToken } from '../../lib/firebase-admin';

// Verify Firebase token
const authHeader = req.headers.get('authorization');
const token = authHeader?.substring(7);
const { user, error } = await verifyIdToken(token);

if (error || !user) {
  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
}

// Query database
const result = await query('SELECT * FROM user_profiles WHERE user_id = $1', [
  user.uid,
]);
```

---

## Phase 8: Grant IAM Permissions

```bash
# Get Cloud Run service account
SERVICE_ACCOUNT=$(gcloud run services describe jobapai --region=us-south1 --format="value(spec.template.spec.serviceAccountName)")

# Grant Cloud SQL Client role
gcloud projects add-iam-policy-binding YOUR_PROJECT_ID \
  --member="serviceAccount:$SERVICE_ACCOUNT" \
  --role="roles/cloudsql.client"

# Grant Storage Object Admin (for file uploads)
gsutil iam ch serviceAccount:$SERVICE_ACCOUNT:objectAdmin gs://jobapai-user-files
```

---

## Phase 9: Testing Checklist

- [ ] Database connection works from Cloud Run
- [ ] Firebase Auth signup works
- [ ] Firebase Auth login works
- [ ] Token verification in backend works
- [ ] Profile sync to Cloud SQL works
- [ ] Custom answers save/load works
- [ ] Employment history saves correctly
- [ ] CV upload to Cloud Storage works
- [ ] Resume generation and download works
- [ ] Cover letter generation works
- [ ] Job application tracking logs correctly

---

## Cost Estimation

**Monthly costs (estimated):**

- Cloud SQL (db-f1-micro): ~$7-10
- Cloud Run (existing): ~$5-10
- Cloud Storage: <$1
- Identity Platform: Free (up to 50k MAU)
- Secrets Manager: <$1
- **Total: ~$15-25/month**

---

## Rollback Plan

If issues arise:

1. Keep Supabase running temporarily
2. Toggle between backends via environment variable
3. Migrate data back to Supabase if needed

---

## Next Steps

1. ✅ Run Phase 1: Create Cloud SQL instance
2. Run Phase 2: Enable Identity Platform
3. Run Phase 3: Create Storage bucket
4. Update backend code (Phases 4, 6, 7)
5. Update frontend code (Phase 5)
6. Deploy and test (Phases 8, 9)

