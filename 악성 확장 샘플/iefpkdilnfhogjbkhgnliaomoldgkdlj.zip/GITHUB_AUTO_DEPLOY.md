# Set Up GitHub → Cloud Run Continuous Deployment

## 🎯 What This Does

Every time you push to GitHub, Cloud Run will automatically rebuild and deploy your backend.

---

## 📋 Step-by-Step Setup

### **Step 1: Push Your Code to GitHub**

```bash
cd /home/stationone/Desktop/up/ancilia/chromeextension2

# Initialize git if not already done
git add .
git commit -m "GCP migration complete - Cloud SQL + Firebase Auth"

# Push to your GitHub repository
git push origin main
```

---

### **Step 2: Connect Cloud Run to GitHub**

#### **Option A: Via Google Cloud Console (Recommended - Easiest)**

1. Go to [Cloud Run Console](https://console.cloud.google.com/run?project=jobapai)

2. Click on your **`jobapai`** service

3. Click **"SET UP CONTINUOUS DEPLOYMENT"** at the top (or "Edit & Deploy New Revision")

4. Under **"Source"**, select **"Continuously deploy from a repository"**

5. Click **"SET UP WITH CLOUD BUILD"**

6. Click **"ADD REPOSITORY"**

7. Select **"GitHub"**

8. Click **"Authenticate with GitHub"** (sign in with your GitHub account)

9. Select your **repository** (e.g., `ancilia/chromeextension2`)

10. Select **branch**: `main` (or your default branch)

11. Set **"Build Configuration"**:

    - **Build type**: `Buildpacks` (auto-detect)
    - **Source location**: `/vercel-backend`
    - **Output image**: Leave default

12. Click **"SAVE"**

---

#### **Option B: Via gcloud CLI**

```bash
# Set project
gcloud config set project jobapai

# Enable required APIs
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com

# Connect GitHub repository
gcloud beta run services update jobapai \
  --source=https://github.com/YOUR_USERNAME/YOUR_REPO \
  --source-revision=main \
  --region=us-east1

# Follow the prompts to authenticate with GitHub
```

---

### **Step 3: Configure Build Triggers (Optional - Advanced)**

For more control over builds:

1. Go to [Cloud Build Triggers](https://console.cloud.google.com/cloud-build/triggers?project=jobapai)

2. Click **"CREATE TRIGGER"**

3. Configure:

   - **Name**: `jobapai-deploy`
   - **Event**: `Push to a branch`
   - **Source**: Connect your GitHub repo
   - **Branch**: `^main$` (regex for main branch)
   - **Configuration**: `Cloud Build configuration file`
   - **Location**: `/vercel-backend/cloudbuild.yaml` (we'll create this)

4. Click **"CREATE"**

---

### **Step 4: Create `cloudbuild.yaml` (For Custom Build)**

Create this file in `vercel-backend/cloudbuild.yaml`:

```yaml
steps:
  # Build the container image
  - name: 'gcr.io/cloud-builders/gcloud'
    args:
      - 'run'
      - 'deploy'
      - 'jobapai'
      - '--source=.'
      - '--region=us-east1'
      - '--platform=managed'
      - '--allow-unauthenticated'
      - '--add-cloudsql-instances=jobapai:us-east1:jobapai-db'
      - '--set-env-vars=DB_HOST=/cloudsql/jobapai:us-east1:jobapai-db,DB_USER=jobapai-app,DB_NAME=jobapai,DB_PORT=5432,GOOGLE_CLOUD_PROJECT=jobapai,STORAGE_BUCKET=jobapai-user-files'
      - '--update-secrets=DB_PASSWORD=db-password:latest'

# Timeout for the build
timeout: '1600s'

# Build options
options:
  logging: CLOUD_LOGGING_ONLY
```

---

## ✅ Verification

### **Test the Setup:**

1. Make a small change to your code:

   ```bash
   echo "# Auto-deploy test" >> vercel-backend/README.md
   ```

2. Commit and push:

   ```bash
   git add .
   git commit -m "Test auto-deploy"
   git push origin main
   ```

3. Check Cloud Build:

   - Go to [Cloud Build History](https://console.cloud.google.com/cloud-build/builds?project=jobapai)
   - You should see a new build starting automatically

4. Check Cloud Run:
   - Go to [Cloud Run Console](https://console.cloud.google.com/run?project=jobapai)
   - Wait for new revision to deploy (usually 2-5 minutes)

---

## 🔧 Configure Build Settings

### **Set Environment Variables for Builds:**

```bash
# Grant Cloud Build access to secrets
gcloud projects add-iam-policy-binding jobapai \
  --member="serviceAccount:323731579339@cloudbuild.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"

# Grant Cloud Build permission to deploy to Cloud Run
gcloud projects add-iam-policy-binding jobapai \
  --member="serviceAccount:323731579339@cloudbuild.gserviceaccount.com" \
  --role="roles/run.admin"

# Grant Cloud Build permission to act as Cloud Run service account
gcloud iam service-accounts add-iam-policy-binding \
  323731579339-compute@developer.gserviceaccount.com \
  --member="serviceAccount:323731579339@cloudbuild.gserviceaccount.com" \
  --role="roles/iam.serviceAccountUser" \
  --project=jobapai
```

---

## 📊 Monitor Deployments

### **View Build Logs:**

```bash
gcloud builds list --project=jobapai --limit=5
```

### **View Deployment History:**

```bash
gcloud run revisions list --service=jobapai --region=us-east1
```

---

## 🎉 Benefits

- ✅ **Automatic deployments** on every push to `main`
- ✅ **No manual `gcloud run deploy`** commands needed
- ✅ **Built-in rollback** if deployment fails
- ✅ **Revision history** for easy rollbacks
- ✅ **Build logs** for debugging

---

## 🔄 Manual Deploy (When Needed)

If you need to deploy manually:

```bash
cd /home/stationone/Desktop/up/ancilia/chromeextension2/vercel-backend

gcloud run deploy jobapai \
  --source . \
  --region=us-east1 \
  --platform=managed \
  --allow-unauthenticated \
  --add-cloudsql-instances=jobapai:us-east1:jobapai-db \
  --set-env-vars="DB_HOST=/cloudsql/jobapai:us-east1:jobapai-db,DB_USER=jobapai-app,DB_NAME=jobapai,DB_PORT=5432,GOOGLE_CLOUD_PROJECT=jobapai,STORAGE_BUCKET=jobapai-user-files" \
  --update-secrets=DB_PASSWORD=db-password:latest
```

---

## 🚀 Quick Start

**Easiest method** (takes 2 minutes):

1. Go to https://console.cloud.google.com/run/detail/us-east1/jobapai/edit?project=jobapai
2. Click **"CONTINUOUS DEPLOYMENT"** tab at the top
3. Click **"SET UP WITH CLOUD BUILD"**
4. Connect your GitHub repo
5. Select branch: `main`
6. Click **"SAVE"**
7. Done! ✅

From now on, every `git push` will automatically deploy! 🎉

