# Fix: Invalid OAuth2 Client ID

## 🔴 **Error Cause**

Chrome Identity API requires an OAuth2 Client ID in `manifest.json`, but it's missing.

---

## 🔧 **Step 1: Get Your Extension ID**

1. Go to `chrome://extensions/`
2. Enable **"Developer mode"** (toggle in top right)
3. Find **JobApAI** extension
4. **Copy the Extension ID** (looks like: `abcdefghijklmnopqrstuvwxyz123456`)

**Example:**

```
Extension ID: abcdefghijklmnopqrstuvwxyzabcdef
```

---

## 🔧 **Step 2: Create OAuth Client ID**

1. Go to [Google Cloud Console - Credentials](https://console.cloud.google.com/apis/credentials?project=323731579339)

2. Click **"+ CREATE CREDENTIALS"** button (top of page)

3. Select **"OAuth client ID"**

4. If prompted to configure consent screen:

   - Click **"CONFIGURE CONSENT SCREEN"**
   - Select **"External"**
   - Fill in:
     - **App name**: `JobApAI`
     - **User support email**: Your email
     - **Developer contact**: Your email
   - Click **"SAVE AND CONTINUE"**
   - Skip "Scopes" (click "SAVE AND CONTINUE")
   - Skip "Test users" (click "SAVE AND CONTINUE")
   - Click **"BACK TO DASHBOARD"**
   - Go back to **Credentials** tab

5. Click **"+ CREATE CREDENTIALS"** → **"OAuth client ID"** again

6. Configure:

   - **Application type**: Select **"Chrome extension"** from dropdown
   - **Name**: `JobApAI Extension`
   - **Item ID**: Paste your Extension ID from Step 1

7. Click **"CREATE"**

8. **Copy the Client ID** that appears (format: `XXXXX.apps.googleusercontent.com`)

---

## 🔧 **Step 3: Add OAuth2 to manifest.json**

I'll add this for you once you provide the Client ID, or you can add it manually:

```json
{
  "manifest_version": 3,
  "name": "JobApAI",
  "version": "0.3.0",
  // ... other fields ...

  "oauth2": {
    "client_id": "YOUR_CLIENT_ID_HERE.apps.googleusercontent.com",
    "scopes": [
      "https://www.googleapis.com/auth/userinfo.email",
      "https://www.googleapis.com/auth/userinfo.profile"
    ]
  }

  // ... rest of manifest ...
}
```

**Add this section AFTER the `"icons"` section and BEFORE `"content_scripts"`.**

---

## 🔧 **Step 4: Reload Extension**

1. Go to `chrome://extensions/`
2. Click **"Reload"** on JobApAI
3. Try "Continue with Google" again

---

## 📋 **Quick Summary**

1. ✅ Get Extension ID from `chrome://extensions/`
2. ✅ Create OAuth Client ID in Google Cloud Console
3. ✅ Copy the Client ID
4. ✅ Add `oauth2` section to `manifest.json`
5. ✅ Reload extension
6. ✅ Test Google Sign-In

---

## 🎯 **What's Your Extension ID?**

Tell me your Extension ID and Client ID, and I'll update the manifest.json for you!

Or follow the steps above to do it yourself.

---

## ⚠️ **Important Notes:**

- The Extension ID changes if you remove and reload the extension
- The OAuth Client ID must match your Extension ID exactly
- If Extension ID changes, create a new OAuth Client ID

---

## 🚀 **After Adding OAuth2:**

The "Invalid OAuth2 Client ID" error will be gone and Google Sign-In will work! ✅

