(function () {
  const RR_STATE_KEY = 'rrIntegrationState';
  const GESTURE_PROMPT_KEY = 'rrGesturePrompt';
  let gestureBannerElement = null;

  // Abort flag for form filling - can be set by sidepanel to stop filling
  let isFillingAborted = false;

  // Helper to check if error is a recoverable Chrome extension error (context invalidated, etc.)
  function isRecoverableExtensionError(error) {
    const msg = String(error?.message || error || '').toLowerCase();
    return (
      msg.includes('extension context invalidated') ||
      msg.includes('could not establish connection') ||
      msg.includes('receiving end does not exist') ||
      msg.includes('message port closed') ||
      msg.includes('cannot access') ||
      msg.includes('frame was removed')
    );
  }

  // Check if the extension context is still valid
  function isExtensionContextValid() {
    try {
      // If chrome.runtime.id is undefined, the context is invalidated
      return (
        typeof chrome !== 'undefined' &&
        typeof chrome.runtime !== 'undefined' &&
        !!chrome.runtime.id
      );
    } catch (_) {
      return false;
    }
  }

  async function getRRState() {
    if (!isExtensionContextValid()) return {};
    try {
      const stored = await chrome.storage.local.get(RR_STATE_KEY);
      return stored?.[RR_STATE_KEY] || {};
    } catch (_) {
      return {};
    }
  }

  async function setRRState(update) {
    if (!isExtensionContextValid()) {
      // Silently skip if extension context is invalid - page will need refresh
      return update;
    }
    try {
      const current = await getRRState();
      const next = { ...current, ...update, updatedAt: Date.now() };
      await chrome.storage.local.set({ [RR_STATE_KEY]: next });
      try {
        await chrome.runtime.sendMessage({
          type: 'rrIntegrationStateUpdated',
          payload: next,
        });
      } catch (_) {}
      return next;
    } catch (error) {
      // Only log if it's not an expected extension error
      if (!isRecoverableExtensionError(error)) {
        console.warn('[Content] Failed to persist RR state:', error);
      }
      return update;
    }
  }

  async function persistRRToken(token) {
    if (!token) return;
    try {
      await chrome.storage.local.set({ rrAuthToken: token });
    } catch (_) {}
    try {
      await chrome.storage.sync.set({
        firebaseSession: {
          access_token: token,
          provider: 'reverse-recruiting',
        },
      });
    } catch (_) {}
  }

  async function requestRRTokenFromHost() {
    try {
      window.postMessage({ type: 'RR_EXTENSION_REQUEST_TOKEN' }, '*');
    } catch (_) {}
  }

  function showExtensionGestureBanner(message) {
    try {
      const bannerMessage =
        message ||
        'Get AI-assisted resumes & cover letters. Click the Reverse Recruiting extension.';

      // Always remove existing banner first to avoid duplicates
      hideExtensionGestureBanner();

      // Create style element with scoped CSS using !important to override host styles
      const styleEl = document.createElement('style');
      styleEl.id = 'rr-extension-gesture-banner-styles';
      styleEl.textContent = `
        #rr-extension-gesture-banner {
          all: initial !important;
          position: fixed !important;
          top: 16px !important;
          right: 16px !important;
          z-index: 2147483647 !important;
          background: #1a1d2e !important;
          color: #ffffff !important;
          padding: 18px 22px !important;
          border-radius: 12px !important;
          box-shadow: 0 8px 32px rgba(0,0,0,0.45) !important;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
          font-size: 14px !important;
          line-height: 1.5 !important;
          max-width: 400px !important;
          min-width: 300px !important;
          box-sizing: border-box !important;
          display: block !important;
        }
        #rr-extension-gesture-banner .rr-title {
          all: initial !important;
          display: block !important;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
          font-size: 16px !important;
          font-weight: 700 !important;
          color: #ffffff !important;
          margin: 0 0 10px 0 !important;
          padding: 0 !important;
          line-height: 1.3 !important;
        }
        #rr-extension-gesture-banner .rr-message {
          all: initial !important;
          display: block !important;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
          font-size: 13px !important;
          font-weight: 400 !important;
          color: rgba(255,255,255,0.9) !important;
          margin: 0 0 16px 0 !important;
          padding: 0 !important;
          line-height: 1.6 !important;
        }
        #rr-extension-gesture-banner .rr-btn {
          all: initial !important;
          display: inline-block !important;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
          background: #ffffff !important;
          color: #1a1d2e !important;
          border: none !important;
          border-radius: 6px !important;
          padding: 10px 20px !important;
          font-size: 13px !important;
          font-weight: 600 !important;
          cursor: pointer !important;
          margin: 0 !important;
        }
        #rr-extension-gesture-banner .rr-btn:hover {
          background: #f0f0f0 !important;
        }
        #rr-extension-gesture-banner .rr-close {
          all: initial !important;
          position: absolute !important;
          top: 8px !important;
          right: 8px !important;
          width: 24px !important;
          height: 24px !important;
          background: transparent !important;
          border: none !important;
          cursor: pointer !important;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
          font-size: 18px !important;
          color: rgba(255,255,255,0.6) !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          padding: 0 !important;
          margin: 0 !important;
          line-height: 1 !important;
        }
        #rr-extension-gesture-banner .rr-close:hover {
          color: #ffffff !important;
        }
      `;
      document.head.appendChild(styleEl);

      const banner = document.createElement('div');
      banner.id = 'rr-extension-gesture-banner';
      banner.style.position = 'relative';
      banner.innerHTML = `
        <button type="button" class="rr-close" title="Close">×</button>
        <div class="rr-title">Open Reverse Recruiting Extension</div>
        <div class="rr-message">${bannerMessage}</div>
        <button type="button" class="rr-btn">Got it</button>
      `;

      // Close button dismisses and clears storage
      banner.querySelector('.rr-close').addEventListener('click', () => {
        clearGesturePrompt(true);
      });

      // "Got it" button dismisses and clears storage
      banner.querySelector('.rr-btn').addEventListener('click', () => {
        clearGesturePrompt(true);
      });

      document.documentElement.appendChild(banner);
      gestureBannerElement = banner;
      gestureBannerElement._styleEl = styleEl;
    } catch (error) {
      console.warn('[Content] Failed to show gesture banner:', error);
    }
  }

  function hideExtensionGestureBanner() {
    try {
      if (gestureBannerElement) {
        if (gestureBannerElement._styleEl) {
          gestureBannerElement._styleEl.remove();
        }
        gestureBannerElement.remove();
        gestureBannerElement = null;
      }
      // Also remove any orphaned style elements
      const orphanedStyle = document.getElementById(
        'rr-extension-gesture-banner-styles'
      );
      if (orphanedStyle) orphanedStyle.remove();
    } catch (_) {}
  }

  async function persistGesturePrompt(context) {
    try {
      if (!context) {
        await chrome.storage.local.remove(GESTURE_PROMPT_KEY);
        return;
      }
      await chrome.storage.local.set({
        [GESTURE_PROMPT_KEY]: {
          ...context,
          createdAt: Date.now(),
          pending: true,
        },
      });
    } catch (error) {
      console.warn('[Content] Failed to persist gesture prompt:', error);
    }
  }

  async function loadGesturePrompt() {
    try {
      const stored = await chrome.storage.local.get(GESTURE_PROMPT_KEY);
      return stored?.[GESTURE_PROMPT_KEY] || null;
    } catch (_) {
      return null;
    }
  }

  async function clearGesturePrompt(removeBanner = true) {
    try {
      await chrome.storage.local.remove(GESTURE_PROMPT_KEY);
    } catch (_) {}
    if (removeBanner) hideExtensionGestureBanner();
  }

  async function maybeShowQueuedGesturePrompt() {
    const prompt = await loadGesturePrompt();
    if (!prompt?.pending) return;

    // Check if prompt has expired (5 minutes max)
    const EXPIRY_MS = 5 * 60 * 1000; // 5 minutes
    const age = Date.now() - (prompt.createdAt || 0);
    if (age > EXPIRY_MS) {
      console.log('[Content] Gesture prompt expired, clearing');
      await clearGesturePrompt();
      return;
    }

    // Only show banner on the target job URL (or similar job board URLs)
    const currentUrl = window.location.href.toLowerCase();
    const targetUrl = (prompt.externalJobUrl || '').toLowerCase();

    // Check if we're on a job board site
    const isJobBoard =
      /greenhouse|lever|ashby|workday|bamboohr|icims|linkedin.*jobs|indeed|glassdoor|myworkdayjobs/i.test(
        currentUrl
      );

    // Check if we're on the specific target URL (same domain at minimum)
    let isTargetUrl = false;
    if (targetUrl) {
      try {
        const targetDomain = new URL(targetUrl).hostname;
        const currentDomain = window.location.hostname;
        isTargetUrl =
          currentDomain === targetDomain ||
          currentDomain.endsWith('.' + targetDomain);
      } catch (_) {}
    }

    // Only show banner if we're on a job board OR the specific target URL
    if (!isJobBoard && !isTargetUrl) {
      console.log('[Content] Not on job board or target URL, skipping banner');
      return;
    }

    const label =
      prompt.jobTitle ||
      prompt.metadata?.jobTitle ||
      prompt.jobId ||
      'this job';
    showExtensionGestureBanner(
      `Get AI-assisted resumes & cover letters for ${label}. Click the Reverse Recruiting extension.`
    );

    // Mark as shown so it doesn't keep appearing on every page
    // Clear after showing once on a valid job page
    await clearGesturePrompt(false); // Don't remove banner yet, user needs to click
  }
  function isHidden(el) {
    try {
      const style =
        el.ownerDocument && el.ownerDocument.defaultView
          ? el.ownerDocument.defaultView.getComputedStyle(el)
          : window.getComputedStyle(el);
      return (
        el.type === 'hidden' ||
        style.display === 'none' ||
        style.visibility === 'hidden'
      );
    } catch (_) {
      return false;
    }
  }

  function isCaptchaLike(el) {
    const txt = (el.outerHTML || '').toLowerCase();
    const name = (
      el.getAttribute &&
      (el.getAttribute('name') || '')
    ).toLowerCase();
    const id = (el.getAttribute && (el.getAttribute('id') || '')).toLowerCase();
    const role = (
      el.getAttribute &&
      (el.getAttribute('role') || '')
    ).toLowerCase();
    return (
      txt.includes('recaptcha') ||
      txt.includes('captcha') ||
      name.includes('recaptcha') ||
      id.includes('recaptcha') ||
      role.includes('captcha')
    );
  }

  function getLabelText(input) {
    try {
      if (!input) return '';
      if ((input.tagName || '').toLowerCase() === 'label') {
        return (input.innerText || input.textContent || '').trim();
      }
      const id = input.getAttribute && input.getAttribute('id');
      if (id) {
        const label = (input.getRootNode() || document).querySelector(
          `label[for="${CSS.escape(id)}"]`
        );
        if (label) return (label.innerText || label.textContent || '').trim();
      }
      const aria =
        (input.getAttribute && input.getAttribute('aria-label')) || '';
      if (aria) return aria.trim();
      const placeholder =
        (input.getAttribute && input.getAttribute('placeholder')) || '';
      if (placeholder) return placeholder.trim();
      const parentLabel = input.closest && input.closest('label');
      if (parentLabel)
        return (parentLabel.innerText || parentLabel.textContent || '').trim();
      const legend =
        input.closest && input.closest('fieldset')?.querySelector('legend');
      if (legend) return (legend.innerText || legend.textContent || '').trim();
      return '';
    } catch (_) {
      return '';
    }
  }

  function resolveLabelForElement(root, el) {
    try {
      if (!el) return '';

      // UNIVERSAL LABEL RESOLUTION - Works with ALL frameworks
      let label = '';

      // 1) Direct label mechanisms (standard HTML)
      label = getLabelText(el);

      // 2) aria-label (most accessible, used by modern frameworks)
      if (!label && el.getAttribute) {
        label = el.getAttribute('aria-label') || '';
      }

      // 3) aria-labelledby (references another element)
      if (!label) {
        const ariaIds =
          (el.getAttribute && el.getAttribute('aria-labelledby')) ||
          (el.closest &&
            el.closest('[aria-labelledby]')?.getAttribute('aria-labelledby')) ||
          '';
        if (ariaIds) {
          const ids = ariaIds.split(/\s+/);
          for (const id of ids) {
            const src = root.getElementById
              ? root.getElementById(id)
              : document.getElementById(id);
            if (src) {
              label = (src.innerText || src.textContent || '').trim();
              if (label) break;
            }
          }
        }
      }

      // 4) placeholder (common in modern forms)
      if (!label && el.getAttribute) {
        label = el.getAttribute('placeholder') || '';
      }

      // 5) title attribute
      if (!label && el.getAttribute) {
        label = el.getAttribute('title') || '';
      }

      // 6) data-* attributes (React, Vue, Angular often use these)
      if (!label && el.getAttribute) {
        label =
          el.getAttribute('data-label') ||
          el.getAttribute('data-field-label') ||
          el.getAttribute('data-question') ||
          el.getAttribute('data-name') ||
          el.getAttribute('data-testid') || // React Testing Library
          '';
      }

      // 7) Group/fieldset/role container headings (radio groups, checkboxes)
      if (!label && el.closest) {
        const group = el.closest(
          '[role="group"], [role="radiogroup"], fieldset, [data-field], [data-question], ' +
            '.field, .form-field, .question, .form-group, .input-group, ' +
            '[class*="field"], [class*="question"], [class*="form-item"], ' +
            '[class*="input-wrapper"], [class*="control"]'
        );
        if (group) {
          // Try multiple heading sources
          const legend = group.querySelector('legend');
          const heading = group.querySelector('h1,h2,h3,h4,h5,h6');
          const lab = group.querySelector('label:not([for])'); // Label without 'for' is likely group label
          const span = group.querySelector(
            '[class*="label"], [class*="heading"], [class*="title"]'
          );

          const headerText =
            (legend && (legend.innerText || legend.textContent)) ||
            (heading && (heading.innerText || heading.textContent)) ||
            (lab && (lab.innerText || lab.textContent)) ||
            (span && (span.innerText || span.textContent)) ||
            '';
          label = (headerText || '').trim();

          // Check previous sibling (common pattern in many frameworks)
          if (!label && group.previousElementSibling) {
            const sib = group.previousElementSibling;
            label = (sib.innerText || sib.textContent || '').trim();
          }
        }
      }

      // 8) Parent container text (last resort - look for text above the input)
      if (!label && el.parentElement) {
        const parent = el.parentElement;
        // Get all text nodes before the input
        const walker = document.createTreeWalker(parent, NodeFilter.SHOW_TEXT, {
          acceptNode: (node) => {
            // Only accept text nodes that come before our element
            return node.parentElement &&
              parent.contains(node.parentElement) &&
              node.textContent.trim().length > 0
              ? NodeFilter.FILTER_ACCEPT
              : NodeFilter.FILTER_SKIP;
          },
        });

        let textNodes = [];
        let node;
        while ((node = walker.nextNode())) {
          if (node.parentElement && !node.parentElement.contains(el)) {
            textNodes.push(node.textContent.trim());
          }
        }

        if (textNodes.length > 0) {
          label = textNodes.join(' ').trim();
        }
      }

      // 9) Clean up the label
      if (label) {
        // Remove common suffixes
        label = label.replace(/[*:]+\s*$/, '').trim();
        // Limit length to avoid capturing too much text
        if (label.length > 200) {
          label = label.substring(0, 200) + '...';
        }
      }

      return (label || '').trim();
    } catch (_) {
      return '';
    }
  }

  function* enumerateRoots(root) {
    yield root;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let node;
    while ((node = walker.nextNode())) {
      const el = node;
      if (el && el.shadowRoot) {
        yield el.shadowRoot;
      }
    }
    const iframes = root.querySelectorAll
      ? root.querySelectorAll('iframe')
      : [];
    for (const iframe of iframes) {
      try {
        const doc = iframe.contentDocument;
        if (doc) yield doc;
      } catch (_) {}
    }
  }

  function collectFields() {
    const lines = [];
    for (const root of enumerateRoots(document)) {
      const forms = Array.from(
        root.querySelectorAll ? root.querySelectorAll('form') : []
      );
      const collectFrom = (scope) => {
        // First, identify all radio button names so we can skip individual radios
        const radioGroupNames = new Set();
        const allRadios = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll('input[type="radio"]')
            : []
        );
        for (const radio of allRadios) {
          const name = radio.getAttribute('name');
          if (name) radioGroupNames.add(name);
        }

        // Collect all input types including date, number, etc.
        const inputs = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll('input, textarea, select')
            : []
        );
        for (const el of inputs) {
          if (isHidden(el) || isCaptchaLike(el)) continue;
          const type = (
            el.getAttribute('type') || el.tagName.toLowerCase()
          ).toLowerCase();

          // SKIP individual radio buttons - they'll be collected as radio-groups later
          if (type === 'radio') {
            continue;
          }

          const name = el.getAttribute('name') || '';
          const id = el.getAttribute('id') || '';
          const label = resolveLabelForElement(scope, el);
          const placeholder = el.getAttribute('placeholder') || '';
          const required = el.hasAttribute('required') ? 'required' : '';
          const min = el.getAttribute('min') || '';
          const max = el.getAttribute('max') || '';
          const pattern = el.getAttribute('pattern') || '';
          const currentValue = el.value || '';

          // Build detailed field info based on type
          let fieldInfo = `FIELD: type=${type} name=${name} id=${id} label=${label}`;

          // Add extra info for specific field types
          if (
            type === 'date' ||
            type === 'datetime-local' ||
            type === 'time' ||
            type === 'month' ||
            type === 'week'
          ) {
            fieldInfo += ` format=${type}`;
            if (min) fieldInfo += ` min=${min}`;
            if (max) fieldInfo += ` max=${max}`;
          }
          if (type === 'number' || type === 'range') {
            if (min) fieldInfo += ` min=${min}`;
            if (max) fieldInfo += ` max=${max}`;
            const step = el.getAttribute('step') || '';
            if (step) fieldInfo += ` step=${step}`;
          }
          if (placeholder) fieldInfo += ` placeholder=${placeholder}`;
          if (required) fieldInfo += ` ${required}`;
          if (currentValue && type !== 'hidden')
            fieldInfo += ` current=${currentValue}`;

          lines.push(fieldInfo);

          // For select elements, list all options
          if (el.tagName.toLowerCase() === 'select') {
            const opts = Array.from(el.querySelectorAll('option'))
              .map((o) => {
                const val = o.value || '';
                const txt = o.innerText.trim();
                return val && val !== txt ? `${txt} (value=${val})` : txt;
              })
              .filter(Boolean)
              .slice(0, 50);
            if (opts.length) lines.push(`  OPTIONS: ${opts.join(' | ')}`);
          }
        }

        // Checkbox groups (multiple checkboxes with same name or in same container)
        const checkboxGroups = new Map();
        const checkboxes = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll('input[type="checkbox"]')
            : []
        );
        for (const cb of checkboxes) {
          if (isHidden(cb)) continue;
          const name = cb.getAttribute('name') || '';
          const containerLabel = resolveLabelForElement(
            scope,
            cb.closest('fieldset, div, li') || cb
          );
          const key = name || containerLabel || cb.getAttribute('id') || '';
          if (!checkboxGroups.has(key)) {
            checkboxGroups.set(key, []);
          }
          checkboxGroups.get(key).push({
            label: getLabelText(cb) || cb.value || '',
            value: cb.value || '',
            checked: cb.checked,
          });
        }
        // Output checkbox groups with multiple options
        for (const [groupKey, items] of checkboxGroups) {
          if (items.length > 1) {
            const opts = items.map((i) => i.label).filter(Boolean);
            const checked = items.filter((i) => i.checked).map((i) => i.label);
            lines.push(
              `FIELD: type=checkbox-group name=${groupKey} label=${groupKey}`
            );
            if (opts.length) lines.push(`  OPTIONS: ${opts.join(' | ')}`);
            if (checked.length)
              lines.push(`  SELECTED: ${checked.join(' | ')}`);
          }
        }

        // ARIA/Workday style selects
        const comboCandidates = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                'button[aria-haspopup="listbox"], [role="combobox"], [aria-haspopup="menu"]'
              )
            : []
        );
        for (const el of comboCandidates) {
          if (isHidden(el) || isCaptchaLike(el)) continue;
          const type =
            el.getAttribute('role') === 'combobox'
              ? 'combobox'
              : el.getAttribute('aria-haspopup') === 'menu'
              ? 'dropdown-menu'
              : 'button-listbox';
          const name = el.getAttribute('name') || '';
          const id = el.getAttribute('id') || '';
          const label = resolveLabelForElement(scope, el);
          const current = (el.innerText || el.textContent || '').trim();
          const ariaExpanded = el.getAttribute('aria-expanded') || '';
          lines.push(
            `FIELD: type=${type} name=${name} id=${id} label=${label} current=${current}`
          );
        }

        // ARIA listboxes present in DOM
        const listboxes = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll('[role="listbox"]')
            : []
        );
        for (const lb of listboxes) {
          if (isHidden(lb) || isCaptchaLike(lb)) continue;
          const id = lb.getAttribute('id') || '';
          const label = resolveLabelForElement(scope, lb);
          const options = Array.from(
            lb.querySelectorAll('[role="option"], li, [data-value], option')
          )
            .map((o) =>
              (
                o.innerText ||
                o.textContent ||
                o.getAttribute('data-value') ||
                ''
              ).trim()
            )
            .filter(Boolean)
            .slice(0, 100);
          lines.push(`FIELD: type=listbox id=${id} label=${label}`);
          if (options.length) lines.push(`  OPTIONS: ${options.join(' | ')}`);
        }

        // Radio groups summarized by container
        const fieldsets = Array.from(
          scope.querySelectorAll ? scope.querySelectorAll('fieldset') : []
        );
        for (const fs of fieldsets) {
          const radios = Array.from(fs.querySelectorAll('input[type="radio"]'));
          if (!radios.length) continue;
          if (isHidden(fs)) continue;
          // Prefer legend/heading/label in group
          let label = resolveLabelForElement(scope, fs);
          if (!label) label = resolveLabelForElement(scope, radios[0]);
          const name = radios[0]?.getAttribute('name') || '';
          const opts = radios
            .map((r) => {
              const lbl = getLabelText(r) || r.value || '';
              const val = r.value || '';
              return lbl && val && lbl !== val ? `${lbl} (value=${val})` : lbl;
            })
            .filter(Boolean)
            .slice(0, 50);
          const selected = radios.find((r) => r.checked);
          const selectedLabel = selected
            ? getLabelText(selected) || selected.value || ''
            : '';
          lines.push(
            `FIELD: type=radio-group name=${name} label=${label}${
              selectedLabel ? ` selected=${selectedLabel}` : ''
            }`
          );
          if (opts.length) lines.push(`  OPTIONS: ${opts.join(' | ')}`);
        }

        // Also capture standalone radio groups not in fieldsets
        const radiosOutsideFieldsets = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll('input[type="radio"]:not(fieldset input)')
            : []
        );
        const radioGroupsByName = new Map();
        for (const r of radiosOutsideFieldsets) {
          if (isHidden(r)) continue;
          const name = r.getAttribute('name') || '';
          if (!name) continue;
          if (!radioGroupsByName.has(name)) {
            radioGroupsByName.set(name, []);
          }
          radioGroupsByName.get(name).push(r);
        }
        for (const [name, radios] of radioGroupsByName) {
          if (radios.length < 2) continue;

          // Try to find a better label by looking at the question text
          let label = '';

          // 1. Try to find a heading/label before the first radio
          const firstRadio = radios[0];
          const container = firstRadio.closest(
            '[class*="field"], [class*="question"], [data-field], .form-group, div'
          );
          if (container) {
            // Look for heading, label, or legend
            const heading = container.querySelector(
              'h1, h2, h3, h4, h5, h6, legend, [class*="question"], [class*="label"], [class*="heading"]'
            );
            if (heading && !heading.contains(firstRadio)) {
              label = (heading.textContent || '').trim();
            }

            // If no heading, look for a label element that's not for a specific radio
            if (!label) {
              const labels = Array.from(container.querySelectorAll('label'));
              for (const lbl of labels) {
                const forAttr = lbl.getAttribute('for');
                // If label doesn't have 'for' or doesn't point to a radio, it might be the group label
                if (!forAttr || !radios.some((r) => r.id === forAttr)) {
                  const txt = (lbl.textContent || '').trim();
                  if (txt && txt.length > 5) {
                    label = txt;
                    break;
                  }
                }
              }
            }
          }

          // 2. Fallback to resolveLabel
          if (!label) {
            label = resolveLabelForElement(scope, firstRadio);
          }

          // 3. Last resort: use first option as hint
          if (!label || label === 'Application' || label.length < 3) {
            const firstOpt = getLabelText(radios[0]) || '';
            if (firstOpt) {
              // Infer question from options (e.g., "Male" -> "Gender")
              label = `Radio Group (${firstOpt})`;
            } else {
              label = name;
            }
          }

          const opts = radios
            .map((r) => getLabelText(r) || r.value || '')
            .filter(Boolean);
          const selected = radios.find((r) => r.checked);
          const selectedLabel = selected
            ? getLabelText(selected) || selected.value || ''
            : '';

          // Use the technical 'name' for matching, but include human-readable label in a comment
          // Format: FIELD: type=radio-group name=UUID label=UUID
          //         QUESTION: Human readable question text
          lines.push(
            `FIELD: type=radio-group name=${name} label=${name}${
              selectedLabel ? ` selected=${selectedLabel}` : ''
            }`
          );
          // If we found a better human-readable label, include it as a hint
          if (
            label &&
            label !== name &&
            label !== 'Application' &&
            label.length > 3
          ) {
            lines.push(`  QUESTION: ${label}`);
          }
          if (opts.length) lines.push(`  OPTIONS: ${opts.join(' | ')}`);
        }

        // Custom UI components (React Select, MUI, etc.)
        const customSelects = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[class*="select"], [class*="Select"], [class*="dropdown"], [class*="Dropdown"], ' +
                  '[data-testid*="select"], [data-testid*="dropdown"]'
              )
            : []
        );
        for (const el of customSelects) {
          if (isHidden(el)) continue;
          // Skip if already captured as a native element
          if (el.tagName.toLowerCase() === 'select') continue;
          const hasInput = el.querySelector('input');
          if (!hasInput && !el.getAttribute('role')) continue;

          const id = el.getAttribute('id') || '';
          const label = resolveLabelForElement(scope, el);
          const current = (
            el.querySelector('[class*="value"], [class*="placeholder"]')
              ?.textContent || ''
          ).trim();
          if (label || current) {
            lines.push(
              `FIELD: type=custom-select id=${id} label=${label} current=${current}`
            );
          }
        }

        // Date picker components (React DatePicker, MUI DatePicker, etc.)
        const datePickers = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[class*="datepicker"], [class*="DatePicker"], [class*="date-picker"], ' +
                  '[data-testid*="date"], input[placeholder*="date" i], input[placeholder*="mm/dd" i], ' +
                  'input[placeholder*="yyyy" i], input[placeholder*="dd/mm" i]'
              )
            : []
        );
        for (const el of datePickers) {
          if (isHidden(el)) continue;
          const tag = el.tagName.toLowerCase();
          if (tag === 'input' && el.type !== 'date') {
            const label = resolveLabelForElement(scope, el);
            const placeholder = el.getAttribute('placeholder') || '';
            lines.push(
              `FIELD: type=date-picker label=${label} placeholder=${placeholder}`
            );
          }
        }

        // ARIA textbox roles (contenteditable divs, rich text editors)
        const ariaTextboxes = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[role="textbox"], [contenteditable="true"]'
              )
            : []
        );
        for (const el of ariaTextboxes) {
          if (isHidden(el)) continue;
          const label = resolveLabelForElement(scope, el);
          const id = el.getAttribute('id') || '';
          const current = (el.textContent || '').trim().slice(0, 100);
          lines.push(
            `FIELD: type=rich-text id=${id} label=${label} current=${current}`
          );
        }

        // LinkedIn-specific fields (data-test-* attributes)
        const linkedinFields = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[data-test-text-entity-list-form-component], ' +
                  '[data-test-single-typeahead-entity], ' +
                  '[data-test-text-selectable-option], ' +
                  '[data-test-form-element], ' +
                  '[data-test-text-input], ' +
                  '[data-test-date-input]'
              )
            : []
        );
        for (const el of linkedinFields) {
          if (isHidden(el)) continue;
          const input = el.querySelector('input, textarea, [contenteditable]');
          if (!input) continue;
          const label =
            resolveLabelForElement(scope, el) ||
            resolveLabelForElement(scope, input);
          const id =
            input.getAttribute('id') ||
            el.getAttribute('data-test-form-element') ||
            '';
          const type = input.getAttribute('type') || 'text';
          lines.push(
            `FIELD: type=${type} id=${id} label=${label} framework=linkedin`
          );
        }

        // Google Forms fields (data-params, freebirdFormviewerComponentsQuestion*)
        const googleFormFields = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[data-params*="question"], ' +
                  '[class*="freebirdFormviewerComponentsQuestion"], ' +
                  '[jsname], ' +
                  '[data-item-id]'
              )
            : []
        );
        for (const el of googleFormFields) {
          if (isHidden(el)) continue;
          const input = el.querySelector('input, textarea, select');
          if (!input) continue;
          const label =
            resolveLabelForElement(scope, el) ||
            resolveLabelForElement(scope, input);
          const id =
            input.getAttribute('id') || el.getAttribute('data-item-id') || '';
          const type =
            input.getAttribute('type') || input.tagName.toLowerCase();
          lines.push(
            `FIELD: type=${type} id=${id} label=${label} framework=google-forms`
          );
        }

        // WordPress/Gravity Forms fields
        const wordpressFields = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '.gfield, .wpforms-field, .wpcf7-form-control-wrap, ' +
                  '[class*="gravity"], [class*="wpform"]'
              )
            : []
        );
        for (const el of wordpressFields) {
          if (isHidden(el)) continue;
          const input = el.querySelector('input, textarea, select');
          if (!input) continue;
          const label =
            resolveLabelForElement(scope, el) ||
            resolveLabelForElement(scope, input);
          const id =
            input.getAttribute('id') || input.getAttribute('name') || '';
          const type =
            input.getAttribute('type') || input.tagName.toLowerCase();
          lines.push(
            `FIELD: type=${type} id=${id} label=${label} framework=wordpress`
          );
        }

        // Material-UI / MUI fields
        const muiFields = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '.MuiTextField-root, .MuiSelect-root, .MuiAutocomplete-root, ' +
                  '[class*="MuiInput"], [class*="MuiFormControl"]'
              )
            : []
        );
        for (const el of muiFields) {
          if (isHidden(el)) continue;
          const input = el.querySelector(
            'input, textarea, select, [role="combobox"]'
          );
          if (!input) continue;
          const label =
            resolveLabelForElement(scope, el) ||
            resolveLabelForElement(scope, input);
          const id =
            input.getAttribute('id') || input.getAttribute('name') || '';
          const type = input.getAttribute('type') || 'text';
          lines.push(
            `FIELD: type=${type} id=${id} label=${label} framework=mui`
          );
        }

        // Ant Design fields
        const antdFields = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '.ant-input, .ant-select, .ant-picker, .ant-form-item, ' +
                  '[class*="ant-input"], [class*="ant-select"]'
              )
            : []
        );
        for (const el of antdFields) {
          if (isHidden(el)) continue;
          const input = el.querySelector('input, textarea, select') || el;
          if (
            input.tagName &&
            !['INPUT', 'TEXTAREA', 'SELECT'].includes(input.tagName)
          )
            continue;
          const label = resolveLabelForElement(
            scope,
            el.closest('.ant-form-item') || el
          );
          const id =
            input.getAttribute('id') || input.getAttribute('name') || '';
          const type =
            input.getAttribute('type') || input.tagName.toLowerCase();
          lines.push(
            `FIELD: type=${type} id=${id} label=${label} framework=antd`
          );
        }

        // Chakra UI fields
        const chakraFields = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[class*="chakra-input"], [class*="chakra-select"], ' +
                  '[class*="chakra-textarea"], .chakra-form-control'
              )
            : []
        );
        for (const el of chakraFields) {
          if (isHidden(el)) continue;
          const input = el.querySelector('input, textarea, select') || el;
          if (
            input.tagName &&
            !['INPUT', 'TEXTAREA', 'SELECT'].includes(input.tagName)
          )
            continue;
          const label = resolveLabelForElement(
            scope,
            el.closest('.chakra-form-control') || el
          );
          const id =
            input.getAttribute('id') || input.getAttribute('name') || '';
          const type =
            input.getAttribute('type') || input.tagName.toLowerCase();
          lines.push(
            `FIELD: type=${type} id=${id} label=${label} framework=chakra`
          );
        }

        // Toggle/Switch components
        const toggles = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[role="switch"], [class*="toggle"], [class*="Toggle"], [class*="switch"], [class*="Switch"]'
              )
            : []
        );
        for (const el of toggles) {
          if (isHidden(el)) continue;
          const label = resolveLabelForElement(scope, el);
          const id = el.getAttribute('id') || '';
          const checked =
            el.getAttribute('aria-checked') ||
            (el.querySelector('input[type="checkbox"]')?.checked
              ? 'true'
              : 'false');
          lines.push(
            `FIELD: type=toggle id=${id} label=${label} checked=${checked}`
          );
        }

        // Slider/Range components
        const sliders = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[role="slider"], [class*="slider"], [class*="Slider"], [class*="range"], [class*="Range"]'
              )
            : []
        );
        for (const el of sliders) {
          if (isHidden(el)) continue;
          const label = resolveLabelForElement(scope, el);
          const id = el.getAttribute('id') || '';
          const min =
            el.getAttribute('aria-valuemin') || el.getAttribute('min') || '0';
          const max =
            el.getAttribute('aria-valuemax') || el.getAttribute('max') || '100';
          const current = el.getAttribute('aria-valuenow') || '';
          lines.push(
            `FIELD: type=slider id=${id} label=${label} min=${min} max=${max} current=${current}`
          );
        }

        // Spinbutton/Counter components
        const spinbuttons = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[role="spinbutton"], [class*="counter"], [class*="Counter"], [class*="stepper"], [class*="Stepper"]'
              )
            : []
        );
        for (const el of spinbuttons) {
          if (isHidden(el)) continue;
          const label = resolveLabelForElement(scope, el);
          const id = el.getAttribute('id') || '';
          const min = el.getAttribute('aria-valuemin') || '';
          const max = el.getAttribute('aria-valuemax') || '';
          const current = el.getAttribute('aria-valuenow') || '';
          lines.push(
            `FIELD: type=spinbutton id=${id} label=${label} min=${min} max=${max} current=${current}`
          );
        }

        // Autocomplete/Typeahead components
        const autocompletes = Array.from(
          scope.querySelectorAll
            ? scope.querySelectorAll(
                '[class*="autocomplete"], [class*="Autocomplete"], [class*="typeahead"], [class*="Typeahead"]'
              )
            : []
        );
        for (const el of autocompletes) {
          if (isHidden(el)) continue;
          const label = resolveLabelForElement(scope, el);
          const id = el.getAttribute('id') || '';
          const input = el.querySelector('input');
          const current = input ? input.value : '';
          lines.push(
            `FIELD: type=autocomplete id=${id} label=${label} current=${current}`
          );
        }
      };
      if (forms.length === 0) {
        collectFrom(root);
        continue;
      }
      forms.forEach((form, idx) => {
        const formId = form.getAttribute('id') || `form_${idx + 1}`;
        const formAction = form.getAttribute('action') || '';
        const formMethod = (form.getAttribute('method') || 'GET').toUpperCase();
        lines.push(
          `FORM: id=${formId} method=${formMethod} action=${formAction}`
        );
        collectFrom(form);
      });
    }
    return lines.join('\n');
  }

  function getVisibleMainText() {
    const root = document.querySelector('main, article') || document.body;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => {
        const text = node.nodeValue || '';
        if (!text.trim()) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        const style = window.getComputedStyle(parent);
        if (
          style &&
          (style.visibility === 'hidden' || style.display === 'none')
        )
          return NodeFilter.FILTER_REJECT;
        const tag = parent.tagName.toLowerCase();
        if (/^(script|style|noscript|svg|canvas)$/.test(tag))
          return NodeFilter.FILTER_REJECT;
        if (parent.closest('[class*="recaptcha" i], [id*="recaptcha" i]'))
          return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    const chunks = [];
    let node;
    while ((node = walker.nextNode())) {
      const t = (node.nodeValue || '').replace(/\s+/g, ' ').trim();
      if (t) chunks.push(t);
      if (chunks.length > 5000) break;
    }
    return chunks.join(' ').slice(0, 50000);
  }

  function getFullHTML() {
    try {
      return '<!DOCTYPE html>\n' + document.documentElement.outerHTML;
    } catch (_) {
      return document.body ? document.body.outerHTML : '';
    }
  }

  function normalize(str) {
    return (str || '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .replace(/[^a-z0-9 ]+/g, '')
      .trim();
  }

  function scoreMatch(fieldName, el) {
    const target = normalize(fieldName);
    const candidates = [];
    candidates.push(getLabelText(el));
    candidates.push(el.getAttribute && (el.getAttribute('name') || ''));
    candidates.push(el.getAttribute && (el.getAttribute('id') || ''));
    candidates.push(el.getAttribute && (el.getAttribute('placeholder') || ''));
    candidates.push(el.getAttribute && (el.getAttribute('aria-label') || ''));
    candidates.push(
      el.getAttribute && (el.getAttribute('aria-labelledby') || '')
    );

    try {
      const tag = (el.tagName || '').toLowerCase();
      if (tag === 'label' || tag === 'fieldset') {
        candidates.push(el.textContent || '');
      }
    } catch (_) {}

    // For React Select containers, also check the input inside
    try {
      if (el.querySelector) {
        const innerInput = el.querySelector(
          'input[role="combobox"], input.select__input, input[id]'
        );
        if (innerInput) {
          candidates.push(innerInput.getAttribute('id') || '');
          candidates.push(innerInput.getAttribute('name') || '');
          candidates.push(innerInput.getAttribute('aria-label') || '');
          // Get label by aria-labelledby
          const labelledBy = innerInput.getAttribute('aria-labelledby');
          if (labelledBy) {
            const labelEl = document.getElementById(labelledBy);
            if (labelEl) candidates.push(labelEl.textContent || '');
          }
        }
        // Also check for associated label element
        const labelEl = el.querySelector('label');
        if (labelEl) candidates.push(labelEl.textContent || '');
      }
    } catch (_) {}

    const hay = normalize(candidates.filter(Boolean).join(' '));
    if (!target || !hay) return 0;
    let score = 0;
    if (hay.includes(target)) score += 3;
    const words = target.split(' ');
    let contained = 0;
    for (const w of words) if (w && hay.includes(w)) contained++;
    score += Math.min(2, contained);

    try {
      const typeAttr =
        (el.getAttribute && el.getAttribute('type')) || el.tagName || '';
      const t = String(typeAttr).toLowerCase();
      if (/(^| )email( |$)/.test(target) && t === 'email') score += 4;
      if (
        /(^| )(phone|mobile|tel)( |$)/.test(target) &&
        (t === 'tel' || t === 'phone')
      )
        score += 3;
      if (/(^| )linkedin( |$)/.test(target) && hay.includes('linkedin'))
        score += 1;
      if (/(^| )github( |$)/.test(target) && hay.includes('github')) score += 1;
    } catch (_) {}

    return score;
  }

  function synonyms(s) {
    const v = normalize(s);
    if (['yes', 'y', 'true', '1'].includes(v)) return 'yes';
    if (['no', 'n', 'false', '0'].includes(v)) return 'no';
    if (['united states', 'usa', 'us', 'u s a', 'u s'].includes(v))
      return 'united states';
    if (['full time', 'fulltime', 'full-time'].includes(v)) return 'full time';
    if (
      [
        'part time',
        'part-time',
        'parttime',
        'part time summer job',
        'part-time summer job',
      ].includes(v)
    )
      return 'part time';
    if (
      [
        'fluent',
        'native',
        'fluent native',
        'fluentnative',
        'fluent/native',
      ].includes(v)
    )
      return 'fluent native';
    if (['intermediate', 'mid', 'medium'].includes(v)) return 'intermediate';
    if (['beginner', 'junior', 'basic'].includes(v)) return 'beginner';
    return v;
  }

  // Convert ambiguous EEO values like "Not specified" to valid dropdown options
  function resolveEEOValue(fieldName, value) {
    const name = normalize(fieldName || '');
    const val = normalize(value || '');

    // If value is already specific, return as-is
    const ambiguous = [
      'not specified',
      'n a',
      'na',
      'none',
      'unspecified',
      'unknown',
      'not applicable',
      'prefer not to say',
      'decline',
    ];
    if (!ambiguous.some((a) => val.includes(a) || val === a)) {
      return value;
    }

    // Map ambiguous values to appropriate EEO responses based on field type
    if (name.includes('hispanic') || name.includes('latino')) {
      return 'No';
    }
    if (name.includes('veteran')) {
      return 'I am not a protected veteran';
    }
    if (name.includes('disability')) {
      return 'I do not wish to answer';
    }
    if (name.includes('gender') || name.includes('sex')) {
      return 'Decline to self-identify';
    }
    if (name.includes('race') || name.includes('ethnicity')) {
      return 'Decline to self-identify';
    }
    if (name.includes('sponsorship') || name.includes('visa')) {
      return 'No';
    }
    if (name.includes('relocate') || name.includes('relocation')) {
      return 'Yes';
    }
    if (
      name.includes('acknowledge') ||
      name.includes('confirm') ||
      name.includes('agree')
    ) {
      return 'true';
    }

    // For other fields, try common fallbacks
    return value;
  }

  function setExactOrClosestSelect(selectEl, value) {
    const norm = (s) => synonyms(String(s || ''));
    const opts = Array.from(selectEl.querySelectorAll('option'));
    const vNorm = norm(value);
    const vLower = (value || '').toLowerCase().trim();

    console.log(
      `[Content] setExactOrClosestSelect: looking for "${value}" in ${opts.length} options`
    );

    // Score each option and pick the best match
    let bestOption = null;
    let bestScore = 0;

    for (const opt of opts) {
      const optText = (opt.textContent || '').trim();
      const optNorm = norm(optText);
      const optLower = optText.toLowerCase();
      const optValue = (opt.value || '').toLowerCase();

      let score = 0;

      // Exact normalized match (highest priority)
      if (optNorm === vNorm) {
        score = 100;
      }
      // Exact case-insensitive match
      else if (optLower === vLower) {
        score = 95;
      }
      // Option value matches
      else if (optValue === vLower) {
        score = 90;
      }
      // For short values like "Yes"/"No", require exact match or starts with
      else if (vLower.length <= 3) {
        if (optLower === vLower) {
          score = 100;
        } else if (
          optLower.startsWith(vLower + ',') ||
          optLower.startsWith(vLower + ' ')
        ) {
          // "No, I don't..." should match "No" but with lower score
          score = 60;
        }
      }
      // Option starts with search value (good match)
      else if (optLower.startsWith(vLower)) {
        score = 80;
      }
      // Search value starts with option (option is a prefix)
      else if (vLower.startsWith(optLower) && optLower.length >= 3) {
        score = 70;
      }
      // Option contains all significant words from search (for longer phrases)
      else if (vLower.length > 10) {
        const searchWords = vLower.split(/\s+/).filter((w) => w.length > 2);
        const matchingWords = searchWords.filter((w) => optLower.includes(w));
        if (matchingWords.length === searchWords.length) {
          score = 65;
        } else if (matchingWords.length >= searchWords.length * 0.7) {
          score = 50;
        }
      }
      // Contains with length ratio (penalize long options containing short search terms)
      else if (optLower.includes(vLower) && vLower.length >= 3) {
        const ratio = vLower.length / optLower.length;
        score = Math.floor(40 * ratio);
      }

      if (score > bestScore) {
        bestScore = score;
        bestOption = opt;
      }
    }

    // For yes/no questions, be very strict
    if (
      !bestOption ||
      (bestScore < 60 && (vNorm === 'yes' || vNorm === 'no'))
    ) {
      const exactMatch = opts.find((o) => norm(o.textContent) === vNorm);
      if (exactMatch) {
        bestOption = exactMatch;
        bestScore = 100;
      }
    }

    // EEO-specific fallback matching for common dropdown options
    if (!bestOption || bestScore < 50) {
      const eeoFallbacks = {
        // Veteran status
        'i am not a protected veteran': [
          'not a protected veteran',
          'i am not',
          'not a veteran',
        ],
        // Disability status
        'i do not wish to answer': [
          'do not wish',
          'prefer not',
          'decline',
          'i dont wish to answer',
        ],
        'no i dont have a disability': [
          'no i do not',
          'i do not have',
          'no disability',
        ],
        // Gender
        'decline to self identify': [
          'decline to selfidentify',
          'prefer not to say',
          'choose not to disclose',
        ],
        male: ['man', 'm'],
        female: ['woman', 'f'],
      };
      for (const [target, alts] of Object.entries(eeoFallbacks)) {
        if (vNorm === target || alts.includes(vNorm)) {
          // Try to find an option matching any of these
          for (const altVal of [target, ...alts]) {
            const found = opts.find((o) =>
              norm(o.textContent).includes(altVal)
            );
            if (found) {
              bestOption = found;
              break;
            }
          }
          if (bestOption) break;
        }
      }
    }

    // Last resort: if value contains key terms, find matching option
    if (!bestOption && vLower.length > 5) {
      const keyTerms = vLower.split(' ').filter((w) => w.length > 4);
      for (const term of keyTerms) {
        const found = opts.find((o) =>
          (o.textContent || '').toLowerCase().includes(term)
        );
        if (found) {
          bestOption = found;
          break;
        }
      }
    }

    if (bestOption) {
      console.log(
        `[Content] Selected option: "${bestOption.textContent?.trim()}" with score ${bestScore}`
      );
      selectEl.value = bestOption.value;
      selectEl.dispatchEvent(new Event('input', { bubbles: true }));
      selectEl.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }

    // FALLBACK: If no match found, select the first non-empty option as a last resort
    // This ensures we don't leave the field empty
    console.log(
      `[Content] No match found for "${value}", selecting first available option`
    );
    const firstValidOption = opts.find((o) => {
      const txt = (o.textContent || '').trim();
      const val = (o.value || '').trim();
      return (
        txt &&
        val &&
        !txt.toLowerCase().includes('select') &&
        !txt.toLowerCase().includes('choose')
      );
    });

    if (firstValidOption) {
      console.log(
        `[Content] Fallback: selecting first option "${firstValidOption.textContent?.trim()}"`
      );
      selectEl.value = firstValidOption.value;
      selectEl.dispatchEvent(new Event('input', { bubbles: true }));
      selectEl.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }

    return false;
  }

  // Specialized handler for React Select components (used by Greenhouse, Lever, etc.)
  async function setReactSelect(container, value) {
    try {
      const vNorm = normalize(value);
      const vLower = (value || '').toLowerCase().trim();

      console.log(
        `[Content] setReactSelect: trying to set "${value}" on container`,
        container
      );

      // Close any existing open dropdowns first
      const existingMenus = document.querySelectorAll(
        '[class*="select__menu"], [class*="menu-list"]'
      );
      if (existingMenus.length > 0) {
        document.dispatchEvent(
          new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })
        );
        await new Promise((r) => setTimeout(r, 100));
      }

      // Find the control element (the clickable part)
      const control =
        container.querySelector('[class*="select__control"]') ||
        container.querySelector('[class*="control"]') ||
        container;

      // Find the input inside
      const input = container.querySelector(
        'input[role="combobox"], input.select__input, input[class*="select__input"]'
      );

      // Get the ID that will be used for aria-controls when menu opens
      const inputId = input?.id || '';
      const expectedMenuId = inputId
        ? `react-select-${inputId.split('-').pop()}-listbox`
        : '';

      // Click on the control to open dropdown
      control.scrollIntoView({ block: 'center' });
      await new Promise((r) => setTimeout(r, 50));
      control.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      control.dispatchEvent(new MouseEvent('click', { bubbles: true }));

      if (input) {
        input.focus();
        // Trigger focus events to open dropdown
        input.dispatchEvent(new FocusEvent('focus', { bubbles: true }));
      }

      // Wait for dropdown menu to appear
      await new Promise((r) => setTimeout(r, 250));

      // Look for the menu - prioritize finding the menu associated with this specific input
      let menu = null;

      // 1. Try aria-controls/aria-owns first (most reliable)
      if (input) {
        const ariaOwns =
          input.getAttribute('aria-owns') ||
          input.getAttribute('aria-controls');
        if (ariaOwns) {
          menu = document.getElementById(ariaOwns);
          console.log(`[Content] Found menu via aria: ${ariaOwns}`, menu);
        }
      }

      // 2. Try finding menu in same container hierarchy
      if (!menu) {
        menu =
          container.querySelector('[class*="select__menu"]') ||
          container.querySelector('[class*="menu-list"]');
      }

      // 3. Look for menu that appeared near the container (within same parent structure)
      if (!menu) {
        // React Select often appends menu as sibling or in a portal
        const parent =
          container.closest(
            '[class*="select"], .field, .form-group, [data-field]'
          ) || container.parentElement;
        if (parent) {
          menu = parent.querySelector('[class*="select__menu"]');
        }
      }

      // 4. Fall back to finding any visible menu in the document
      if (!menu) {
        const allMenus = document.querySelectorAll(
          '[class*="select__menu"], [class*="menu-list"], [class*="MenuList"]'
        );
        for (const m of allMenus) {
          if (!isHidden(m)) {
            menu = m;
            break;
          }
        }
      }

      console.log(`[Content] Menu found:`, menu);

      // Try finding options in the menu
      let options = [];
      if (menu) {
        options = Array.from(
          menu.querySelectorAll(
            '[class*="select__option"], [class*="option"], [role="option"]'
          )
        ).filter((opt) => !isHidden(opt));
        console.log(`[Content] Found ${options.length} options in menu`);
      }

      // Only use document-wide search if menu-specific search failed
      if (!options.length) {
        const allOptions = document.querySelectorAll(
          '[class*="select__option"], [class*="option"]:not([class*="control"])'
        );
        options = Array.from(allOptions).filter((opt) => !isHidden(opt));
        console.log(
          `[Content] Fallback: Found ${options.length} options in document`
        );
      }

      // Log available options for debugging
      if (options.length > 0 && options.length <= 10) {
        console.log(
          `[Content] Available options:`,
          options.map((o) => o.textContent?.trim())
        );
      }

      // Helper to find best option with progressive matching
      function findBestOption(searchValue, optionsList) {
        const sNorm = normalize(searchValue);
        const sLower = (searchValue || '').toLowerCase().trim();

        let best = null;
        let bestScore = 0;

        for (const opt of optionsList) {
          if (isHidden(opt)) continue;
          const txt = normalize(opt.textContent || '');
          const txtLower = (opt.textContent || '').toLowerCase().trim();

          let score = 0;

          // Exact match (highest priority)
          if (txt === sNorm || txtLower === sLower) {
            score = 100;
          }
          // Option text equals search value (case insensitive word match)
          else if (txtLower === sLower) {
            score = 95;
          }
          // Search value is contained exactly at word boundary in option
          else if (
            new RegExp(
              '\\b' + sLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b',
              'i'
            ).test(txtLower)
          ) {
            score = 80;
          }
          // Option starts with search value
          else if (txtLower.startsWith(sLower)) {
            score = 70;
          }
          // Search starts with option (option is shorter but matches beginning)
          else if (sLower.startsWith(txtLower) && txtLower.length >= 3) {
            score = 60;
          }
          // Option contains search value (but penalize if option is much longer)
          else if (txtLower.includes(sLower)) {
            // Penalize long options that happen to contain short search terms
            const lengthRatio = sLower.length / txtLower.length;
            score = Math.floor(40 * lengthRatio);
          }

          if (score > bestScore) {
            bestScore = score;
            best = opt;
          }
        }

        return { best, score: bestScore };
      }

      // Progressive matching: try full value, then progressively shorter
      let bestMatch = null;
      let searchValue = vLower;

      // Try full value first
      let result = findBestOption(searchValue, options);
      if (result.score >= 60) {
        bestMatch = result.best;
      }

      // If no good match, try progressively shorter versions
      if (!bestMatch && searchValue.length > 3) {
        // Try by words first (e.g., "I am not a protected veteran" -> "not a protected veteran" -> "protected veteran")
        const words = searchValue.split(/\s+/);
        for (let i = 0; i < words.length - 1 && !bestMatch; i++) {
          const partial = words.slice(i).join(' ');
          if (partial.length < 3) break;
          result = findBestOption(partial, options);
          if (result.score >= 70) {
            bestMatch = result.best;
            console.log(
              `[Content] React Select matched "${partial}" with score ${result.score}`
            );
            break;
          }
        }

        // Try from the end (e.g., "protected veteran" -> "veteran")
        if (!bestMatch) {
          for (let i = words.length - 1; i >= 0 && !bestMatch; i--) {
            const partial = words.slice(i).join(' ');
            if (partial.length < 3) break;
            result = findBestOption(partial, options);
            if (result.score >= 70) {
              bestMatch = result.best;
              console.log(
                `[Content] React Select matched "${partial}" from end with score ${result.score}`
              );
              break;
            }
          }
        }

        // Try half length, then quarter, etc.
        if (!bestMatch) {
          let len = searchValue.length;
          while (len >= 3 && !bestMatch) {
            const partial = searchValue.substring(0, len);
            result = findBestOption(partial, options);
            if (result.score >= 70) {
              bestMatch = result.best;
              console.log(
                `[Content] React Select matched "${partial}" (${len} chars) with score ${result.score}`
              );
              break;
            }
            len = Math.floor(len / 2);
          }
        }
      }

      if (bestMatch) {
        console.log(
          `[Content] React Select: selecting "${bestMatch.textContent?.trim()}" for value "${value}"`
        );
        bestMatch.scrollIntoView({ block: 'center' });
        await new Promise((r) => setTimeout(r, 30));
        bestMatch.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        bestMatch.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        await new Promise((r) => setTimeout(r, 100));

        // Verify selection was made
        const selectedValue = container.querySelector(
          '[class*="single-value"], [class*="singleValue"]'
        );
        console.log(
          `[Content] After selection, displayed value: "${selectedValue?.textContent?.trim()}"`
        );

        return true;
      }

      // Fallback: if no option found, try typing and pressing Enter
      if (input && !bestMatch) {
        input.focus();
        // Clear and type the value
        const nativeSetter = Object.getOwnPropertyDescriptor(
          window.HTMLInputElement.prototype,
          'value'
        )?.set;
        if (nativeSetter) {
          nativeSetter.call(input, value);
        } else {
          input.value = value;
        }
        input.dispatchEvent(new Event('input', { bubbles: true }));
        await new Promise((r) => setTimeout(r, 150));

        // Check if options appeared after typing
        options = Array.from(
          document.querySelectorAll(
            '[class*="select__option"], [class*="option"]:not([class*="control"])'
          )
        );

        // Use progressive matching on filtered options too
        result = findBestOption(value, options);
        if (result.best && result.score >= 60) {
          result.best.scrollIntoView({ block: 'center' });
          result.best.dispatchEvent(
            new MouseEvent('mousedown', { bubbles: true })
          );
          result.best.dispatchEvent(new MouseEvent('click', { bubbles: true }));
          return true;
        }

        // Press Enter to select first filtered option
        input.dispatchEvent(
          new KeyboardEvent('keydown', {
            key: 'Enter',
            keyCode: 13,
            bubbles: true,
          })
        );
        await new Promise((r) => setTimeout(r, 50));

        // Check if selection was made
        const selectedValue = container.querySelector(
          '[class*="single-value"], [class*="singleValue"]'
        );
        if (selectedValue && selectedValue.textContent?.trim()) {
          return true;
        }

        // FINAL FALLBACK: Just type the value and leave it (for free-text React Selects)
        console.log(
          `[Content] No option matched, typing value directly: "${value}"`
        );
        // The value is already typed in the input from above, so we're done
        // Close the dropdown
        document.dispatchEvent(
          new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })
        );
        await new Promise((r) => setTimeout(r, 50));

        // Check if the typed value stuck
        if (input && input.value && input.value.trim()) {
          console.log(`[Content] Value typed successfully: "${input.value}"`);
          return true;
        }
      }

      // Close the dropdown if nothing was selected
      document.dispatchEvent(
        new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })
      );
    } catch (e) {
      console.warn('[Content] React Select error:', e);
    }
    return false;
  }

  async function setCombobox(container, value) {
    try {
      // Check if this is a React Select component
      const isReactSelect =
        container.querySelector('[class*="select__"]') ||
        container.classList?.toString().includes('select__') ||
        container.closest('[class*="select-shell"]');

      if (isReactSelect) {
        return await setReactSelect(
          container.closest(
            '[class*="select-shell"], [class*="select__container"], .select'
          ) || container,
          value
        );
      }

      const clickTarget =
        container.querySelector(
          'input, [contenteditable="true"], [role="textbox"]'
        ) || container;
      clickTarget.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      clickTarget.dispatchEvent(new MouseEvent('click', { bubbles: true }));
      const input = container.querySelector('input');
      if (input) {
        input.focus();
        input.value = value;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(
          new KeyboardEvent('keydown', { key: 'Enter', bubbles: true })
        );
      }
      await new Promise((r) => setTimeout(r, 150));
      const listboxId = container.getAttribute('aria-controls');
      let optionsRoot = listboxId
        ? document.getElementById(listboxId)
        : document;
      const options = Array.from(
        optionsRoot.querySelectorAll('[role="option"], li, [data-value]')
      );
      const vNorm = normalize(value);
      let best = null,
        bestScore = 0;
      for (const opt of options) {
        const txt = normalize(
          opt.textContent || opt.getAttribute('data-value') || ''
        );
        let score = 0;
        if (txt === vNorm) score = 4;
        else if (txt.startsWith(vNorm)) score = 3;
        else if (txt.includes(vNorm)) score = 2;
        if (score > bestScore) {
          bestScore = score;
          best = opt;
        }
      }
      if (best) {
        best.scrollIntoView({ block: 'center' });
        best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        best.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        container.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      }
    } catch (_) {}
    return false;
  }

  function setListbox(listboxEl, value) {
    try {
      const vNorm = normalize(value);
      const options = Array.from(
        listboxEl.querySelectorAll('[role="option"], li, [data-value], option')
      );
      let best = null,
        bestScore = 0;
      for (const opt of options) {
        const txt = normalize(
          opt.textContent ||
            opt.getAttribute('data-value') ||
            opt.getAttribute?.('value') ||
            ''
        );
        let score = 0;
        if (txt === vNorm) score = 4;
        else if (txt.startsWith(vNorm)) score = 3;
        else if (txt.includes(vNorm)) score = 2;
        if (score > bestScore) {
          bestScore = score;
          best = opt;
        }
      }

      // EEO fallback: try key terms from value if no match found
      if (!best || bestScore < 2) {
        const keyTerms = vNorm.split(' ').filter((w) => w.length > 2);
        for (const term of keyTerms) {
          for (const opt of options) {
            const txt = normalize(
              opt.textContent ||
                opt.getAttribute('data-value') ||
                opt.getAttribute?.('value') ||
                ''
            );
            if (txt.includes(term)) {
              best = opt;
              bestScore = 2;
              break;
            }
          }
          if (best && bestScore >= 2) break;
        }
      }

      if (best) {
        best.scrollIntoView({ block: 'center' });
        best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        best.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        listboxEl.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      }
    } catch (_) {}
    return false;
  }

  function setRadioGroup(el, value) {
    try {
      const form = el.form || el.ownerDocument;
      const name = el.getAttribute && el.getAttribute('name');
      if (!name) return false;
      const radios = Array.from(
        (form || document).querySelectorAll(
          `input[type="radio"][name="${CSS.escape(name)}"]`
        )
      );
      const vNorm = synonyms(String(value || ''));
      let best = null,
        bestScore = 0;
      for (const r of radios) {
        const lbl = getLabelText(r) || r.value || '';
        const txt = synonyms(lbl);
        let score = 0;
        if (txt === vNorm) score = 4;
        else if (txt.startsWith(vNorm)) score = 3;
        else if (txt.includes(vNorm)) score = 2;
        if (score > bestScore) {
          bestScore = score;
          best = r;
        }
      }
      if (best) {
        // Skip if already checked to avoid toggle behavior on retries
        // Check both native checked property AND CSS class (for Ashby-style forms)
        const parentSpan = best.closest('span');
        const isAlreadyChecked =
          best.checked ||
          (parentSpan && parentSpan.className.includes('checked'));
        if (isAlreadyChecked) {
          return true;
        }
        const id = best.getAttribute('id');
        const label = id
          ? (best.getRootNode() || document).querySelector(
              `label[for="${CSS.escape(id)}"]`
            )
          : null;
        if (label) {
          label.scrollIntoView({ block: 'center' });
          label.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          label.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        } else {
          best.scrollIntoView({ block: 'center' });
          best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          best.dispatchEvent(new MouseEvent('click', { bubbles: true }));
          best.checked = true;
          best.dispatchEvent(new Event('input', { bubbles: true }));
          best.dispatchEvent(new Event('change', { bubbles: true }));
        }
        return true;
      }
    } catch (_) {}
    return false;
  }

  function setRadioInContainer(container, value) {
    try {
      const radios = Array.from(
        container.querySelectorAll('input[type="radio"]')
      );
      if (!radios.length) return false;
      const vNorm = synonyms(String(value || ''));
      let best = null,
        bestScore = 0;
      for (const r of radios) {
        const lbl = getLabelText(r) || r.value || '';
        const txt = synonyms(lbl);
        let score = 0;
        if (txt === vNorm) score = 4;
        else if (txt.startsWith(vNorm)) score = 3;
        else if (txt.includes(vNorm)) score = 2;
        if (score > bestScore) {
          bestScore = score;
          best = r;
        }
      }
      if (best) {
        // Skip if already checked to avoid toggle behavior on retries
        // Check both native checked property AND CSS class (for Ashby-style forms)
        const parentSpan = best.closest('span');
        const isAlreadyChecked =
          best.checked ||
          (parentSpan && parentSpan.className.includes('checked'));
        if (isAlreadyChecked) {
          return true;
        }
        const id = best.getAttribute('id');
        const label = id
          ? (best.getRootNode() || document).querySelector(
              `label[for="${CSS.escape(id)}"]`
            )
          : best.closest('label');
        if (label) {
          label.scrollIntoView({ block: 'center' });
          label.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          label.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        } else {
          best.scrollIntoView({ block: 'center' });
          best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          best.dispatchEvent(new MouseEvent('click', { bubbles: true }));
          best.checked = true;
          best.dispatchEvent(new Event('input', { bubbles: true }));
          best.dispatchEvent(new Event('change', { bubbles: true }));
        }
        return true;
      }
    } catch (_) {}
    return false;
  }

  // Fallback: try to set any compatible control anywhere in the root by matching the option text/value
  // Helper to check if element or its container is in usedElements
  function isElementUsed(el, usedElements) {
    if (!usedElements || usedElements.size === 0) return false;
    if (usedElements.has(el)) return true;
    for (const used of usedElements) {
      if (el.contains(used) || used.contains(el)) return true;
    }
    return false;
  }

  async function tryFallbackByValue(root, value, usedElements = null) {
    try {
      // 1) Native <select>
      const selects = Array.from(root.querySelectorAll('select'));
      for (const sel of selects) {
        if (isElementUsed(sel, usedElements)) continue;
        if (setExactOrClosestSelect(sel, value)) return true;
      }

      // 1.5) React Select components (very common on Greenhouse, Lever, etc.)
      const reactSelects = Array.from(
        root.querySelectorAll(
          '[class*="select-shell"], [class*="select__container"], .select:has([class*="select__control"])'
        )
      );
      for (const rs of reactSelects) {
        if (isHidden(rs)) continue;
        if (isElementUsed(rs, usedElements)) continue;
        // Only try if it has React Select structure
        if (
          rs.querySelector('[class*="select__control"]') ||
          rs.querySelector('input[role="combobox"]')
        ) {
          if (await setReactSelect(rs, value)) return true;
        }
      }

      // 2) ARIA listboxes
      const listboxes = Array.from(root.querySelectorAll('[role="listbox"]'));
      for (const lb of listboxes) {
        if (isElementUsed(lb, usedElements)) continue;
        if (setListbox(lb, value)) return true;
      }

      // 3) ARIA comboboxes
      const comboboxes = Array.from(root.querySelectorAll('[role="combobox"]'));
      for (const cb of comboboxes) {
        // Skip if inside a React Select (already handled above)
        if (cb.closest('[class*="select-shell"], [class*="select__container"]'))
          continue;
        if (isElementUsed(cb, usedElements)) continue;
        if (await setCombobox(cb, value)) return true;
      }

      // 4) Button-triggered listbox menus
      const buttons = Array.from(
        root.querySelectorAll(
          'button[aria-haspopup="listbox"], button[aria-haspopup="menu"]'
        )
      );
      for (const btn of buttons) {
        if (isElementUsed(btn, usedElements)) continue;
        if (await setButtonListbox(btn, value)) return true;
      }

      // 5) Radio groups (try all groups until one matches)
      const radios = Array.from(root.querySelectorAll('input[type="radio"]'));
      for (const r of radios) {
        if (isElementUsed(r, usedElements)) continue;
        if (setRadioGroup(r, value)) return true;
      }

      // 6) Checkbox groups
      const checkboxGroups = Array.from(
        root.querySelectorAll(
          'fieldset, [role="group"], [class*="checkbox-group"]'
        )
      );
      for (const grp of checkboxGroups) {
        if (isElementUsed(grp, usedElements)) continue;
        const checkboxes = grp.querySelectorAll('input[type="checkbox"]');
        if (checkboxes.length > 1 && setCheckboxGroup(grp, value)) return true;
      }

      // 7) Date inputs (native and custom pickers)
      const dateInputs = Array.from(
        root.querySelectorAll(
          'input[type="date"], input[type="datetime-local"], [class*="datepicker"] input, [class*="DatePicker"] input'
        )
      );
      for (const di of dateInputs) {
        if (isHidden(di)) continue;
        if (isElementUsed(di, usedElements)) continue;
        try {
          di.scrollIntoView({ block: 'center' });
          di.focus();
          const formatted = formatDateForInput(value);
          di.value = formatted;
          di.dispatchEvent(new Event('input', { bubbles: true }));
          di.dispatchEvent(new Event('change', { bubbles: true }));
          if (di.value) return true;
        } catch (_) {}
      }

      // 8) Number inputs
      const numberInputs = Array.from(
        root.querySelectorAll('input[type="number"], input[type="range"]')
      );
      for (const ni of numberInputs) {
        if (isHidden(ni)) continue;
        if (isElementUsed(ni, usedElements)) continue;
        try {
          ni.scrollIntoView({ block: 'center' });
          ni.focus();
          const numMatch = String(value).match(/[\d,]+\.?\d*/);
          if (numMatch) {
            const numValue = numMatch[0].replace(/,/g, '');
            ni.value = numValue;
            ni.dispatchEvent(new Event('input', { bubbles: true }));
            ni.dispatchEvent(new Event('change', { bubbles: true }));
            if (ni.value) return true;
          }
        } catch (_) {}
      }

      // 9) Labels: direct click on a label whose text matches the value
      const vNorm = normalize(String(value || ''));
      const labels = Array.from(root.querySelectorAll('label'));
      for (const lab of labels) {
        const txt = normalize(lab.textContent || '');
        if (!txt) continue;
        if (txt === vNorm || (txt.startsWith(vNorm) && vNorm.length >= 2)) {
          lab.scrollIntoView({ block: 'center' });
          lab.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          lab.dispatchEvent(new MouseEvent('click', { bubbles: true }));
          return true;
        }
      }

      // 10) Custom React Select / MUI Select components
      const customSelects = Array.from(
        root.querySelectorAll(
          '[class*="select__control"], [class*="MuiSelect"], [class*="ant-select"]'
        )
      );
      for (const cs of customSelects) {
        if (isHidden(cs)) continue;
        try {
          cs.scrollIntoView({ block: 'center' });
          cs.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          cs.dispatchEvent(new MouseEvent('click', { bubbles: true }));
          await new Promise((r) => setTimeout(r, 150));

          // Look for options in dropdown menu
          const menuOptions = Array.from(
            document.querySelectorAll(
              '[class*="option"], [class*="MenuItem"], [class*="ant-select-item"], [role="option"]'
            )
          );
          let best = null,
            bestScore = 0;
          for (const opt of menuOptions) {
            const txt = normalize(opt.textContent || '');
            let score = 0;
            if (txt === vNorm) score = 4;
            else if (txt.startsWith(vNorm)) score = 3;
            else if (txt.includes(vNorm)) score = 2;
            if (score > bestScore) {
              bestScore = score;
              best = opt;
            }
          }
          if (best) {
            best.scrollIntoView({ block: 'center' });
            best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
            best.dispatchEvent(new MouseEvent('click', { bubbles: true }));
            return true;
          }
        } catch (_) {}
      }

      // 11) Text inputs with matching placeholder
      const textInputs = Array.from(
        root.querySelectorAll('input[type="text"], input:not([type]), textarea')
      );
      for (const ti of textInputs) {
        if (isHidden(ti)) continue;
        const placeholder = normalize(ti.getAttribute('placeholder') || '');
        if (
          placeholder &&
          (placeholder.includes(vNorm) || vNorm.includes(placeholder))
        ) {
          try {
            ti.scrollIntoView({ block: 'center' });
            ti.focus();
            ti.value = value;
            ti.dispatchEvent(new Event('input', { bubbles: true }));
            ti.dispatchEvent(new Event('change', { bubbles: true }));
            return true;
          } catch (_) {}
        }
      }
    } catch (_) {}
    return false;
  }

  function isButtonListbox(el) {
    try {
      const tag = (el.tagName || '').toLowerCase();
      const haspopup = (el.getAttribute('aria-haspopup') || '').toLowerCase();
      return (
        tag === 'button' &&
        (haspopup === 'listbox' || haspopup === 'menu' || haspopup === 'true')
      );
    } catch (_) {
      return false;
    }
  }

  async function setButtonListbox(button, value) {
    try {
      button.scrollIntoView({ block: 'center' });
      button.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      button.dispatchEvent(new MouseEvent('click', { bubbles: true }));
      await new Promise((r) => setTimeout(r, 150));

      // Look for options in various dropdown patterns (listbox, menu, custom dropdowns)
      const options = Array.from(
        document.querySelectorAll(
          '[role="option"], [role="menuitem"], [role="menuitemradio"], [role="menuitemcheckbox"], ' +
            'li[role="option"], li[data-value], [data-value], ' +
            '[class*="option"], [class*="menu-item"], [class*="MenuItem"], ' +
            '[class*="dropdown-item"], [class*="ant-select-item"]'
        )
      );
      const vNorm = normalize(value);
      let best = null,
        bestScore = 0;
      for (const opt of options) {
        if (isHidden(opt)) continue;
        const txt = normalize(
          opt.textContent || opt.getAttribute('data-value') || ''
        );
        let score = 0;
        if (txt === vNorm) score = 4;
        else if (txt.startsWith(vNorm)) score = 3;
        else if (txt.includes(vNorm)) score = 2;
        else if (vNorm.includes(txt) && txt.length >= 2) score = 1;
        if (score > bestScore) {
          bestScore = score;
          best = opt;
        }
      }
      if (best) {
        best.scrollIntoView({ block: 'center' });
        best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        best.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        button.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      }

      // If no match found, try closing the dropdown by pressing Escape
      try {
        document.dispatchEvent(
          new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })
        );
      } catch (_) {}
    } catch (_) {}
    return false;
  }

  async function retry(fn, tries = 3, delayMs = 180) {
    let last = false;
    for (let i = 0; i < tries; i++) {
      last = await fn();
      if (last) return true;
      await new Promise((r) => setTimeout(r, delayMs));
    }
    return false;
  }

  function applyAutofillHints(root) {
    try {
      const map = [
        { key: /email|e-mail/i, value: 'email' },
        { key: /phone|mobile|tel/i, value: 'tel' },
        { key: /name|full name/i, value: 'name' },
        { key: /first name/i, value: 'given-name' },
        { key: /last name|family name|surname/i, value: 'family-name' },
        { key: /address line 1|address1|street/i, value: 'address-line1' },
        { key: /address line 2|address2/i, value: 'address-line2' },
        { key: /city|locality/i, value: 'address-level2' },
        { key: /state|province|region/i, value: 'address-level1' },
        { key: /postal|zip/i, value: 'postal-code' },
        { key: /country/i, value: 'country-name' },
        { key: /linkedin/i, value: 'url' },
        { key: /website|portfolio|github/i, value: 'url' },
      ];
      const inputs = root.querySelectorAll
        ? root.querySelectorAll('input, textarea, select')
        : [];
      for (const el of inputs) {
        if (isHidden(el) || isCaptchaLike(el)) continue;
        if (el.getAttribute('autocomplete')) continue;
        const label = [
          getLabelText(el),
          el.getAttribute('name') || '',
          el.getAttribute('id') || '',
        ]
          .filter(Boolean)
          .join(' ');
        for (const { key, value } of map) {
          if (key.test(label)) {
            el.setAttribute('autocomplete', value);
            break;
          }
        }
      }
    } catch (_) {}
  }

  // Helper to parse and format dates for input[type="date"]
  function formatDateForInput(value) {
    if (!value) return '';
    // Already in YYYY-MM-DD format
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;

    // Try parsing various formats
    const datePatterns = [
      // MM/DD/YYYY or MM-DD-YYYY
      {
        regex: /^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/,
        format: (m) =>
          `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`,
      },
      // DD/MM/YYYY (European)
      {
        regex: /^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/,
        format: (m) =>
          `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`,
      },
      // Month DD, YYYY
      {
        regex: /^([A-Za-z]+)\s+(\d{1,2}),?\s*(\d{4})$/i,
        format: (m) => {
          const months = [
            'jan',
            'feb',
            'mar',
            'apr',
            'may',
            'jun',
            'jul',
            'aug',
            'sep',
            'oct',
            'nov',
            'dec',
          ];
          const monthIdx = months.findIndex((mon) =>
            m[1].toLowerCase().startsWith(mon)
          );
          if (monthIdx >= 0)
            return `${m[3]}-${String(monthIdx + 1).padStart(
              2,
              '0'
            )}-${m[2].padStart(2, '0')}`;
          return '';
        },
      },
      // "Immediately" or "ASAP" → today's date
      {
        regex: /^(immediately|asap|now|today)$/i,
        format: () => new Date().toISOString().split('T')[0],
      },
      // "2 weeks" or "two weeks" → 2 weeks from now
      {
        regex: /^(2|two)\s*weeks?/i,
        format: () => {
          const d = new Date();
          d.setDate(d.getDate() + 14);
          return d.toISOString().split('T')[0];
        },
      },
    ];

    for (const { regex, format } of datePatterns) {
      const match = value.match(regex);
      if (match) {
        const result = format(match);
        if (result) return result;
      }
    }

    // Try native Date parsing as fallback
    try {
      const d = new Date(value);
      if (!isNaN(d.getTime())) {
        return d.toISOString().split('T')[0];
      }
    } catch (_) {}

    return value; // Return as-is if we can't parse
  }

  // Helper to set checkbox group values
  function setCheckboxGroup(container, values) {
    try {
      const checkboxes = Array.from(
        container.querySelectorAll('input[type="checkbox"]')
      );
      if (!checkboxes.length) return false;

      const valsArray = Array.isArray(values)
        ? values
        : String(values)
            .split(/[,;|]/)
            .map((v) => v.trim());
      const valsNorm = valsArray.map((v) => normalize(v));

      let anySet = false;
      for (const cb of checkboxes) {
        const cbLabel = normalize(getLabelText(cb) || cb.value || '');
        const cbValue = normalize(cb.value || '');

        const shouldCheck = valsNorm.some(
          (v) =>
            cbLabel.includes(v) ||
            v.includes(cbLabel) ||
            cbValue.includes(v) ||
            v.includes(cbValue) ||
            cbLabel === v ||
            cbValue === v
        );

        if (shouldCheck && !cb.checked) {
          cb.scrollIntoView({ block: 'center' });
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          anySet = true;
        }
      }
      return anySet;
    } catch (_) {
      return false;
    }
  }

  async function setValue(el, value) {
    if (isHidden(el) || isCaptchaLike(el)) return false;
    const tag = (el.tagName || '').toLowerCase();
    const inputType = (el.type || el.getAttribute('type') || '').toLowerCase();

    // Handle native <select> dropdown
    if (tag === 'select') {
      return setExactOrClosestSelect(el, value);
    }

    // Handle React Select components (Greenhouse, Lever, etc.)
    // Check if element is inside a React Select container
    const reactSelectContainer =
      el.closest &&
      (el.closest('[class*="select-shell"]') ||
        el.closest('[class*="select__container"]') ||
        el.closest('.select'));
    if (
      reactSelectContainer &&
      (reactSelectContainer.querySelector('[class*="select__control"]') ||
        reactSelectContainer.querySelector('input[role="combobox"]'))
    ) {
      return await setReactSelect(reactSelectContainer, value);
    }

    // Also check if element itself has React Select classes
    if (
      el.classList &&
      (el.classList.toString().includes('select__') ||
        el.classList.toString().includes('select-shell'))
    ) {
      return await setReactSelect(el, value);
    }

    // Handle ARIA button-based listbox
    if (isButtonListbox(el)) {
      return await setButtonListbox(el, value);
    }

    // Handle ARIA combobox (including React Select inputs)
    if (
      el.matches &&
      (el.matches('[role="combobox"]') ||
        (el.closest && el.closest('[role="combobox"]')))
    ) {
      // Check if this is part of a React Select
      const selectShell = el.closest(
        '[class*="select-shell"], [class*="select__container"], .select'
      );
      if (selectShell) {
        return await setReactSelect(selectShell, value);
      }
      const container = el.matches('[role="combobox"]')
        ? el
        : el.closest('[role="combobox"]');
      return await setCombobox(container, value);
    }

    // Handle ARIA listbox
    if (el.getAttribute && el.getAttribute('role') === 'listbox') {
      return setListbox(el, value);
    }

    // Handle containers with radio buttons
    if (el.querySelector && el.querySelector('input[type="radio"]')) {
      if (setRadioInContainer(el, value)) return true;
    }

    // Handle label elements that might be for radio groups
    if (tag === 'label') {
      const container =
        (el.closest && el.closest('fieldset')) ||
        (el.parentElement &&
          el.parentElement.querySelector &&
          el.parentElement);
      if (
        container &&
        container.querySelector &&
        container.querySelector('input[type="radio"]')
      ) {
        if (setRadioInContainer(container, value)) return true;
      }
    }

    // Handle checkbox groups (containers with multiple checkboxes)
    if (
      el.querySelector &&
      el.querySelectorAll('input[type="checkbox"]').length > 1
    ) {
      if (setCheckboxGroup(el, value)) return true;
    }

    // Handle DATE inputs
    if (inputType === 'date' || inputType === 'datetime-local') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        const formatted = formatDateForInput(value);
        el.value = formatted;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return el.value === formatted || !!el.value;
      } catch (_) {}
    }

    // Handle NUMBER inputs
    if (inputType === 'number' || inputType === 'range') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        // Extract numeric value from string
        const numMatch = String(value).match(/[\d,]+\.?\d*/);
        const numValue = numMatch ? numMatch[0].replace(/,/g, '') : value;
        const min = parseFloat(el.min) || -Infinity;
        const max = parseFloat(el.max) || Infinity;
        let finalValue = parseFloat(numValue);
        if (!isNaN(finalValue)) {
          finalValue = Math.max(min, Math.min(max, finalValue));
          el.value = finalValue;
        } else {
          el.value = value;
        }
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle TIME inputs
    if (inputType === 'time') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        // Try to parse time format
        let timeValue = value;
        const timeMatch = String(value).match(
          /(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\s*(am|pm))?/i
        );
        if (timeMatch) {
          let hours = parseInt(timeMatch[1]);
          const minutes = timeMatch[2];
          const ampm = (timeMatch[4] || '').toLowerCase();
          if (ampm === 'pm' && hours < 12) hours += 12;
          if (ampm === 'am' && hours === 12) hours = 0;
          timeValue = `${String(hours).padStart(2, '0')}:${minutes}`;
        }
        el.value = timeValue;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle MONTH inputs (type="month")
    if (inputType === 'month') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        // Format: YYYY-MM
        let monthValue = value;
        const monthMatch = String(value).match(/(\d{4})[-\/](\d{1,2})/);
        if (monthMatch) {
          monthValue = `${monthMatch[1]}-${monthMatch[2].padStart(2, '0')}`;
        }
        el.value = monthValue;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle WEEK inputs (type="week")
    if (inputType === 'week') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        // Format: YYYY-Www
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle COLOR inputs (type="color")
    if (inputType === 'color') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        // Ensure hex format
        let colorValue = value;
        if (!colorValue.startsWith('#')) {
          colorValue = '#' + colorValue;
        }
        el.value = colorValue;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle TEL inputs (phone numbers)
    if (inputType === 'tel') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle URL inputs
    if (inputType === 'url') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        // Ensure URL has protocol
        let urlValue = value;
        if (
          urlValue &&
          !urlValue.match(/^https?:\/\//i) &&
          !urlValue.startsWith('//')
        ) {
          urlValue = 'https://' + urlValue;
        }
        el.value = urlValue;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle SEARCH inputs
    if (inputType === 'search') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('search', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle hidden inputs (some forms use hidden inputs that should be filled)
    if (inputType === 'hidden') {
      try {
        el.value = value;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle ARIA textbox role (contenteditable divs styled as inputs)
    if (el.getAttribute && el.getAttribute('role') === 'textbox') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        el.textContent = value;
        if (el.innerHTML !== undefined) el.innerHTML = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle ARIA spinbutton (number inputs)
    if (el.getAttribute && el.getAttribute('role') === 'spinbutton') {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        const numMatch = String(value).match(/[\d,]+\.?\d*/);
        const numValue = numMatch ? numMatch[0].replace(/,/g, '') : value;
        el.setAttribute('aria-valuenow', numValue);
        el.textContent = numValue;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle ARIA slider (range inputs)
    if (el.getAttribute && el.getAttribute('role') === 'slider') {
      try {
        el.scrollIntoView({ block: 'center' });
        const numMatch = String(value).match(/[\d,]+\.?\d*/);
        const numValue = numMatch
          ? parseFloat(numMatch[0].replace(/,/g, ''))
          : 50;
        el.setAttribute('aria-valuenow', numValue);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle ARIA switch (toggle on/off)
    if (el.getAttribute && el.getAttribute('role') === 'switch') {
      try {
        el.scrollIntoView({ block: 'center' });
        const truthy = ['yes', 'true', '1', 'y', 'on', 'enabled'].includes(
          String(value).trim().toLowerCase()
        );
        el.setAttribute('aria-checked', truthy ? 'true' : 'false');
        el.click();
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle toggle/switch classes (MUI Switch, etc.)
    if (
      el.matches &&
      el.matches(
        '[class*="toggle"], [class*="Toggle"], [class*="switch"], [class*="Switch"]'
      )
    ) {
      try {
        el.scrollIntoView({ block: 'center' });
        const truthy = ['yes', 'true', '1', 'y', 'on', 'enabled'].includes(
          String(value).trim().toLowerCase()
        );
        // Find the inner checkbox or clickable element
        const innerCheckbox = el.querySelector('input[type="checkbox"]');
        if (innerCheckbox) {
          if (innerCheckbox.checked !== truthy) {
            innerCheckbox.click();
          }
          return true;
        } else {
          // Click the toggle itself
          el.click();
          return true;
        }
      } catch (_) {}
    }

    // Handle contenteditable elements (rich text editors)
    if (el.contentEditable === 'true' || el.isContentEditable) {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        el.textContent = value;
        el.innerHTML = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle Slate.js editors
    if (el.matches && el.matches('[data-slate-editor]')) {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        // Clear and type
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, value);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle Lexical editors
    if (el.matches && el.matches('[data-lexical-editor]')) {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, value);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Handle individual checkbox
    if (el.type === 'checkbox') {
      // Special case: Ashby-style yes/no widgets using two buttons + hidden checkbox
      try {
        const container =
          (el.closest &&
            el.closest(
              '._yesno_lxvad_149, [class*="yesno_lxvad_"], [class*="_yesno_"]'
            )) ||
          (el.parentElement &&
            el.parentElement.querySelector &&
            el.parentElement.querySelector('button'));
        const vNorm = synonyms(String(value || ''));
        const isYes = vNorm === 'yes';
        const isNo = vNorm === 'no';
        if (container && (isYes || isNo)) {
          const buttons = Array.from(container.querySelectorAll('button'));
          if (buttons.length >= 2) {
            const targetBtn = isYes ? buttons[0] : buttons[1];
            try {
              targetBtn.scrollIntoView({ block: 'center' });
            } catch (_) {}
            targetBtn.dispatchEvent(
              new MouseEvent('mousedown', { bubbles: true })
            );
            targetBtn.dispatchEvent(new MouseEvent('click', { bubbles: true }));
            // Some implementations also listen to checkbox changes, so keep it in sync
            el.checked = isYes; // treat "Yes" as checked, "No" as unchecked
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            return true;
          }
        }
      } catch (_) {}

      const truthy = ['yes', 'true', '1', 'y', 'on'].includes(
        String(value).trim().toLowerCase()
      );
      el.checked = truthy;
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    if (el.type === 'radio') {
      return setRadioGroup(el, value);
    }
    try {
      // Make sure the element is visible to avoid lazy-loaded listeners
      if (el.scrollIntoView) el.scrollIntoView({ block: 'center' });
      el.focus();
    } catch (_) {}
    if ('value' in el) {
      try {
        // Prefer native setter so frameworks (React/Vue) receive proper events
        const proto = Object.getPrototypeOf(el) || {};
        const desc = Object.getOwnPropertyDescriptor(proto, 'value');
        if (desc && typeof desc.set === 'function') {
          desc.set.call(el, value);
        } else {
          el.value = value;
        }
      } catch (_) {
        try {
          el.value = value;
        } catch (_) {}
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      try {
        el.dispatchEvent(new Event('blur', { bubbles: true }));
      } catch (_) {}
      // If some sites ignore programmatic set, try execCommand as a fallback
      if (String(el.value || '') !== String(value || '')) {
        try {
          el.select && el.select();
          document.execCommand &&
            document.execCommand('insertText', false, value);
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          try {
            el.dispatchEvent(new Event('blur', { bubbles: true }));
          } catch (_) {}
        } catch (_) {}
      }
      // Third fallback: simulate keyboard typing for stubborn React inputs
      if (String(el.value || '') !== String(value || '')) {
        try {
          el.focus();
          // Clear existing value first
          el.value = '';
          el.dispatchEvent(new Event('input', { bubbles: true }));
          // Type each character
          for (const char of String(value)) {
            el.dispatchEvent(
              new KeyboardEvent('keydown', { key: char, bubbles: true })
            );
            el.value += char;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(
              new KeyboardEvent('keyup', { key: char, bubbles: true })
            );
          }
          el.dispatchEvent(new Event('change', { bubbles: true }));
        } catch (_) {}
      }
      return (
        String(el.value || '') === String(value || '') || tag === 'textarea'
      );
    }

    // Fallback for any element with contentEditable
    if (el.contentEditable === 'true' || el.isContentEditable) {
      try {
        el.scrollIntoView({ block: 'center' });
        el.focus();
        el.textContent = value;
        el.innerHTML = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (_) {}
    }

    // Fallback for any clickable element that might trigger a dropdown/modal
    if (
      el.onclick ||
      el.getAttribute('onclick') ||
      el.matches('button, [role="button"]')
    ) {
      try {
        el.scrollIntoView({ block: 'center' });
        el.click();
        await new Promise((r) => setTimeout(r, 150));
        // Look for any input/option that appeared
        const newInput = document.querySelector(
          'input:focus, [contenteditable="true"]:focus'
        );
        if (newInput && newInput !== el) {
          return await setValue(newInput, value);
        }
      } catch (_) {}
    }

    return false;
  }

  async function applyFieldsToRoot(root, fields) {
    // Apply browser autofill hints to aid native autofill if user interacts
    applyAutofillHints(root);

    const candidates = [];
    if (root.querySelectorAll) {
      // Standard form elements including all input types (text, date, number, email, tel, url, etc.)
      candidates.push(
        ...root.querySelectorAll(
          'input, textarea, select, button[aria-haspopup="listbox"], button[aria-haspopup="menu"], button[aria-haspopup="true"]'
        )
      );
      // ARIA widgets
      candidates.push(
        ...root.querySelectorAll(
          '[role="combobox"], [aria-haspopup="listbox"], [role="listbox"], [role="radiogroup"], ' +
            '[role="textbox"], [role="spinbutton"], [role="slider"], [role="switch"], ' +
            'fieldset, label'
        )
      );
      // Custom select/dropdown components (React Select, MUI, Ant Design, etc.)
      candidates.push(
        ...root.querySelectorAll(
          '[class*="select"], [class*="Select"], [class*="dropdown"], [class*="Dropdown"], ' +
            '[class*="autocomplete"], [class*="Autocomplete"], [class*="typeahead"], ' +
            '[class*="combobox"], [class*="Combobox"], [class*="picker"], [class*="Picker"], ' +
            '[data-testid*="select"], [data-testid*="dropdown"], [data-testid*="input"]'
        )
      );
      // React Select specific containers (Greenhouse, Lever, common ATS)
      candidates.push(
        ...root.querySelectorAll(
          '[class*="select-shell"], [class*="select__container"], ' +
            '.select:has([class*="select__control"]), ' +
            '[class*="remix-css"]:has(input[role="combobox"])'
        )
      );
      // Date/Time picker components
      candidates.push(
        ...root.querySelectorAll(
          '[class*="datepicker"], [class*="DatePicker"], [class*="date-picker"], ' +
            '[class*="timepicker"], [class*="TimePicker"], [class*="time-picker"], ' +
            '[class*="datetime"], [class*="DateTime"], ' +
            '[data-testid*="date"], input[placeholder*="date" i], input[placeholder*="mm/dd" i], ' +
            'input[placeholder*="yyyy" i], input[placeholder*="time" i]'
        )
      );
      // Checkbox/Radio groups
      candidates.push(
        ...root.querySelectorAll(
          '[class*="checkbox-group"], [class*="CheckboxGroup"], [class*="radio-group"], [class*="RadioGroup"], ' +
            '[role="group"], [class*="form-group"], [class*="FormGroup"], [class*="field-group"]'
        )
      );
      // Custom input components (React, Vue, Angular patterns)
      candidates.push(
        ...root.querySelectorAll(
          '[class*="input"], [class*="Input"], [class*="text-field"], [class*="TextField"], ' +
            '[class*="form-control"], [class*="FormControl"], [class*="field"], [class*="Field"], ' +
            '[contenteditable="true"], [data-slate-editor], [data-lexical-editor]'
        )
      );
      // Number/Range inputs
      candidates.push(
        ...root.querySelectorAll(
          '[class*="number"], [class*="Number"], [class*="counter"], [class*="Counter"], ' +
            '[class*="stepper"], [class*="Stepper"], [class*="range"], [class*="Range"]'
        )
      );
      // Toggle/Switch components
      candidates.push(
        ...root.querySelectorAll(
          '[class*="toggle"], [class*="Toggle"], [class*="switch"], [class*="Switch"], ' +
            '[class*="checkbox"], [class*="Checkbox"]'
        )
      );

      // ========== FRAMEWORK-SPECIFIC SELECTORS ==========

      // LinkedIn fields
      candidates.push(
        ...root.querySelectorAll(
          '[data-test-text-entity-list-form-component], ' +
            '[data-test-single-typeahead-entity], ' +
            '[data-test-text-selectable-option], ' +
            '[data-test-form-element], ' +
            '[data-test-text-input], ' +
            '[data-test-date-input]'
        )
      );

      // Google Forms fields
      candidates.push(
        ...root.querySelectorAll(
          '[data-params*="question"], ' +
            '[class*="freebirdFormviewerComponentsQuestion"], ' +
            '[jsname], ' +
            '[data-item-id]'
        )
      );

      // WordPress/Gravity Forms/WPForms
      candidates.push(
        ...root.querySelectorAll(
          '.gfield, .wpforms-field, .wpcf7-form-control-wrap, ' +
            '[class*="gravity"], [class*="wpform"], [class*="elementor-field"]'
        )
      );

      // Material-UI (MUI)
      candidates.push(
        ...root.querySelectorAll(
          '.MuiTextField-root, .MuiSelect-root, .MuiAutocomplete-root, ' +
            '[class*="MuiInput"], [class*="MuiFormControl"], [class*="MuiOutlinedInput"]'
        )
      );

      // Ant Design
      candidates.push(
        ...root.querySelectorAll(
          '.ant-input, .ant-select, .ant-picker, .ant-form-item, ' +
            '[class*="ant-input"], [class*="ant-select"], [class*="ant-picker"]'
        )
      );

      // Chakra UI
      candidates.push(
        ...root.querySelectorAll(
          '[class*="chakra-input"], [class*="chakra-select"], ' +
            '[class*="chakra-textarea"], .chakra-form-control'
        )
      );

      // Tailwind CSS common patterns
      candidates.push(
        ...root.querySelectorAll(
          '[class*="form-input"], [class*="form-select"], [class*="form-textarea"], ' +
            '[class*="border-gray"], [class*="rounded"]'
        )
      );

      // Bootstrap form controls
      candidates.push(
        ...root.querySelectorAll(
          '.form-control, .form-select, .form-check-input, ' +
            '[class*="form-control"], [class*="form-select"]'
        )
      );

      // Semantic UI
      candidates.push(
        ...root.querySelectorAll(
          '.ui.input, .ui.dropdown, .ui.checkbox, .ui.radio, ' +
            '[class*="ui input"], [class*="ui dropdown"]'
        )
      );

      // Vuetify
      candidates.push(
        ...root.querySelectorAll(
          '.v-text-field, .v-select, .v-autocomplete, .v-textarea, ' +
            '[class*="v-text-field"], [class*="v-select"]'
        )
      );

      // Angular Material
      candidates.push(
        ...root.querySelectorAll(
          'mat-form-field, mat-input, mat-select, mat-autocomplete, ' +
            '[class*="mat-form-field"], [class*="mat-input"]'
        )
      );

      // Formik fields (React)
      candidates.push(
        ...root.querySelectorAll(
          '[name]:not([name=""]), [id*="formik"], [class*="formik"]'
        )
      );

      // React Hook Form
      candidates.push(
        ...root.querySelectorAll(
          '[data-testid*="rhf"], [class*="react-hook-form"]'
        )
      );
    }

    // ========== NEW APPROACH: Map fields to elements first, then fill ==========
    // This ensures each element is used only once and prevents overwriting

    // Step 1: Clean and prepare all fields
    const cleanedFields = [];
    for (const { name, value: rawValue } of fields) {
      const cleanedValue = String(rawValue || '')
        .replace(/\[FILE_UPLOAD[^\]]*\]/gi, '')
        .replace(/\[SKIP_FILE[^\]]*\]/gi, '')
        .replace(/\[FILE_UPLOAD_REQUIRED[^\]]*\]/gi, '')
        .trim();

      if (!cleanedValue) {
        console.log(`[Content] Skipping field "${name}" - empty value`);
        continue;
      }

      const value = resolveEEOValue(name, cleanedValue);
      cleanedFields.push({ name, value });
    }

    // Step 2: Create unique element-to-field mapping
    // Score all field-element pairs and assign each element to at most one field
    const elementToField = new Map(); // element -> { name, value, score }
    const fieldToElement = new Map(); // field name -> element
    const usedElements = new Set();

    // First pass: find best element for each field
    const fieldScores = [];
    for (const { name, value } of cleanedFields) {
      const scores = [];
      for (const el of candidates) {
        if (isHidden(el)) continue;
        const score = scoreMatch(name, el);
        if (score >= 2) {
          scores.push({ el, score, name, value });
        }
      }
      // Sort by score descending
      scores.sort((a, b) => b.score - a.score);
      fieldScores.push({ name, value, scores });
    }

    // Sort fields by their best score descending (fill high-confidence matches first)
    fieldScores.sort((a, b) => {
      const aTop = a.scores[0]?.score || 0;
      const bTop = b.scores[0]?.score || 0;
      return bTop - aTop;
    });

    // Helper to get radio group name if element is a radio button
    function getRadioGroupKey(el) {
      if (!el) return null;
      const tag = (el.tagName || '').toLowerCase();
      const type = (el.type || el.getAttribute?.('type') || '').toLowerCase();

      if (tag === 'input' && type === 'radio') {
        const name = el.getAttribute('name');
        return name ? `radio-group:${name}` : null;
      }

      // Check if it's a container with radio buttons
      if (el.querySelector) {
        const firstRadio = el.querySelector('input[type="radio"]');
        if (firstRadio) {
          const name = firstRadio.getAttribute('name');
          return name ? `radio-group:${name}` : null;
        }
      }

      return null;
    }

    // Assign elements to fields, ensuring each element is used only once
    const usedRadioGroups = new Set(); // Track radio groups separately

    for (const { name, value, scores } of fieldScores) {
      for (const { el, score } of scores) {
        // Check if this element (or its container/children) is already used
        let alreadyUsed = usedElements.has(el);

        // For radio buttons, check if the radio group is already used
        const radioGroupKey = getRadioGroupKey(el);
        if (radioGroupKey && usedRadioGroups.has(radioGroupKey)) {
          alreadyUsed = true;
        }

        // Also check if this element contains or is contained by a used element
        if (!alreadyUsed) {
          for (const usedEl of usedElements) {
            if (el.contains(usedEl) || usedEl.contains(el)) {
              alreadyUsed = true;
              break;
            }
          }
        }

        if (!alreadyUsed) {
          fieldToElement.set(name, { el, value, score });
          usedElements.add(el);

          // If it's a radio button, mark the entire group as used
          if (radioGroupKey) {
            usedRadioGroups.add(radioGroupKey);
            console.log(
              `[Content] Mapped "${name}" → radio group "${radioGroupKey}" (score: ${score})`
            );
          } else {
            console.log(
              `[Content] Mapped "${name}" → element (score: ${score})`,
              el.tagName,
              el.id || el.className?.substring(0, 50)
            );
          }
          break;
        }
      }
    }

    console.log(
      `[Content] Mapped ${fieldToElement.size} fields to unique elements`
    );

    // Log which fields were NOT mapped
    const unmappedFields = cleanedFields.filter(
      (f) => !fieldToElement.has(f.name)
    );
    if (unmappedFields.length > 0) {
      console.log(
        `[Content] ⚠️ ${unmappedFields.length} fields could not be mapped:`,
        unmappedFields.map((f) => f.name)
      );
    }

    // Step 3: Fill each mapped field-element pair
    const pending = [];
    for (const { name, value } of cleanedFields) {
      if (isFillingAborted) {
        console.log('[Content] Filling aborted by user, stopping');
        return;
      }

      const mapping = fieldToElement.get(name);
      let ok = false;

      if (!mapping) {
        console.log(`[Content] ⚠️ No element mapped for field "${name}"`);
      }

      if (mapping) {
        const { el } = mapping;
        console.log(
          `[Content] Filling "${name}" = "${value.substring(0, 50)}..." on:`,
          el.tagName,
          el.id || el.className?.substring(0, 50) || '',
          'type:',
          el.type || el.getAttribute?.('type') || 'N/A'
        );

        ok = await setValue(el, value);

        if (ok) {
          console.log(`[Content] ✓ Successfully filled "${name}"`);
        } else {
          console.log(`[Content] ✗ Failed to fill "${name}"`);
        }
        if (!ok) {
          // Retry a few times for dynamic menus
          ok = await retry(() => setValue(el, value), 3, 200);
        }

        // If still not filled, try to type the value directly as a last resort
        if (!ok) {
          console.log(
            `[Content] setValue failed, trying direct input for "${name}"`
          );
          // Try to find an input within the element
          const input = el.querySelector
            ? el.querySelector('input, textarea')
            : el.tagName === 'INPUT' || el.tagName === 'TEXTAREA'
            ? el
            : null;
          if (input) {
            try {
              input.focus();
              const nativeSetter =
                Object.getOwnPropertyDescriptor(
                  window.HTMLInputElement.prototype,
                  'value'
                )?.set ||
                Object.getOwnPropertyDescriptor(
                  window.HTMLTextAreaElement.prototype,
                  'value'
                )?.set;
              if (nativeSetter) {
                nativeSetter.call(input, value);
              } else {
                input.value = value;
              }
              input.dispatchEvent(new Event('input', { bubbles: true }));
              input.dispatchEvent(new Event('change', { bubbles: true }));
              console.log(`[Content] Typed value directly into input`);
              ok = true;
            } catch (e) {
              console.warn(`[Content] Direct input failed:`, e);
            }
          }
        }

        // Wait for dropdown to close before filling next field
        await new Promise((r) => setTimeout(r, 200));
      }

      // Fallback: try by label if no element was mapped
      if (!ok && !isFillingAborted) {
        try {
          const vName = normalize(String(name || ''));
          const labels = Array.from(root.querySelectorAll('label'));
          for (const lab of labels) {
            if (isFillingAborted) break;
            const txt = normalize(lab.textContent || '');
            if (!txt) continue;
            if (
              txt === vName ||
              (txt.startsWith(vName) && vName.length >= 3) ||
              (vName.startsWith(txt) && txt.length >= 3)
            ) {
              let target = null;
              const forId = lab.getAttribute && lab.getAttribute('for');
              if (forId) {
                target = (root.getRootNode() || document).getElementById(forId);
              }
              if (!target) {
                target =
                  lab.parentElement &&
                  lab.parentElement.querySelector &&
                  (lab.parentElement.querySelector(
                    'input, textarea, select, [role="combobox"]'
                  ) ||
                    (lab.nextElementSibling &&
                      lab.nextElementSibling.querySelector &&
                      lab.nextElementSibling.querySelector(
                        'input, textarea, select, [role="combobox"]'
                      )));
              }
              if (target && !usedElements.has(target)) {
                ok = await setValue(target, value);
                if (ok) {
                  usedElements.add(target);
                  await new Promise((r) => setTimeout(r, 200));
                  break;
                }
              }
            }
          }
        } catch (_) {}
      }

      if (!ok) pending.push({ name, value });
    }

    // One more pass after a short delay for any fields that didn't stick (often the last field)
    if (pending.length && !isFillingAborted) {
      try {
        await new Promise((r) => setTimeout(r, 220));
      } catch (_) {}
      const stillPending = [];
      for (const { name, value } of pending) {
        // Check abort before each field
        if (isFillingAborted) {
          console.log('[Content] Filling aborted during pending pass');
          return;
        }
        // Attempt fallback flows again - but only on unused elements
        let ok = await tryFallbackByValue(root, value, usedElements);
        if (!ok && !isFillingAborted) {
          try {
            const vName = normalize(String(name || ''));
            const labels = Array.from(root.querySelectorAll('label'));
            for (const lab of labels) {
              if (isFillingAborted) break;
              const txt = normalize(lab.textContent || '');
              if (!txt) continue;
              if (
                txt === vName ||
                (txt.startsWith(vName) && vName.length >= 3) ||
                (vName.startsWith(txt) && txt.length >= 3)
              ) {
                let target = null;
                const forId = lab.getAttribute && lab.getAttribute('for');
                if (forId) {
                  target = (root.getRootNode() || document).getElementById(
                    forId
                  );
                }
                if (!target) {
                  target =
                    lab.parentElement &&
                    lab.parentElement.querySelector &&
                    (lab.parentElement.querySelector(
                      'input, textarea, select'
                    ) ||
                      (lab.nextElementSibling &&
                        lab.nextElementSibling.querySelector &&
                        lab.nextElementSibling.querySelector(
                          'input, textarea, select'
                        )));
                }
                if (target && !usedElements.has(target)) {
                  ok = await setValue(target, value);
                  if (ok) {
                    usedElements.add(target);
                    await new Promise((r) => setTimeout(r, 200));
                    break;
                  }
                }
              }
            }
          } catch (_) {}
        }
        if (!ok) stillPending.push({ name, value });
      }

      // AGGRESSIVE FINAL PASS: Try to fill any empty visible fields that might match
      if (stillPending.length > 0) {
        try {
          await new Promise((r) => setTimeout(r, 150));

          // Find all empty/unfilled visible inputs (excluding already used elements)
          const allInputs = Array.from(
            root.querySelectorAll(
              'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="file"]), ' +
                'textarea, select'
            )
          );
          const emptyInputs = allInputs.filter((inp) => {
            if (isHidden(inp)) return false;
            if (isElementUsed(inp, usedElements)) return false;
            const val = inp.value || '';
            const tag = inp.tagName.toLowerCase();
            if (tag === 'select') {
              // Consider select empty if on default/placeholder option
              return inp.selectedIndex <= 0;
            }
            return !val.trim();
          });

          for (const { name, value } of stillPending) {
            if (isFillingAborted) break;
            const vName = normalize(String(name || ''));

            // Try to match by partial text in label, placeholder, name, or id
            for (const inp of emptyInputs) {
              if (isElementUsed(inp, usedElements)) continue;

              const label = normalize(getLabelText(inp) || '');
              const placeholder = normalize(
                inp.getAttribute('placeholder') || ''
              );
              const inputName = normalize(inp.getAttribute('name') || '');
              const inputId = normalize(inp.getAttribute('id') || '');
              const ariaLabel = normalize(inp.getAttribute('aria-label') || '');

              // Check if any attribute partially matches
              const allText = [
                label,
                placeholder,
                inputName,
                inputId,
                ariaLabel,
              ].join(' ');
              if (
                allText.includes(vName) ||
                vName.includes(label) ||
                (label && vName.length >= 3 && label.includes(vName))
              ) {
                const ok = await setValue(inp, value);
                if (ok) {
                  // Mark as used and remove from emptyInputs to avoid double-filling
                  usedElements.add(inp);
                  const idx = emptyInputs.indexOf(inp);
                  if (idx >= 0) emptyInputs.splice(idx, 1);
                  await new Promise((r) => setTimeout(r, 200));
                  break;
                }
              }
            }
          }

          // Log remaining pending fields (but don't force-fill to wrong fields)
          const finalPending = stillPending.filter(({ name }) => {
            // Check if field was filled by checking usedElements
            return !Array.from(usedElements).some((el) => {
              const label = normalize(getLabelText(el) || '');
              const vName = normalize(String(name || ''));
              return (
                label === vName ||
                label.includes(vName) ||
                vName.includes(label)
              );
            });
          });

          if (finalPending.length > 0) {
            console.log(
              `[Content] Could not fill ${finalPending.length} fields:`,
              finalPending.map((f) => f.name)
            );
          }
        } catch (e) {
          console.warn('[Content] Aggressive fill pass error:', e);
        }
      }
    }
  }

  function getJobMeta() {
    try {
      const titleCandidates = [
        'h1',
        'h2',
        'h3',
        'header h1',
        'header h2',
        '[data-testid="job-title"]',
        '[data-qa="job-title"]',
        '.job-title',
        '.posting-headline',
        '.top-card-layout__title',
        '.jobs-unified-top-card__job-title',
      ];
      const companyCandidates = [
        '[data-testid="company-name"]',
        '[data-qa="company-name"]',
        '.company',
        '.company-name',
        '.posting-company',
        '.topcard__org-name-link',
        '.jobs-unified-top-card__company-name',
        'a[href*="/company/"]',
        'a[href*="/careers"]',
      ];
      let jobTitle = '';
      for (const sel of titleCandidates) {
        const el = document.querySelector(sel);
        if (el && el.textContent) {
          jobTitle = el.textContent.trim();
          break;
        }
      }
      let company = '';
      for (const sel of companyCandidates) {
        const el = document.querySelector(sel);
        if (el && el.textContent) {
          company = el.textContent.trim();
          break;
        }
      }
      // Heuristic from <title>, avoid generic titles like "Application Tracker"
      if (!jobTitle || !company) {
        const pageTitle = (document.title || '').trim();
        const generic =
          /application\s+tracker|apply\s+now|careers?|job\s+application|my\s+applications|dashboard/i;
        if (pageTitle && !generic.test(pageTitle)) {
          // e.g., "Senior Engineer - Acme Corp | Careers"
          const m = pageTitle.match(/^(.*?)\s*[-|–]\s*(.*?)(\||$)/);
          if (m) {
            if (!jobTitle) jobTitle = (m[1] || '').trim();
            if (!company) company = (m[2] || '').trim();
          }
        }
      }

      // Final generic filter: if the extracted heading is generic, clear it
      try {
        const isGeneric =
          /application\s+tracker|apply\s+now|careers?|job\s+application|my\s+applications|dashboard/i;
        if (isGeneric.test(jobTitle)) jobTitle = '';
      } catch (_) {}
      const url =
        (document && document.location && document.location.href) || '';
      return { jobTitle, company, url };
    } catch (_) {
      const url =
        (document && document.location && document.location.href) || '';
      return { jobTitle: '', company: '', url };
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'scanApplicationForm') {
      try {
        const summary = collectFields();
        const html = getFullHTML();
        sendResponse({ ok: true, summary, html });
      } catch (e) {
        sendResponse({ ok: false, summary: '', html: '' });
      }
      return true;
    }
    if (msg && msg.type === 'getFieldLabel') {
      try {
        const tokenRaw = (msg.token || '').toString();
        const normalize = (s) =>
          (s || '')
            .toString()
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '');
        const token = normalize(tokenRaw);
        if (!token) {
          sendResponse({ ok: false, label: '' });
          return true;
        }
        let labelText = '';
        for (const root of enumerateRoots(document)) {
          const walker = document.createTreeWalker(
            root,
            NodeFilter.SHOW_ELEMENT
          );
          let node;
          while ((node = walker.nextNode())) {
            const el = node;
            try {
              const id = normalize(el.getAttribute && el.getAttribute('id'));
              const name = normalize(
                el.getAttribute && el.getAttribute('name')
              );
              if (
                (id && (id === token || id.includes(token))) ||
                (name && (name === token || name.includes(token)))
              ) {
                // 1) Direct label mechanisms
                labelText = getLabelText(el);
                // 2) aria-labelledby on element or ancestors
                if (!labelText) {
                  const ariaIds =
                    (el.getAttribute && el.getAttribute('aria-labelledby')) ||
                    (el.closest &&
                      el
                        .closest('[aria-labelledby]')
                        ?.getAttribute('aria-labelledby')) ||
                    '';
                  if (ariaIds) {
                    const firstId = ariaIds.split(/\s+/)[0];
                    const src = firstId
                      ? root.getElementById
                        ? root.getElementById(firstId)
                        : document.getElementById(firstId)
                      : null;
                    if (src)
                      labelText = (
                        src.innerText ||
                        src.textContent ||
                        ''
                      ).trim();
                  }
                }
                // 3) Group/fieldset/role container headings
                if (!labelText && el.closest) {
                  const group = el.closest(
                    '[role="group"], [role="radiogroup"], fieldset, [data-field], .field, .form-field, .question'
                  );
                  if (group) {
                    const legend = group.querySelector('legend');
                    const heading = group.querySelector('h1,h2,h3,h4,h5,h6');
                    const lab = group.querySelector('label');
                    const headerText =
                      (legend && (legend.innerText || legend.textContent)) ||
                      (heading && (heading.innerText || heading.textContent)) ||
                      (lab && (lab.innerText || lab.textContent)) ||
                      '';
                    labelText = (headerText || '').trim();
                    if (!labelText && group.previousElementSibling) {
                      const sib = group.previousElementSibling;
                      labelText = (
                        sib.innerText ||
                        sib.textContent ||
                        ''
                      ).trim();
                    }
                  }
                }
                labelText = (labelText || '').trim();
                if (labelText) break;
              }
            } catch (_) {}
          }
          if (labelText) break;
        }
        sendResponse({ ok: true, label: labelText });
      } catch (e) {
        sendResponse({ ok: false, label: '' });
      }
      return true;
    }
    if (msg && msg.type === 'scanJobDescription') {
      try {
        const text = getVisibleMainText();
        const html = getFullHTML();
        sendResponse({ ok: true, text, html });
      } catch (e) {
        sendResponse({ ok: false, text: '', html: '' });
      }
      return true;
    }
    if (msg && msg.type === 'getJobMeta') {
      try {
        const meta = getJobMeta();
        sendResponse({ ok: true, ...meta });
      } catch (e) {
        const url =
          (document && document.location && document.location.href) || '';
        sendResponse({ ok: false, jobTitle: '', company: '', url });
      }
      return true;
    }
    // Handle abort filling request
    if (msg && msg.type === 'abortFilling') {
      isFillingAborted = true;
      console.log('[Content] Received abort signal from sidepanel');
      sendResponse({ ok: true });
      return true;
    }

    if (msg && msg.type === 'applyFields') {
      (async () => {
        try {
          // Reset abort flag when starting new fill
          isFillingAborted = false;
          const fields = Array.isArray(msg.fields) ? msg.fields : [];
          for (const root of enumerateRoots(document)) {
            // Check abort before each root
            if (isFillingAborted) {
              console.log(
                '[Content] Filling aborted, stopping root enumeration'
              );
              break;
            }
            await applyFieldsToRoot(root, fields);
          }

          // Save custom answers for reuse (in background)
          // Only save answers that are substantial (> 10 chars) and not profile data
          chrome.runtime
            .sendMessage({
              type: 'saveCustomAnswers',
              fields: fields.filter(
                (f) =>
                  (f.value && f.value.length > 10 && !f.source) ||
                  f.source !== 'profile' // Save AI-generated and cached answers
              ),
            })
            .catch((e) => console.log('[Content] Background save error:', e));

          sendResponse({ ok: true });
        } catch (e) {
          sendResponse({
            ok: false,
            error: String(e && e.message ? e.message : e),
          });
        }
      })();
      return true;
    }
    // Handle file upload requests (for resume/cover letter auto-upload)
    if (msg && msg.type === 'triggerFileUpload') {
      (async () => {
        try {
          const { inputSelector, fileData, fileName, mimeType } = msg;
          const fileInput = document.querySelector(inputSelector);
          if (!fileInput || fileInput.type !== 'file') {
            sendResponse({ ok: false, error: 'File input not found' });
            return;
          }

          // Create a File from the data
          const byteArray = new Uint8Array(fileData);
          const blob = new Blob([byteArray], {
            type: mimeType || 'application/pdf',
          });
          const file = new File([blob], fileName, {
            type: mimeType || 'application/pdf',
          });

          // Create DataTransfer and set files
          const dataTransfer = new DataTransfer();
          dataTransfer.items.add(file);
          fileInput.files = dataTransfer.files;

          // Dispatch events
          fileInput.dispatchEvent(new Event('change', { bubbles: true }));
          fileInput.dispatchEvent(new Event('input', { bubbles: true }));

          console.log('[Content] File uploaded to:', inputSelector);
          sendResponse({ ok: true });
        } catch (e) {
          console.error('[Content] File upload error:', e);
          sendResponse({ ok: false, error: String(e) });
        }
      })();
      return true;
    }
    // Find and return file input selectors for resume/cover letter
    if (msg && msg.type === 'findFileInputs') {
      try {
        const fileInputs = [];
        for (const root of enumerateRoots(document)) {
          const inputs = Array.from(
            root.querySelectorAll('input[type="file"]') || []
          );
          for (const input of inputs) {
            if (isHidden(input)) continue;
            const label = resolveLabelForElement(root, input);
            const name = input.getAttribute('name') || '';
            const id = input.getAttribute('id') || '';
            const accept = input.getAttribute('accept') || '';
            const labelLower = (label || '').toLowerCase();
            const nameLower = (name || '').toLowerCase();

            // Determine file type based on label/name
            let fileType = 'unknown';
            if (
              labelLower.includes('resume') ||
              labelLower.includes('cv') ||
              nameLower.includes('resume') ||
              nameLower.includes('cv') ||
              labelLower.includes('application')
            ) {
              fileType = 'resume';
            } else if (
              labelLower.includes('cover') ||
              labelLower.includes('letter') ||
              labelLower.includes('motivation') ||
              nameLower.includes('cover')
            ) {
              fileType = 'cover_letter';
            }

            // Create a unique selector for this input
            let selector = '';
            if (id) {
              selector = `#${CSS.escape(id)}`;
            } else if (name) {
              selector = `input[type="file"][name="${CSS.escape(name)}"]`;
            } else {
              // Use index-based selector as fallback
              const allFileInputs = Array.from(
                root.querySelectorAll('input[type="file"]')
              );
              const idx = allFileInputs.indexOf(input);
              selector = `input[type="file"]:nth-of-type(${idx + 1})`;
            }

            fileInputs.push({
              selector,
              label,
              name,
              id,
              accept,
              fileType,
            });
          }
        }
        sendResponse({ ok: true, fileInputs });
      } catch (e) {
        sendResponse({ ok: false, error: String(e), fileInputs: [] });
      }
      return true;
    }
    if (msg && msg.type === 'rrRequestToken') {
      requestRRTokenFromHost();
      sendResponse({ ok: true });
      return true;
    }
    if (msg && msg.type === 'RR_EXTENSION_OPEN_PANEL_FAILED') {
      if (msg.reason === 'user_gesture_required') {
        const jobLabel =
          msg.jobTitle || msg.metadata?.jobTitle || msg.jobId || 'the jobs';
        const bannerText = `Get AI-assisted resumes & cover letters for ${jobLabel}. Click the Reverse Recruiting extension.`;
        console.warn(
          '[Content] Side panel open blocked by Chrome (user gesture required)'
        );
        showExtensionGestureBanner(bannerText);
        persistGesturePrompt({
          jobId: msg.jobId || '',
          jobTitle: jobLabel,
          externalJobUrl: msg.externalJobUrl || '',
          metadata: msg.metadata || {},
        });
      }
      return false;
    }
    if (msg && msg.type === 'RR_EXTENSION_OPEN_PANEL_SUCCESS') {
      clearGesturePrompt();
      return false;
    }
  });

  // Capture Supabase/Firebase token broadcasts from tracker page and persist for the extension.
  // Also respond when the tracker asks for the current token (so it can sign in even without #hash).
  try {
    window.addEventListener('message', async (event) => {
      try {
        const data = event && event.data;
        if (!data || typeof data !== 'object') return;

        if (data.type === 'SUPABASE_OAUTH_TOKEN') {
          const token = String(data.access_token || '').trim();
          if (!token) return;
          await persistRRToken(token);
          await setRRState({ authToken: token });
          return;
        }

        if (data.type === 'REQUEST_TRACKER_TOKEN') {
          const stored = await chrome.storage.sync.get(['firebaseSession']);
          let token = stored.firebaseSession?.access_token || '';
          if (!token) {
            const localToken = await chrome.storage.local
              .get('rrAuthToken')
              .catch(() => ({}));
            token = localToken?.rrAuthToken || '';
          }
          if (token) {
            window.postMessage(
              { type: 'TRACKER_TOKEN_RESPONSE', access_token: token },
              '*'
            );
          }
          return;
        }

        if (data.type === 'RR_EXTENSION_INIT') {
          console.log('[Content] ✅ RR_EXTENSION_INIT received - AUTO LOGIN', {
            origin: event.origin,
            hasToken: !!data.token || !!data.access_token,
            user: data.user || null,
            jobId: data.job_id || data.jobId || '',
            externalJobUrl:
              data.external_job_url || data.job_url || data.url || '',
            metadataKeys: Object.keys(data.metadata || {}),
          });
          const token =
            String(data.token || data.access_token || '').trim() || '';
          if (token) {
            await persistRRToken(token);
            console.log('[Content] ✅ Token persisted to storage');
          }
          const rrState = {
            authToken: token,
            user: data.user || null,
            jobId: data.job_id || data.jobId || '',
            extensionClientId: data.extension_client_id || data.client_id || '',
            externalJobUrl:
              data.external_job_url || data.job_url || data.url || '',
            metadata: data.metadata || {},
            source: data.source || 'reverse-recruiting',
          };
          await setRRState(rrState);
          console.log('[Content] ✅ RR state updated');

          try {
            const storageUpdate = {
              // Store rrIntegrationState for sidepanel's RRIntegration module
              rrIntegrationState: {
                authToken: token,
                user: data.user || null,
                jobId: rrState.jobId || '',
                externalJobUrl: rrState.externalJobUrl || '',
                metadata: rrState.metadata || {},
                source: rrState.source,
                updatedAt: Date.now(),
              },
              currentJob: {
                job_id: rrState.jobId || '',
                external_job_url: rrState.externalJobUrl || '',
                metadata: rrState.metadata || {},
                user: rrState.user || null,
                source: rrState.source,
                receivedAt: Date.now(),
              },
            };
            if (token) {
              storageUpdate.authToken = token;
              storageUpdate.rrAuthToken = token;
            }
            if (rrState.jobId || rrState.metadata?.jobTitle) {
              storageUpdate[GESTURE_PROMPT_KEY] = {
                jobId: rrState.jobId || '',
                jobTitle:
                  rrState.metadata?.jobTitle ||
                  rrState.metadata?.job_title ||
                  '',
                externalJobUrl: rrState.externalJobUrl || '',
                metadata: rrState.metadata || {},
                createdAt: Date.now(),
                pending: true,
              };
            }
            await chrome.storage.local.set(storageUpdate);
            console.log(
              '[Content] ✅ Stored auth + job context in local storage',
              {
                hasToken: !!token,
                userName: data.user?.name || 'N/A',
                userEmail: data.user?.email || 'N/A',
                jobId: storageUpdate.currentJob.job_id,
              }
            );
          } catch (storageError) {
            console.warn('[Content] Failed to store context:', storageError);
          }

          // Send explicit message to sidepanel to trigger auth refresh
          try {
            await chrome.runtime.sendMessage({
              type: 'rrIntegrationStateUpdated',
              payload: rrState,
            });
            console.log(
              '[Content] ✅ Sent rrIntegrationStateUpdated to sidepanel'
            );
          } catch (_) {}
          // Check if extension context is still valid before messaging
          if (!isExtensionContextValid()) {
            console.log(
              '[Content] Extension context invalidated, skipping panel open request'
            );
            return;
          }
          try {
            const response = await chrome.runtime.sendMessage({
              type: 'RR_EXTENSION_OPEN_PANEL',
              reason: 'rr_extension_init',
              jobId: rrState.jobId || '',
              externalJobUrl: rrState.externalJobUrl || '',
              metadata: rrState.metadata || {},
            });
            console.log('[Content] Requested side panel open', response);
          } catch (error) {
            // Only log if it's not an expected extension lifecycle error
            if (!isRecoverableExtensionError(error)) {
              console.warn(
                '[Content] Failed to request side panel open:',
                error?.message || error
              );
            }
          }
          return;
        }

        if (data.type === 'RR_EXTENSION_TOKEN') {
          const token = String(data.token || '').trim();
          if (token) {
            await persistRRToken(token);
            await setRRState({ authToken: token });
          }
        }
      } catch (error) {
        // Only log unexpected errors
        if (!isRecoverableExtensionError(error)) {
          console.warn('[Content] RR message handling failed:', error);
        }
      }
    });
  } catch (_) {}

  maybeShowQueuedGesturePrompt();

  // On page load, check for stored RR auth and notify sidepanel to auto-login
  // This handles the case when user clicked "Apply" from RR app and navigated to job page
  (async () => {
    console.log(
      '[Content] 🚀 Page load - checking for stored auth on:',
      window.location.href
    );
    try {
      if (!isExtensionContextValid()) {
        console.log('[Content] ❌ Extension context invalid, skipping');
        return;
      }

      const stored = await chrome.storage.local.get([
        'rrAuthToken',
        'authToken',
        'rrIntegrationState',
        'currentJob',
      ]);

      console.log('[Content] 📦 Raw storage check:', {
        rrAuthToken: stored?.rrAuthToken
          ? '✓ present (' + stored.rrAuthToken.slice(0, 20) + '...)'
          : '✗ missing',
        authToken: stored?.authToken ? '✓ present' : '✗ missing',
        rrIntegrationState: stored?.rrIntegrationState
          ? '✓ present'
          : '✗ missing',
        currentJob: stored?.currentJob ? '✓ present' : '✗ missing',
      });

      if (stored?.rrIntegrationState) {
        console.log('[Content] 📦 rrIntegrationState details:', {
          hasAuthToken: !!stored.rrIntegrationState.authToken,
          userEmail: stored.rrIntegrationState.user?.email || 'N/A',
          jobId: stored.rrIntegrationState.jobId || 'N/A',
        });
      }

      const token =
        stored?.rrAuthToken ||
        stored?.authToken ||
        stored?.rrIntegrationState?.authToken;
      const rrState = stored?.rrIntegrationState;
      const currentJob = stored?.currentJob;

      if (token) {
        console.log('[Content] ✅ Found stored RR auth token');

        // Build state from storage
        const state = {
          authToken: token,
          user: rrState?.user || currentJob?.user || null,
          jobId: rrState?.jobId || currentJob?.job_id || '',
          externalJobUrl:
            rrState?.externalJobUrl || currentJob?.external_job_url || '',
          metadata: rrState?.metadata || currentJob?.metadata || {},
          source: rrState?.source || currentJob?.source || 'reverse-recruiting',
        };

        console.log('[Content] 🔄 Sending to sidepanel:', {
          tokenPreview: token.slice(0, 25) + '...',
          userEmail: state.user?.email || 'N/A',
          jobId: state.jobId || 'N/A',
        });

        // Notify sidepanel to auto-login
        try {
          await chrome.runtime.sendMessage({
            type: 'rrIntegrationStateUpdated',
            payload: state,
          });
          console.log(
            '[Content] ✅ Sent rrIntegrationStateUpdated to sidepanel'
          );
        } catch (err) {
          if (!isRecoverableExtensionError(err)) {
            console.warn('[Content] Failed to notify sidepanel:', err);
          } else {
            console.log(
              '[Content] ℹ️ Sidepanel may not be open yet (this is normal)'
            );
          }
        }
      } else {
        console.log('[Content] ⚠️ No stored token found in any location');
        requestRRTokenFromHost();
      }
    } catch (err) {
      if (!isRecoverableExtensionError(err)) {
        console.warn('[Content] Init auth check failed:', err);
      }
    }
  })();
})();
