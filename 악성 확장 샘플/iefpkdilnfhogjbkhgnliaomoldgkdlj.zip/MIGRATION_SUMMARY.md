# Migration & Integration Summary

## What We've Done

### 1. ✅ Migration Plan Created

- **From**: Supabase (Database + Auth + Storage)
- **To**: Google Cloud Platform
  - Cloud SQL (PostgreSQL) for database
  - Identity Platform (Firebase Auth) for authentication
  - Cloud Storage for file uploads

### 2. ✅ Backend Code Updated

- Created `lib/db.ts` - Cloud SQL connection with connection pooling
- Created `lib/firebase-admin.ts` - Firebase Admin SDK for auth & storage
- Updated `app/api/v1/profile/sync/route.ts` - Uses Cloud SQL queries instead of Supabase client
- Updated `package.json` - Replaced Supabase deps with Firebase Admin, pg, @google-cloud/storage

### 3. ✅ Frontend Auth Client Created

- Created `firebase-auth.js` - Drop-in replacement for Supabase Auth
- Maintains same API surface: `signUpWithEmail`, `signInWithEmail`, `getSession`, etc.
- Uses Firebase SDK from CDN

### 4. ✅ Setup Documentation

- `MIGRATION_TO_GCP.md` - Complete migration guide with phases
- `GCP_SETUP_COMMANDS.md` - Step-by-step terminal commands to set everything up
- `REVERSE_RECRUITING_INTEGRATION.md` - Integration contract between Reverse Recruiting and extension

---

## Next Steps for You

### Immediate (Required for Migration)

**1. Set Up Cloud SQL**

```bash
# Run these commands from GCP_SETUP_COMMANDS.md
gcloud config set project YOUR_PROJECT_ID
gcloud services enable sqladmin.googleapis.com identitytoolkit.googleapis.com storage.googleapis.com

# Create database
gcloud sql instances create jobapai-db --database-version=POSTGRES_15 --tier=db-f1-micro --region=us-south1

# Run schema
# (See GCP_SETUP_COMMANDS.md Step 4)
```

**2. Set Up Firebase Auth**

```bash
# Enable Identity Platform
gcloud services enable identitytoolkit.googleapis.com

# Configure via Firebase Console
# 1. Go to https://console.firebase.google.com
# 2. Enable Email/Password provider
# 3. Get Firebase config for frontend
# 4. Update firebase-auth.js with your config
```

**3. Update Environment Variables**

```bash
# Set in Cloud Run
gcloud run services update jobapai \
  --region=us-south1 \
  --set-env-vars="DB_HOST=/cloudsql/YOUR_PROJECT:us-south1:jobapai-db" \
  --set-env-vars="DB_USER=jobapai-app" \
  --set-env-vars="DB_NAME=jobapai" \
  --update-secrets=DB_PASSWORD=db-password:latest \
  --add-cloudsql-instances=YOUR_PROJECT:us-south1:jobapai-db
```

**4. Deploy Backend**

```bash
cd vercel-backend
npm install
npm run build
# Deploy via Cloud Run (see GCP_SETUP_COMMANDS.md Step 9)
```

**5. Update Extension Frontend**
Replace all Supabase auth calls with Firebase:

```javascript
// Old
import { supabase } from './supabase-global.js';
const { data, error } = await supabase.auth.signInWithPassword({
  email,
  password,
});

// New
import { signInWithEmail } from './firebase-auth.js';
const { user, session, error } = await signInWithEmail(email, password);
```

### For Reverse Recruiting Integration

**Read:** `REVERSE_RECRUITING_INTEGRATION.md`

**Summary of what their team needs:**

**Data to Send to Extension:**

```javascript
{
  type: 'REVERSE_RECRUITING_APPLY',
  token: '<firebase_id_token>',
  userProfile: { /* all user data */ },
  job: { /* job details, description, requirements */ },
  settings: {
    auto_generate_resume: true,
    auto_generate_cover_letter: true,
    callback_url: 'https://your-api.com/api/v1/applications/:jobId/status'
  }
}
```

**Data Extension Will Send Back:**

```javascript
POST {callback_url}
{
  job_id: "job-456",
  status: "submitted",
  resume: {
    url: "https://storage.googleapis.com/...",
    file_name: "Jane_Smith_Resume.pdf"
  },
  cover_letter: {
    url: "https://storage.googleapis.com/...",
    file_name: "Jane_Smith_Cover_Letter.pdf"
  },
  auto_fill: {
    fields_total: 15,
    fields_filled: 14,
    fill_percentage: 93
  },
  metadata: { /* timing, tokens, models used */ }
}
```

---

## Cost Estimate (Monthly)

### Supabase (Current)

- Pro Plan: **$25/month**

### Google Cloud (After Migration)

- Cloud SQL (db-f1-micro): **$7-10**
- Cloud Run (existing): **$5-10**
- Cloud Storage: **<$1**
- Identity Platform: **Free** (up to 50k users)
- Secrets Manager: **<$1**

**Total: ~$15-25/month** (similar or cheaper, with more control)

---

## Testing Plan

**Phase 1: Database**

- [ ] Cloud SQL instance created
- [ ] Schema deployed
- [ ] Proxy connection works locally
- [ ] Queries from Cloud Run work

**Phase 2: Auth**

- [ ] Firebase Auth enabled
- [ ] Signup works from extension
- [ ] Login works from extension
- [ ] Token verification works in backend

**Phase 3: Storage**

- [ ] Cloud Storage bucket created
- [ ] CORS configured
- [ ] File upload works
- [ ] Signed URLs accessible from extension

**Phase 4: Integration**

- [ ] Profile sync works (GET/POST)
- [ ] Custom answers save
- [ ] Employment history saves
- [ ] CV upload and retrieval works

**Phase 5: End-to-End**

- [ ] Complete onboarding flow
- [ ] Job application with AI
- [ ] Resume generation and download
- [ ] Cover letter generation

---

## Files to Review

1. **MIGRATION_TO_GCP.md** - Complete migration strategy
2. **GCP_SETUP_COMMANDS.md** - Copy-paste commands for setup
3. **REVERSE_RECRUITING_INTEGRATION.md** - Integration contract
4. **vercel-backend/lib/db.ts** - Database connection module
5. **vercel-backend/lib/firebase-admin.ts** - Auth & storage module
6. **vercel-backend/app/api/v1/profile/sync/route.ts** - Updated API route
7. **firebase-auth.js** - Frontend auth client

---

## Questions to Resolve

**Before Migration:**

1. What's your Google Cloud project ID?
2. What region do you prefer? (currently us-south1)
3. Do you want to keep data in Supabase temporarily during migration?

**For Reverse Recruiting:**

1. What's their API base URL?
2. Will they use `chrome.runtime.sendMessage` or `window.postMessage`?
3. Do they need real-time status updates or just final status?
4. What's their authentication flow? (shared Firebase project or separate?)

---

## Support During Migration

If you encounter issues:

1. Check logs: `gcloud run logs read --service=jobapai --region=us-south1`
2. Test database: `cloud-sql-proxy YOUR_CONNECTION_NAME` + `psql`
3. Verify IAM: Service account needs `cloudsql.client` and `secretmanager.secretAccessor`
4. Check CORS: Extension must be in allowed origins

---

**Ready to proceed? Start with GCP_SETUP_COMMANDS.md Step 1! 🚀**

