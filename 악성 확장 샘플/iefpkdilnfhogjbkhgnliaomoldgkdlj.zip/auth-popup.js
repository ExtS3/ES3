/* auth-popup.js
 * NOTE: Must be external (no inline script) to comply with MV3 CSP.
 */

(() => {
  const log = (...args) => console.log('[Auth Popup]', ...args);
  const warn = (...args) => console.warn('[Auth Popup]', ...args);
  const errLog = (...args) => console.error('[Auth Popup]', ...args);

  // Firebase configuration (public)
  const firebaseConfig = {
    apiKey: 'AIzaSyCCNJxco3gHrlaqi0XfKRAFpM1jUDPrbiQ',
    authDomain: 'reverse-recruiting-backend.firebaseapp.com',
    projectId: 'reverse-recruiting-backend',
    storageBucket: 'reverse-recruiting-backend.firebasestorage.app',
    messagingSenderId: '142692177063',
    appId: '1:142692177063:web:0f72c7e5c9c9d77a85b782',
    measurementId: 'G-Q8333PY0SV',
  };

  async function loadCallbackUrl() {
    // Use API route for auth callback (more reliable than page route)
    let callbackUrl = 'https://159.203.120.48.nip.io/rrext/api/auth-callback';
    try {
      const configRes = await fetch(chrome.runtime.getURL('config.json'));
      const config = await configRes.json();
      if (config?.apiBaseUrl) {
        // Use the API base URL directly and append /auth-callback
        const base = String(config.apiBaseUrl).replace(/\/$/, '');
        callbackUrl = `${base}/auth-callback`;
      }
    } catch (e) {
      warn('Could not load config, using default callback URL');
    }
    return callbackUrl;
  }

  function showError(message) {
    try {
      const el = document.getElementById('error');
      if (!el) return;
      el.textContent = `Error: ${message}`;
      el.style.display = 'block';
    } catch (_) {}
  }

  async function run() {
    log('Script loaded');

    try {
      if (typeof firebase === 'undefined') {
        throw new Error('Firebase SDK not loaded');
      }

      if (!firebase.apps || firebase.apps.length === 0) {
        firebase.initializeApp(firebaseConfig);
        log('Firebase initialized');
      }
      const auth = firebase.auth();

      // Check for redirect result first (if returning from OAuth redirect)
      log('Checking for redirect result...');
      const redirectResult = await auth.getRedirectResult();

      if (redirectResult?.user) {
        log('User authenticated via redirect');
        const idToken = await redirectResult.user.getIdToken();

        // Store session in Chrome storage (do not log token)
        await chrome.storage.sync.set({
          firebaseSession: {
            access_token: idToken,
            user: {
              id: redirectResult.user.uid,
              email: redirectResult.user.email,
            },
          },
        });

        // Send result back to opener
        try {
          if (window.opener) {
            window.opener.postMessage(
              {
                type: 'FIREBASE_AUTH_RESULT',
                user: {
                  id: redirectResult.user.uid,
                  email: redirectResult.user.email,
                  email_verified: redirectResult.user.emailVerified,
                  displayName: redirectResult.user.displayName,
                  photoURL: redirectResult.user.photoURL,
                },
                session: {
                  access_token: idToken,
                  user: redirectResult.user,
                },
              },
              '*'
            );
          }
        } catch (_) {}

        setTimeout(() => window.close(), 500);
        return;
      }

      // No redirect result - initiate sign-in with redirect
      log('No redirect result, initiating sign-in...');
      const provider = new firebase.auth.GoogleAuthProvider();
      provider.addScope('email');
      provider.addScope('profile');

      const callbackUrl = await loadCallbackUrl();
      provider.setCustomParameters({
        redirect_uri: callbackUrl,
      });

      await chrome.storage.local.set({
        firebaseAuthCallbackUrl: callbackUrl,
        firebaseAuthPending: true,
      });

      log('Calling signInWithRedirect');
      await auth.signInWithRedirect(provider);
    } catch (error) {
      errLog('Error:', error);
      const errorMsg = error?.message || error?.code || 'Sign-in failed';
      showError(errorMsg);
      try {
        if (window.opener) {
          window.opener.postMessage(
            {
              type: 'FIREBASE_AUTH_RESULT',
              error: errorMsg,
            },
            '*'
          );
        }
      } catch (_) {}
      setTimeout(() => window.close(), 5000);
    }
  }

  // Ensure DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }
})();
