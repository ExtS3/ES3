import {
  getUserProfile,
  saveUserProfile,
  extractProfileFromCV,
} from './profile-utils.js';
import { syncProfileToDatabase } from './profile-sync.js';

// Configure PDF.js worker
if (typeof pdfjsLib !== 'undefined') {
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdfjs/pdf.worker.min.js';
}

function $(id) {
  return document.getElementById(id);
}

// Common interview questions (must match profile-setup.html data-question attributes)
const COMMON_QUESTIONS = [
  'Tell me about yourself',
  'Greatest strength',
  'Greatest weakness',
  'Why this company?',
  'Most challenging project',
  'Conflict with teammate',
  'Leadership example',
  'Failure and learning',
  'Time you improved a process',
  'Handling tight deadlines',
  'Explain a complex topic',
  'Preferred work environment',
];

function resolveProfileApiBase(cfg) {
  return (
    cfg?.rrApiBaseUrl ||
    cfg?.rrProductionApiBaseUrl ||
    cfg?.activeRrBaseUrl ||
    ''
  ).replace(/\/$/, '');
}

async function loadProfile() {
  // Try backend first; fall back to local
  let profile = null;
  try {
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await resp.json();
    const base = resolveProfileApiBase(cfg);
    
    // Get auth token - prioritize RR token
    const storage = await chrome.storage.sync.get(['firebaseSession']);
    const localStorage = await chrome.storage.local.get(['rrAuthToken', 'rrIntegrationState']);
    
    let token = '';
    // Priority 1: RR Integration State (from dashboard)
    if (localStorage.rrIntegrationState?.authToken) {
      token = localStorage.rrIntegrationState.authToken;
    }
    // Priority 2: Direct RR Auth Token
    else if (localStorage.rrAuthToken) {
      token = localStorage.rrAuthToken;
    }
    // Priority 3: Firebase Session
    else if (storage.firebaseSession?.access_token) {
      token = storage.firebaseSession.access_token;
    }
    
    if (token) {
      // Try RR /api/auth/me first
      if (cfg.rrApiBaseUrl || cfg.rrProductionApiBaseUrl) {
        console.log('[Profile] Attempting to fetch from /api/auth/me');
        try {
          const RR_API_BASE = 'https://api.reverserecruiting.io';
          const r = await fetch(`${RR_API_BASE}/api/auth/me`, {
            method: 'GET',
            headers: { 
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json'
            },
            credentials: 'include',
          });
          
          if (r.ok) {
            const response = await r.json();
            console.log('[Profile] Successfully loaded from /api/auth/me');
            
            // Extract data from response wrapper
            const p = response.data || response;
            
            // Convert /api/auth/me response to local editor shape
            profile = {
              essential: {
                fullName: p.name || '',
                email: p.email || '',
                phone: p.phoneNumber || '', // API uses phoneNumber, not phone
                location: (p.preferredLocations && p.preferredLocations[0]) || '',
                linkedIn: p.linkedinUrl || '',
                portfolio: p.portfolioUrl || '',
                github: p.githubUrl || '',
                workAuthorization: '',
                securityClearance: '',
              },
              preferences: {
                jobTypes: p.workType || [], // ["remote", "hybrid", "onsite"]
                expectedSalaryMin: p.minSalary || '',
                expectedSalaryMax: '',
                willingToRelocate: '',
              },
              skills: {
                topSkills: p.keywords || [], // keywords array
                education: {
                  highestDegree: '',
                  fieldOfStudy: '',
                  university: '',
                  graduationYear: '',
                },
                yearsExperience: { total: 0 }, // Derive from experienceLevel if needed
              },
              professional: {
                currentRole: (p.targetRole && p.targetRole[0]) || '',
                summary: p.resumeSummary || '',
              },
              metadata: {
                experienceLevel: p.experienceLevel || '',
                status: p.status || '',
                userId: p.id || '',
              },
            };
            
            console.log('[Profile] Mapped data:', {
              name: profile.essential.fullName,
              email: profile.essential.email,
              targetRoles: p.targetRole?.length || 0,
              locations: p.preferredLocations?.length || 0,
              keywords: p.keywords?.length || 0,
            });
            
            // Store raw parsed CV text (resume_text or cv_text) instead of summary
            // resume_text/cv_text contains the full parsed CV text, resumeSummary is just a summary
            const rawCvText = p.resume_text || p.cv_text || p.resumeSummary || '';
            if (rawCvText) {
              await chrome.storage.local.set({ userCV: rawCvText });
              console.log('[Profile] Stored CV text from:', 
                p.resume_text ? 'resume_text' : p.cv_text ? 'cv_text' : 'resumeSummary (fallback)',
                `(${rawCvText.length} characters)`
              );
            }
          } else {
            console.warn('[Profile] /api/auth/me failed:', r.status);
          }
        } catch (err) {
          console.warn('[Profile] Error fetching /api/auth/me:', err);
        }
      }
      
      // Fallback to legacy endpoint if no profile yet
      if (!profile && base) {
        try {
          const r = await fetch(`${base}/v1/profile/sync`, {
            method: 'GET',
            headers: { Authorization: `Bearer ${token}` },
            credentials: 'include',
          });
          if (r.ok) {
            const data = await r.json();
            const p = data?.profile || {};
            // Convert DB shape to local editor shape
            profile = {
              essential: {
                fullName: p.full_name || '',
                email: p.email || '',
                phone: p.phone || '',
                location: p.location || '',
                linkedIn: p.linkedin_url || '',
                portfolio: p.portfolio_url || '',
                github: p.github_url || '',
                workAuthorization: p.work_authorization || '',
                securityClearance: p.security_clearance || '',
              },
              preferences: {
                jobTypes: p.job_types || [],
                expectedSalaryMin: p.expected_salary_min || '',
                expectedSalaryMax: p.expected_salary_max || '',
                willingToRelocate: p.willing_to_relocate || '',
              },
              skills: {
                topSkills: p.top_skills || [],
                education: {
                  highestDegree: p.highest_degree || '',
                  fieldOfStudy: p.field_of_study || '',
                  university: p.university || '',
                  graduationYear: p.graduation_year || '',
                },
                yearsExperience: { total: p.years_total_experience || 0 },
              },
              professional: {
                currentRole: p.current_job_title || '',
                summary: p.professional_summary || '',
              },
              metadata: {},
            };
            // Store raw CV for re-upload preview/use
            if (p.cv_text) {
              await chrome.storage.local.set({ userCV: p.cv_text });
            }
          }
        } catch (_) {}
      }
    }
  } catch (_) {}

  if (!profile) profile = (await getUserProfile()) || {};

  const essential = profile.essential || {};
  $('p_fullName').value = essential.fullName || '';
  $('p_email').value = essential.email || '';
  $('p_phone').value = essential.phone || '';
  $('p_location').value = essential.location || '';
  $('p_linkedIn').value = essential.linkedIn || '';
  $('p_portfolio').value = essential.portfolio ?? essential.portfolioUrl ?? '';
  $('p_github').value = essential.github ?? essential.githubUrl ?? '';
  $('p_workAuth').value = essential.workAuthorization || '';
  $('p_clearance').value = essential.securityClearance || '';

  const skills = profile.skills || {};
  $('p_skills').value = (skills.topSkills || []).join(', ');
  $('p_degree').value = skills.education?.highestDegree || '';
  $('p_major').value = skills.education?.fieldOfStudy || '';
  $('p_university').value = skills.education?.university || '';
  $('p_gradYear').value = skills.education?.graduationYear || '';
  $('p_yearsExp').value = skills.yearsExperience?.total || 0;

  const prefs = profile.preferences || {};
  $('p_jobTypes').value = (prefs.jobTypes || []).join(', ');
  $('p_salaryMin').value = prefs.expectedSalaryMin || '';
  $('p_salaryMax').value = prefs.expectedSalaryMax || '';
  $('p_relocate').value = prefs.willingToRelocate || '';

  const prof = profile.professional || {};
  $('p_currentRole').value = prof.currentRole || '';
  $('p_summary').value = prof.summary || '';

  // Load resume if available
  await loadResume();

  // Sync interview questions from database, then load them
  await syncInterviewQuestionsFromDatabase();
  await loadInterviewQuestions();
}

async function saveProfile() {
  const jobTypes = $('p_jobTypes')
    .value.split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const skills = $('p_skills')
    .value.split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  // Collect interview answers
  const interviewAnswers = {};
  COMMON_QUESTIONS.forEach((q, idx) => {
    const input = document.getElementById(`q_${idx}`);
    if (input && input.value.trim()) {
      interviewAnswers[q] = input.value.trim();
    }
  });

  const profile = {
    version: '1.0',
    essential: {
      fullName: $('p_fullName').value.trim(),
      email: $('p_email').value.trim(),
      phone: $('p_phone').value.trim(),
      location: $('p_location').value.trim(),
      linkedIn: $('p_linkedIn').value.trim(),
      portfolio: $('p_portfolio').value.trim(),
      github: $('p_github').value.trim(),
      workAuthorization: $('p_workAuth').value.trim(),
      securityClearance: $('p_clearance').value.trim(),
    },
    preferences: {
      jobTypes,
      expectedSalaryMin: $('p_salaryMin').value.trim(),
      expectedSalaryMax: $('p_salaryMax').value.trim(),
      willingToRelocate: $('p_relocate').value.trim(),
    },
    skills: {
      topSkills: skills,
      certifications: [],
      yearsExperience: {
        total: parseInt($('p_yearsExp').value || '0', 10) || 0,
      },
      education: {
        highestDegree: $('p_degree').value.trim(),
        fieldOfStudy: $('p_major').value.trim(),
        university: $('p_university').value.trim(),
        graduationYear: $('p_gradYear').value.trim(),
      },
    },
    commonAnswers: interviewAnswers,
    professional: {
      summary: $('p_summary').value.trim(),
      currentRole: $('p_currentRole').value.trim(),
    },
    metadata: {
      createdAt: Date.now(),
      lastUpdated: Date.now(),
      completeness: 0,
      source: 'manual',
    },
  };

  const ok = await saveUserProfile(profile);

  // Save interview answers to local storage
  await chrome.storage.local.set({ customAnswers: interviewAnswers });

  let syncError = null;
  if (ok) {
    try {
      const syncResult = await syncProfileToDatabase();
      if (!syncResult.success) {
        syncError = syncResult.error || 'Sync failed';
      }
    } catch (e) {
      syncError = e?.message || String(e);
      console.error('[Profile] Backend sync failed (will retry later):', e);
    }
  }
  const status = document.getElementById('saveStatus');
  if (ok && !syncError) {
    status.textContent = 'Saved ✅';
    status.className = 'save-status success';
    status.style.display = 'block';
    setTimeout(() => {
      status.style.display = 'none';
    }, 2000);
  } else if (ok && syncError) {
    status.textContent = 'Saved locally. Sync will retry automatically.';
    status.className = 'save-status';
    status.style.display = 'block';
    setTimeout(() => {
      status.style.display = 'none';
    }, 3000);
  } else {
    status.textContent = 'Save failed';
    status.className = 'save-status error';
    status.style.display = 'block';
  }
}

// Load resume from storage
async function loadResume() {
  const { userCV } = await chrome.storage.local.get('userCV');
  if (userCV) {
    $('resumeCard').style.display = 'block';
    $('uploadZone').style.display = 'none';
    $('resumeFileName').textContent = 'Resume';
    const words = userCV.split(/\s+/).length;
    $('resumeFileSize').textContent = `${words} words • Uploaded`;
    $('resumeTextPreview').textContent =
      userCV.substring(0, 1000) + (userCV.length > 1000 ? '...' : '');
  }
}

// Sync interview questions from Supabase database
async function syncInterviewQuestionsFromDatabase() {
  try {
    console.log('[Profile] Syncing interview questions...');

    // Get auth token - prioritize RR token
    const storage = await chrome.storage.sync.get(['firebaseSession']);
    const localStorage = await chrome.storage.local.get(['rrAuthToken', 'rrIntegrationState']);
    
    let token = '';
    // Priority 1: RR Integration State (from dashboard)
    if (localStorage.rrIntegrationState?.authToken) {
      token = localStorage.rrIntegrationState.authToken;
    }
    // Priority 2: Direct RR Auth Token
    else if (localStorage.rrAuthToken) {
      token = localStorage.rrAuthToken;
    }
    // Priority 3: Firebase Session
    else if (storage.firebaseSession?.access_token) {
      token = storage.firebaseSession.access_token;
    }

    if (!token) {
      console.log('[Profile] No auth token, skipping sync');
      return;
    }

    const respCfg = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await respCfg.json();
    const base = resolveProfileApiBase(cfg);

    let customAnswers = [];

    // Try RR /api/auth/me first
    if (cfg.rrApiBaseUrl || cfg.rrProductionApiBaseUrl) {
      console.log('[Profile] Fetching interview questions from /api/auth/me');
      try {
        const RR_API_BASE = 'https://api.reverserecruiting.io';
        const res = await fetch(`${RR_API_BASE}/api/auth/me`, {
          method: 'GET',
          headers: { 
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          credentials: 'include',
        });

        if (res.ok) {
          const data = await res.json();
          customAnswers = data?.custom_answers || [];
          console.log(`[Profile] Fetched ${customAnswers.length} interview questions from /api/auth/me`);
        } else {
          console.warn('[Profile] /api/auth/me failed:', res.status);
        }
      } catch (err) {
        console.warn('[Profile] Error fetching /api/auth/me:', err);
      }
    }

    // Fallback to legacy endpoint if no answers yet
    if (customAnswers.length === 0 && base) {
      console.log('[Profile] Trying legacy endpoint...');
      try {
        const res = await fetch(`${base}/v1/profile/sync`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        if (!res.ok) {
          console.warn('[Profile] Legacy endpoint failed:', res.status);
          return;
        }
        
        const data = await res.json();
        customAnswers = data?.customAnswers || [];
        console.log(`[Profile] Fetched ${customAnswers.length} interview questions from legacy endpoint`);
      } catch (err) {
        console.warn('[Profile] Error fetching from legacy endpoint:', err);
        return;
      }
    }

    if (customAnswers.length === 0) {
      console.log('[Profile] No interview questions found');
      return;
    }

    console.log(
      `[Profile] Synced ${customAnswers.length} interview questions`
    );

    // Convert array format to object format for local storage
    const answersMap = {};
    customAnswers.forEach((a) => {
      if (a.question_text && a.answer_text) {
        answersMap[a.question_text] = a.answer_text;
      }
    });

    // Save to local storage
    await chrome.storage.local.set({ customAnswers: answersMap });
    console.log('[Profile] Interview questions saved to local storage');
  } catch (error) {
    console.warn('[Profile] Error syncing interview questions:', error);
  }
}

// Helper: normalize question labels for comparison
function normalizeQuestionLabel(label) {
  return String(label || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

// Labels that correspond to basic profile fields already shown above.
// We keep their answers in storage/DB but hide them from the Interview section UI
// to avoid duplicate fields like Email / Phone / Full Name.
const BASIC_PROFILE_QUESTION_LABELS = new Set([
  'full name',
  'name',
  'email',
  'email address',
  'phone',
  'phone number',
  'phone number include country code xxx',
  'phone number include country code',
  'location',
]);

function isBasicProfileQuestion(label) {
  const norm = normalizeQuestionLabel(label);
  return BASIC_PROFILE_QUESTION_LABELS.has(norm);
}

// Map normalized question labels -> Essential Information input IDs
const BASIC_PROFILE_ANSWER_TARGETS = {
  'full name': 'p_fullName',
  name: 'p_fullName',
  email: 'p_email',
  'email address': 'p_email',
  phone: 'p_phone',
  'phone number': 'p_phone',
  'phone number include country code xxx': 'p_phone',
  'phone number include country code': 'p_phone',
  location: 'p_location',
};

// Apply basic profile answers (from custom interview answers) into Essential Information
// without overwriting any fields the user has already filled.
function applyBasicProfileFromAnswers(answers) {
  try {
    if (!answers || typeof answers !== 'object') return;

    // Build normalized map of question label -> answer
    const normMap = new Map();
    Object.entries(answers).forEach(([question, answer]) => {
      const norm = normalizeQuestionLabel(question);
      if (!norm) return;
      if (!answer) return;
      if (!normMap.has(norm)) {
        normMap.set(norm, String(answer));
      }
    });

    Object.entries(BASIC_PROFILE_ANSWER_TARGETS).forEach(
      ([normLabel, inputId]) => {
        const ans = normMap.get(normLabel);
        if (!ans) return;
        const input = $(inputId);
        if (!input) return;
        if (!input.value || !String(input.value).trim()) {
          input.value = ans;
        }
      }
    );
  } catch (e) {
    console.error('[Profile] Error applying basic profile answers:', e);
  }
}

// Load interview questions from local storage
async function loadInterviewQuestions() {
  const { customAnswers } = await chrome.storage.local.get('customAnswers');
  const answers = customAnswers || {};

  const container = $('interviewQuestionsContainer');
  container.innerHTML = '';

  if (Object.keys(answers).length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>No interview questions answered yet.</p>
        <p>Complete the onboarding to add common interview questions.</p>
      </div>
    `;
    return;
  }

  // First, apply any basic profile answers (Full Name, Email, Phone, Location)
  // into the Essential Information section without overwriting existing values.
  applyBasicProfileFromAnswers(answers);

  // Load common questions first (from COMMON_QUESTIONS array)
  let loadedCount = 0;
  COMMON_QUESTIONS.forEach((question, idx) => {
    if (answers[question]) {
      const item = document.createElement('div');
      item.className = 'question-item';

      const label = document.createElement('div');
      label.className = 'question-label';
      label.textContent = question;

      const textarea = document.createElement('textarea');
      textarea.id = `q_${idx}`;
      textarea.className = 'question-input';
      textarea.placeholder = 'Your answer...';
      textarea.value = answers[question];

      item.appendChild(label);
      item.appendChild(textarea);
      container.appendChild(item);
      loadedCount++;
    }
  });

  // Load any additional questions not in COMMON_QUESTIONS (custom questions)
  Object.entries(answers).forEach(([question, answer], idx) => {
    if (!answer) return;
    // Skip basic profile questions (Full Name, Email, Phone, Location, etc.)
    if (isBasicProfileQuestion(question)) return;
    if (!COMMON_QUESTIONS.includes(question)) {
      const item = document.createElement('div');
      item.className = 'question-item';

      const label = document.createElement('div');
      label.className = 'question-label';
      label.textContent = question;
      label.style.fontStyle = 'italic'; // Indicate custom question

      const textarea = document.createElement('textarea');
      textarea.id = `q_custom_${idx}`;
      textarea.className = 'question-input';
      textarea.placeholder = 'Your answer...';
      textarea.value = answer;

      item.appendChild(label);
      item.appendChild(textarea);
      container.appendChild(item);
      loadedCount++;
    }
  });

  console.log(
    `[Profile] Loaded ${loadedCount} interview questions to UI (${
      Object.keys(answers).length
    } total in storage, basic-profile questions hidden from UI)`
  );
}

// Resume upload (analyze with Gemini 2.5 Flash Lite and sync)
async function handleResumeUpload(file) {
  try {
    // Show loading state
    const status = $('saveStatus');
    status.textContent = 'Processing resume...';
    status.className = 'save-status';
    status.style.display = 'block';
    status.style.background = 'var(--brand-light)';
    status.style.color = 'var(--brand-primary)';

    const arrayBuffer = await file.arrayBuffer();
    let text = '';
    // Use PDF.js if available for PDF
    if (file.type === 'application/pdf' && typeof pdfjsLib !== 'undefined') {
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const tc = await page.getTextContent();
        text += tc.items.map((it) => it.str).join(' ') + '\n';
      }
    } else {
      text = new TextDecoder().decode(arrayBuffer);
    }

    // Persist raw CV
    await chrome.storage.local.set({ userCV: text });

    // Update UI
    await loadResume();

    // Extract with backend using Gemini 2.5 Flash Lite
    const respCfg = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await respCfg.json();
    const base = resolveProfileApiBase(cfg);
    const profileExtracted = await extractProfileFromCV(
      text,
      base,
      'gemini-2.5-flash-lite'
    );

    // Update inputs
    if (profileExtracted.fullName)
      $('p_fullName').value = profileExtracted.fullName;
    if (profileExtracted.email) $('p_email').value = profileExtracted.email;
    if (profileExtracted.phone) $('p_phone').value = profileExtracted.phone;
    if (profileExtracted.location)
      $('p_location').value = profileExtracted.location;
    if (profileExtracted.linkedIn)
      $('p_linkedIn').value = profileExtracted.linkedIn;
    if (profileExtracted.portfolioUrl)
      $('p_portfolio').value = profileExtracted.portfolioUrl;
    if (profileExtracted.githubUrl)
      $('p_github').value = profileExtracted.githubUrl;
    if (Array.isArray(profileExtracted.topSkills))
      $('p_skills').value = profileExtracted.topSkills.join(', ');
    if (profileExtracted.currentJobTitle)
      $('p_currentRole').value = profileExtracted.currentJobTitle;
    if (profileExtracted.yearsExperience)
      $('p_yearsExp').value = profileExtracted.yearsExperience;
    if (profileExtracted.highestDegree)
      $('p_degree').value = profileExtracted.highestDegree;
    if (profileExtracted.fieldOfStudy)
      $('p_major').value = profileExtracted.fieldOfStudy;
    if (profileExtracted.university)
      $('p_university').value = profileExtracted.university;
    if (profileExtracted.graduationYear)
      $('p_gradYear').value = profileExtracted.graduationYear;

    // Save + backend sync
    await saveProfile();

    status.textContent = 'Resume processed ✅';
    status.className = 'save-status success';
    setTimeout(() => {
      status.style.display = 'none';
    }, 2000);
  } catch (e) {
    console.error('[Profile] Resume upload failed:', e);
    const status = $('saveStatus');
    status.textContent = 'Upload failed';
    status.className = 'save-status error';
    status.style.display = 'block';
  }
}

// Setup resume upload handlers
function setupResumeHandlers() {
  const uploadZone = $('uploadZone');
  const resumeInput = $('resumeInput');
  const btnViewResume = $('btnViewResume');
  const btnChangeResume = $('btnChangeResume');

  // Click to upload
  uploadZone.addEventListener('click', () => resumeInput.click());

  // Drag and drop
  uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.classList.add('dragover');
  });

  uploadZone.addEventListener('dragleave', () => {
    uploadZone.classList.remove('dragover');
  });

  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    const file = e.dataTransfer.files[0];
    if (file) handleResumeUpload(file);
  });

  // File input change
  resumeInput.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (file) handleResumeUpload(file);
  });

  // View resume text
  btnViewResume.addEventListener('click', () => {
    const preview = $('resumeTextPreview');
    if (preview.style.display === 'none') {
      preview.style.display = 'block';
      btnViewResume.textContent = 'Hide Text';
    } else {
      preview.style.display = 'none';
      btnViewResume.textContent = 'View Text';
    }
  });

  // Change resume
  btnChangeResume.addEventListener('click', () => {
    resumeInput.click();
  });
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  setupResumeHandlers();
  loadProfile();
});

document.getElementById('btnSave').addEventListener('click', saveProfile);
document
  .getElementById('btnClose')
  .addEventListener('click', () => window.close());

document.getElementById('btnLogout').addEventListener('click', async () => {
  try {
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await resp.json();
    const base = resolveProfileApiBase(cfg);

    // Best-effort revoke server session if token exists
    const storage = await chrome.storage.sync.get(['firebaseSession']);
    const token = storage.firebaseSession?.access_token || '';
    if (token && base) {
      await fetch(`${base}/v1/auth/logout`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        credentials: 'include',
      }).catch(() => {});
    }

    // Clear local auth/session related items
    await chrome.storage.sync.remove(['firebaseSession']);
    await chrome.storage.local.remove([
      'userProfile',
      'employmentHistory',
      'customAnswers',
      'userCV',
      'lastProfileSync',
      'profileSyncStatus',
      'profileSyncError',
    ]);

    // Clear session cache
    if (chrome?.storage?.session) {
      await chrome.storage.session.clear().catch(() => {});
    }

    // Send message to background script to clear all caches
    try {
      await chrome.runtime.sendMessage({ type: 'logout' });
    } catch (e) {
      console.log('[Profile] Background message failed (expected):', e);
    }

    // Close profile window and let sidepanel detect logout
    window.close();
  } catch (e) {
    console.error('[Profile] Logout error:', e);
    window.close();
  }
});
