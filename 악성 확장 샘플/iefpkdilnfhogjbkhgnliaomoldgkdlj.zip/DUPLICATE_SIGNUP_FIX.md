# Duplicate Signup Issue - Fix Documentation

## 🐛 Problem Description

**User Report:**

> "Even though I have created an account with this email, when I try to sign up again it says 'Please check your email to confirm your account' but there is no email reached."

## 🔍 Root Cause Analysis

### What Was Happening:

1. User creates an account with email `user@example.com`
2. User confirms their email (account is active)
3. User tries to sign up again with the same email `user@example.com`
4. Supabase receives the duplicate signup request
5. **Security Feature:** Supabase doesn't explicitly say "user already exists" (to prevent user enumeration attacks)
6. Instead, Supabase returns:
   - `user` object (with the existing user data)
   - No `session` (because it's not a real signup)
   - `requiresConfirmation: true` (misleading!)
7. Frontend shows: "Please check your email to confirm your account"
8. **No email is sent** because the user already exists and is confirmed
9. User is confused 😕

### Why This Is Bad UX:

- User thinks the email system is broken
- User doesn't know they should sign in instead
- No clear path forward
- Wastes user's time

## ✅ Solution Implemented

### 1. **Backend Detection** (Primary Fix)

**File:** `vercel-backend/app/api/v1/auth/signup/route.ts`

Added intelligent duplicate detection logic that catches this scenario BEFORE it reaches the frontend:

```typescript
// Check for duplicate user error in response text
if (
  text &&
  /already registered|already exists|user already exists/i.test(text)
) {
  return withCORS(
    NextResponse.json(
      { error: 'An account with this email already exists. Please sign in.' },
      { status: 400 }
    ),
    req
  );
}

// Check if user already exists (confirmed or unconfirmed)
if (data?.user && !data?.session) {
  const emailConfirmedAt =
    data?.user?.email_confirmed_at || data?.user?.confirmed_at;
  const userCreatedRecently =
    data?.user?.created_at &&
    new Date().getTime() - new Date(data.user.created_at).getTime() < 5000;

  // If email is already confirmed OR user was not just created, it's a duplicate
  if (emailConfirmedAt || !userCreatedRecently) {
    return withCORS(
      NextResponse.json(
        { error: 'An account with this email already exists. Please sign in.' },
        { status: 400 }
      ),
      req
    );
  }
}
```

**Detection Criteria:**

1. ✅ Explicit error text contains "already exists"
2. ✅ User has `email_confirmed_at` field set (account is verified)
3. ✅ User was created more than 5 seconds ago (not a fresh signup)

### 2. **Frontend Smart Handling** (Secondary Fix)

**File:** `onboarding.js`

Enhanced error handling to auto-switch to sign-in mode when duplicate is detected:

```javascript
if (data?.error && /already exists/i.test(data.error)) {
  // Email already registered - offer to switch to sign in
  emailError.innerHTML =
    'This email is already registered. <a href="#" id="switchToSignInLink" style="color: #6366f1; text-decoration: underline; cursor: pointer;">Sign in instead?</a>';
  showElement(emailError);

  const switchLink = document.getElementById('switchToSignInLink');
  if (switchLink) {
    switchLink.addEventListener('click', (e) => {
      e.preventDefault();
      hideElement(emailError);
      isSignUpMode = false;
      updateAuthMode(); // Switches to sign-in mode
    });
  }
}
```

## 🎯 User Flow After Fix

### Before Fix:

1. User enters existing email → "Please check your email" ❌
2. User waits for email → No email arrives 😞
3. User is stuck → Bad experience 😡

### After Fix:

1. User enters existing email → "This email is already registered. [Sign in instead?]" ✅
2. User clicks link → Auto-switches to sign-in mode 🎉
3. Email is pre-filled → User just enters password ✨
4. User signs in successfully → Happy! 😊

## 🧪 Testing

### Test Case 1: New User (Should Work Normally)

1. Enter new email + password
2. Click "Create Account"
3. Should show: "Please check your email to confirm"
4. Email should arrive ✅

### Test Case 2: Existing Confirmed User (Duplicate Signup)

1. Enter existing email + password
2. Click "Create Account"
3. Should show: "This email is already registered. [Sign in instead?]" ✅
4. Click "Sign in instead?"
5. Should switch to sign-in mode ✅
6. Email field should be pre-filled ✅

### Test Case 3: Existing Unconfirmed User (Pending Confirmation)

1. Enter email of unconfirmed account + password
2. Click "Create Account"
3. Should show: "Please check your email to confirm" ✅
4. New confirmation email should be sent ✅

## 📊 Detection Logic Flow

```
Signup Request
    ↓
Backend receives request
    ↓
Supabase processes
    ↓
Check response text ──→ Contains "already exists"? ──→ YES → Return error
    ↓ NO
Parse JSON response
    ↓
User exists? ──→ NO → Continue normal signup
    ↓ YES
Has session? ──→ YES → Continue normal signup (auto-sign-in)
    ↓ NO
Email confirmed? ──→ YES → Return "already exists" error
    ↓ NO
Created recently (<5s)? ──→ NO → Return "already exists" error
    ↓ YES
Continue → Send confirmation email
```

## 🔐 Security Considerations

**User Enumeration Concern:**

- Supabase's default behavior (not revealing user existence) is a security feature
- Our fix trades some security for better UX
- **Mitigation:** This is acceptable because:
  1. Most applications prioritize UX over preventing user enumeration
  2. Attackers can enumerate users through other means (e.g., password reset)
  3. The benefit to legitimate users outweighs the minimal security risk

**Alternative Approach (If security is paramount):**

- Keep Supabase's default behavior
- Add rate limiting to prevent enumeration attacks
- Add CAPTCHA for repeated signup attempts

## 📝 Summary

**What was fixed:**

- ✅ Backend now detects duplicate signups accurately
- ✅ Backend returns clear error message
- ✅ Frontend auto-switches to sign-in mode
- ✅ User gets immediate, actionable feedback
- ✅ No more confusion about missing emails

**Files modified:**

1. `vercel-backend/app/api/v1/auth/signup/route.ts` - Backend duplicate detection
2. `onboarding.js` - Frontend smart error handling

**Impact:**

- Better user experience
- Reduced support requests
- Faster user onboarding
- Clear, actionable error messages

---

**Status:** ✅ Fixed and ready for deployment
**Last Updated:** October 22, 2025
