# Reverse Recruiting /api/auth/me Integration

## Overview
The Chrome extension now integrates with the Reverse Recruiting dashboard's `/api/auth/me` endpoint to automatically fetch and populate user profile data.

## Endpoint Details

### User Profile Endpoint
- **Method**: GET
- **Endpoint**: `/api/auth/me`
- **Base URL**: `https://api.reverserecruiting.io`
- **Full URL**: `https://api.reverserecruiting.io/api/auth/me`

### Authentication
Requires JWT authentication via Bearer token:
```
Authorization: Bearer <user_jwt_token>
```

The token is received from the dashboard via `postMessage` (type: `RR_EXTENSION_INIT`) and stored in extension storage.

### Response Format
The API returns the authenticated user's profile details in this structure:

```json
{
  "success": true,
  "data": {
    "id": "123e4567-e89b-12d3-a456-426614174000",
    "email": "john.doe@email.com",
    "name": "John Doe",
    "resumeUrl": "https://storage.googleapis.com/your-bucket/resumes/john-doe.pdf",
    "resumeSummary": "5+ years of full-stack development experience...",
    "linkedinUrl": "https://linkedin.com/in/johndoe",
    "targetRole": ["Website Developer", "Data Scientist", "Full Stack Engineer"],
    "experienceLevel": "senior",
    "preferredLocations": ["San Francisco, CA", "Remote", "New York, NY"],
    "workType": ["remote", "hybrid"],
    "keywords": ["React", "Node.js", "TypeScript", "AWS", "PostgreSQL"],
    "minSalary": 150000,
    "status": "active",
    "createdAt": "2025-12-16T12:48:16.573Z",
    "updatedAt": "2025-12-16T12:48:16.573Z"
  }
}
```

**Fields:**
- `id`: User ID (UUID)
- `email`: User's email address
- `name`: Full name
- `resumeUrl`: URL to uploaded resume PDF
- `resumeSummary`: AI-generated resume summary
- `linkedinUrl`: LinkedIn profile URL
- `targetRole`: Array of target job roles
- `experienceLevel`: Experience level ("junior", "mid", "senior", "lead", etc.)
- `preferredLocations`: Array of preferred work locations
- `workType`: Array of work preferences (["remote", "hybrid", "onsite"])
- `keywords`: Array of skills/keywords
- `minSalary`: Minimum salary expectation
- `status`: Account status ("active", "inactive")
- `createdAt`: Account creation timestamp
- `updatedAt`: Last update timestamp

### Error Handling
- **401**: Invalid or expired token
- **404**: User not found
- **500**: Server-side error

## Implementation

### 1. **New Functions** (profile-setup.js)

#### `fetchRRAuthMe(token)`
Fetches user profile from the `/api/auth/me` endpoint.

```javascript
async function fetchRRAuthMe(token) {
  const RR_API_BASE = 'https://api.reverserecruiting.io';
  const res = await fetch(`${RR_API_BASE}/api/auth/me`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    credentials: 'include',
  });
  
  if (!res.ok) {
    // Handle errors (401, 404, 500)
    return null;
  }
  
  const data = await res.json();
  console.log('[ProfileSetup] /api/auth/me response:', JSON.stringify(data, null, 2));
  
  return data;
}
```

**Features:**
- Fetches profile data using JWT token
- Logs full response for debugging
- Handles HTTP errors gracefully
- Returns null on failure

#### `mapAuthMeToProfile(authMeData)`
Maps the `/api/auth/me` response to the extension's profile format.

```javascript
function mapAuthMeToProfile(authMeData) {
  const profile = {
    // Basic Info
    full_name: authMeData.name || authMeData.full_name || '',
    email: authMeData.email || '',
    phone: authMeData.phone || authMeData.phone_number || '',
    
    // Resume/CV
    cv_text: authMeData.resume_text || authMeData.cv_text || '',
    cv_url: authMeData.resume_url || authMeData.cv_url || '',
    
    // Social Links
    linkedin_url: authMeData.linkedin_url || authMeData.linkedIn || '',
    portfolio_url: authMeData.portfolio_url || '',
    github_url: authMeData.github_url || '',
    
    // Job Preferences
    role_preferences: authMeData.role_preferences || [],
    experience_level: authMeData.experience_level || '',
    locations: authMeData.locations || [],
    
    // Work Details
    current_job_title: authMeData.current_role || authMeData.current_job_title || '',
    years_total_experience: authMeData.years_experience || authMeData.years_total_experience || null,
    
    // Education
    highest_degree: authMeData.degree || authMeData.highest_degree || '',
    field_of_study: authMeData.major || authMeData.field_of_study || '',
    university: authMeData.university || '',
    graduation_year: authMeData.graduation_year || authMeData.gradYear || null,
    
    // Skills & Certifications
    top_skills: authMeData.skills || authMeData.top_skills || [],
    certifications: authMeData.certifications || [],
    
    // Additional
    professional_summary: authMeData.summary || authMeData.professional_summary || '',
    work_authorization: authMeData.work_authorization || '',
    security_clearance: authMeData.security_clearance || '',
    
    // Metadata
    user_id: authMeData.id || authMeData.user_id || '',
    created_at: authMeData.created_at || '',
    updated_at: authMeData.updated_at || '',
  };
  
  return profile;
}
```

**Features:**
- Handles multiple field name variations (snake_case, camelCase)
- Provides fallbacks for missing fields
- Logs mapped profile summary
- Returns null-safe profile object

### 2. **Enhanced `loadExistingProfile()`**

The function now:
1. Checks for RR API configuration
2. Attempts to fetch from `/api/auth/me` first
3. Maps the response to extension format
4. Falls back to legacy endpoints if needed

```javascript
async function loadExistingProfile() {
  // Get auth token
  const token = await getAuthToken();
  
  // Get config
  const cfg = await getConfig();
  
  // Try RR /api/auth/me first
  if (cfg.rrApiBaseUrl || cfg.rrProductionApiBaseUrl) {
    const authMeData = await fetchRRAuthMe(token);
    
    if (authMeData) {
      const mappedProfile = mapAuthMeToProfile(authMeData);
      
      return {
        profile: mappedProfile,
        customAnswers: authMeData.custom_answers || [],
        employment: authMeData.employment || [],
        synced_at: authMeData.updated_at || new Date().toISOString(),
      };
    }
  }
  
  // Fall back to legacy endpoint
  return fetchLegacyProfile(token);
}
```

### 3. **Enhanced `fillFormWithProfile()`**

Now handles additional fields from `/api/auth/me`:

```javascript
function fillFormWithProfile(profile) {
  // ... existing field mapping ...
  
  // Handle locations array (from /api/auth/me)
  if (profile.locations && Array.isArray(profile.locations) && profile.locations.length > 0) {
    const locationInput = document.getElementById('location');
    if (locationInput && !locationInput.value) {
      locationInput.value = profile.locations[0];
    }
  }
  
  // Handle role_preferences array
  if (profile.role_preferences && Array.isArray(profile.role_preferences) && profile.role_preferences.length > 0) {
    const currentRoleInput = document.getElementById('currentRole');
    if (currentRoleInput && !currentRoleInput.value) {
      currentRoleInput.value = profile.role_preferences[0];
    }
  }
  
  // Handle experience_level
  if (profile.experience_level) {
    console.log('[ProfileSetup] Experience level from API:', profile.experience_level);
  }
}
```

## Field Mapping

### API Response → Extension Profile

| API Field (from response.data) | Extension Field | Type | Notes |
|-------------------------------|----------------|------|-------|
| `name` | `full_name` | string | User's full name |
| `email` | `email` | string | Email address |
| `phone` | `phone` | string | Phone number (may not be in response) |
| `resumeSummary` | `cv_text` | string | AI-generated resume summary |
| `resumeUrl` | `cv_url` | string | Resume PDF URL |
| `linkedinUrl` | `linkedin_url` | string | LinkedIn profile URL |
| `portfolioUrl` | `portfolio_url` | string | Portfolio website URL |
| `githubUrl` | `github_url` | string | GitHub profile URL |
| `targetRole` | `role_preferences` | array | Target job roles (e.g., ["Software Engineer", "Data Scientist"]) |
| `experienceLevel` | `experience_level` | string | Experience level ("junior", "mid", "senior", "lead") |
| `preferredLocations` | `locations` | array | Preferred work locations (e.g., ["San Francisco, CA", "Remote"]) |
| `targetRole[0]` | `current_job_title` | string | First target role used as current role |
| `experienceLevel` | `years_total_experience` | number | Mapped: junior=2, mid=5, senior=8, lead=10, staff=12, principal=15 |
| `keywords` | `top_skills` | array | Skills/keywords (e.g., ["React", "Node.js", "TypeScript"]) |
| `resumeSummary` | `professional_summary` | string | Professional summary |
| `workType` | `job_types` | array | Work preferences (["remote", "hybrid", "onsite"]) |
| `minSalary` | `expected_salary_min` | number | Minimum salary expectation |
| `status` | `status` | string | Account status ("active", "inactive") |
| `id` | `user_id` | string | User ID (UUID) |
| `createdAt` | `created_at` | string | Account creation timestamp (ISO 8601) |
| `updatedAt` | `updated_at` | string | Last update timestamp (ISO 8601) |

**Note:** Fields not in API response (education, certifications, work authorization, security clearance) are left empty and can be filled manually by the user.

### Extension Form → Profile Fields

| Form Field ID | Profile Field | Type |
|---------------|--------------|------|
| `fullName` | `full_name` | string |
| `email` | `email` | string |
| `phone` | `phone` | string |
| `location` | `location` or `locations[0]` | string |
| `linkedIn` | `linkedin_url` | string |
| `portfolio` | `portfolio_url` | string |
| `github` | `github_url` | string |
| `currentRole` | `current_job_title` or `role_preferences[0]` | string |
| `yearsExperience` | `years_total_experience` | number |
| `degree` | `highest_degree` | string |
| `major` | `field_of_study` | string |
| `university` | `university` | string |
| `gradYear` | `graduation_year` | number |
| `skills` | `top_skills` (joined with ", ") | string |
| `certifications` | `certifications` (joined with ", ") | string |
| `summary` | `professional_summary` | string |
| `workAuth` | `work_authorization` | string |
| `clearance` | `security_clearance` | string |

## Data Flow

```
1. User logs in via RR Dashboard
    ↓
2. Dashboard sends token via postMessage (RR_EXTENSION_INIT)
    ↓
3. Extension stores token in chrome.storage
    ↓
4. User opens Profile Setup page
    ↓
5. Extension calls loadExistingProfile()
    ↓
6. fetchRRAuthMe(token) calls /api/auth/me
    ↓
7. API returns user profile data
    ↓
8. mapAuthMeToProfile() converts to extension format
    ↓
9. fillFormWithProfile() populates form fields
    ↓
10. User reviews and can update information
    ↓
11. On save, profile syncs back to backend
```

## Debugging

### Console Logs

The integration includes comprehensive logging:

```javascript
// Fetch attempt
console.log('[ProfileSetup] Fetching profile from /api/auth/me...');

// Full API response (for debugging)
console.log('[ProfileSetup] /api/auth/me response:', JSON.stringify(data, null, 2));

// Mapping summary
console.log('[ProfileSetup] Mapped profile:', {
  name: profile.full_name,
  email: profile.email,
  hasResume: !!profile.cv_text,
  resumeLength: profile.cv_text?.length || 0,
  rolePreferences: profile.role_preferences?.length || 0,
  locations: profile.locations?.length || 0,
});

// Field population
console.log('[ProfileSetup] Set location from locations array:', profile.locations[0]);
console.log('[ProfileSetup] Set current role from role_preferences:', profile.role_preferences[0]);
console.log('[ProfileSetup] Experience level from API:', profile.experience_level);
```

### Testing

To test the integration:

1. **Check Token**:
   ```javascript
   chrome.storage.sync.get(['firebaseSession'], (data) => {
     console.log('Token:', data.firebaseSession?.access_token);
   });
   ```

2. **Test API Call**:
   ```javascript
   const token = 'your_jwt_token_here';
   fetch('https://api.reverserecruiting.io/api/auth/me', {
     headers: { 'Authorization': `Bearer ${token}` }
   }).then(r => r.json()).then(console.log);
   ```

3. **Check Profile Load**:
   - Open Profile Setup page
   - Check browser console for logs
   - Look for `/api/auth/me response:` log
   - Verify form fields are populated

### Common Issues

#### Issue: 401 Unauthorized
**Cause**: Token is invalid or expired
**Solution**: 
- Check if token is being received from dashboard
- Verify token is stored correctly
- Try logging in again

#### Issue: 404 Not Found
**Cause**: User doesn't exist in database
**Solution**:
- Verify user account is created
- Check user_id matches

#### Issue: Fields Not Populating
**Cause**: Field name mismatch
**Solution**:
- Check console logs for mapped profile
- Verify API response field names
- Update `mapAuthMeToProfile()` if needed

#### Issue: Array Fields Not Showing
**Cause**: Arrays need to be joined to strings
**Solution**:
- Arrays are automatically joined with ", "
- Check `fillFormWithProfile()` array handling

## Future Enhancements

### Potential Improvements
1. **Real-time Sync**: Auto-sync profile changes back to dashboard
2. **Conflict Resolution**: Handle conflicts between local and remote data
3. **Offline Support**: Cache profile data for offline use
4. **Partial Updates**: Only sync changed fields
5. **Version Control**: Track profile version/revision history
6. **Validation**: Validate API response schema
7. **Retry Logic**: Automatic retry on network failures
8. **Progress Indicator**: Show loading state during fetch

### Additional Fields to Consider
- `preferred_salary_range`
- `remote_preference`
- `visa_status`
- `availability_date`
- `job_search_status`
- `preferred_company_size`
- `preferred_industries`

## Security Considerations

### Token Handling
- ✅ Token stored securely in chrome.storage
- ✅ Token sent via HTTPS only
- ✅ Token included in Authorization header
- ✅ Token validated by backend

### Data Privacy
- ✅ Profile data only fetched when needed
- ✅ No sensitive data logged (except in debug mode)
- ✅ User controls what data is shared
- ✅ Data encrypted in transit (HTTPS)

### Error Handling
- ✅ Graceful degradation on API failures
- ✅ No sensitive error messages to user
- ✅ Detailed logs for debugging (dev only)
- ✅ Fallback to legacy endpoints

## Conclusion

The `/api/auth/me` integration provides:
- ✅ **Seamless Experience**: Auto-populate profile from dashboard
- ✅ **Data Consistency**: Single source of truth
- ✅ **Reduced Friction**: Users don't re-enter data
- ✅ **Better UX**: Faster profile setup
- ✅ **Maintainable**: Clear field mapping and logging
- ✅ **Extensible**: Easy to add new fields

**Users can now log in once and have their profile automatically populated across the extension!** 🎉

