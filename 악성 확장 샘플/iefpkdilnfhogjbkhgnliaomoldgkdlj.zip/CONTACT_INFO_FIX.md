# Contact Information Fix

## Issue
The extension was generating random/fake phone numbers, addresses, and contact information when the actual data was not available in the user's profile or CV.

### Root Causes
1. **API Field Mismatch**: The RR API returns `phoneNumber` but the code was looking for `phone`
2. **AI Prompt Issue**: AI prompts didn't explicitly forbid generating fake contact info
3. **Missing Data Handling**: No clear instructions for handling missing contact information

## Changes Made

### 1. Fixed API Field Mapping (`profile-storage.js`)

**Before:**
```javascript
phone: data.phone || '',
```

**After:**
```javascript
phone: data.phoneNumber || '', // API uses phoneNumber, not phone
```

**Impact:** Now correctly reads phone number from API response (or gets `null`/empty string if not provided)

### 2. Fixed Profile Page Mapping (`profile.js`)

**Before:**
```javascript
phone: p.phone || '',
```

**After:**
```javascript
phone: p.phoneNumber || '', // API uses phoneNumber, not phone
```

### 3. Updated AI Prompts (All Models)

Added explicit rules to **ALL AI models** (Gemini, Claude, Grok, OpenAI):

```
**CRITICAL - DO NOT GENERATE FAKE CONTACT INFO:**
- If phone number is NOT in CV, leave the field empty or use empty string ""
- If address is NOT in CV, leave the field empty or use city/state only
- If LinkedIn/Portfolio/GitHub URL is NOT in CV, leave the field empty
- NEVER generate placeholder or fake contact information like "+1234567890" or "123 Main St"
```

#### Updated Field-Specific Instructions:

**Before:**
```
- Phone (type=tel): Use phone number from CV
- LinkedIn (type=text/url): Use LinkedIn URL from CV
```

**After:**
```
- Phone (type=tel): Use phone number from CV ONLY if explicitly provided. If phone is not in CV, leave empty or skip field.
- Address/Location (type=text): Use address from CV ONLY if explicitly provided. If address is not in CV, use city/state only.
- LinkedIn (type=text/url): Use LinkedIn URL from CV ONLY if provided. Do NOT generate fake URLs.
- Portfolio/Website: Use actual URL from CV ONLY if provided. Do NOT generate fake URLs.
```

## Files Modified

1. ✅ `/profile-storage.js` - Fixed `phoneNumber` mapping
2. ✅ `/profile.js` - Fixed `phoneNumber` mapping
3. ✅ `/vercel-backend/lib/openai.ts` - Updated AI prompts for:
   - Gemini (lines 550-575)
   - Claude (lines 625-645)
   - Grok (lines 672-695)
   - OpenAI (lines 777-800)

## Expected Behavior

### Before Fix
```json
{
  "fields": [
    {"name": "Phone", "value": "+1234567890"},  // ❌ Fake/random
    {"name": "Address", "value": "123 Main St"}, // ❌ Fake/random
    {"name": "LinkedIn", "value": "https://linkedin.com/in/fake"} // ❌ Fake
  ]
}
```

### After Fix
```json
{
  "fields": [
    {"name": "Phone", "value": ""},  // ✅ Empty if not in CV
    {"name": "Address", "value": "Washington D.C."}, // ✅ City/state only
    {"name": "LinkedIn", "value": ""} // ✅ Empty if not in CV
  ]
}
```

## Real Example

### API Response
```json
{
  "success": true,
  "data": {
    "name": "BRIAN WONDRACK",
    "email": "nogivo1968@bipochub.com",
    "phoneNumber": null,  // ← No phone number
    "preferredLocations": ["Washington D.C."],
    "linkedinUrl": "www.linkedin.com/in/brian-wondrack-policyadvisor/"
  }
}
```

### Extension Behavior

**Before Fix:**
- Phone field: `+251911234567` (random/fake)
- Address field: `123 Main Street, Washington D.C.` (fake address)

**After Fix:**
- Phone field: `` (empty - no phone in profile)
- Address field: `Washington D.C.` (city/state only from preferredLocations)

## Testing

### Manual Test Steps

1. **Check Profile Storage:**
   ```javascript
   chrome.storage.local.get('userProfile', (data) => {
     console.log('Phone:', data.userProfile.phone); // Should be empty string or null
   });
   ```

2. **Test AI Analysis:**
   - Scan a job form with phone/address fields
   - Click "Auto-Fill Fields"
   - Check console logs for AI response
   - Verify phone field is empty (not random)

3. **Check Profile Page:**
   - Open profile page
   - Phone field should be empty (not showing random number)

### Expected Console Logs

```
[ProfileStorage] Profile data: {
  "data": {
    "phoneNumber": null,  ← Correctly null
    ...
  }
}

[ProfileStorage] Mapped profile: {
  phone: "",  ← Correctly empty
  ...
}

[AI Response] {
  "fields": [
    {"name": "Phone", "value": ""}  ← Correctly empty
  ]
}
```

## Rules Summary

### ✅ DO:
- Use actual phone number if provided in CV/profile
- Use actual address if provided in CV/profile
- Use actual URLs if provided in CV/profile
- Use city/state from preferredLocations for location fields
- Leave fields empty if data is not available

### ❌ DON'T:
- Generate random phone numbers like "+1234567890"
- Generate fake addresses like "123 Main St"
- Generate placeholder URLs
- Make up contact information
- Use default/template values

## Impact

### For Users
- ✅ No more fake/random contact info
- ✅ Accurate profile data
- ✅ Professional form submissions
- ✅ No embarrassing placeholder data

### For AI
- ✅ Clear instructions to not fabricate data
- ✅ Better understanding of when to leave fields empty
- ✅ More accurate form filling

### For Data Quality
- ✅ Only real, verified contact info is used
- ✅ Empty fields are clearly empty (not fake data)
- ✅ Users can manually fill missing fields if needed

## Future Enhancements

- [ ] Add UI indicator when fields are left empty due to missing data
- [ ] Allow users to manually add missing contact info in profile
- [ ] Validate contact info format (phone, email, URLs)
- [ ] Add "incomplete profile" warnings
- [ ] Sync manually-added contact info back to RR API




























