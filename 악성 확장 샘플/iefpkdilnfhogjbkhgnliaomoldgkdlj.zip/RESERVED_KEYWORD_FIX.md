# Fixed: Reserved Keyword Error

## ❌ Error:

```
ERROR: 42601: syntax error at or near "current_role"
LINE 28:     current_role text,
```

## 🔍 Root Cause:

`current_role` is a **reserved keyword** in PostgreSQL! It's a special system function that returns the current user's role.

See: https://www.postgresql.org/docs/current/functions-info.html

## ✅ Solution:

Renamed `current_role` → `current_job_title` throughout the entire codebase.

---

## Files Modified:

### 1. `vercel-backend/user_profiles.sql`

**Line 28:**

```sql
-- BEFORE:
current_role text,

-- AFTER:
current_job_title text,
```

**Lines 269-270 (in function):**

```sql
-- BEFORE:
if v_profile.current_role is not null
and v_profile.current_role != '' then v_score := v_score + 5;

-- AFTER:
if v_profile.current_job_title is not null
and v_profile.current_job_title != '' then v_score := v_score + 5;
```

### 2. `vercel-backend/app/api/v1/profile/sync/route.ts`

**Line 172 (completeness check):**

```typescript
// BEFORE:
if (profile.current_role) completenessScore += 5;

// AFTER:
if (profile.current_role || profile.currentRole || profile.current_job_title)
  completenessScore += 5;
```

**Line 199 (saving to DB):**

```typescript
// BEFORE:
current_role: profile.currentRole || profile.current_role || null,

// AFTER:
current_job_title: profile.currentRole || profile.current_role || profile.current_job_title || null,
```

### 3. `profile-sync.js`

**Line 190 (reading from DB):**

```javascript
// BEFORE:
currentRole: profile.current_role || '',

// AFTER:
currentRole: profile.current_job_title || '',
```

---

## ✅ Result:

**The SQL file will now run without errors!**

All references to `current_role` column updated to `current_job_title`.

Backwards compatibility maintained: the API still accepts `current_role` and `currentRole` from client code.

---

## 🚀 Deploy Now:

```bash
# Go to Supabase Dashboard → SQL Editor
# Paste vercel-backend/user_profiles.sql
# Click Run
# ✅ Success!
```

**No more syntax errors!** 🎉
