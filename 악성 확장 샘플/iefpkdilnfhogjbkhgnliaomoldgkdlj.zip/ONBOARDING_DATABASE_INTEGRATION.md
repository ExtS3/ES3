# Onboarding Database Integration - Complete Guide

## Overview

The onboarding system now fully integrates with the Supabase database to:

1. ✅ **Differentiate new vs returning users**
2. ✅ **Pre-fill forms with existing profile data**
3. ✅ **Sync all changes back to database**
4. ✅ **Show appropriate welcome messages**

## Architecture

```
┌─────────────────┐
│  onboarding.js  │  Auth (Sign up/Log in)
└────────┬────────┘
         │
         ▼
┌─────────────────────┐
│ profile-setup.js    │  Profile management
│                     │
│ • loadExistingProfile() ─────► GET /v1/profile/sync
│ • fillFormWithProfile()       (Fetch from Supabase)
│ • finishSetup() ──────────────► POST /v1/profile/sync
│                                  (Save to Supabase)
└─────────────────────┘
```

## User Flow

### 🆕 New User Flow

```
1. User signs up on onboarding.html
   ├─ POST /v1/auth/signup
   └─ Session saved to chrome.storage.sync

2. Redirect to profile-setup.html
   ├─ loadExistingProfile() → No data found
   ├─ Show: "🎉 Welcome to JobApAI!"
   └─ Empty form fields

3. User uploads resume & fills form
   ├─ AI extracts profile data
   └─ Pre-fills form fields

4. User clicks "Finish Setup"
   ├─ finishSetup() saves locally
   ├─ POST /v1/profile/sync (save to Supabase)
   └─ Redirect to tracker (if >30% complete) or sidepanel
```

### 🔄 Returning User Flow

```
1. User logs in on onboarding.html
   ├─ POST /v1/auth/login
   └─ Session saved to chrome.storage.sync

2. Redirect to profile-setup.html
   ├─ loadExistingProfile() → GET /v1/profile/sync
   ├─ Profile data loaded from Supabase
   └─ fillFormWithProfile(existingProfile)

3. Welcome message shows:
   ├─ "👋 Welcome Back!"
   ├─ "Your profile is already set up"
   └─ Shows: Profile name, Resume status, Email

4. All form fields pre-filled:
   ├─ Full Name: "Alexandra Martinez"
   ├─ Email: "alex@example.com"
   ├─ Phone, Location, LinkedIn, etc.
   └─ Resume: "✅ Resume Already Saved (10KB)"

5. User can:
   ├─ Review existing data
   ├─ Update any fields
   ├─ Upload new resume (replaces old one)
   └─ Click "Finish Setup" to save changes
```

## Implementation Details

### 1. Loading Existing Profile (`profile-setup.js`)

```javascript
async function loadExistingProfile() {
  try {
    console.log('[ProfileSetup] Loading existing profile data...');

    // Get auth token
    const { supabaseSession } = await chrome.storage.sync.get([
      'supabaseSession',
    ]);
    const token = supabaseSession?.access_token;

    if (!token) {
      console.log('[ProfileSetup] No auth token, skipping profile load');
      return null;
    }

    // Get config
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await resp.json();
    const base = (cfg?.apiBaseUrl || '').replace(/\/$/, '');

    // Fetch profile from backend
    const res = await fetch(`${base}/v1/profile/sync`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    if (!res.ok) {
      console.warn('[ProfileSetup] Failed to fetch profile:', res.status);
      return null;
    }

    const data = await res.json();
    return data?.profile;
  } catch (e) {
    console.error('[ProfileSetup] Error loading profile:', e);
    return null;
  }
}
```

### 2. Pre-filling Form with Existing Data

```javascript
function fillFormWithProfile(profile) {
  if (!profile) return;

  console.log('[ProfileSetup] Pre-filling form with existing data');

  // Update welcome message for returning users
  const welcomeTitle = document.getElementById('welcomeTitle');
  const welcomeSubtitle = document.getElementById('welcomeSubtitle');
  const welcomeInfoBox = document.getElementById('welcomeInfoBox');

  if (welcomeTitle && welcomeSubtitle && welcomeInfoBox) {
    welcomeTitle.textContent = '👋 Welcome Back!';
    welcomeSubtitle.textContent =
      'Your profile is already set up. You can review and update your information below.';
    welcomeInfoBox.innerHTML = `
      <p style="margin: 0; color: var(--text-secondary); font-size: 14px; line-height: 1.6;">
        ✓ Profile: ${profile.full_name || 'Not set'}<br>
        ✓ Resume: ${
          profile.cv_text
            ? `Saved (${Math.round(profile.cv_text.length / 1000)}KB)`
            : 'Not uploaded'
        }<br>
        ✓ Contact: ${profile.email || 'Not set'}
      </p>
    `;
  }

  // Map profile fields to form inputs
  const fieldMappings = {
    full_name: 'fullName',
    email: 'email',
    phone: 'phone',
    location: 'location',
    linkedin_url: 'linkedIn',
    portfolio_url: 'portfolioUrl',
    github_url: 'githubUrl',
    current_role: 'currentRole',
    years_of_experience: 'experience',
    highest_degree: 'degree',
    field_of_study: 'fieldOfStudy',
    institution: 'institution',
    graduation_year: 'graduationYear',
    top_skills: 'skills',
    certifications: 'certifications',
    professional_summary: 'summary',
  };

  // Fill text inputs
  Object.entries(fieldMappings).forEach(([profileKey, formId]) => {
    const input = document.getElementById(formId);
    if (input && profile[profileKey]) {
      input.value = profile[profileKey];
    }
  });

  // Handle CV text
  if (profile.cv_text) {
    cvText = profile.cv_text;
    chrome.storage.local.set({ userCV: profile.cv_text });

    // Show resume status
    const uploadStatus = document.getElementById('uploadStatus');
    if (uploadStatus) {
      const wordCount = profile.cv_text.split(/\s+/).filter(Boolean).length;
      const charCount = profile.cv_text.length;

      uploadStatus.innerHTML = `
        <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 16px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 20px;">✅</span>
            <strong style="color: #16a34a;">Resume Already Saved</strong>
          </div>
          <p style="color: #15803d; margin: 8px 0; font-size: 14px;">
            Your resume is ready (${wordCount} words, ${charCount} characters)
          </p>
        </div>
      `;
    }
  }
}
```

### 3. Initialization on Page Load

```javascript
(async () => {
  try {
    const { supabaseSession } = await chrome.storage.sync.get([
      'supabaseSession',
    ]);

    if (supabaseSession && supabaseSession.access_token) {
      console.log('[ProfileSetup] User authenticated, loading profile');

      // Load and pre-fill existing profile data
      const existingProfile = await loadExistingProfile();

      if (existingProfile) {
        // Wait for DOM if needed
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', () => {
            fillFormWithProfile(existingProfile);
          });
        } else {
          fillFormWithProfile(existingProfile);
        }
      }
    }
  } catch (e) {
    console.error('[ProfileSetup] Auth check error:', e);
  }
})();
```

## Database Schema

### Profile Fields Mapped to Form

| **Database Field**     | **Form Input ID** | **Type** | **Description**          |
| ---------------------- | ----------------- | -------- | ------------------------ |
| `full_name`            | `fullName`        | text     | Full name                |
| `email`                | `email`           | email    | Email address            |
| `phone`                | `phone`           | tel      | Phone number             |
| `location`             | `location`        | text     | City, State              |
| `linkedin_url`         | `linkedIn`        | url      | LinkedIn profile         |
| `portfolio_url`        | `portfolioUrl`    | url      | Portfolio website        |
| `github_url`           | `githubUrl`       | url      | GitHub profile           |
| `current_role`         | `currentRole`     | text     | Current job title        |
| `years_of_experience`  | `experience`      | number   | Years of experience      |
| `highest_degree`       | `degree`          | text     | Highest degree           |
| `field_of_study`       | `fieldOfStudy`    | text     | Major/Field              |
| `institution`          | `institution`     | text     | School name              |
| `graduation_year`      | `graduationYear`  | text     | Year graduated           |
| `top_skills`           | `skills`          | textarea | Skills (comma separated) |
| `certifications`       | `certifications`  | textarea | Certifications           |
| `professional_summary` | `summary`         | textarea | Professional summary     |
| `cv_text`              | (internal)        | text     | Full resume text         |

## UI Differences: New vs Returning Users

### New User (Step 1)

```
┌─────────────────────────────────────────┐
│  🎉 Welcome to JobApAI!                 │
│                                         │
│  Let's set up your profile. This       │
│  takes 3 minutes but saves you hours   │
│  on every application.                  │
│                                         │
│  ✓ Fill basic info once → Auto-fill    │
│  ✓ AI generates resumes & covers       │
│  ✓ Track all applications              │
│                                         │
│  [ Get Started ]  Skip for now          │
└─────────────────────────────────────────┘
```

### Returning User (Step 1)

```
┌─────────────────────────────────────────┐
│  👋 Welcome Back!                       │
│                                         │
│  Your profile is already set up. You   │
│  can review and update your            │
│  information below.                     │
│                                         │
│  ✓ Profile: Alexandra Martinez          │
│  ✓ Resume: Saved (10KB)                 │
│  ✓ Contact: alex@example.com            │
│                                         │
│  [ Get Started ]  Skip for now          │
└─────────────────────────────────────────┘
```

### Returning User (Step 2 - Resume)

```
┌─────────────────────────────────────────┐
│  Upload Your Resume                     │
│                                         │
│  [Drag & drop zone]                     │
│                                         │
│  ┌───────────────────────────────────┐ │
│  │ ✅ Resume Already Saved           │ │
│  │                                   │ │
│  │ Your resume is saved and ready    │ │
│  │ (2,543 words, 14,832 characters)  │ │
│  │                                   │ │
│  │ 💡 You can upload a new resume    │ │
│  │    if you want to update it.      │ │
│  └───────────────────────────────────┘ │
│                                         │
│  Basic Information                      │
│  ─────────────────                      │
│  Full Name: [Alexandra Martinez]        │
│  Email: [alex@example.com]              │
│  Phone: [+1 555-234-9876]               │
│  ...                                    │
└─────────────────────────────────────────┘
```

## Benefits

### ✅ **For New Users**

- Clear onboarding flow
- AI-powered resume extraction
- Quick profile setup
- No repeated data entry

### ✅ **For Returning Users**

- No repeated setup
- All data pre-loaded from database
- Can update any field
- Seamless experience

### ✅ **For Developers**

- Centralized data source (Supabase)
- Automatic sync on save
- Graceful fallbacks (local storage)
- Clear separation of concerns

## Sync Flow

```
┌──────────────┐
│  User Action │
└──────┬───────┘
       │
       ▼
┌──────────────────┐
│ Local Storage    │ ← Fast, immediate
│ chrome.storage   │
└──────┬───────────┘
       │
       ▼
┌──────────────────┐
│ Backend Sync     │ ← Reliable, persistent
│ POST /profile    │
│ (Supabase)       │
└──────────────────┘
```

### On Save (finishSetup)

1. Collect all form data
2. Save to `chrome.storage.local` (immediate, fast)
3. Sync to Supabase (persistent, reliable)
4. Mark `onboarding_completed = true` if >30% filled
5. Redirect to tracker or sidepanel

### On Load (loadExistingProfile)

1. Check if user authenticated (token exists)
2. Fetch profile from Supabase (`GET /v1/profile/sync`)
3. Pre-fill all form fields
4. Update welcome message
5. Show resume status

## Error Handling

### No Token

```javascript
if (!token) {
  console.log('[ProfileSetup] No auth token, skipping profile load');
  return null; // Show empty form
}
```

### Network Error

```javascript
if (!res.ok) {
  console.warn('[ProfileSetup] Failed to fetch profile:', res.status);
  return null; // Graceful fallback
}
```

### Missing Profile

```javascript
if (!profile) {
  console.log('[ProfileSetup] No profile data found');
  return null; // Treat as new user
}
```

## Testing

### Test 1: New User

1. Clear all data: `chrome.storage.sync.clear()`, `chrome.storage.local.clear()`
2. Open `onboarding.html` → Sign up
3. Verify: "🎉 Welcome to JobApAI!"
4. Verify: All form fields empty
5. Fill form and upload resume
6. Click "Finish Setup"
7. Verify: Data saved to Supabase

### Test 2: Returning User (Same Session)

1. After Test 1, close and reopen `profile-setup.html`
2. Verify: "👋 Welcome Back!"
3. Verify: All form fields pre-filled
4. Verify: Resume status shown ("✅ Resume Already Saved")
5. Update a field (e.g., phone number)
6. Click "Finish Setup"
7. Verify: Changes saved to Supabase

### Test 3: Returning User (New Session)

1. Sign out completely
2. Clear local storage: `chrome.storage.local.clear()`
3. Open `onboarding.html` → Log in
4. Verify: "👋 Welcome Back!"
5. Verify: All form fields pre-filled from database
6. Verify: Resume loaded from database

## Console Logs

### New User

```
[ProfileSetup] Script loaded, initializing...
[ProfileSetup] User authenticated, loading profile
[ProfileSetup] Loading existing profile data...
[ProfileSetup] No profile data found
```

### Returning User

```
[ProfileSetup] Script loaded, initializing...
[ProfileSetup] User authenticated, loading profile
[ProfileSetup] Loading existing profile data...
[ProfileSetup] Profile loaded: {fullName: "Alexandra Martinez", email: "alex@...", hasCV: true, cvLength: 14832}
[ProfileSetup] Pre-filling form with existing data
[ProfileSetup] Updated welcome message for returning user
[ProfileSetup] Form pre-filled successfully
```

## Summary

✅ **Onboarding now differentiates new vs returning users**  
✅ **Database integration complete (loads from Supabase)**  
✅ **Form pre-fills with existing profile data**  
✅ **Welcome message updates for returning users**  
✅ **Resume status shows for returning users**  
✅ **All changes sync back to database**  
✅ **Graceful fallbacks for errors**  
✅ **Clear console logging for debugging**

The onboarding system now provides a **seamless experience** for both new and returning users, with full database integration! 🎉









