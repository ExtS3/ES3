## Developer Guide

### Overview

JobApAI is a Chrome Extension (Manifest V3) with a side panel UI for AI-assisted job application workflows, plus a minimal Next.js (App Router) backend deployed on Vercel for API endpoints and optional BYOK/shared-key proxying.

### Repository Structure

- `manifest.json` — Extension configuration (MV3)
- `background.js` — Service worker controlling side panel and AI actions
- `content.js` — Content script for page integration/scanning hooks
- `sidepanel.html`, `sidepanel.js`, `sidepanel.css` — Main UI
- `plugin.html`, `plugin.css` — Plugin sub-UI
- `options.html`, `options.js` — BYOK key and settings
- `onboarding.*`, `login.*`, `signup.*` — Auth/onboarding UI
- `vendor/` — Bundled libraries (`jspdf`, `pdfjs`, `supabase-js` UMD)
- `vercel-backend/` — Next.js 14 App Router API (TypeScript)

### Prerequisites

- Chrome (or Chromium-based) browser
- Node.js 18+ and npm for backend
- Accounts/keys as needed: OpenAI (BYOK), Supabase project (optional), Vercel (for deploy)

### Quick Start — Extension (Local)

1. Open Chrome → `chrome://extensions` → enable Developer Mode.
2. Click “Load unpacked” and select the project folder.
3. Pin the extension and click it to open the side panel.
4. Open the Options page and add your OpenAI API key (stored in `chrome.storage.sync`).

Notes:

- Default model is `gpt-5-mini` in `background.js`. Change via the UI model selector or code.
- `config.json` controls `apiBaseUrl` and Supabase settings for backend-assisted features.

### Quick Start — Backend (Local)

1. `cd vercel-backend`
2. `npm install`
3. Create a `.env.local` with required environment variables (see ENVIRONMENT.md).
4. `npm run dev` → serves on `http://localhost:3000`
5. In the extension `config.json`, point `apiBaseUrl` to `http://localhost:3000/api` if using local backend.

### Build & Deploy

- Extension: Zip project (excluding `.git`) for Chrome Web Store. See `CHROME_STORE_COMPLIANCE.md`.
- Backend: Deploy `vercel-backend/` to Vercel. Set environment variables in Vercel per `vercel-backend/README.md`.

### Common Tasks

- Update model or providers: adjust UI selector in `sidepanel.html` and API routing in backend `lib/*`.
- PDF parsing/generation: use `vendor/pdfjs/*` and `vendor/jspdf/*` from the side panel flows.
- App tracking: endpoints under `/api/v1/apps/*` write to Supabase via server helpers.

### Testing (Manual)

- Extension: Verify side panel opens, options save/load keys, analyze/generate flows return results, and content script injection works on job forms.
- Backend: Use `curl` or REST client to hit `POST /api/v1/analyze-form`, `POST /api/v1/generate/*`, and auth endpoints.

### Release Checklist

- Validate manifest and permissions
- Screenshots and store listing ready
- No secrets in the repo or packaged zip
- Verify CORS and host permissions for your backend domains





