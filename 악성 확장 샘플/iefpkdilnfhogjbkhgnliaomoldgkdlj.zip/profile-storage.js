/**
 * Profile Storage Utility
 * Centralized profile data management for the extension
 * Handles fetching from RR API, storing, and retrieving profile data
 */

const RR_API_BASE = 'https://api.reverserecruiting.io';

/**
 * Fetch profile from RR /api/auth/me endpoint
 * @param {string} token - JWT token
 * @returns {Promise<object|null>} - Profile data or null
 */
async function fetchProfileFromRR(token) {
  if (!token) {
    console.warn('[ProfileStorage] No token provided');
    return null;
  }

  console.log('[ProfileStorage] Fetching profile from /api/auth/me...');

  try {
    const response = await fetch(`${RR_API_BASE}/api/auth/me`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    if (!response.ok) {
      let errorBody = '';
      try {
        errorBody = await response.text();
      } catch (_) {}

      console.warn(
        `[ProfileStorage] /api/auth/me failed: ${response.status}`,
        errorBody
      );

      if (response.status === 401) {
        console.warn('[ProfileStorage] Token invalid or expired');
      }

      return null;
    }

    const data = await response.json();
    console.log('[ProfileStorage] ✅ Successfully fetched profile from RR API');
    try {
      const d = data?.data || data || {};
      console.log('[ProfileStorage] Profile summary:', {
        hasName: !!d.name,
        hasEmail: !!d.email,
        hasPhoneNumber:
          d.phoneNumber != null && String(d.phoneNumber).trim() !== '',
        hasResumeUrl: !!d.resumeUrl,
        hasResumeText: !!d.resume_text,
        hasCvText: !!d.cv_text,
        hasResumeSummary: !!d.resumeSummary,
        resumeTextLength: d.resume_text?.length || 0,
        cvTextLength: d.cv_text?.length || 0,
        resumeSummaryLength: d.resumeSummary?.length || 0,
        targetRoleCount: Array.isArray(d.targetRole) ? d.targetRole.length : 0,
        preferredLocationsCount: Array.isArray(d.preferredLocations)
          ? d.preferredLocations.length
          : 0,
        keywordsCount: Array.isArray(d.keywords) ? d.keywords.length : 0,
      });
    } catch (_) {}
    return data;
  } catch (error) {
    console.error('[ProfileStorage] Error fetching profile:', error);
    return null;
  }
}

/**
 * Map RR API response to extension profile format
 * @param {object} response - Response from /api/auth/me
 * @returns {object|null} - Mapped profile data
 */
function mapRRProfileToExtension(response) {
  if (!response) return null;

  const data = response.data || response;

  if (!data) {
    console.warn('[ProfileStorage] No data in response');
    return null;
  }

  // Map to extension format
  const profile = {
    // Basic Info
    full_name: data.name || '',
    email: data.email || '',
    phone: data.phoneNumber || '', // API uses phoneNumber, not phone

    // Resume/CV - Use raw parsed text (resume_text or cv_text) instead of summary
    // resume_text/cv_text contains the full parsed CV text, resumeSummary is just a summary
    cv_text: data.resume_text || data.cv_text || data.resumeSummary || '',
    cv_url: data.resumeUrl || '',

    // Social Links
    linkedin_url: data.linkedinUrl || '',
    portfolio_url: data.portfolioUrl || '',
    github_url: data.githubUrl || '',

    // Job Preferences
    role_preferences: data.targetRole || [],
    experience_level: data.experienceLevel || '',
    locations: data.preferredLocations || [],

    // Work Details
    current_job_title: (data.targetRole && data.targetRole[0]) || '',
    years_total_experience: estimateYearsFromLevel(data.experienceLevel),

    // Skills
    top_skills: data.keywords || [],

    // Additional - professional_summary should use resumeSummary (it's a summary, not raw text)
    professional_summary: data.resumeSummary || '',

    // Salary & Work Type
    expected_salary_min: data.minSalary || null,
    job_types: data.workType || [],

    // Status
    status: data.status || '',

    // Metadata
    user_id: data.id || '',
    created_at: data.createdAt || '',
    updated_at: data.updatedAt || '',

    // Source tracking
    source: 'reverse_recruiting',
    last_synced: new Date().toISOString(),
  };

  console.log('[ProfileStorage] Mapped profile:', {
    name: profile.full_name,
    email: profile.email,
    targetRoles: profile.role_preferences.length,
    locations: profile.locations.length,
    skills: profile.top_skills.length,
    experienceLevel: profile.experience_level,
    cvTextLength: profile.cv_text?.length || 0,
    cvTextSource: data.resume_text
      ? 'resume_text'
      : data.cv_text
      ? 'cv_text'
      : data.resumeSummary
      ? 'resumeSummary (fallback)'
      : 'none',
  });

  return profile;
}

/**
 * Estimate years of experience from experience level
 * @param {string} level - Experience level (junior, mid, senior, etc.)
 * @returns {number} - Estimated years
 */
function estimateYearsFromLevel(level) {
  if (!level) return 0;

  const levelMap = {
    junior: 2,
    mid: 5,
    senior: 8,
    lead: 10,
    staff: 12,
    principal: 15,
  };

  return levelMap[level.toLowerCase()] || 0;
}

/**
 * Save profile to chrome.storage.local
 * @param {object} profile - Profile data
 * @returns {Promise<void>}
 */
async function saveProfile(profile) {
  if (!profile) {
    console.warn('[ProfileStorage] No profile to save');
    return;
  }

  try {
    await chrome.storage.local.set({
      userProfile: profile,
      profileLastUpdated: new Date().toISOString(),
    });

    // Also save CV text separately for backward compatibility
    if (profile.cv_text) {
      await chrome.storage.local.set({ userCV: profile.cv_text });
    }

    console.log('[ProfileStorage] ✅ Profile saved to storage');
  } catch (error) {
    console.error('[ProfileStorage] Error saving profile:', error);
  }
}

/**
 * Get profile from chrome.storage.local
 * @returns {Promise<object|null>} - Profile data or null
 */
async function getProfile() {
  try {
    const result = await chrome.storage.local.get([
      'userProfile',
      'profileLastUpdated',
    ]);

    if (result.userProfile) {
      console.log('[ProfileStorage] ✅ Profile loaded from storage');
      console.log(
        '[ProfileStorage] Last updated:',
        result.profileLastUpdated || 'unknown'
      );
      return result.userProfile;
    }

    console.log('[ProfileStorage] No profile in storage');
    return null;
  } catch (error) {
    console.error('[ProfileStorage] Error loading profile:', error);
    return null;
  }
}

/**
 * Sync profile from RR API and save to storage
 * @param {string} token - JWT token
 * @returns {Promise<object|null>} - Synced profile or null
 */
async function syncProfileFromRR(token) {
  console.log('[ProfileStorage] Starting profile sync from RR API...');

  const response = await fetchProfileFromRR(token);

  if (!response) {
    console.warn('[ProfileStorage] Failed to fetch profile from RR API');
    return null;
  }

  const profile = mapRRProfileToExtension(response);

  if (!profile) {
    console.warn('[ProfileStorage] Failed to map profile');
    return null;
  }

  await saveProfile(profile);

  console.log('[ProfileStorage] ✅ Profile sync complete');
  return profile;
}

/**
 * Get profile for AI analysis (formatted as CV text)
 * @returns {Promise<string>} - Formatted profile text
 */
async function getProfileForAI() {
  const profile = await getProfile();

  if (!profile) {
    console.log('[ProfileStorage] No profile available for AI');
    return '';
  }

  // Format profile as structured text for AI
  const sections = [];

  // Basic Info
  if (profile.full_name) {
    sections.push(`Name: ${profile.full_name}`);
  }
  if (profile.email) {
    sections.push(`Email: ${profile.email}`);
  }
  if (profile.phone) {
    sections.push(`Phone: ${profile.phone}`);
  }

  // Location
  if (profile.locations && profile.locations.length > 0) {
    sections.push(`Location: ${profile.locations.join(', ')}`);
  }

  // Links
  if (profile.linkedin_url) {
    sections.push(`LinkedIn: ${profile.linkedin_url}`);
  }
  if (profile.portfolio_url) {
    sections.push(`Portfolio: ${profile.portfolio_url}`);
  }
  if (profile.github_url) {
    sections.push(`GitHub: ${profile.github_url}`);
  }

  // Professional Info
  if (profile.current_job_title) {
    sections.push(`Current Role: ${profile.current_job_title}`);
  }
  if (profile.experience_level) {
    sections.push(`Experience Level: ${profile.experience_level}`);
  }
  if (profile.years_total_experience) {
    sections.push(`Years of Experience: ${profile.years_total_experience}`);
  }

  // Target Roles
  if (profile.role_preferences && profile.role_preferences.length > 0) {
    sections.push(`Target Roles: ${profile.role_preferences.join(', ')}`);
  }

  // Skills
  if (profile.top_skills && profile.top_skills.length > 0) {
    sections.push(`Skills: ${profile.top_skills.join(', ')}`);
  }

  // Work Preferences
  if (profile.job_types && profile.job_types.length > 0) {
    sections.push(`Work Type Preferences: ${profile.job_types.join(', ')}`);
  }

  // Salary
  if (profile.expected_salary_min) {
    sections.push(`Minimum Salary: $${profile.expected_salary_min}`);
  }

  // Professional Summary
  if (profile.professional_summary) {
    sections.push(`\nProfessional Summary:\n${profile.professional_summary}`);
  }

  // Resume Text (if available and different from summary)
  if (profile.cv_text && profile.cv_text !== profile.professional_summary) {
    sections.push(`\nResume:\n${profile.cv_text}`);
  }

  const formattedProfile = sections.join('\n');

  console.log(
    '[ProfileStorage] Formatted profile for AI:',
    formattedProfile.length,
    'characters'
  );

  return formattedProfile;
}

/**
 * Check if profile needs refresh (older than 1 hour)
 * @returns {Promise<boolean>}
 */
async function needsRefresh() {
  try {
    const result = await chrome.storage.local.get(['profileLastUpdated']);

    if (!result.profileLastUpdated) {
      return true;
    }

    const lastUpdated = new Date(result.profileLastUpdated);
    const now = new Date();
    const hoursSinceUpdate = (now - lastUpdated) / (1000 * 60 * 60);

    return hoursSinceUpdate > 1;
  } catch (error) {
    console.error('[ProfileStorage] Error checking refresh status:', error);
    return true;
  }
}

// Export functions for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    fetchProfileFromRR,
    mapRRProfileToExtension,
    saveProfile,
    getProfile,
    syncProfileFromRR,
    getProfileForAI,
    needsRefresh,
  };
}
