console.log('[Sidepanel] Script starting - this should appear immediately');

// Simple test to see if any JavaScript works
document.addEventListener('DOMContentLoaded', () => {
  console.log('[Sidepanel] DOM loaded - testing basic functionality');

  // rerunBtn removed
});

(() => {
  console.log('[Sidepanel] Script starting - this should appear immediately');
  const $ = (id) => document.getElementById(id);

  const apiKeyStatusEl = $('apiKeyStatus');
  const cvEl = $('cvTextarea');
  const jdEl = $('jdTextarea');
  const formEl = $('formTextarea');
  const analyzeBtn = $('generateBtn');
  const clearBtn = $('clearBtn');
  const resultsSection = $('results');
  const resultsList = $('resultsList');
  const notesEl = $('notes');
  const loadingEl = $('loadingOverlay');
  const copyAllBtn = $('copyAllBtn');
  const fillPageBtn = $('fillPageBtn');
  const scanJDBtn = $('scanJdBtn');
  const scanFormBtn = $('scanFormBtn');
  const analyzeFastBtn = $('analyzeFastBtn');
  const scanJDFastBtn = $('scanJDFastBtn');
  const scanFormFastBtn = $('scanFormFastBtn');
  const assetFileInput = $('cvFileInput');
  const assetStatusEl = $('assetStatus');
  const modelSelect = $('modelSelect');
  console.log('assetFileInput element:', assetFileInput);
  console.log('assetStatusEl element:', assetStatusEl);

  // Auth & BYOK elements
  const authNameInput = $('authName');
  const authEmailInput = $('authEmail');
  const authPasswordInput = $('authPassword');
  const agreeTermsCheckbox = $('agreeTerms');
  const agreeMarketingCheckbox = $('agreeMarketing');
  const signUpBtn = $('signUpBtn');
  const signInBtn = $('signInBtn');
  const signOutBtn = $('signOutBtn');
  const signInWithGoogleBtn = $('signInWithGoogleBtn');
  const signUpWithGoogleBtn = $('signUpWithGoogleBtn');
  const forgotPasswordBtn = $('forgotPasswordBtn');
  const togglePasswordBtn = $('togglePasswordBtn');
  const authStatusEl = $('authStatus');
  const byokInput = $('byokInput');
  const saveByokBtn = $('saveByokBtn');
  const clearByokBtn = $('clearByokBtn');
  const byokStatusEl = $('byokStatus');
  const themeToggleBtn = null;

  // New document generation elements
  const generateCvBtn = $('generateCvBtn');
  const generateCoverLetterBtn = $('generateCoverLetterBtn');
  const documentsSection = $('documents'); // Legacy, kept for compatibility
  const resumePage = $('resumePage');
  const coverPage = $('coverPage');
  const generatedCvEl = $('generatedCv');
  const generatedCoverEl = $('generatedCoverLetter');
  const copyCvBtn = $('copyCvBtn');
  const copyCoverBtn = $('copyCoverBtn');
  const exportCvPdfBtn = $('exportCvPdfBtn');
  const exportCoverPdfBtn = $('exportCoverPdfBtn');
  const resumeBackBtn = $('resumeBackBtn');
  const coverBackBtn = $('coverBackBtn');
  const resultsBackBtn = $('resultsBackBtn');
  const downloadResumeBtn = $('downloadResumeBtn');
  const downloadCoverBtn = $('downloadCoverBtn');
  const resumeDownloadMenu = $('resumeDownloadMenu');
  const coverDownloadMenu = $('coverDownloadMenu');
  const resumeDirectLink = $('resumeDirectLink');
  const coverDirectLink = $('coverDirectLink');

  // Filling status elements
  const fillingStatusBanner = $('fillingStatusBanner');
  const fillingStatusText = $('fillingStatusText');
  const fillingProgressFill = $('fillingProgressFill');
  const stopFillingBtn = $('stopFillingBtn');

  // Filling state
  let isFillingAborted = false;
  let currentFillingPromise = null;

  let CONFIG = {
    apiBaseUrl: '',
    upgradeUrl: '',
    rrApiBaseUrl: '',
    rrProductionApiBaseUrl: '',
  };

  function resolveRrApiBase() {
    const raw =
      CONFIG?.activeRrBaseUrl ||
      CONFIG?.rrApiBaseUrl ||
      CONFIG?.rrProductionApiBaseUrl ||
      '';
    return raw.replace(/\/$/, '');
  }
  let authSession = null; // { access_token, provider }
  let byok = '';
  let clientId = '';
  let currentUserEmail = '';
  let cachedJobUrl = ''; // Cache job URL when scanning JD
  let cachedJobMeta = { jobTitle: '', company: '', url: '', jobId: '' }; // Cache job metadata
  let lastRRSessionContext = null;
  const RR_STATE_STORAGE_KEY = 'rrIntegrationState';
  let resumeDownloadUrl = '';
  let coverDownloadUrl = '';
  // Track generated document URLs from backend for RR sync
  let generatedResumeUrl = '';
  let generatedCoverLetterUrl = '';

  try {
    chrome.storage.local.remove('rrGesturePrompt');
  } catch (_) {}

  function extractJobContext(rrState = {}, overrides = {}) {
    const meta = {
      ...(rrState.metadata || {}),
      ...(overrides.metadata || {}),
    };
    return {
      jobId:
        overrides.jobId ||
        overrides.job_id ||
        rrState.jobId ||
        meta.jobId ||
        meta.job_id ||
        '',
      jobTitle:
        overrides.jobTitle ||
        overrides.job_title ||
        meta.jobTitle ||
        meta.job_title ||
        '',
      company:
        overrides.company ||
        overrides.company_name ||
        meta.company ||
        meta.company_name ||
        '',
      url:
        overrides.url ||
        overrides.external_job_url ||
        rrState.externalJobUrl ||
        meta.external_job_url ||
        meta.url ||
        meta.jobUrl ||
        '',
    };
  }

  function updateCachedJobMeta(context = {}) {
    if (
      !context ||
      (!context.jobId && !context.jobTitle && !context.company && !context.url)
    ) {
      return;
    }
    cachedJobMeta = {
      jobId: context.jobId || cachedJobMeta.jobId || '',
      jobTitle: context.jobTitle || cachedJobMeta.jobTitle || '',
      company: context.company || cachedJobMeta.company || '',
      url: context.url || cachedJobMeta.url || '',
    };
    if (cachedJobMeta.url) {
      cachedJobUrl = cachedJobMeta.url;
    }
  }

  function syncJobCacheFromRRState(rrState = {}, overrides = {}) {
    updateCachedJobMeta(extractJobContext(rrState, overrides));
  }

  const RRIntegration = (() => {
    const DEFAULT_STATE = {
      authToken: '',
      user: null,
      jobId: '',
      extensionClientId: '',
      externalJobUrl: '',
      metadata: {},
      sessionId: '',
      resumeUrl: '',
      coverLetterUrl: '',
      applied: false,
    };

    let state = { ...DEFAULT_STATE };
    let initialized = false;
    let initPromise = null;

    function getBaseUrl() {
      const preferred =
        CONFIG?.activeRrBaseUrl ||
        CONFIG?.rrApiBaseUrl ||
        CONFIG?.rrProductionApiBaseUrl ||
        CONFIG?.apiBaseUrl ||
        '';
      return preferred.replace(/\/$/, '');
    }

    function mergeState(partial) {
      state = { ...state, ...(partial || {}) };
      try {
        syncJobCacheFromRRState(state);
      } catch (_) {}
      return state;
    }

    async function persistState(partial) {
      mergeState(partial);
      try {
        await chrome.storage.local.set({
          [RR_STATE_STORAGE_KEY]: state,
        });
      } catch (error) {
        console.warn('[RRIntegration] Failed to persist state:', error);
      }
    }

    async function refreshFromStorage() {
      try {
        const stored = await chrome.storage.local.get([
          RR_STATE_STORAGE_KEY,
          'rrAuthToken',
          'authToken',
          'currentJob',
        ]);

        console.log('[RRIntegration] refreshFromStorage - raw storage:', {
          hasRrIntegrationState: !!stored?.[RR_STATE_STORAGE_KEY],
          hasRrAuthToken: !!stored?.rrAuthToken,
          hasAuthToken: !!stored?.authToken,
          hasCurrentJob: !!stored?.currentJob,
          rrIntegrationState: stored?.[RR_STATE_STORAGE_KEY]
            ? {
                hasAuthToken: !!stored[RR_STATE_STORAGE_KEY].authToken,
                user: stored[RR_STATE_STORAGE_KEY].user?.email || 'N/A',
                jobId: stored[RR_STATE_STORAGE_KEY].jobId || 'N/A',
              }
            : null,
        });

        const next = {
          ...DEFAULT_STATE,
          ...(stored?.[RR_STATE_STORAGE_KEY] || {}),
        };
        if (!next.authToken && stored?.rrAuthToken) {
          next.authToken = stored.rrAuthToken;
          console.log('[RRIntegration] Using rrAuthToken from storage');
        }
        if (!next.authToken && stored?.authToken) {
          next.authToken = stored.authToken;
          console.log('[RRIntegration] Using authToken from storage');
        }
        const currentJob = stored?.currentJob || {};
        if (currentJob) {
          if (!next.jobId && currentJob.job_id) {
            next.jobId = currentJob.job_id;
          }
          if (!next.externalJobUrl && currentJob.external_job_url) {
            next.externalJobUrl = currentJob.external_job_url;
          }
          if (currentJob.metadata) {
            next.metadata = {
              ...(next.metadata || {}),
              ...(currentJob.metadata || {}),
            };
          }
          if (!next.user && currentJob.user) {
            next.user = currentJob.user;
          }
        }

        console.log('[RRIntegration] refreshFromStorage - final state:', {
          hasAuthToken: !!next.authToken,
          tokenPreview: next.authToken
            ? next.authToken.slice(0, 20) + '...'
            : 'NONE',
          user: next.user?.email || 'N/A',
          jobId: next.jobId || 'N/A',
        });

        mergeState(next);
      } catch (error) {
        console.warn('[RRIntegration] Failed to read storage:', error);
      }
      return state;
    }

    function subscribeToChanges() {
      try {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area !== 'local') return;
          if (changes[RR_STATE_STORAGE_KEY]) {
            mergeState(changes[RR_STATE_STORAGE_KEY].newValue || DEFAULT_STATE);
          }
          if (changes.rrAuthToken) {
            mergeState({ authToken: changes.rrAuthToken.newValue || '' });
          }
          if (changes.authToken) {
            mergeState({ authToken: changes.authToken.newValue || '' });
          }
          if (changes.currentJob) {
            const value = changes.currentJob.newValue || {};
            mergeState({
              jobId: value.job_id || state.jobId,
              externalJobUrl: value.external_job_url || state.externalJobUrl,
              metadata: {
                ...(state.metadata || {}),
                ...(value.metadata || {}),
              },
            });
          }
        });
      } catch (_) {}

      try {
        chrome.runtime.onMessage.addListener((msg) => {
          if (msg?.type === 'rrIntegrationStateUpdated' && msg.payload) {
            mergeState(msg.payload);
          }
        });
      } catch (_) {}
    }

    // Helper to check if error is a recoverable Chrome extension error
    function isRecoverableExtensionError(error) {
      const msg = String(error?.message || error || '').toLowerCase();
      return (
        msg.includes('extension context invalidated') ||
        msg.includes('could not establish connection') ||
        msg.includes('receiving end does not exist') ||
        msg.includes('message port closed') ||
        msg.includes('no tab with id') ||
        msg.includes('cannot access') ||
        msg.includes('frame was removed')
      );
    }

    async function requestTokenFromPage() {
      try {
        const [tab] = await chrome.tabs.query({
          active: true,
          currentWindow: true,
        });
        if (!tab?.id) return;
        await chrome.tabs.sendMessage(tab.id, { type: 'rrRequestToken' });
      } catch (error) {
        // Only log if it's not a common/expected extension error
        if (!isRecoverableExtensionError(error)) {
          console.warn('[RRIntegration] Failed to request token:', error);
        }
        // Silently ignore expected errors (content script not loaded, tab closed, etc.)
      }
    }

    async function ensureAuthToken({ requestIfMissing = true } = {}) {
      if (state.authToken) return state.authToken;
      await refreshFromStorage();
      if (state.authToken) return state.authToken;
      if (!requestIfMissing) return '';
      await requestTokenFromPage();
      await delay(600);
      await refreshFromStorage();
      if (state.authToken) return state.authToken;
      throw new Error('Reverse Recruiting token not available yet.');
    }

    async function rrFetch(path, { method = 'GET', headers, body } = {}) {
      const base = getBaseUrl();
      if (!base) throw new Error('Reverse Recruiting API base URL missing');
      const token = await ensureAuthToken();
      const finalHeaders = new Headers(headers || {});
      if (token) finalHeaders.set('Authorization', `Bearer ${token}`);
      const isFormData =
        typeof FormData !== 'undefined' && body instanceof FormData;
      if (!isFormData && !finalHeaders.has('Content-Type') && body != null) {
        finalHeaders.set('Content-Type', 'application/json');
      }
      const response = await fetch(`${base}${path}`, {
        method,
        headers: finalHeaders,
        body,
        credentials: 'include',
      });
      if (!response.ok) {
        const text = await response.text().catch(() => '');
        throw new Error(text || `RR API error ${response.status}`);
      }
      const data = await response.json().catch(() => ({}));
      return data;
    }

    async function ensureSession(context = {}) {
      const jobId =
        context.job_id ||
        context.jobId ||
        state.jobId ||
        context.defaultJobId ||
        '';
      if (!jobId) {
        throw new Error(
          'job_id is required to create a Reverse Recruiting session'
        );
      }
      if (state.sessionId && state.jobId === jobId) {
        return state.sessionId;
      }
      const payload = {
        job_id: jobId,
        extension_client_id:
          context.extension_client_id ||
          context.extensionClientId ||
          state.extensionClientId ||
          clientId ||
          'jobapai-extension',
        external_job_url:
          context.external_job_url ||
          context.externalJobUrl ||
          state.externalJobUrl ||
          cachedJobMeta?.url ||
          '',
        user_agent: context.user_agent || navigator.userAgent,
        metadata: {
          source: 'chrome-extension',
          ...(state.metadata || {}),
          ...(context.metadata || {}),
        },
      };
      const res = await rrFetch('/v1/apps/session', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      const sessionId =
        res?.data?.session_id || res?.session_id || res?.data?.sessionId || '';
      if (!sessionId) {
        throw new Error('Session creation did not return a session_id');
      }
      await persistState({
        sessionId,
        jobId,
        extensionClientId: payload.extension_client_id,
        externalJobUrl: payload.external_job_url,
        metadata: payload.metadata,
      });
      return sessionId;
    }

    async function uploadExtensionFiles({ resumeFile, coverLetterFile }) {
      if (!resumeFile && !coverLetterFile) {
        console.warn(
          '[RRIntegration] uploadExtensionFiles called with no files'
        );
        return state;
      }

      // Get jobId - REQUIRED as query parameter
      const jobId = state.jobId || cachedJobMeta?.jobId || '';
      if (!jobId) {
        console.error(
          '[RRIntegration] uploadExtensionFiles: jobId is REQUIRED but missing'
        );
        throw new Error('jobId is required for file upload');
      }

      const form = new FormData();
      if (resumeFile) form.append('resume', resumeFile);
      if (coverLetterFile) form.append('cover_letter', coverLetterFile);

      // Build URL with jobId as query parameter (REQUIRED by the endpoint)
      const uploadPath = `/v1/upload/extension-files?jobId=${encodeURIComponent(
        jobId
      )}`;

      const base = getBaseUrl();
      const token = await ensureAuthToken();

      console.log('='.repeat(60));
      console.log(
        '[RRIntegration] ===== UPLOAD EXTENSION FILES - REQUEST ====='
      );
      console.log('[RRIntegration] Timestamp:', new Date().toISOString());
      console.log('[RRIntegration] URL:', `${base}${uploadPath}`);
      console.log('[RRIntegration] Method: POST');
      console.log('[RRIntegration] Content-Type: multipart/form-data');
      console.log(
        '[RRIntegration] Authorization:',
        token ? `Bearer ${token.slice(0, 20)}...` : 'NONE'
      );
      console.log('[RRIntegration] Query Parameters:', { jobId });
      console.log('[RRIntegration] FormData Files:');
      if (resumeFile) {
        console.log('[RRIntegration]   - resume:', {
          name: resumeFile.name,
          type: resumeFile.type || 'unknown',
          size: resumeFile.size
            ? `${(resumeFile.size / 1024).toFixed(2)} KB`
            : 'unknown',
        });
      }
      if (coverLetterFile) {
        console.log('[RRIntegration]   - cover_letter:', {
          name: coverLetterFile.name,
          type: coverLetterFile.type || 'unknown',
          size: coverLetterFile.size
            ? `${(coverLetterFile.size / 1024).toFixed(2)} KB`
            : 'unknown',
        });
      }
      console.log('='.repeat(60));

      try {
        const finalHeaders = new Headers();
        if (token) finalHeaders.set('Authorization', `Bearer ${token}`);

        const response = await fetch(`${base}${uploadPath}`, {
          method: 'POST',
          headers: finalHeaders,
          body: form,
          credentials: 'include',
        });

        const responseText = await response.text();

        console.log('='.repeat(60));
        console.log(
          '[RRIntegration] ===== UPLOAD EXTENSION FILES - RESPONSE ====='
        );
        console.log('[RRIntegration] Timestamp:', new Date().toISOString());
        console.log(
          '[RRIntegration] Status:',
          response.status,
          response.statusText
        );
        console.log('[RRIntegration] Response Headers:', {
          contentType: response.headers.get('content-type'),
          contentLength: response.headers.get('content-length'),
        });
        // Do not log raw response body (may contain PII / signed URLs)
        console.log(
          '[RRIntegration] Response Body Length:',
          responseText?.length || 0
        );

        if (!response.ok) {
          console.error('[RRIntegration] ===== UPLOAD FAILED =====');
          console.error('[RRIntegration] Error Status:', response.status);
          // Avoid dumping raw body (may contain PII)
          console.error(
            '[RRIntegration] Error Body Length:',
            responseText?.length || 0
          );
          console.log('='.repeat(60));
          throw new Error(
            responseText || `Upload failed with status ${response.status}`
          );
        }

        let data = {};
        try {
          data = JSON.parse(responseText);
        } catch (_) {
          console.warn(
            '[RRIntegration] Response is not valid JSON:',
            responseText
          );
        }

        const result = data?.data || data || {};
        console.log('[RRIntegration] ===== UPLOAD SUCCESS =====');
        console.log(
          '[RRIntegration] Parsed Response:',
          JSON.stringify(result, null, 2)
        );
        console.log('[RRIntegration] Extracted URLs:');
        console.log(
          '[RRIntegration]   - resume_url:',
          result.resume_url || 'NOT RETURNED'
        );
        console.log(
          '[RRIntegration]   - cover_letter_url:',
          result.cover_letter_url || 'NOT RETURNED'
        );
        console.log('='.repeat(60));

        // Persist the URLs to state
        await persistState({
          resumeUrl: result.resume_url || state.resumeUrl,
          coverLetterUrl: result.cover_letter_url || state.coverLetterUrl,
        });

        return result;
      } catch (error) {
        console.error('[RRIntegration] ===== UPLOAD ERROR =====');
        console.error('[RRIntegration] Error:', error.message);
        console.error('='.repeat(60));
        throw error;
      }
    }

    async function syncProfileSnapshot({
      session_id,
      resume_url,
      cover_letter_url,
      profile_snapshot,
      applied,
      skipUrlFallback = false, // If true, don't fallback to state URLs
    }) {
      const sessionId = session_id || state.sessionId;
      if (!sessionId) {
        throw new Error('session_id is required to sync profile');
      }
      const jobId = state.jobId || cachedJobMeta?.jobId || '';

      // Determine final URLs:
      // - If skipUrlFallback is true, only use explicitly provided URLs (or empty)
      // - Otherwise, fallback to state URLs if not provided
      const finalResumeUrl = skipUrlFallback
        ? resume_url || ''
        : resume_url || state.resumeUrl || '';
      const finalCoverUrl = skipUrlFallback
        ? cover_letter_url || ''
        : cover_letter_url || state.coverLetterUrl || '';

      const payload = {
        session_id: sessionId,
        job_id: jobId, // Include job_id in sync request
        resume_url: finalResumeUrl,
        cover_letter_url: finalCoverUrl,
        profile_snapshot: profile_snapshot || {},
        applied:
          typeof applied === 'boolean' ? applied : state.applied || false,
      };

      const base = getBaseUrl();
      const token = await ensureAuthToken();

      console.log('='.repeat(60));
      console.log('[RRIntegration] ===== PROFILE SYNC - REQUEST =====');
      console.log('[RRIntegration] Timestamp:', new Date().toISOString());
      console.log('[RRIntegration] URL:', `${base}/v1/profile/sync`);
      console.log('[RRIntegration] Method: POST');
      console.log('[RRIntegration] Content-Type: application/json');
      console.log(
        '[RRIntegration] Authorization:',
        token ? `Bearer ${token.slice(0, 20)}...` : 'NONE'
      );
      console.log('[RRIntegration] Request Payload:');
      console.log('[RRIntegration]   session_id:', payload.session_id);
      console.log('[RRIntegration]   job_id:', payload.job_id || 'NOT SET');
      console.log(
        '[RRIntegration]   resume_url:',
        payload.resume_url || 'EMPTY'
      );
      console.log(
        '[RRIntegration]   cover_letter_url:',
        payload.cover_letter_url || 'EMPTY'
      );
      console.log('[RRIntegration]   applied:', payload.applied);
      console.log('[RRIntegration]   profile_snapshot:', {
        headline: payload.profile_snapshot?.headline || 'N/A',
        skillsCount: Array.isArray(payload.profile_snapshot?.skills)
          ? payload.profile_snapshot.skills.length
          : 0,
        hasExperience: !!payload.profile_snapshot?.experience,
        hasEducation: !!payload.profile_snapshot?.education,
      });
      // console.log('[RRIntegration] Full Payload JSON:');
      // console.log(JSON.stringify(payload, null, 2));
      // console.log('='.repeat(60));

      try {
        const res = await rrFetch('/v1/profile/sync', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
        const data = res?.data || res || {};

        console.log('='.repeat(60));
        console.log('[RRIntegration] ===== PROFILE SYNC - RESPONSE =====');
        console.log('[RRIntegration] Timestamp:', new Date().toISOString());
        console.log('[RRIntegration] Status: SUCCESS');
        console.log('[RRIntegration] Response Data:');
        console.log(
          '[RRIntegration]   snapshot_id:',
          data.snapshot_id || 'NOT RETURNED'
        );
        console.log(
          '[RRIntegration]   resume_url:',
          data.resume_url || 'NOT RETURNED'
        );
        console.log(
          '[RRIntegration]   cover_letter_url:',
          data.cover_letter_url || 'NOT RETURNED'
        );
        console.log('[RRIntegration]   applied:', data.applied);
        console.log(
          '[RRIntegration]   job_status_updated:',
          data.job_status_updated
        );
        // Do not log full response JSON (may contain PII / signed URLs)
        console.log('[RRIntegration] Response keys:', Object.keys(data || {}));
        console.log('='.repeat(60));

        await persistState({
          resumeUrl: data.resume_url || payload.resume_url,
          coverLetterUrl: data.cover_letter_url || payload.cover_letter_url,
          applied:
            typeof data.applied === 'boolean' ? data.applied : payload.applied,
        });
        return data;
      } catch (error) {
        console.log('='.repeat(60));
        console.error('[RRIntegration] ===== PROFILE SYNC - ERROR =====');
        console.error('[RRIntegration] Timestamp:', new Date().toISOString());
        console.error('[RRIntegration] Error Message:', error.message);
        console.error('[RRIntegration] Error Stack:', error.stack);
        console.log('='.repeat(60));
        throw error;
      }
    }

    async function recordApplication(jobIdOverride, overrides = {}) {
      const jobId = jobIdOverride || state.jobId;
      if (!jobId) throw new Error('jobId is required to record application');
      const sessionId = overrides.session_id || state.sessionId;
      if (!sessionId)
        throw new Error('session_id is required to record application');
      const payload = {
        session_id: sessionId,
        job_id: jobId, // Include job_id in the payload
        external_job_url:
          overrides.external_job_url ||
          overrides.externalJobUrl ||
          state.externalJobUrl,
        applied:
          typeof overrides.applied === 'boolean'
            ? overrides.applied
            : state.applied,
        // Use globally stored generated URLs as fallback
        resume_url:
          overrides.resume_url || state.resumeUrl || generatedResumeUrl || '',
        cover_letter_url:
          overrides.cover_letter_url ||
          state.coverLetterUrl ||
          generatedCoverLetterUrl ||
          '',
      };
      const res = await rrFetch(
        `/v1/jobs/${encodeURIComponent(jobId)}/applications/extension`,
        {
          method: 'POST',
          body: JSON.stringify(payload),
        }
      );
      const data = res?.data || res || {};
      await persistState({
        applied:
          typeof data.applied === 'boolean' ? data.applied : payload.applied,
      });
      return data;
    }

    async function init() {
      if (initialized) return state;
      if (initPromise) return initPromise;
      initPromise = (async () => {
        await refreshFromStorage();
        subscribeToChanges();
        initialized = true;
        if (!state.authToken) {
          requestTokenFromPage().catch(() => {});
        }
        return state;
      })();
      return initPromise;
    }

    function getState() {
      return { ...state };
    }

    function hasAuthToken() {
      return !!state.authToken;
    }

    window.RRIntegration = {
      init,
      getState,
      hasAuthToken,
      getAuthToken: () => state.authToken || '',
      getBaseUrl,
      ensureAuthToken,
      ensureSession,
      uploadExtensionFiles,
      syncProfileSnapshot,
      recordApplication,
      requestTokenFromPage,
    };

    return window.RRIntegration;
  })();

  // Lightweight session cache helpers (avoid repeated network calls per tab)
  async function getSessionCache(key) {
    try {
      if (chrome?.storage?.session) {
        const out = await chrome.storage.session.get(key);
        const entry = out?.[key];
        if (entry && (!entry.expiry || Date.now() < entry.expiry)) {
          return entry.data;
        }
      }
    } catch (_) {}
    return null;
  }

  async function setSessionCache(key, data, ttlMs = 5 * 60 * 1000) {
    try {
      if (chrome?.storage?.session) {
        await chrome.storage.session.set({
          [key]: { data, expiry: Date.now() + ttlMs },
        });
      }
    } catch (_) {}
  }

  // Auth Check Functions
  async function checkAuthentication() {
    console.log('[checkAuthentication] Starting auth check...');
    try {
      try {
        await window.RRIntegration?.init?.();
      } catch (_) {}
      const rrState = window.RRIntegration?.getState?.();
      console.log('[checkAuthentication] RRIntegration state:', {
        hasAuthToken: !!rrState?.authToken,
        user: rrState?.user?.email || 'N/A',
        jobId: rrState?.jobId || 'N/A',
      });

      if (rrState?.authToken) {
        console.log(
          '[checkAuthentication] ✅ Found RR auth token - user is authenticated'
        );
        const rrEmail =
          rrState.user?.email ||
          rrState.user?.emailAddress ||
          rrState.user?.primaryEmail ||
          '';
        if (authStatusEl) {
          authStatusEl.textContent = rrEmail
            ? `Signed in via Reverse Recruiting (${rrEmail})`
            : 'Signed in via Reverse Recruiting';
          authStatusEl.className = 'status-message success';
        }
        if (rrEmail) currentUserEmail = rrEmail;
        updateAuthUI(true);
        return true;
      }

      console.log(
        '[checkAuthentication] No RR token - checking other sources...'
      );
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) {
        console.log('[checkAuthentication] No API base URL configured');
        return false;
      }

      let token = getAuthAccessToken();
      if (!token) token = await getLatestAccessToken();
      if (!token) {
        console.log('[checkAuthentication] ❌ No token found from any source');
        return false;
      }
      console.log('[checkAuthentication] Found token from other source');

      const cacheKey = `auth_me:${token.slice(0, 12)}`;
      const cached = await getSessionCache(cacheKey);
      if (cached?.ok) {
        currentUserEmail = cached?.user?.email || '';
        return true;
      }

      const headers = { Authorization: `Bearer ${token}` };
      const res = await fetch(`${base}/v1/auth/me`, {
        method: 'GET',
        headers,
        credentials: 'include',
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.ok) {
          await setSessionCache(cacheKey, data, 5 * 60 * 1000);
          currentUserEmail = data?.user?.email || '';
          return true;
        }
      }

      return false;
    } catch (err) {
      console.error('Auth check error:', err);
      return false;
    }
  }

  let isSignUpMode = true; // Track current auth mode

  function showAuthRequired() {
    const authScreen = $('authRequired');
    const mainContainer = $('mainContainer');
    if (authScreen) authScreen.classList.remove('hidden');
    if (mainContainer) mainContainer.classList.add('hidden');

    // Setup auth form
    setupAuthForm();
    updateAuthMode();
  }

  function updateAuthMode() {
    const nameField = $('authNameField');
    const marketingField = $('authMarketingField');
    const forgotPassword = $('authForgotPassword');
    const togglePrompt = $('authTogglePrompt');
    const toggleLink = $('authToggleLink');
    const googleBtnText = $('authGoogleBtnText');
    const submitBtnText = $('authSubmitBtnText');
    const passwordHelper = $('authPasswordHelper');

    if (isSignUpMode) {
      // Show signup mode
      if (nameField) nameField.style.display = '';
      if (marketingField) marketingField.style.display = '';
      if (forgotPassword) forgotPassword.classList.add('hidden');
      if (passwordHelper) passwordHelper.style.display = '';

      if (togglePrompt) togglePrompt.textContent = 'Already have an account?';
      if (toggleLink) toggleLink.textContent = 'Log in';
      if (googleBtnText) googleBtnText.textContent = 'Continue with Google';
      if (submitBtnText) submitBtnText.textContent = 'Continue with email';
    } else {
      // Show login mode
      if (nameField) nameField.style.display = 'none';
      if (marketingField) marketingField.style.display = 'none';
      if (forgotPassword) forgotPassword.classList.remove('hidden');
      if (passwordHelper) passwordHelper.style.display = 'none';

      if (togglePrompt) togglePrompt.textContent = "Don't have an account?";
      if (toggleLink) toggleLink.textContent = 'Sign up for free';
      if (googleBtnText) googleBtnText.textContent = 'Log in with Google';
      if (submitBtnText) submitBtnText.textContent = 'Log in';
    }
  }

  function setupAuthForm() {
    const authForm = $('authForm');
    const authToggleLink = $('authToggleLink');
    const authGoogleBtn = $('authGoogleBtn');
    const authTogglePasswordBtn = $('authTogglePasswordBtn');
    const authForgotPasswordBtn = $('authForgotPasswordBtn');

    // Toggle between signup and login
    if (authToggleLink) {
      authToggleLink.addEventListener('click', (e) => {
        e.preventDefault();
        isSignUpMode = !isSignUpMode;
        updateAuthMode();

        // Clear status message
        const statusEl = $('authStatusMessage');
        if (statusEl) {
          statusEl.classList.add('hidden');
          statusEl.textContent = '';
        }
      });
    }

    // Password visibility toggle
    if (authTogglePasswordBtn) {
      authTogglePasswordBtn.addEventListener('click', () => {
        const passwordInput = $('authPasswordInput');
        if (!passwordInput) return;

        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;

        const svg = authTogglePasswordBtn.querySelector('svg');
        if (type === 'text') {
          // Show eye (visible)
          svg.innerHTML =
            '<path d="M10 6.5C8.34315 6.5 7 7.84315 7 9.5C7 11.1569 8.34315 12.5 10 12.5C11.6569 12.5 13 11.1569 13 9.5C13 7.84315 11.6569 6.5 10 6.5Z" stroke="currentColor" stroke-width="1.5"/><path d="M1 9.5C2.5 6.5 5.5 4 10 4C14.5 4 17.5 6.5 19 9.5C17.5 12.5 14.5 15 10 15C5.5 15 2.5 12.5 1 9.5Z" stroke="currentColor" stroke-width="1.5"/>';
        } else {
          // Show eye-slash (hidden)
          svg.innerHTML =
            '<path d="M3.75 3.13L12.5 13.75M6.88 7.69C6.32 8.28 6 9.1 6 10C6 11.66 7.34 13 9 13C9.9 13 10.72 12.68 11.31 12.12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M1.25 5.36C2.5 7.5 5.5 11.5 10 11.5C11.5 11.5 12.75 11 13.75 10.25M8.38 4.38C8.75 4.13 9.25 4 10 4C14.5 4 17.5 8 18.75 10.15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><line x1="2.5" y1="2.5" x2="17.5" y2="17.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>';
        }
      });
    }

    // Google sign in
    if (authGoogleBtn) {
      authGoogleBtn.addEventListener('click', handleGoogleSignIn);
    }

    // Forgot password
    if (authForgotPasswordBtn) {
      authForgotPasswordBtn.addEventListener('click', handleForgotPassword);
    }

    // Form submission
    if (authForm) {
      authForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (isSignUpMode) {
          await handleSignUp();
        } else {
          await handleSignIn();
        }
      });
    }
  }

  async function handleSignUp() {
    const nameInput = $('authNameInput');
    const emailInput = $('authEmailInput');
    const passwordInput = $('authPasswordInput');
    const marketingCheckbox = $('authMarketingCheckbox');
    const submitBtn = $('authSubmitBtn');
    const submitSpinner = $('authSubmitSpinner');
    const submitText = $('authSubmitBtnText');
    const statusEl = $('authStatusMessage');

    const name = nameInput?.value.trim() || '';
    const email = emailInput?.value.trim() || '';
    const password = passwordInput?.value || '';
    const agreeMarketing = marketingCheckbox?.checked || false;

    // Validation
    if (!name) {
      showAuthStatus('Please enter your full name', 'error');
      return;
    }

    if (!email || !email.includes('@')) {
      showAuthStatus('Please enter a valid email', 'error');
      return;
    }

    if (
      password.length < 8 ||
      !/[a-zA-Z]/.test(password) ||
      !/[0-9]/.test(password)
    ) {
      showAuthStatus(
        'Password must be 8+ characters with letters and numbers',
        'error'
      );
      return;
    }

    try {
      // Show loading
      if (submitBtn) submitBtn.disabled = true;
      if (submitSpinner) submitSpinner.classList.remove('hidden');
      if (submitText) submitText.textContent = 'Creating account...';

      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) throw new Error('API not configured');

      console.log('Signup: Sending request...', {
        name,
        email,
        apiBaseUrl: base,
      });

      const res = await fetch(`${base}/v1/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          password,
          agreeMarketing,
          clientId,
        }),
        credentials: 'include',
      });

      console.log('Signup: Response received', {
        status: res.status,
        statusText: res.statusText,
        contentType: res.headers.get('content-type'),
      });

      // Check if response has content
      const contentType = res.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await res.text();
        console.error('Signup: Non-JSON response', {
          status: res.status,
          body: text,
        });
        throw new Error(
          `Server returned ${res.status}: ${text || 'No response content'}`
        );
      }

      let data;
      try {
        data = await res.json();
        console.log('Signup: JSON parsed', { hasToken: !!data?.access_token });
      } catch (jsonErr) {
        console.error('Signup: JSON parse error', jsonErr);
        throw new Error(
          `Invalid server response (HTTP ${res.status}). Please try again or contact support.`
        );
      }

      if (!res.ok) {
        // Handle duplicate email specifically
        if (data?.error && /already exists/i.test(data.error)) {
          console.log('Signup: Email already exists');
          showAuthStatus(
            'Account already exists with this email. Sign in to continue.',
            'error'
          );
          return;
        }

        const errorMsg =
          data?.error || data?.message || `Server error (${res.status})`;
        console.error('Signup: Request failed', {
          status: res.status,
          error: errorMsg,
        });
        throw new Error(errorMsg);
      }

      if (data?.access_token) {
        console.log('Signup: Success! Saving session...');
        const session = {
          access_token: data.access_token,
          provider: 'email',
        };
        rememberAuthSession(session);
        await persistWebSession(data.access_token);
        currentUserEmail = email;

        showAuthStatus('Account created successfully! 🎉', 'success');

        // Show main interface after short delay
        setTimeout(async () => {
          await hideAuthRequired();
        }, 1500);
      } else {
        // New users: open skippable profile/questions in a new tab; also allow skipping
        showAuthStatus(
          'Account created. Opening quick profile (optional)…',
          'success'
        );
        try {
          chrome.tabs.create({
            url: chrome.runtime.getURL('profile-setup.html'),
          });
        } catch (_) {}
      }
    } catch (err) {
      console.error('Signup Error:', err);
      showAuthStatus(
        err.message || 'Signup failed. Please try again.',
        'error'
      );
    } finally {
      if (submitBtn) submitBtn.disabled = false;
      if (submitSpinner) submitSpinner.classList.add('hidden');
      if (submitText) submitText.textContent = 'Continue with email';
    }
  }

  async function handleSignIn() {
    const emailInput = $('authEmailInput');
    const passwordInput = $('authPasswordInput');
    const submitBtn = $('authSubmitBtn');
    const submitSpinner = $('authSubmitSpinner');
    const submitText = $('authSubmitBtnText');

    const email = emailInput?.value.trim() || '';
    const password = passwordInput?.value || '';

    // Validation
    if (!email || !email.includes('@')) {
      showAuthStatus('Please enter a valid email', 'error');
      return;
    }

    if (!password) {
      showAuthStatus('Please enter your password', 'error');
      return;
    }

    try {
      // Show loading
      if (submitBtn) submitBtn.disabled = true;
      if (submitSpinner) submitSpinner.classList.remove('hidden');
      if (submitText) submitText.textContent = 'Signing in...';

      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) throw new Error('API not configured');

      console.log('Login: Sending request...', { email, apiBaseUrl: base });

      const res = await fetch(`${base}/v1/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, clientId }),
        credentials: 'include',
      });

      console.log('Login: Response received', {
        status: res.status,
        statusText: res.statusText,
        contentType: res.headers.get('content-type'),
      });

      // Check if response has content
      const contentType = res.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await res.text();
        console.error('Login: Non-JSON response', {
          status: res.status,
          body: text,
        });
        throw new Error(
          `Server returned ${res.status}: ${text || 'No response content'}`
        );
      }

      let data;
      try {
        data = await res.json();
        console.log('Login: JSON parsed', { hasToken: !!data?.access_token });
      } catch (jsonErr) {
        console.error('Login: JSON parse error', jsonErr);
        throw new Error(
          `Invalid server response (HTTP ${res.status}). Please try again or contact support.`
        );
      }

      if (!res.ok) {
        const errorMsg =
          data?.error || data?.message || `Server error (${res.status})`;
        console.error('Login: Request failed', {
          status: res.status,
          error: errorMsg,
        });
        throw new Error(errorMsg);
      }

      if (data?.access_token) {
        console.log('Login: Success! Saving session...');
        const session = {
          access_token: data.access_token,
          provider: 'email',
        };
        rememberAuthSession(session);
        await persistWebSession(data.access_token);
        currentUserEmail = email;

        showAuthStatus('Welcome back! 👋', 'success');

        // Sync profile from database in background
        if (window.JobApAIProfile?.syncOnLogin) {
          window.JobApAIProfile.syncOnLogin()
            .then((result) => {
              if (result.success) {
                console.log('[Login] Profile synced from database');
              }
            })
            .catch((e) => console.error('[Login] Profile sync error:', e));
        }

        // Show main interface after short delay
        setTimeout(async () => {
          await hideAuthRequired();
        }, 1500);
      } else {
        throw new Error('No access token received from server');
      }
    } catch (err) {
      console.error('Login Error:', err);
      showAuthStatus(err.message || 'Login failed. Please try again.', 'error');
    } finally {
      if (submitBtn) submitBtn.disabled = false;
      if (submitSpinner) submitSpinner.classList.add('hidden');
      if (submitText) submitText.textContent = 'Log in';
    }
  }

  async function handleGoogleSignIn() {
    const googleBtn = $('authGoogleBtn');
    const googleBtnText = $('authGoogleBtnText');

    try {
      if (googleBtn) googleBtn.disabled = true;
      if (googleBtnText) googleBtnText.textContent = 'Opening Google...';

      console.log('[Google Sign-In] Starting Firebase Web Google Auth...');

      const module = await import(chrome.runtime.getURL('firebase-auth.js'));
      if (!module?.signInWithGoogle) {
        throw new Error('Firebase Google sign-in not available');
      }
      const response = await module.signInWithGoogle();

      if (!response) {
        throw new Error('No response from Firebase Google sign-in.');
      }
      if (response.error) {
        throw new Error(response.error);
      }
      if (!response.user || !response.session) {
        throw new Error('No user data received from Google');
      }

      console.log('[Google Sign-In] Success:', response.user);

      rememberAuthSession({ ...response.session, provider: 'google' });
      await persistWebSession(response.session.access_token);

      currentUserEmail = response.user.email;

      showAuthStatus('Signed in with Google! 🎉', 'success');

      try {
        const profileData = {
          email: response.user.email,
          full_name: response.user.displayName || '',
          source: 'google',
          onboardingComplete: false,
        };

        const rrBase = resolveRrApiBase();
        if (rrBase) {
          const syncResponse = await fetch(`${rrBase}/v1/profile/sync`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${response.session.access_token}`,
            },
            body: JSON.stringify({ profile: profileData }),
          });

          if (syncResponse.ok) {
            console.log('[Google OAuth] Initial profile created in database');
            if (window.JobApAIProfile?.syncOnLogin) {
              const syncResult = await window.JobApAIProfile.syncOnLogin();
              if (syncResult.success) {
                console.log('[Google OAuth] Profile synced from database');
              }
            }
          } else {
            console.warn(
              '[Google OAuth] Failed to create initial profile:',
              await syncResponse.text()
            );
          }
        }
      } catch (syncError) {
        console.error('[Google OAuth] Profile creation error:', syncError);
      }

      try {
        chrome.tabs.create({
          url: chrome.runtime.getURL('profile-setup.html'),
        });
      } catch (_) {}

      setTimeout(async () => {
        await hideAuthRequired();
        await refreshAuthStatus();
      }, 1500);
    } catch (err) {
      console.error('Google sign-in error:', err);
      showAuthStatus(
        err?.message || 'Google sign-in failed. Please try again.',
        'error'
      );
    } finally {
      if (googleBtn) googleBtn.disabled = false;
      if (googleBtnText) googleBtnText.textContent = 'Continue with Google';
    }
  }

  async function handleForgotPassword(e) {
    if (e) e.preventDefault();

    const emailInput = $('authEmailInput');
    const email = emailInput?.value.trim() || '';

    if (!email || !email.includes('@')) {
      showAuthStatus('Please enter your email first', 'error');
      return;
    }

    try {
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) throw new Error('API not configured');

      const res = await fetch(`${base}/v1/auth/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
        credentials: 'include',
      });

      const data = await res.json();

      if (res.ok && data?.ok) {
        showAuthStatus('Password reset link sent to your email', 'success');
      } else {
        throw new Error(data?.error || 'Request failed');
      }
    } catch (err) {
      showAuthStatus(err.message || 'Could not send reset email', 'error');
    }
  }

  function showAuthStatus(message, type = 'error') {
    const statusEl = $('authStatusMessage');
    if (!statusEl) return;

    statusEl.textContent = message;
    statusEl.className = `auth-status ${type}`;
    statusEl.classList.remove('hidden');

    // Auto-hide success messages
    if (type === 'success') {
      setTimeout(() => {
        statusEl.classList.add('hidden');
      }, 3000);
    }
  }

  async function hideAuthRequired() {
    const authScreen = $('authRequired');
    const mainContainer = $('mainContainer');
    if (authScreen) authScreen.classList.add('hidden');
    if (mainContainer) mainContainer.classList.remove('hidden');

    // Initialize the main interface after showing it
    await initAuthSession();
    await loadByok();
    await loadModelSelection();

    // Preload jsPDF so PDF export always works
    try {
      await loadJsPdfCtor();
    } catch (_) {}

    refreshApiKeyStatus();
    refreshAuthStatus();

    // Setup UI components
    setupAIModelSelector();
    setupUserMenu();
    checkFormCompletion();
  }

  // Check if all steps are complete and enable/disable Generate button
  function checkFormCompletion() {
    const hasJD = jdEl && jdEl.value.trim().length > 20;
    const hasForm = formEl && formEl.value.trim().length > 10;
    const hasCV = cvEl && cvEl.value.trim().length > 50;

    const allComplete = hasJD && hasForm && hasCV;

    if (analyzeBtn) {
      analyzeBtn.disabled = !allComplete;
      analyzeBtn.classList.toggle('disabled', !allComplete);
    }

    return allComplete;
  }

  // AI Model Selector Dropdown
  let aiSelectorSetup = false; // Prevent multiple setups
  function setupAIModelSelector() {
    const aiSelectorBtn = $('aiSelectorBtn');
    const aiDropdown = $('aiDropdown');
    const selectedModelEl = $('selectedModel');

    if (!aiSelectorBtn || !aiDropdown) return;
    if (aiSelectorSetup) return; // Already setup
    aiSelectorSetup = true;

    let currentModel = 'grok-4-1-fast-non-reasoning';

    // Toggle dropdown on button click
    aiSelectorBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isHidden = aiDropdown.classList.contains('hidden');
      aiDropdown.classList.toggle('hidden');
      console.log(
        'AI Selector clicked, dropdown is now:',
        isHidden ? 'visible' : 'hidden'
      );
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (aiDropdown && !aiDropdown.classList.contains('hidden')) {
        // Don't close if clicking inside dropdown
        if (
          !aiDropdown.contains(e.target) &&
          !aiSelectorBtn.contains(e.target)
        ) {
          aiDropdown.classList.add('hidden');
        }
      }
    });

    // Prevent dropdown from closing when clicking inside it
    aiDropdown.addEventListener('click', (e) => {
      e.stopPropagation();
    });

    // Handle model selection
    const dropdownItems = aiDropdown.querySelectorAll(
      '.dropdown-item[data-model]'
    );
    dropdownItems.forEach((item) => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const model = item.getAttribute('data-model');

        // Update active state and check icons
        dropdownItems.forEach((i) => {
          i.classList.remove('active');
          const checkIcon = i.querySelector('.check-icon');
          if (checkIcon) checkIcon.style.display = 'none';
        });
        item.classList.add('active');
        const selectedCheckIcon = item.querySelector('.check-icon');
        if (selectedCheckIcon) selectedCheckIcon.style.display = 'block';

        // Update selected model text
        currentModel = model;
        const modelNames = {
          'auto-fast': 'Auto (Fast)',
          'auto-ultra-fast': 'Auto (Ultra Fast)',
          'auto-ultra-fast-2': 'Auto (Ultra Fast 2)',
          'gpt-4o-mini': 'GPT-4o Mini (Fast)',
          'o1-mini': 'o1-Mini (Reasoning)',
          'o3-mini': 'o3-Mini (Fastest)',
          'gpt-5-mini': 'GPT-5 Mini',
          'gpt-5-nano': 'GPT-5 Nano',
          'gemini-1.5-flash-8b': 'Gemini 1.5 Flash-8B (Fastest)',
          'gemini-1.5-flash': 'Gemini 1.5 Flash',
          'gemini-2.5-flash': 'Gemini 2.5 Flash',
          'gemini-2.5-pro': 'Gemini 2.5 Pro',
          'gemini-2.5-flash-lite': 'Gemini 2.5 Flash-Lite',
          'claude-3-5-haiku-latest': 'Claude 3.5 Haiku (Fast)',
          'claude-3-5-sonnet-latest': 'Claude 3.5 Sonnet',
          'claude-3-opus-20240229': 'Claude 3 Opus',
          'grok-4-1-fast-non-reasoning': 'Grok 4.1 Fast (Non-Reasoning)',
          'grok-2': 'Grok 2',
        };

        if (selectedModelEl) {
          selectedModelEl.textContent = modelNames[model] || model;
        }

        aiDropdown.classList.add('hidden');
        console.log('Selected model:', model);

        // Save the selection
        saveModelSelection();
      });
    });
  }

  // AI Model Selector for Generator Page
  function setupGeneratorAIModelSelector() {
    const aiSelectorBtn = $('aiSelectorBtnGen');
    const aiDropdown = $('aiDropdown');
    const selectedModelEl = $('selectedModelGen');

    if (!aiSelectorBtn || !aiDropdown) return;

    // Reuse the same dropdown, just different button and label
    aiSelectorBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      aiDropdown.classList.toggle('hidden');
    });

    // Update the generator page's selected model text when a model is chosen
    const dropdownItems = aiDropdown.querySelectorAll('.dropdown-item');
    dropdownItems.forEach((item) => {
      item.addEventListener('click', async () => {
        const model = item.dataset.model;

        // Update active state and check icons
        dropdownItems.forEach((i) => {
          i.classList.remove('active');
          const checkIcon = i.querySelector('.check-icon');
          if (checkIcon) checkIcon.style.display = 'none';
        });
        item.classList.add('active');
        const selectedCheckIcon = item.querySelector('.check-icon');
        if (selectedCheckIcon) selectedCheckIcon.style.display = 'block';

        const modelNames = {
          'auto-fast': 'Auto (Fast)',
          'gpt-4o-mini': 'GPT-4o Mini (Fast)',
          'o1-mini': 'o1-Mini (Reasoning)',
          'o3-mini': 'o3-Mini (Fastest)',
          'gpt-5-mini': 'GPT-5 Mini',
          'gpt-5-nano': 'GPT-5 Nano',
          'gemini-1.5-flash-8b': 'Gemini 1.5 Flash-8B (Fastest)',
          'gemini-1.5-flash': 'Gemini 1.5 Flash',
          'gemini-2.5-flash': 'Gemini 2.5 Flash',
          'gemini-2.5-pro': 'Gemini 2.5 Pro',
          'gemini-2.5-flash-lite': 'Gemini 2.5 Flash-Lite',
          'auto-ultra-fast': 'Auto (Ultra Fast)',
          'auto-ultra-fast-2': 'Auto (Ultra Fast 2)',
        };

        if (selectedModelEl) {
          selectedModelEl.textContent = modelNames[model] || model;
        }
        aiDropdown.classList.add('hidden');

        // Save the selection and ensure label/state persistence
        await saveModelSelection();
        await loadModelSelection();
      });
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!aiSelectorBtn.contains(e.target) && !aiDropdown.contains(e.target)) {
        aiDropdown.classList.add('hidden');
      }
    });
  }

  // User Menu Dropdown
  function setupUserMenu() {
    const userBtn = $('userBtn');
    if (!userBtn) return;

    userBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      try {
        const url = chrome.runtime.getURL('profile.html');
        await chrome.tabs.create({ url });
      } catch (error) {
        console.error('[Sidepanel] Failed to open profile page:', error);
        // Fallback to window.open
        const url = chrome.runtime.getURL('profile.html');
        window.open(url, '_blank');
      }
    });
  }

  // User Menu for Generator Page
  function setupGeneratorUserMenu() {
    const userBtn = $('userBtnGen');
    if (!userBtn) return;

    userBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      try {
        const url = chrome.runtime.getURL('profile.html');
        await chrome.tabs.create({ url });
      } catch (error) {
        console.error('[Sidepanel] Failed to open profile page:', error);
        // Fallback to window.open
        const url = chrome.runtime.getURL('profile.html');
        window.open(url, '_blank');
      }
    });
  }

  async function handleSignOut() {
    try {
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) return;

      const token = getAuthAccessToken() || (await getLatestAccessToken());
      if (token) {
        await fetch(`${base}/v1/auth/logout`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          credentials: 'include',
        });
      }

      // Clear session
      await chrome.storage.sync.remove(['firebaseSession']);
      rememberAuthSession(null);
      currentUserEmail = '';

      // Show auth required screen
      showAuthRequired();
    } catch (err) {
      console.error('Sign out error:', err);
    }
  }

  function setElementVisibility(el, show) {
    try {
      if (!el) return;
      el.style.display = show ? '' : 'none';
    } catch (_) {}
  }

  function updateAuthUI(isSignedIn) {
    try {
      // Top-level auth CTA buttons
      setElementVisibility(signInWithGoogleBtn, !isSignedIn);
      const dividerEl = document.querySelector('.divider');
      setElementVisibility(dividerEl, !isSignedIn);

      // Form fields and groups
      const formFields = document.querySelector('.form-fields');
      if (formFields) {
        const hideWhenSignedIn = formFields.querySelectorAll(
          '.form-field, .checkbox-group, .auth-actions-primary'
        );
        hideWhenSignedIn.forEach((el) => {
          el.style.display = isSignedIn ? 'none' : '';
        });

        // Secondary actions: show only Sign Out when signed in
        const secondaryActionsEl = formFields.querySelector(
          '.auth-actions-secondary'
        );
        if (secondaryActionsEl) {
          setElementVisibility(forgotPasswordBtn, !isSignedIn);
          setElementVisibility(signOutBtn, isSignedIn);
          secondaryActionsEl.style.display = '';
        }
      }

      // Hide/show main content sections based on sign-in status
      const mainContent = document.querySelector('.main-content');
      if (mainContent) {
        // Hide everything except account section when not signed in
        const sectionsToHide = mainContent.querySelectorAll(
          '.quick-actions, .data-section, .action-section'
        );
        sectionsToHide.forEach((section) => {
          section.style.display = isSignedIn ? '' : 'none';
        });

        // Expand account section when not signed in
        const accountSection = document.querySelector(
          '.account-section details'
        );
        if (accountSection && !isSignedIn) {
          accountSection.setAttribute('open', 'open');
        }
      }

      // Toggle body class for clean sign-in screen styling
      if (isSignedIn) {
        document.body.classList.remove('not-signed-in');
      } else {
        document.body.classList.add('not-signed-in');
      }
    } catch (_) {}
  }

  function uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(
      /[xy]/g,
      function (c) {
        const r = (crypto.getRandomValues(new Uint8Array(1))[0] & 15) >> 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      }
    );
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Filling status UI functions
  function showFillingStatus(message = 'Auto-filling form fields...') {
    isFillingAborted = false;
    if (fillingStatusBanner) {
      fillingStatusBanner.classList.remove('hidden');
      if (fillingStatusText) fillingStatusText.textContent = message;
      if (fillingProgressFill) {
        fillingProgressFill.style.width = '0%';
        // Animate progress bar
        animateFillingProgress();
      }
    }
  }

  function hideFillingStatus() {
    if (fillingStatusBanner) {
      fillingStatusBanner.classList.add('hidden');
    }
    if (fillingProgressFill) {
      fillingProgressFill.style.width = '0%';
    }
  }

  function updateFillingStatus(message, progress = null) {
    if (fillingStatusText) fillingStatusText.textContent = message;
    if (progress !== null && fillingProgressFill) {
      fillingProgressFill.style.width = `${Math.min(
        100,
        Math.max(0, progress)
      )}%`;
    }
  }

  function animateFillingProgress() {
    if (!fillingProgressFill) return;
    let progress = 0;
    const interval = setInterval(() => {
      if (
        isFillingAborted ||
        fillingStatusBanner?.classList.contains('hidden')
      ) {
        clearInterval(interval);
        return;
      }
      // Slow down as we approach 90%
      if (progress < 30) {
        progress += 3;
      } else if (progress < 60) {
        progress += 2;
      } else if (progress < 90) {
        progress += 0.5;
      }
      fillingProgressFill.style.width = `${progress}%`;
    }, 100);
  }

  async function abortFilling() {
    isFillingAborted = true;
    updateFillingStatus('Stopping... You can now fill manually.', 100);

    // Send abort signal to content script
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (tab?.id) {
        await chrome.tabs.sendMessage(tab.id, { type: 'abortFilling' });
        console.log('[Sidepanel] Abort signal sent to content script');
      }
    } catch (err) {
      console.log('[Sidepanel] Error sending abort signal:', err);
    }

    setTimeout(() => {
      hideFillingStatus();
    }, 1500);
  }

  // Setup stop filling button
  if (stopFillingBtn) {
    stopFillingBtn.addEventListener('click', () => {
      console.log('[Sidepanel] User clicked Stop Filling');
      abortFilling();
    });
  }

  function setStatusMessage(element, message, type = 'info') {
    if (!element) return;
    element.textContent = message;
    element.className = `status-message ${type}`;
    if (!message) element.className = 'status-message';
  }

  async function loadOrCreateClientId() {
    try {
      const stored = await chrome.storage.sync.get(['clientId']);
      if (stored?.clientId) {
        clientId = stored.clientId;
      } else {
        clientId = uuidv4();
        await chrome.storage.sync.set({ clientId });
      }
    } catch (_) {
      if (!clientId) clientId = uuidv4();
    }
  }

  async function ensureRRSessionForCurrentJob(metaOverrides = {}) {
    if (!window.RRIntegration?.ensureSession) {
      console.warn(
        '[Sidepanel] RRIntegration.ensureSession not available, cannot create RR session'
      );
      return null;
    }
    try {
      await window.RRIntegration.init?.();
    } catch (_) {}
    const state = window.RRIntegration.getState?.() || {};
    if (!state.authToken) {
      console.warn(
        '[Sidepanel] No RR auth token yet; host app must send RR_EXTENSION_INIT. Skipping RR session.'
      );
      return null;
    }
    const metaFromPage =
      metaOverrides.skipPageLookup === true
        ? {}
        : await getJobMetaFromPage().catch(() => ({}));
    const mergedMeta = {
      jobTitle:
        metaOverrides.jobTitle ||
        cachedJobMeta.jobTitle ||
        metaFromPage.jobTitle ||
        state.metadata?.jobTitle ||
        '',
      company:
        metaOverrides.company ||
        cachedJobMeta.company ||
        metaFromPage.company ||
        state.metadata?.company ||
        '',
      url:
        metaOverrides.url ||
        cachedJobMeta.url ||
        metaFromPage.url ||
        state.externalJobUrl ||
        '',
      jobId:
        metaOverrides.jobId ||
        cachedJobMeta.jobId ||
        metaFromPage.jobId ||
        state.jobId ||
        '',
    };
    if (!mergedMeta.jobId) {
      console.warn(
        '[Sidepanel] No jobId available for RR session yet; will sync profile without session_id'
      );
      // Return minimal context so sync can still proceed without a session
      lastRRSessionContext = null;
      return {
        sessionId: '',
        jobId: '',
        externalJobUrl: mergedMeta.url || '',
      };
    }
    let externalJobUrl =
      mergedMeta.url ||
      metaOverrides.externalJobUrl ||
      state.externalJobUrl ||
      cachedJobUrl ||
      '';
    if (!externalJobUrl) {
      try {
        externalJobUrl = await getActiveTabUrl();
      } catch (_) {}
    }
    try {
      const sessionId = await window.RRIntegration.ensureSession({
        job_id: mergedMeta.jobId,
        external_job_url: externalJobUrl,
        metadata: {
          ...(state.metadata || {}),
          jobTitle: mergedMeta.jobTitle || state.metadata?.jobTitle || '',
          company: mergedMeta.company || state.metadata?.company || '',
        },
      });
      cachedJobMeta = {
        jobTitle: mergedMeta.jobTitle,
        company: mergedMeta.company,
        url: externalJobUrl || mergedMeta.url || '',
        jobId: mergedMeta.jobId,
      };
      if (externalJobUrl) cachedJobUrl = externalJobUrl;
      lastRRSessionContext = {
        sessionId,
        jobId: mergedMeta.jobId,
        externalJobUrl,
      };
      return lastRRSessionContext;
    } catch (error) {
      console.warn('[Sidepanel] Failed to ensure RR session:', error);
      return null;
    }
  }

  function normalizeNumberInput(value) {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string') {
      const parsed = parseFloat(value);
      return Number.isFinite(parsed) ? parsed : 0;
    }
    return 0;
  }

  function toArray(value) {
    if (Array.isArray(value)) return value.filter(Boolean);
    if (typeof value === 'string' && value.trim()) return [value.trim()];
    return [];
  }

  async function buildRrProfileSnapshot(cvTextOverride = '') {
    try {
      const stored = await chrome.storage.local.get(['userProfile', 'userCV']);
      const profile = stored.userProfile || {};
      const essential = profile.essential || {};
      const preferences = profile.preferences || {};
      const professional = profile.professional || {};
      const skills = profile.skills || {};
      const education = skills.education || {};
      const years =
        typeof skills.yearsExperience === 'object'
          ? skills.yearsExperience || {}
          : {
              total:
                skills.yearsExperience ||
                profile.yearsExperience ||
                essential.yearsExperience ||
                0,
              management: 0,
              technical: 0,
            };
      const cvText =
        cvTextOverride || stored.userCV || cvEl?.value?.trim() || '';

      return {
        full_name: essential.fullName || '',
        headline: professional.summary || professional.currentRole || '',
        email: essential.email || '',
        phone: essential.phone || '',
        location: essential.location || '',
        linkedin_url: essential.linkedIn || '',
        portfolio_url:
          essential.portfolio ||
          essential.portfolioUrl ||
          profile.portfolio ||
          profile.portfolioUrl ||
          '',
        github_url:
          essential.github ||
          essential.githubUrl ||
          profile.github ||
          profile.githubUrl ||
          '',
        current_role: professional.currentRole || '',
        job_types: toArray(preferences.jobTypes || profile.jobTypes),
        preferred_industries: toArray(
          preferences.preferredIndustries || profile.preferredIndustries
        ),
        skills: toArray(skills.topSkills || profile.topSkills),
        certifications: toArray(
          skills.certifications || profile.certifications
        ),
        years_experience: normalizeNumberInput(years.total ?? 0),
        years_management_experience: normalizeNumberInput(
          years.management ?? 0
        ),
        years_technical_experience: normalizeNumberInput(years.technical ?? 0),
        education: {
          degree: education.highestDegree || profile.degree || '',
          field_of_study: education.fieldOfStudy || profile.major || '',
          university: education.university || profile.university || '',
          graduation_year: education.graduationYear || profile.gradYear || '',
        },
        salary_expectation: {
          min:
            preferences.expectedSalaryMin ||
            preferences.salaryMin ||
            profile.salaryMin ||
            '',
          max:
            preferences.expectedSalaryMax ||
            preferences.salaryMax ||
            profile.salaryMax ||
            '',
        },
        willingness_to_relocate:
          preferences.willingToRelocate ||
          preferences.relocate ||
          profile.relocate ||
          '',
        work_authorization: essential.workAuthorization || '',
        security_clearance: essential.securityClearance || '',
        resume_excerpt: cvText.slice(0, 4000),
        metadata: {
          source: profile.metadata?.source || 'manual',
          onboarding_complete:
            profile.metadata?.onboardingComplete !== undefined
              ? profile.metadata.onboardingComplete
              : true,
          completeness: profile.metadata?.completeness || 0,
        },
      };
    } catch (error) {
      console.warn('[Sidepanel] Failed to build RR snapshot:', error);
      return null;
    }
  }

  async function syncRRProfileSnapshot({
    applied = false,
    cvText,
    resume_url,
    cover_letter_url,
    skipUrlFallback = false, // If true, don't use URLs from state
  } = {}) {
    console.log('[Sidepanel] syncRRProfileSnapshot called with:', {
      applied,
      resume_url: resume_url || 'NOT PROVIDED',
      cover_letter_url: cover_letter_url || 'NOT PROVIDED',
      skipUrlFallback,
      hasCvText: !!cvText,
    });

    if (!window.RRIntegration?.syncProfileSnapshot) {
      console.warn(
        '[Sidepanel] RRIntegration.syncProfileSnapshot not available, skipping RR sync'
      );
      return;
    }
    try {
      const snapshot = await buildRrProfileSnapshot(cvText);
      if (!snapshot) {
        console.log('[Sidepanel] No profile snapshot to sync yet');
        return;
      }

      console.log('[Sidepanel] Calling RRIntegration.syncProfileSnapshot:', {
        resume_url: resume_url || 'EMPTY',
        cover_letter_url: cover_letter_url || 'EMPTY',
        applied,
        skipUrlFallback,
      });

      await window.RRIntegration.syncProfileSnapshot({
        profile_snapshot: snapshot,
        applied,
        resume_url,
        cover_letter_url,
        skipUrlFallback,
      });

      console.log('[Sidepanel] Profile sync completed successfully');
    } catch (error) {
      console.warn('[Sidepanel] RR profile sync failed:', error);
    }
  }

  async function loadConfig() {
    try {
      const url = chrome.runtime.getURL('config.json');
      const res = await fetch(url);
      if (res.ok) {
        CONFIG = await res.json();
        CONFIG.activeRrBaseUrl =
          CONFIG.rrApiBaseUrl ||
          CONFIG.rrProductionApiBaseUrl ||
          CONFIG.activeRrBaseUrl ||
          '';
      }
    } catch (_) {}
  }

  async function initAuthSession() {
    try {
      const stored = await chrome.storage.sync.get(['firebaseSession']);
      if (stored?.firebaseSession) {
        authSession = stored.firebaseSession;
        console.log('[initAuthSession] Loaded Firebase session');
      }
    } catch (_) {
      // ignore
    }
    // Also initialize RRIntegration state from storage
    try {
      if (window.RRIntegration?.init) {
        await window.RRIntegration.init();
        const rrState = window.RRIntegration.getState?.();
        syncJobCacheFromRRState(rrState);
        const rrToken =
          rrState?.authToken || window.RRIntegration.getAuthToken?.();
        if (rrToken && !authSession?.access_token) {
          // Set authSession from RR token so callBackend can use it
          authSession = {
            access_token: rrToken,
            provider: 'reverse-recruiting',
          };
          console.log(
            '[initAuthSession] Set authSession from RRIntegration token'
          );
        }
      }
    } catch (_) {
      // ignore
    }
    // Check local storage for RR token as fallback
    try {
      const local = await chrome.storage.local.get([
        'rrAuthToken',
        'rrIntegrationState',
      ]);
      const rrTokenFromStorage =
        local?.rrAuthToken || local?.rrIntegrationState?.authToken;
      if (rrTokenFromStorage && !authSession?.access_token) {
        // Set authSession from stored RR token
        authSession = {
          access_token: rrTokenFromStorage,
          provider: 'reverse-recruiting',
        };
        console.log(
          '[initAuthSession] Set authSession from RR token in local storage'
        );
      }
    } catch (_) {
      // ignore
    }
  }

  // React to storage changes so sign-in state updates immediately
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync') return;
      if (changes && changes.firebaseSession) {
        authSession = changes.firebaseSession.newValue || null;
        setTimeout(() => refreshAuthStatus(), 200);
      }
    });
  } catch (_) {}

  // If RRIntegration state is updated (e.g. via Test Extension button or RR_EXTENSION_INIT),
  // immediately treat the user as signed-in via Reverse Recruiting.
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === 'rrIntegrationStateUpdated') {
        console.log(
          '[Sidepanel] ✅ Received rrIntegrationStateUpdated - AUTO LOGIN'
        );
        // Process immediately AND with a slight delay for reliability
        const handleAuthUpdate = async () => {
          try {
            // Check payload first (from content script)
            const payloadToken = msg?.payload?.authToken;
            const payloadUser = msg?.payload?.user;

            if (payloadToken) {
              authSession = {
                access_token: payloadToken,
                provider: 'reverse-recruiting',
              };
              console.log('[Sidepanel] ✅ Set authSession from payload token');

              // Sync profile from RR API when token is received
              try {
                if (typeof syncProfileFromRR === 'function') {
                  console.log('[Sidepanel] Syncing profile from RR API...');
                  const profile = await syncProfileFromRR(payloadToken);
                  if (profile) {
                    console.log('[Sidepanel] ✅ Profile synced successfully');
                  }
                }
              } catch (error) {
                console.warn('[Sidepanel] Error syncing profile:', error);
              }
            } else {
              // Fallback to RRIntegration
              const rrToken = window.RRIntegration?.getAuthToken?.();
              if (rrToken) {
                authSession = {
                  access_token: rrToken,
                  provider: 'reverse-recruiting',
                };
                console.log(
                  '[Sidepanel] ✅ Set authSession from RRIntegration'
                );

                // Sync profile from RR API when token is received
                try {
                  if (typeof syncProfileFromRR === 'function') {
                    console.log('[Sidepanel] Syncing profile from RR API...');
                    const profile = await syncProfileFromRR(rrToken);
                    if (profile) {
                      console.log('[Sidepanel] ✅ Profile synced successfully');
                    }
                  }
                } catch (error) {
                  console.warn('[Sidepanel] Error syncing profile:', error);
                }
              }
            }

            // Update user display if we have user info
            if (payloadUser?.email && authStatusEl) {
              authStatusEl.textContent = `Signed in via Reverse Recruiting (${payloadUser.email})`;
              authStatusEl.className = 'status-message success';
              currentUserEmail = payloadUser.email;
              console.log(
                '[Sidepanel] ✅ User logged in:',
                payloadUser.email,
                payloadUser.name
              );
            }

            try {
              const currentState =
                msg?.payload || window.RRIntegration?.getState?.();
              syncJobCacheFromRRState(currentState);
            } catch (_) {}

            await refreshAuthStatus();

            // If the auth-required screen is showing, hide it now
            const authScreen = $('authRequired');
            const mainContainer = $('mainContainer');
            if (authScreen && !authScreen.classList.contains('hidden')) {
              if (authScreen) authScreen.classList.add('hidden');
              if (mainContainer) mainContainer.classList.remove('hidden');
              console.log(
                '[Sidepanel] ✅ Switched from auth screen to main container'
              );
            }
          } catch (err) {
            console.warn('[Sidepanel] Auth update failed:', err);
          }
        };

        // Process immediately
        handleAuthUpdate();
        // Also process with delay for reliability
        setTimeout(handleAuthUpdate, 200);
      }
    });
  } catch (_) {}

  // Also listen for local storage changes (RR token updates)
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (
        changes?.rrAuthToken?.newValue ||
        changes?.rrIntegrationState?.newValue?.authToken
      ) {
        const newToken =
          changes?.rrAuthToken?.newValue ||
          changes?.rrIntegrationState?.newValue?.authToken;
        if (newToken && !authSession?.access_token) {
          authSession = {
            access_token: newToken,
            provider: 'reverse-recruiting',
          };
          console.log('[storage.onChanged] Updated authSession from RR token');
          setTimeout(() => refreshAuthStatus(), 200);
        }
      }
      if (changes?.rrIntegrationState?.newValue) {
        syncJobCacheFromRRState(changes.rrIntegrationState.newValue);
      }
      if (changes?.currentJob?.newValue) {
        syncJobCacheFromRRState({}, changes.currentJob.newValue);
      }
    });
  } catch (_) {}

  async function refreshAuthStatus() {
    try {
      // Prefer Reverse Recruiting auth state when available
      try {
        await window.RRIntegration?.init?.();
      } catch (_) {}
      const rrState = window.RRIntegration?.getState?.();
      if (rrState?.authToken) {
        syncJobCacheFromRRState(rrState);
        // IMPORTANT: Set authSession so callBackend uses the RR token
        if (
          !authSession?.access_token ||
          authSession.provider === 'reverse-recruiting'
        ) {
          authSession = {
            access_token: rrState.authToken,
            provider: 'reverse-recruiting',
          };
        }
        const rrEmail =
          rrState.user?.email ||
          rrState.user?.emailAddress ||
          rrState.user?.primaryEmail ||
          '';
        if (authStatusEl) {
          authStatusEl.textContent = rrEmail
            ? `Signed in via Reverse Recruiting (${rrEmail})`
            : 'Signed in via Reverse Recruiting';
          authStatusEl.className = 'status-message success';
        }
        if (rrEmail) currentUserEmail = rrEmail;
        if (authEmailInput && !authEmailInput.value && rrEmail) {
          authEmailInput.value = rrEmail;
        }
        updateAuthUI(true);
        return;
      }

      const me = await backendMe();
      if (!me?.ok) {
        authStatusEl.innerHTML =
          '🔐 <strong>Not signed in</strong><br/>Sign in above to get your  free requests.';
        authStatusEl.className = 'status-message info';
        currentUserEmail = '';
        updateAuthUI(false);
        return;
      }
      const label = me?.email || me?.userId || 'user';
      authStatusEl.textContent = `Signed in as ${label}`;
      authStatusEl.className = 'status-message success';
      // Cache email and prefill input if empty
      currentUserEmail = me?.email || '';
      if (authEmailInput && !authEmailInput.value && currentUserEmail) {
        authEmailInput.value = currentUserEmail;
      }
      updateAuthUI(true);
    } catch (_) {
      if (authStatusEl) authStatusEl.textContent = '';
    }
  }

  async function doSignUp() {
    const name = (authNameInput?.value || '').trim();
    const email = (authEmailInput?.value || '').trim();
    const password = (authPasswordInput?.value || '').trim();
    const agreedToMarketing = agreeMarketingCheckbox?.checked || false;

    if (!name || !email || !password) {
      authStatusEl.textContent = 'Please fill in all required fields.';
      return;
    }
    // Terms are agreed to by signup (mentioned in UI text)
    showButtonSpinner(signUpBtn, true);
    try {
      authStatusEl.textContent = 'Signing up…';
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) throw new Error('Backend not configured');
      const res = await fetch(`${base}/v1/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          name,
          email,
          password,
          marketingConsent: agreedToMarketing,
          agreedToTerms: true,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data?.ok)
        throw new Error(data?.error || 'Sign up failed');
      if (data?.access_token) {
        rememberAuthSession({
          access_token: data.access_token,
          provider: 'email',
        });
      }
      if (data?.requiresConfirmation) {
        setStatusMessage(
          authStatusEl,
          'Account created. Check your email to confirm, then sign in.',
          'success'
        );
      } else {
        setStatusMessage(
          authStatusEl,
          'Account created and signed in.',
          'success'
        );
        setTimeout(() => refreshAuthStatus(), 300);
      }
    } catch (e) {
      setStatusMessage(
        authStatusEl,
        'Sign up failed. ' + String(e && e.message ? e.message : e),
        'error'
      );
    } finally {
      showButtonSpinner(signUpBtn, false);
    }
  }

  async function doSignIn() {
    showButtonSpinner(signInBtn, true);
    try {
      authStatusEl.textContent = 'Signing in…';
      const r = await backendLogin();
      if (!r.ok) throw new Error(r.error || 'Login failed');
      setStatusMessage(authStatusEl, 'Signed in.', 'success');
    } catch (e) {
      setStatusMessage(
        authStatusEl,
        'Sign in failed. Please check your credentials and try again.',
        'error'
      );
    } finally {
      showButtonSpinner(signInBtn, false);
      setTimeout(() => refreshAuthStatus(), 300);
    }
  }

  async function doForgotPassword() {
    try {
      let email = (authEmailInput?.value || '').trim();
      if (!email && currentUserEmail) email = currentUserEmail;
      if (!email) {
        setStatusMessage(authStatusEl, 'Enter your email first.', 'error');
        return;
      }
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) throw new Error('Backend not configured');
      const res = await fetch(`${base}/v1/auth/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email }),
      });
      if (!res.ok) {
        const data = await res
          .json()
          .catch(async () => ({ error: await res.text() }));
        const rawMsg = String(data?.error || 'Failed to send reset email');
        // Supabase over-email rate limit
        if (res.status === 429 || /over_email_send_rate_limit/i.test(rawMsg)) {
          // Extract seconds if present
          const secMatch = rawMsg.match(/after\s+(\d+)\s*seconds?/i);
          const seconds = secMatch ? parseInt(secMatch[1], 10) : 60;
          let remain = Math.max(1, seconds);
          setStatusMessage(
            authStatusEl,
            `Please wait ${remain}s before requesting another reset email.`,
            'warning'
          );
          if (forgotPasswordBtn) forgotPasswordBtn.disabled = true;
          const timer = setInterval(() => {
            remain -= 1;
            if (remain <= 0) {
              clearInterval(timer);
              setStatusMessage(
                authStatusEl,
                'You can request a reset email now.',
                'success'
              );
              if (forgotPasswordBtn) forgotPasswordBtn.disabled = false;
            } else {
              setStatusMessage(
                authStatusEl,
                `Please wait ${remain}s before requesting another reset email.`,
                'warning'
              );
            }
          }, 1000);
          return;
        }
        throw new Error(rawMsg);
      }
      setStatusMessage(
        authStatusEl,
        'Password reset email sent. Please check your inbox.',
        'success'
      );
    } catch (e) {
      setStatusMessage(
        authStatusEl,
        'Failed to send reset email. ' + String(e && e.message ? e.message : e),
        'error'
      );
    }
  }

  async function doSignInWithGoogle() {
    try {
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) throw new Error('Backend not configured');
      const site = base.replace(/\/api$/, '');
      const redirectTo = `${site}/tracker`;
      const url = `${base}/v1/auth/google/start?redirect_to=${encodeURIComponent(
        redirectTo
      )}`;
      await chrome.tabs.create({ url });
      // Poll backend/me for a short window so UI reflects sign-in immediately
      const start = Date.now();
      const pollId = setInterval(async () => {
        try {
          await refreshAuthStatus();
          if (
            authStatusEl &&
            /Signed in as/i.test(authStatusEl.textContent || '')
          ) {
            clearInterval(pollId);
          } else if (Date.now() - start > 20000) {
            clearInterval(pollId);
          }
        } catch (_) {
          if (Date.now() - start > 20000) clearInterval(pollId);
        }
      }, 1000);
    } catch (e) {
      setStatusMessage(
        authStatusEl,
        'Google sign-in failed to start.',
        'error'
      );
    }
  }

  async function doSignOut() {
    showButtonSpinner(signOutBtn, true);
    try {
      await backendLogout();
      authStatusEl.textContent = 'Signed out.';
    } catch (_) {
    } finally {
      showButtonSpinner(signOutBtn, false);
      setTimeout(() => refreshAuthStatus(), 300);
    }
  }

  async function loadByok() {
    try {
      const stored = await chrome.storage.sync.get(['byok']);
      byok = stored?.byok || '';
      if (byokInput && byok) byokInput.value = byok;
      setStatusMessage(
        byokStatusEl,
        byok ? 'Key is set (stored locally).' : '',
        byok ? 'success' : 'info'
      );
    } catch (_) {}
  }

  async function loadModelSelection() {
    try {
      const stored = await chrome.storage.sync.get(['modelId']);
      const v = stored?.modelId || 'grok-4-1-fast-non-reasoning';

      // Set active state in dropdown system
      const dropdownItems = document.querySelectorAll(
        '.dropdown-item[data-model]'
      );
      dropdownItems.forEach((item) => {
        const model = item.getAttribute('data-model');
        if (model === v) {
          item.classList.add('active');
          const checkIcon = item.querySelector('.check-icon');
          if (checkIcon) checkIcon.style.display = 'block';
        } else {
          item.classList.remove('active');
          const checkIcon = item.querySelector('.check-icon');
          if (checkIcon) checkIcon.style.display = 'none';
        }
      });

      // Update the selected model text immediately
      const selectedModelEl = document.getElementById('selectedModel');
      if (selectedModelEl) {
        const modelNames = {
          'auto-fast': 'Auto (Fast)',
          'auto-ultra-fast': 'Auto (Ultra Fast)',
          'auto-ultra-fast-2': 'Auto (Ultra Fast 2)',
          'gpt-4o-mini': 'GPT-4o Mini (Fast)',
          'o1-mini': 'o1-Mini (Reasoning)',
          'o3-mini': 'o3-Mini (Fastest)',
          'gpt-5-mini': 'GPT-5 Mini',
          'gpt-5-nano': 'GPT-5 Nano',
          'gemini-1.5-flash-8b': 'Gemini 1.5 Flash-8B (Fastest)',
          'gemini-1.5-flash': 'Gemini 1.5 Flash',
          'gemini-2.5-flash': 'Gemini 2.5 Flash',
          'gemini-2.5-pro': 'Gemini 2.5 Pro',
          'gemini-2.5-flash-lite': 'Gemini 2.5 Flash-Lite',
          'claude-3-5-haiku-latest': 'Claude 3.5 Haiku (Fast)',
          'claude-3-5-sonnet-latest': 'Claude 3.5 Sonnet',
          'claude-3-opus-20240229': 'Claude 3 Opus',
          'grok-4-1-fast-non-reasoning': 'Grok 4.1 Fast (Non-Reasoning)',
          'grok-2': 'Grok 2',
        };
        selectedModelEl.textContent = modelNames[v] || v;
      }
    } catch (_) {
      // Set default to Grok Fast if error
      const dropdownItems = document.querySelectorAll(
        '.dropdown-item[data-model]'
      );
      dropdownItems.forEach((item) => {
        const model = item.getAttribute('data-model');
        if (model === 'grok-4-1-fast-non-reasoning') {
          item.classList.add('active');
          const checkIcon = item.querySelector('.check-icon');
          if (checkIcon) checkIcon.style.display = 'block';
        } else {
          item.classList.remove('active');
          const checkIcon = item.querySelector('.check-icon');
          if (checkIcon) checkIcon.style.display = 'none';
        }
      });
    }
  }

  async function saveModelSelection() {
    try {
      // Get the currently selected model from dropdown
      const activeItem = document.querySelector(
        '.dropdown-item[data-model].active'
      );
      const v = activeItem
        ? activeItem.getAttribute('data-model')
        : 'grok-4-1-fast-non-reasoning';
      await chrome.storage.sync.set({ modelId: v });
      // Reflect in the label instantly
      const selectedModelEl = document.getElementById('selectedModel');
      if (selectedModelEl)
        selectedModelEl.textContent = activeItem?.textContent?.trim() || v;
    } catch (_) {}
  }

  function getSelectedModelId() {
    // Get the currently selected model from the dropdown system
    const activeItem = document.querySelector(
      '.dropdown-item[data-model].active'
    );
    const model = activeItem
      ? activeItem.getAttribute('data-model')
      : localStorage.getItem('modelIdFallback') ||
        'grok-4-1-fast-non-reasoning';
    // Persist a simple fallback for robustness
    try {
      localStorage.setItem('modelIdFallback', model);
    } catch (_) {}
    const result = model === 'auto-fast' ? 'gemini-2.5-flash-lite' : model;
    console.log(
      '[Sidepanel] Selected model from dropdown:',
      model,
      'Final:',
      result
    );
    return result;
  }

  async function saveByok() {
    try {
      const v = (byokInput?.value || '').trim();
      if (!v) {
        byokStatusEl.textContent = 'Enter a key first.';
        return;
      }
      byok = v;
      await chrome.storage.sync.set({ byok });
      setStatusMessage(byokStatusEl, 'Saved locally.', 'success');
    } catch (_) {
      setStatusMessage(byokStatusEl, 'Failed to save.', 'error');
    }
  }

  async function clearByok() {
    try {
      byok = '';
      if (byokInput) byokInput.value = '';
      await chrome.storage.sync.remove(['byok']);
      byokStatusEl.textContent = 'Cleared.';
    } catch (_) {}
  }

  function rememberAuthSession(session) {
    authSession = session || null;
    if (session?.access_token) {
      chrome.storage.sync.set({ firebaseSession: session }).catch(() => {});
    } else {
      chrome.storage.sync.remove(['firebaseSession']).catch(() => {});
    }
  }

  function getAuthAccessToken() {
    // First check authSession
    if (authSession?.access_token) {
      console.log('[getAuthAccessToken] Using authSession token');
      return authSession.access_token;
    }
    // Then check RRIntegration
    try {
      const rrToken = window.RRIntegration?.getAuthToken?.();
      if (rrToken) {
        console.log('[getAuthAccessToken] Using RRIntegration token');
        // Also set authSession for future calls
        authSession = { access_token: rrToken, provider: 'reverse-recruiting' };
        return rrToken;
      }
    } catch (_) {}
    // Check RRIntegration state directly
    try {
      const rrState = window.RRIntegration?.getState?.();
      if (rrState?.authToken) {
        console.log('[getAuthAccessToken] Using RRIntegration state token');
        authSession = {
          access_token: rrState.authToken,
          provider: 'reverse-recruiting',
        };
        return rrState.authToken;
      }
    } catch (_) {}
    return '';
  }

  async function getLatestAccessToken() {
    const current = getAuthAccessToken();
    if (current) return current;
    try {
      const stored = await chrome.storage.sync.get(['firebaseSession']);
      if (stored?.firebaseSession?.access_token) {
        authSession = stored.firebaseSession;
        console.log('[getLatestAccessToken] Found firebaseSession token');
        return authSession.access_token;
      }
    } catch (e) {
      console.warn('[Auth] Failed to load token from storage', e);
    }
    try {
      const local = await chrome.storage.local.get([
        'rrAuthToken',
        'rrIntegrationState',
      ]);
      if (local?.rrAuthToken) {
        console.log('[getLatestAccessToken] Found rrAuthToken');
        // Set authSession so future calls are faster
        authSession = {
          access_token: local.rrAuthToken,
          provider: 'reverse-recruiting',
        };
        return local.rrAuthToken;
      }
      if (local?.rrIntegrationState?.authToken) {
        console.log(
          '[getLatestAccessToken] Found rrIntegrationState.authToken'
        );
        // Set authSession so future calls are faster
        authSession = {
          access_token: local.rrIntegrationState.authToken,
          provider: 'reverse-recruiting',
        };
        return local.rrIntegrationState.authToken;
      }
    } catch (_) {}
    console.log('[getLatestAccessToken] No token found anywhere');
    return '';
  }

  async function persistWebSession(accessToken) {
    try {
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base || !accessToken) return;
      await fetch(`${base}/v1/auth/google/session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ access_token: accessToken }),
      });
    } catch (err) {
      console.warn('[Auth] Failed to persist web session', err);
    }
  }

  function showSignInPrompt() {
    // Open the account section collapsible
    const accountCollapsible = document.querySelector(
      '.account-section .collapsible'
    );
    if (accountCollapsible) accountCollapsible.open = true;

    // Scroll to account section
    const accountSection = document.querySelector('.account-section');
    if (accountSection) {
      accountSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    // Focus email input for sign in
    if (authEmailInput) {
      setTimeout(() => authEmailInput.focus(), 300);
    }

    // Show friendly message
    authStatusEl.innerHTML = `🔐 <strong>Sign in required</strong><br/>Get your  free requests to try the app.`;
    authStatusEl.className = 'status-message info';
  }

  function showLimitPrompt() {
    // Open the account section collapsible
    const accountCollapsible = document.querySelector(
      '.account-section .collapsible'
    );
    if (accountCollapsible) accountCollapsible.open = true;

    // Scroll to account section
    const accountSection = document.querySelector('.account-section');
    if (accountSection) {
      accountSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    // Focus BYOK input
    if (byokInput) {
      setTimeout(() => byokInput.focus(), 300);
    }

    const upsell = CONFIG?.upgradeUrl
      ? ` You can also <a href="${CONFIG.upgradeUrl}" target="_blank" style="text-decoration: underline;">upgrade to Pro</a>.`
      : '';
    setStatusMessage(
      authStatusEl,
      `✨ Free trial used (100 requests).${upsell}`,
      'warning'
    );
  }

  async function callBackend(path, body, { useRRBase = false } = {}) {
    const rawBase = useRRBase
      ? CONFIG?.rrApiBaseUrl || CONFIG?.rrProductionApiBaseUrl
      : CONFIG?.apiBaseUrl;
    const base = (rawBase || '').replace(/\/$/, '');
    if (!base) return { ok: false, error: 'Backend not configured' };
    const url = `${base}${path}`;
    const headers = { 'Content-Type': 'application/json' };

    // Ensure RRIntegration is initialized before getting token
    try {
      await window.RRIntegration?.init?.();
    } catch (_) {}

    let jwt = getAuthAccessToken();
    console.log(
      '[callBackend] getAuthAccessToken returned:',
      jwt ? `${jwt.slice(0, 20)}...` : '(empty)'
    );
    if (!jwt) {
      try {
        jwt = await getLatestAccessToken();
        console.log(
          '[callBackend] getLatestAccessToken returned:',
          jwt ? `${jwt.slice(0, 20)}...` : '(empty)'
        );
      } catch (e) {
        console.warn('[callBackend] getLatestAccessToken error:', e);
      }
    }
    // Final fallback: try RRIntegration one more time
    if (!jwt) {
      try {
        const rrState = window.RRIntegration?.getState?.();
        if (rrState?.authToken) {
          jwt = rrState.authToken;
          authSession = { access_token: jwt, provider: 'reverse-recruiting' };
          console.log(
            '[callBackend] Got token from RRIntegration state fallback'
          );
        }
      } catch (_) {}
    }
    if (jwt) {
      headers['Authorization'] = `Bearer ${jwt}`;
      console.log('[callBackend] Authorization header set');
    } else {
      console.warn(
        '[callBackend] No JWT available, request will be unauthenticated'
      );
    }
    if (byok) {
      try {
        const mid = String(body?.modelId || '').toLowerCase();
        if (mid.startsWith('gemini-')) headers['X-Gemini-Key'] = byok;
        else if (mid.startsWith('claude-')) headers['X-Claude-Key'] = byok;
        else headers['X-OpenAI-Key'] = byok;
      } catch (_) {
        headers['X-OpenAI-Key'] = byok;
      }
    }
    if (clientId) headers['X-Client-Id'] = clientId;
    const res = await fetch(url, {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify(body || {}),
    });
    if (!res.ok) {
      const t = await res.text();
      console.warn('[callBackend] Request failed', {
        path,
        status: res.status,
        error: t,
      });
      return { ok: false, status: res.status, error: t || `${res.status}` };
    }
    const data = await res.json().catch(() => ({}));
    return { ok: true, status: res.status, data };
  }

  async function backendLogin() {
    const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
    if (!base) return { ok: false, error: 'Backend not configured' };
    const email = (authEmailInput?.value || '').trim();
    const password = (authPasswordInput?.value || '').trim();
    if (!email || !password) {
      return { ok: false, error: 'Enter email and password.' };
    }
    const res = await fetch(`${base}/v1/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) {
      const t = await res.text();
      return { ok: false, error: t || 'Login failed' };
    }
    // Cache token locally to include Authorization header when needed
    const data = await res.json().catch(() => ({}));
    if (data && data.access_token) {
      rememberAuthSession({
        access_token: data.access_token,
        provider: 'email',
      });
      await persistWebSession(data.access_token);
    }
    return { ok: true };
  }

  async function backendLogout() {
    const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
    if (!base) return;
    await fetch(`${base}/v1/auth/logout`, {
      method: 'POST',
      credentials: 'include',
    }).catch(() => {});
    // Clear cached token and session
    rememberAuthSession(null);
  }

  async function backendMe() {
    const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
    if (!base) return { ok: false };
    const jwt = getAuthAccessToken();
    const headers = jwt ? { Authorization: `Bearer ${jwt}` } : {};
    const res = await fetch(`${base}/v1/auth/me`, {
      method: 'GET',
      headers,
      credentials: 'include',
    });
    if (!res.ok) return { ok: false };
    return res.json();
  }

  // Configure pdf.js worker if available
  if (typeof window !== 'undefined' && window['pdfjsLib']) {
    try {
      window['pdfjsLib'].GlobalWorkerOptions.workerSrc = chrome.runtime.getURL(
        'vendor/pdfjs/pdf.worker.min.js'
      );
    } catch (_) {}
  }

  async function refreshApiKeyStatus() {
    try {
      if (!apiKeyStatusEl) return;
      // Status indicator is now just a visual dot in the header
      apiKeyStatusEl.className = 'status-indicator';
    } catch (_) {
      if (apiKeyStatusEl) {
        apiKeyStatusEl.className = 'status-indicator';
      }
    }
  }

  // Progressive spinner speed controller
  let spinnerSpeedInterval = null;

  function startProgressiveSpinner() {
    const spinner = document.querySelector('.loading-spinner');
    if (!spinner) return;

    // Clear any existing interval
    if (spinnerSpeedInterval) {
      clearInterval(spinnerSpeedInterval);
    }

    let rotationCount = 0;
    const speeds = [
      { rotations: 5, duration: 1.8 }, // First 5 rotations: 1.8s
      { rotations: 5, duration: 1.4 }, // Next 5 rotations: 1.4s
      { rotations: 5, duration: 1.2 }, // Next 5 rotations: 1.2s
      { rotations: 5, duration: 1.0 }, // Next 5 rotations: 1.0s
      { rotations: Infinity, duration: 0.99 }, // After that: 0.8s
    ];

    let currentSpeedIndex = 0;
    let rotationsInCurrentSpeed = 0;

    // Set initial speed
    spinner.style.animationDuration = `${speeds[0].duration}s`;

    // Track rotation count and update speed
    const checkRotation = () => {
      rotationCount++;
      rotationsInCurrentSpeed++;

      // Check if we need to move to next speed tier
      if (rotationsInCurrentSpeed >= speeds[currentSpeedIndex].rotations) {
        currentSpeedIndex++;
        if (currentSpeedIndex < speeds.length) {
          rotationsInCurrentSpeed = 0;
          spinner.style.animationDuration = `${speeds[currentSpeedIndex].duration}s`;
          console.log(
            `[Spinner] Speed changed to ${speeds[currentSpeedIndex].duration}s (rotation ${rotationCount})`
          );
        }
      }
    };

    // Check every rotation (use the current duration)
    const updateInterval = () => {
      if (spinnerSpeedInterval) {
        clearInterval(spinnerSpeedInterval);
      }
      const currentDuration =
        speeds[Math.min(currentSpeedIndex, speeds.length - 1)].duration;
      spinnerSpeedInterval = setInterval(checkRotation, currentDuration * 1000);
    };

    updateInterval();
  }

  function stopProgressiveSpinner() {
    if (spinnerSpeedInterval) {
      clearInterval(spinnerSpeedInterval);
      spinnerSpeedInterval = null;
    }

    // Reset spinner speed
    const spinner = document.querySelector('.loading-spinner');
    if (spinner) {
      spinner.style.animationDuration = '1.8s';
    }
  }

  function setLoading(isLoading, label) {
    if (isLoading) {
      if (label && typeof label === 'string') {
        const loadingTitle = $('loadingTitle');
        if (loadingTitle) loadingTitle.textContent = label;
      }
      if (loadingEl) loadingEl.classList.remove('hidden');

      // Start progressive spinner animation
      startProgressiveSpinner();

      if (analyzeBtn) analyzeBtn.disabled = true;
      if (clearBtn) clearBtn.disabled = true;
      if (scanJDBtn) scanJDBtn.disabled = true;
      if (scanFormBtn) scanFormBtn.disabled = true;
      if (analyzeFastBtn) analyzeFastBtn.disabled = true;
      if (scanJDFastBtn) scanJDFastBtn.disabled = true;
      if (scanFormFastBtn) scanFormFastBtn.disabled = true;
      if (fillPageBtn) fillPageBtn.disabled = true;
      if (generateCvBtn) generateCvBtn.disabled = true;
      if (generateCoverLetterBtn) generateCoverLetterBtn.disabled = true;
      if (signUpBtn) signUpBtn.disabled = true;
      if (signInBtn) signInBtn.disabled = true;
      if (signOutBtn) signOutBtn.disabled = true;
      if (saveByokBtn) saveByokBtn.disabled = true;
      if (clearByokBtn) clearByokBtn.disabled = true;
    } else {
      if (loadingEl) loadingEl.classList.add('hidden');

      // Stop progressive spinner animation
      stopProgressiveSpinner();

      const loadingTitle = $('loadingTitle');
      if (loadingTitle) loadingTitle.textContent = 'Analyzing...';
      if (analyzeBtn) analyzeBtn.disabled = false;
      if (clearBtn) clearBtn.disabled = false;
      if (scanJDBtn) scanJDBtn.disabled = false;
      if (scanFormBtn) scanFormBtn.disabled = false;
      if (analyzeFastBtn) analyzeFastBtn.disabled = false;
      if (scanJDFastBtn) scanJDFastBtn.disabled = false;
      if (scanFormFastBtn) scanFormFastBtn.disabled = false;
      if (fillPageBtn) fillPageBtn.disabled = false;
      if (generateCvBtn) generateCvBtn.disabled = false;
      if (generateCoverLetterBtn) generateCoverLetterBtn.disabled = false;
      if (signUpBtn) signUpBtn.disabled = false;
      if (signInBtn) signInBtn.disabled = false;
      if (signOutBtn) signOutBtn.disabled = false;
      if (saveByokBtn) saveByokBtn.disabled = false;
      if (clearByokBtn) clearByokBtn.disabled = false;
    }
  }

  function showButtonSpinner(btn, show) {
    if (!btn) return;
    const spinner = btn.querySelector('.btn-spinner');
    const text = btn.querySelector('.btn-text');
    if (show) {
      if (spinner) spinner.classList.remove('hidden');
      btn.disabled = true;
    } else {
      if (spinner) spinner.classList.add('hidden');
      btn.disabled = false;
    }
  }

  function clearResults() {
    console.log('[Sidepanel] clearResults called');
    console.log('[Sidepanel] resultsList:', !!resultsList);
    console.log('[Sidepanel] notesEl:', !!notesEl);
    console.log('[Sidepanel] resultsSection:', !!resultsSection);

    if (resultsList) {
      resultsList.innerHTML = '';
      console.log('[Sidepanel] Cleared resultsList');
    } else {
      console.error('[Sidepanel] resultsList is null!');
    }

    if (notesEl) {
      notesEl.textContent = '';
      console.log('[Sidepanel] Cleared notesEl');
    } else {
      console.error('[Sidepanel] notesEl is null!');
    }

    if (resultsSection) {
      resultsSection.classList.add('hidden');
      console.log('[Sidepanel] Hidden resultsSection');
    } else {
      console.error('[Sidepanel] resultsSection is null!');
    }

    // rerunBtn removed
  }

  function showDocumentsSection() {
    if (documentsSection) documentsSection.classList.remove('hidden');
  }

  function toTitleCase(s) {
    try {
      return String(s || '')
        .replace(/[_-]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .replace(/\b\w/g, (c) => c.toUpperCase());
    } catch (_) {
      return String(s || '');
    }
  }

  function isGuidLike(s) {
    return /^(?:[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})$/i.test(
      String(s || '')
    );
  }

  function formatDisplayName(raw) {
    const name = String(raw || '').trim();
    if (!name) return '';
    // Hide GUIDs and long hash-like strings (but keep readable field names)
    if (isGuidLike(name)) return '';
    // Hide long strings that look like IDs (mostly hex/alphanumeric, no spaces, > 30 chars)
    if (
      name.length > 30 &&
      /^[a-zA-Z0-9-]+$/.test(name) &&
      !name.includes(' ')
    ) {
      return '';
    }
    if (name.startsWith('_systemfield_')) {
      const key = name.slice('_systemfield_'.length);
      const map = {
        name: 'Full Name',
        first_name: 'First Name',
        last_name: 'Last Name',
        email: 'Email',
        phone: 'Phone',
        address: 'Address',
        city: 'City',
        state: 'State',
        country: 'Country',
        postal: 'Postal Code',
        linkedin: 'LinkedIn URL',
        website: 'Website',
      };
      if (map[key]) return map[key];
      return toTitleCase(key);
    }
    return toTitleCase(name);
  }

  function renderResults(result) {
    clearResults();

    const fields = Array.isArray(result?.fields) ? result.fields : [];
    const notes = typeof result?.notes === 'string' ? result.notes : '';

    if (fields.length === 0 && !notes) {
      showResultsPage();
      if (resultsList) {
        resultsList.innerHTML =
          '<div class="empty">No fields were detected.</div>';
      }
      return;
    }

    // rerunBtn removed

    for (const field of fields) {
      const name = field?.name ?? '(Unnamed Field)';
      const value = field?.value ?? '';
      const reasoning = field?.reasoning ?? '';
      const suggestion = field?.suggestion ?? '';

      // Debug: Log the field structure to understand what we're receiving
      console.log('Field data:', {
        name,
        label: field?.label,
        displayLabel: field?.displayLabel,
        question: field?.question,
        reasoning: reasoning?.substring(0, 100),
      });

      // Try multiple sources for the display name
      // Prioritize displayLabel (from backend cleanup) over other sources
      const label =
        field?.displayLabel ||
        field?.label ||
        field?.question ||
        field?.fieldName ||
        field?.fieldLabel ||
        name;

      const row = document.createElement('div');
      row.className = 'field-row';
      try {
        row.dataset.fieldName = name;
      } catch (_) {}

      const left = document.createElement('div');
      left.className = 'field-left';

      // Determine what to display as the field name
      let displayText = '';

      // If label looks like an ID (GUID or long hash), try to extract from reasoning
      if (
        isGuidLike(label) ||
        (label.length > 30 &&
          /^[a-zA-Z0-9-\s]+$/.test(label) &&
          label.split(' ').every((part) => part.length > 20))
      ) {
        // Label is an ID, try to extract question from reasoning
        if (reasoning) {
          // Look for common question patterns in reasoning
          const questionMatch = reasoning.match(
            /(?:question|field|asks?|prompt)[\s:]+["']?([^"'\n]+)["']?/i
          );
          if (questionMatch) {
            displayText = questionMatch[1].trim();
          } else {
            // Use first sentence of reasoning as fallback
            const firstSentence = reasoning.split(/[.!?]\s/)[0];
            if (firstSentence && firstSentence.length < 200) {
              displayText = firstSentence;
            }
          }
        }

        // If still no display text, try asking content script for a label by id/name token
        if (!displayText) {
          // Defer async label lookup; render placeholder now and update later
          try {
            const token = (name || '').split(/[\s/]+/).pop();
            (async () => {
              try {
                const [tab] = await chrome.tabs.query({
                  active: true,
                  currentWindow: true,
                });
                if (tab && tab.id != null) {
                  const res = await chrome.tabs.sendMessage(tab.id, {
                    type: 'getFieldLabel',
                    token,
                  });
                  if (res && res.ok && res.label) {
                    try {
                      const el = row.querySelector('.field-name');
                      if (el && el.textContent === 'Form Field') {
                        el.textContent = res.label;
                      }
                    } catch (_) {}
                  }
                }
              } catch (_) {}
            })();
          } catch (_) {}
        }
        // Final fallback to formatting the name
        if (!displayText) displayText = formatDisplayName(name);
      } else if (label !== name) {
        // Label exists and is not an ID, use it directly
        displayText = label;
      } else {
        // Label same as name, format it
        displayText = formatDisplayName(name);
      }

      // Always create a name element, even if displayText is empty (show placeholder)
      const nameEl = document.createElement('div');
      nameEl.className = 'field-name';
      nameEl.textContent = displayText || 'Form Field';
      left.appendChild(nameEl);

      const valueEl = document.createElement('textarea');
      valueEl.className = 'field-value';
      valueEl.value = value;
      valueEl.rows = Math.max(2, Math.min(8, value.split('\n').length));

      left.appendChild(valueEl);
      // Show only one helper text: prefer suggestion, otherwise reasoning
      const explanation = suggestion || reasoning;
      if (explanation) {
        const wrap = document.createElement('div');
        wrap.className = 'field-suggestion';
        const label = document.createElement('span');
        label.textContent = 'Suggestion: ';
        const text = document.createElement('span');
        text.textContent = explanation;
        wrap.appendChild(label);
        wrap.appendChild(text);
        left.appendChild(wrap);
      }

      const right = document.createElement('div');
      right.className = 'field-actions';

      const copyBtn = document.createElement('button');
      copyBtn.className = 'copy-btn';
      copyBtn.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
          <rect x="6" y="6" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
          <path d="M12 6V3C12 2.45 11.55 2 11 2H3C2.45 2 2 2.45 2 3V11C2 11.55 2.45 12 3 12H6" stroke="currentColor" stroke-width="1.5"/>
        </svg>
      `;
      copyBtn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(valueEl.value);
          const originalHTML = copyBtn.innerHTML;
          copyBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 18 18" fill="none">
            <path d="M15 5L7 13L3 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>`;
          setTimeout(() => (copyBtn.innerHTML = originalHTML), 1200);
        } catch (_) {
          copyBtn.innerHTML = `<span style="color: red;">✕</span>`;
          setTimeout(() => {
            copyBtn.innerHTML = `
              <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
                <rect x="6" y="6" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                <path d="M12 6V3C12 2.45 11.55 2 11 2H3C2.45 2 2 2.45 2 3V11C2 11.55 2.45 12 3 12H6" stroke="currentColor" stroke-width="1.5"/>
              </svg>
            `;
          }, 1200);
        }
      });

      right.appendChild(copyBtn);

      row.appendChild(left);
      row.appendChild(right);

      if (resultsList) resultsList.appendChild(row);
    }

    if (notes) {
      const notesHeader = document.createElement('div');
      notesHeader.className = 'notes-header';
      notesHeader.textContent = 'Notes';

      const notesBody = document.createElement('div');
      notesBody.className = 'notes-body';
      notesBody.textContent = notes;

      notesEl.appendChild(notesHeader);
      notesEl.appendChild(notesBody);
    }

    showResultsPage();
  }

  async function analyze() {
    // Log basic tracking once analyze is initiated (after validation)
    clearResults();
    const cvText = cvEl.value.trim();
    const jobDescriptionText = jdEl.value.trim();
    const formText = formEl.value.trim();

    if (!cvText || !jobDescriptionText || !formText) {
      showResultsPage();
      if (resultsList) {
        resultsList.innerHTML =
          '<div class="error">Please provide Resume/Assets, Job Description, and the Application Form text (use Scan buttons to capture).</div>';
      }
      return;
    }

    // Get profile data from storage for AI analysis
    let profileForAI = '';
    try {
      if (typeof getProfileForAI === 'function') {
        profileForAI = await getProfileForAI();
        if (profileForAI) {
          console.log(
            '[Sidepanel] ✅ Using stored profile data for AI analysis'
          );
          console.log(
            '[Sidepanel] Profile length:',
            profileForAI.length,
            'characters'
          );
        } else {
          console.log('[Sidepanel] No stored profile, using CV text only');
        }
      }
    } catch (error) {
      console.warn('[Sidepanel] Error loading profile for AI:', error);
    }

    // Combine CV text with profile data if available
    const combinedCVText = profileForAI
      ? `${profileForAI}\n\n--- Additional Resume Details ---\n${cvText}`
      : cvText;

    if (window.RRIntegration) {
      try {
        await ensureRRSessionForCurrentJob();
      } catch (error) {
        console.warn('[Sidepanel] RR session setup skipped:', error);
      }
    }

    setLoading(true, 'Analyzing…');
    try {
      // Always use backend via optimized-api.js
      if (CONFIG?.apiBaseUrl && window.JobApAIOptimized?.analyzeOptimized) {
        // Streaming path with progressive UI updates
        const onChunk = (text) => {
          try {
            // Append small live dots or partial token count in notes
            if (notesEl) {
              notesEl.textContent = 'Streaming…';
            }
          } catch (_) {}
        };
        const onProgress = (msg) => {
          try {
            if (notesEl) notesEl.textContent = msg;
          } catch (_) {}
        };

        // Combine JD HTML and Form HTML for comprehensive context
        // Prioritize form HTML as it usually has more detailed fields
        const combinedHtml = [
          scannedFormHtml ? scannedFormHtml.slice(0, 35000) : '',
          scannedJdHtml ? scannedJdHtml.slice(0, 15000) : '',
        ]
          .filter(Boolean)
          .join('\n<!-- JD PAGE HTML -->\n');

        const { result, elapsedMs } =
          await window.JobApAIOptimized.analyzeOptimized({
            cvText: combinedCVText, // Use combined CV text with profile data
            jobDescriptionText,
            formText,
            formHtml: combinedHtml.slice(0, 50000), // Include combined HTML for better AI understanding
            modelId: getSelectedModelId(),
            apiBaseUrl: CONFIG.apiBaseUrl,
            onProgress,
            onChunk,
            useStreaming: false, // Disabled - using regular API instead of streaming
          });
        console.log(
          '[Sidepanel] Combined HTML sent:',
          combinedHtml.length,
          'chars (form:',
          scannedFormHtml?.length || 0,
          '+ jd:',
          scannedJdHtml?.length || 0,
          ')'
        );

        renderResults(result);
        if (typeof elapsedMs === 'number') {
          try {
            notesEl.insertAdjacentHTML(
              'beforeend',
              `<div class="notes-meta">⏱️ Took ${(elapsedMs / 1000).toFixed(
                1
              )}s</div>`
            );
          } catch (_) {}
        }
        await syncRRProfileSnapshot({
          applied: true,
          cvText: combinedCVText, // Use combined CV text with profile data
          skipUrlFallback: true,
        });
      } else if (CONFIG?.apiBaseUrl) {
        // Sanitize text to remove control characters that break JSON
        const sanitize = (text) => {
          return text
            .replace(/[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]/g, '') // Remove control chars except \n, \r, \t
            .replace(/\r\n/g, '\n') // Normalize line endings
            .replace(/\r/g, '\n');
        };

        // Combine JD HTML and Form HTML for comprehensive context
        const combinedHtmlForBackend = [
          scannedFormHtml ? scannedFormHtml.slice(0, 35000) : '',
          scannedJdHtml ? scannedJdHtml.slice(0, 15000) : '',
        ]
          .filter(Boolean)
          .join('\n<!-- JD PAGE HTML -->\n');

        const resp = await callBackend(
          '/v1/analyze-form',
          {
            cvText: sanitize(cvText),
            jobDescriptionText: sanitize(jobDescriptionText),
            formText: sanitize(formText),
            formHtml: combinedHtmlForBackend
              ? sanitize(combinedHtmlForBackend.slice(0, 50000))
              : '', // Include combined HTML for better AI understanding
            modelId: getSelectedModelId(),
          },
          { useRRBase: false }
        );
        console.log(
          '[Sidepanel] Combined HTML sent to backend:',
          combinedHtmlForBackend.length,
          'chars'
        );
        if (!resp.ok) {
          // Don't show sign-in prompt for RR users - backend handles auth gracefully
          if (resp.status === 402 || resp.status === 429) {
            showLimitPrompt();
            throw new Error('Free trial used (100 requests).');
          }
          // For any other error, just show the error message
          throw new Error(resp.error || 'Analysis failed. Please try again.');
        }
        const result = resp.data?.result || resp.data;
        if (!result) throw new Error('No data');
        const elapsed = resp.data?.elapsedMs;
        try {
          // Use cached job URL from when JD was scanned, fallback to current page
          const jobUrl =
            cachedJobUrl || cachedJobMeta.url || (await getActiveTabUrl());
          await logApplication({
            job_url: jobUrl,
            job_title: cachedJobMeta.jobTitle || '',
            company_name: cachedJobMeta.company || guessCompanyName(jdEl.value),
            job_description: jobDescriptionText,
            notes: 'Analyze form',
            resume_generated: false,
            cover_letter_generated: false,
          });
        } catch (_) {}
        renderResults(result);
        if (typeof elapsed === 'number') {
          const s = (elapsed / 1000).toFixed(1);
          try {
            notesEl.insertAdjacentHTML(
              'beforeend',
              `<div class=\"notes-meta\">⏱️ Took ${s}s</div>`
            );
          } catch (_) {}
        }
        await syncRRProfileSnapshot({
          applied: true,
          cvText,
          skipUrlFallback: true,
        });
      } else {
        const modelId = getSelectedModelId();
        console.log(
          '[Sidepanel] Sending analyzeForm message with modelId:',
          modelId
        );
        const response = await chrome.runtime.sendMessage({
          type: 'analyzeForm',
          payload: {
            cvText,
            jobDescriptionText,
            formText,
            modelId,
          },
        });
        if (!response || !response.ok) {
          const error = response?.error || 'Unknown error';
          showResultsPage();
          if (resultsList) {
            resultsList.innerHTML = `<div class=\"error\">${error}</div>`;
          }
          return;
        }
        renderResults(response.result);
        await syncRRProfileSnapshot({
          applied: true,
          cvText,
          skipUrlFallback: true,
        });
      }
    } catch (error) {
      showResultsPage();
      const errorMsg = String(error);
      if (resultsList) {
        if (errorMsg.includes('sign in') || errorMsg.includes('401')) {
          resultsList.innerHTML = `<div class="error">Please sign in</div>`;
        } else {
          resultsList.innerHTML = `<div class="error">${errorMsg}</div>`;
        }
      }
    } finally {
      setLoading(false);
    }
  }

  function clearInputs() {
    cvEl.value = '';
    jdEl.value = '';
    formEl.value = '';
    if (generatedCvEl) generatedCvEl.value = '';
    if (generatedCoverEl) generatedCoverEl.value = '';
    // Reset generated document URLs
    generatedResumeUrl = '';
    generatedCoverLetterUrl = '';
    // Reset scanned HTML
    scannedFormHtml = '';
    scannedJdHtml = '';
    hideAllDocumentPages();
    clearResults();
    cvEl.focus();
  }

  async function scanAllFrames(messageType) {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });
    if (!tab?.id) return [];
    try {
      const frames = await chrome.webNavigation.getAllFrames({ tabId: tab.id });
      const aggregated = [];
      for (const frame of frames) {
        try {
          const res = await chrome.tabs.sendMessage(
            tab.id,
            { type: messageType },
            { frameId: frame.frameId }
          );
          if (res) aggregated.push(res);
        } catch (_) {}
      }
      if (aggregated.length === 0) {
        try {
          const res = await chrome.tabs.sendMessage(tab.id, {
            type: messageType,
          });
          if (res) aggregated.push(res);
        } catch (_) {}
      }
      return aggregated;
    } catch (_) {
      return [];
    }
  }

  async function scanJobDescription() {
    showButtonSpinner(scanJDBtn, true);
    try {
      // Load saved CV before scanning
      await loadSavedCV();

      const responses = await scanAllFrames('scanJobDescription');
      const append = responses
        .map((r) => r?.text || '')
        .filter(Boolean)
        .join('\n\n');
      if (append)
        jdEl.value = jdEl.value ? jdEl.value + '\n\n' + append : append;

      // Store JD page HTML for context (truncate to ~50KB)
      const jdHtmlParts = responses.map((r) => r?.html || '').filter(Boolean);
      if (jdHtmlParts.length > 0) {
        scannedJdHtml = jdHtmlParts.join('\n').slice(0, 50000);
        console.log(
          '[Sidepanel] Stored JD HTML:',
          scannedJdHtml.length,
          'chars'
        );
      }

      // Cache the job URL and metadata when scanning JD
      try {
        const meta = await getJobMetaFromPage();
        const rrState = window.RRIntegration?.getState();
        const mergedMeta = {
          jobTitle: meta.jobTitle || '',
          company: meta.company || '',
          url: meta.url || '',
          jobId: meta.jobId || rrState?.jobId || cachedJobMeta.jobId || '',
        };
        if (mergedMeta.url) {
          cachedJobUrl = mergedMeta.url;
        }
        cachedJobMeta = mergedMeta;
      } catch (error) {
        console.warn('[Sidepanel] Failed to cache job metadata:', error);
      }

      // Update button state after programmatically filling the textarea
      checkFormCompletion();
    } finally {
      showButtonSpinner(scanJDBtn, false);
    }
  }

  // Store scanned HTML for better AI analysis
  let scannedFormHtml = '';
  let scannedJdHtml = '';

  async function scanApplicationForm() {
    showButtonSpinner(scanFormBtn, true);
    try {
      // Load saved CV before scanning
      await loadSavedCV();

      const responses = await scanAllFrames('scanApplicationForm');
      const append = responses
        .map((r) => r?.summary || '')
        .filter(Boolean)
        .join('\n\n');
      if (append)
        formEl.value = formEl.value ? formEl.value + '\n\n' + append : append;

      // Store HTML for better AI analysis (truncate to reasonable size)
      const htmlParts = responses.map((r) => r?.html || '').filter(Boolean);
      if (htmlParts.length > 0) {
        // Keep relevant form HTML, truncate to ~50KB to avoid token limits
        scannedFormHtml = htmlParts.join('\n').slice(0, 50000);
        console.log(
          '[Sidepanel] Stored form HTML:',
          scannedFormHtml.length,
          'chars'
        );
      }

      // Update button state after programmatically filling the textarea
      checkFormCompletion();
    } finally {
      showButtonSpinner(scanFormBtn, false);
    }
  }

  // One-click complete fill: Analyze form, fill all fields, and handle file uploads
  async function oneClickCompleteFill() {
    try {
      // Step 1: Scan everything if not already scanned
      if (!jdEl.value.trim()) {
        await scanJobDescription();
      }
      if (!formEl.value.trim()) {
        await scanApplicationForm();
      }

      // Step 2: Analyze and fill the form
      await analyzeAndFill();

      // Step 3: Try to upload resume/cover letter to file inputs
      await autoUploadDocuments();

      console.log('[Sidepanel] One-click complete fill finished');
    } catch (error) {
      console.error('[Sidepanel] One-click fill error:', error);
    }
  }

  // Auto-upload generated resume and cover letter to file input fields
  async function autoUploadDocuments() {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (!tab?.id) return;

      // Check if we have generated resume or cover letter
      const resumeText = generatedCvEl?.value?.trim();
      const coverText = generatedCoverEl?.value?.trim();

      if (!resumeText && !coverText) {
        console.log('[Sidepanel] No generated documents to upload');
        return;
      }

      // First, find all file inputs on the page
      let fileInputs = [];
      const frames = await chrome.webNavigation.getAllFrames({ tabId: tab.id });
      for (const frame of frames) {
        try {
          const res = await chrome.tabs.sendMessage(
            tab.id,
            { type: 'findFileInputs' },
            { frameId: frame.frameId }
          );
          if (res?.ok && res.fileInputs) {
            fileInputs.push(...res.fileInputs);
          }
        } catch (_) {}
      }

      if (fileInputs.length === 0) {
        console.log('[Sidepanel] No file inputs found on page');
        return;
      }

      console.log('[Sidepanel] Found file inputs:', fileInputs);

      // Upload resume to resume input
      if (resumeText) {
        const resumeInput = fileInputs.find((f) => f.fileType === 'resume');
        if (resumeInput) {
          try {
            const pdfBlob = await createPdfBlob(resumeText, 'resume.pdf', true);
            const arrayBuffer = await pdfBlob.arrayBuffer();
            const fileData = Array.from(new Uint8Array(arrayBuffer));

            for (const frame of frames) {
              try {
                await chrome.tabs.sendMessage(
                  tab.id,
                  {
                    type: 'triggerFileUpload',
                    inputSelector: resumeInput.selector,
                    fileData,
                    fileName: 'resume.pdf',
                    mimeType: 'application/pdf',
                  },
                  { frameId: frame.frameId }
                );
                console.log(
                  '[Sidepanel] Resume uploaded to:',
                  resumeInput.selector
                );
                break;
              } catch (_) {}
            }
          } catch (e) {
            console.error('[Sidepanel] Resume upload error:', e);
          }
        }
      }

      // Upload cover letter to cover letter input
      if (coverText) {
        const coverInput = fileInputs.find(
          (f) => f.fileType === 'cover_letter'
        );
        if (coverInput) {
          try {
            const pdfBlob = await createPdfBlob(
              coverText,
              'cover-letter.pdf',
              false
            );
            const arrayBuffer = await pdfBlob.arrayBuffer();
            const fileData = Array.from(new Uint8Array(arrayBuffer));

            for (const frame of frames) {
              try {
                await chrome.tabs.sendMessage(
                  tab.id,
                  {
                    type: 'triggerFileUpload',
                    inputSelector: coverInput.selector,
                    fileData,
                    fileName: 'cover-letter.pdf',
                    mimeType: 'application/pdf',
                  },
                  { frameId: frame.frameId }
                );
                console.log(
                  '[Sidepanel] Cover letter uploaded to:',
                  coverInput.selector
                );
                break;
              } catch (_) {}
            }
          } catch (e) {
            console.error('[Sidepanel] Cover letter upload error:', e);
          }
        }
      }

      console.log('[Sidepanel] Auto-upload completed');
    } catch (error) {
      console.error('[Sidepanel] Auto upload error:', error);
    }
  }

  function readFileAsText(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('Read failed'));
      reader.readAsText(file);
    });
  }

  async function pdfArrayBuffer(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(r.error || new Error('Read failed'));
      r.readAsArrayBuffer(file);
    });
  }

  async function extractPdfText(file) {
    try {
      if (!window['pdfjsLib']) {
        assetStatusEl.textContent =
          'PDF detected. Enable parser by adding pdf.js (see README).';
        return '';
      }
      const buf = await pdfArrayBuffer(file);
      const u8 = new Uint8Array(buf);
      const header = new TextDecoder('ascii').decode(u8.slice(0, 8));
      if (!header.startsWith('%PDF-')) return '';

      const pdf = await window['pdfjsLib'].getDocument({ data: u8 }).promise;
      let text = '';
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const tc = await page.getTextContent();
        const pageText = tc.items.map((it) => it.str || '').join(' ');
        text += (i > 1 ? '\n\n' : '') + pageText;
      }
      return text.trim();
    } catch (e) {
      return '';
    }
  }

  // Basic DOCX text extractor (no external libs).
  // Reads the DOCX ZIP container, finds word/document.xml, and pulls all <w:t> text.
  async function extractDocxText(file) {
    try {
      // Require DecompressionStream (Chrome 80+); otherwise we can't safely parse DOCX
      if (typeof DecompressionStream === 'undefined') {
        console.warn(
          '[CV Upload] DecompressionStream not available - cannot parse DOCX on this browser'
        );
        return '';
      }

      const buf = await pdfArrayBuffer(file); // generic ArrayBuffer reader
      const data = new Uint8Array(buf);
      const view = new DataView(buf);

      const SIG_EOCD = 0x06054b50;
      const SIG_CD = 0x02014b50;
      const SIG_LOCAL = 0x04034b50;

      // 1. Locate End of Central Directory (EOCD) record
      const maxCommentLen = 0xffff;
      const minEOCD = 22;
      const startSearch = Math.max(0, data.length - (minEOCD + maxCommentLen));
      let eocdOffset = -1;
      for (let i = data.length - minEOCD; i >= startSearch; i--) {
        if (view.getUint32(i, true) === SIG_EOCD) {
          eocdOffset = i;
          break;
        }
      }
      if (eocdOffset < 0) {
        console.warn('[CV Upload] DOCX EOCD not found');
        return '';
      }

      const totalEntries = view.getUint16(eocdOffset + 10, true);
      const centralDirOffset = view.getUint32(eocdOffset + 16, true);

      // 2. Walk central directory to find word/document.xml entry
      let entry = null;
      let ptr = centralDirOffset;
      const utf8 = new TextDecoder('utf-8');

      for (let i = 0; i < totalEntries; i++) {
        if (view.getUint32(ptr, true) !== SIG_CD) break;

        const compressionMethod = view.getUint16(ptr + 10, true);
        const compressedSize = view.getUint32(ptr + 20, true);
        const fileNameLen = view.getUint16(ptr + 28, true);
        const extraLen = view.getUint16(ptr + 30, true);
        const commentLen = view.getUint16(ptr + 32, true);
        const localHeaderOffset = view.getUint32(ptr + 42, true);

        const nameBytes = data.subarray(ptr + 46, ptr + 46 + fileNameLen);
        const name = utf8.decode(nameBytes);

        if (name === 'word/document.xml') {
          entry = {
            compressionMethod,
            compressedSize,
            localHeaderOffset,
          };
          break;
        }

        ptr += 46 + fileNameLen + extraLen + commentLen;
      }

      if (!entry) {
        console.warn(
          '[CV Upload] DOCX main document part word/document.xml not found'
        );
        return '';
      }

      // 3. Jump to local file header to find start of compressed data
      let off = entry.localHeaderOffset;
      if (view.getUint32(off, true) !== SIG_LOCAL) {
        console.warn(
          '[CV Upload] DOCX local header mismatch at offset',
          entry.localHeaderOffset
        );
        return '';
      }
      const lfNameLen = view.getUint16(off + 26, true);
      const lfExtraLen = view.getUint16(off + 28, true);
      const dataStart = off + 30 + lfNameLen + lfExtraLen;
      const compressed = data.subarray(
        dataStart,
        dataStart + entry.compressedSize
      );

      let xmlBytes;
      if (entry.compressionMethod === 0) {
        // Stored (no compression)
        xmlBytes = compressed;
      } else if (entry.compressionMethod === 8) {
        // Deflate
        const ds = new DecompressionStream('deflate-raw');
        const stream = new Blob([compressed]).stream().pipeThrough(ds);
        const outBuf = await new Response(stream).arrayBuffer();
        xmlBytes = new Uint8Array(outBuf);
      } else {
        console.warn(
          '[CV Upload] Unsupported DOCX compression method:',
          entry.compressionMethod
        );
        return '';
      }

      const xmlText = utf8.decode(xmlBytes);

      // 4. Extract text from <w:t> elements
      const textPieces = [];
      const re = /<w:t[^>]*>(.*?)<\/w:t>/g;
      let m;
      while ((m = re.exec(xmlText)) !== null) {
        let chunk = m[1] || '';
        // Basic entity decoding
        chunk = chunk
          .replace(/&amp;/g, '&')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&quot;/g, '"')
          .replace(/&apos;/g, "'");
        textPieces.push(chunk);
      }

      if (!textPieces.length) return '';

      // Join with spaces and normalize whitespace
      const plain = textPieces.join(' ').replace(/\s+/g, ' ').trim();
      return plain;
    } catch (e) {
      console.error('[CV Upload] DOCX parse failed:', e);
      return '';
    }
  }

  async function handleAssetUpload() {
    console.log('handleAssetUpload called');
    const files = Array.from(assetFileInput?.files || []);
    console.log('Files selected:', files.length);
    if (!files.length) {
      assetStatusEl.textContent = 'Select one or more files first.';
      return;
    }
    assetStatusEl.textContent = 'Processing…';
    let added = 0;
    for (const file of files) {
      try {
        let text = '';
        const ext = (file.name.split('.').pop() || '').toLowerCase();
        console.log('Processing file:', file.name, 'Extension:', ext);
        if (ext === 'txt') {
          text = await readFileAsText(file);
        } else if (ext === 'pdf') {
          text = await extractPdfText(file);
        } else if (ext === 'doc' || ext === 'docx') {
          // Parse modern Word documents (DOCX). For legacy .doc, this may fail gracefully.
          text = await extractDocxText(file);
        } else {
          text = await readFileAsText(file);
        }
        console.log('Extracted text length:', text.length);
        if (text) {
          const prev = cvEl.value.trim();
          cvEl.value = prev ? prev + '\n\n' + text : text;
          added++;
          console.log('Added text to cvText field');
        } else {
          console.log('No text extracted from file:', file.name);
        }
      } catch (err) {
        console.error('Error processing file:', file.name, err);
      }
    }
    if (added > 0) {
      assetStatusEl.textContent = `Added ${added} file(s) to assets.`;
      // Persist CV text for reuse across onboarding/profile/sidepanel
      try {
        const cvText = cvEl.value.trim();
        if (cvText) {
          await chrome.storage.local.set({ userCV: cvText });
          console.log(
            `[Sidepanel] Saved CV text to local storage (${cvText.length} characters)`
          );
          // Kick off background profile sync so Cloud SQL has the latest CV
          if (window.JobApAIProfile?.syncOnLogin) {
            window.JobApAIProfile.syncOnLogin().catch((e) =>
              console.error('[Sidepanel] Background profile sync failed:', e)
            );
          }
        }
      } catch (e) {
        console.error('[Sidepanel] Error saving CV text:', e);
      }
      // NOTE: Source CV files are NOT uploaded to RR here.
      // Only generated resumes/cover letters are uploaded to RR (in syncRRAfterGeneration).
    } else {
      assetStatusEl.textContent =
        'No text extracted. Please check that the file is a valid PDF, Word (DOCX), or TXT. You can also copy-paste your resume text.';
    }
    // Update button state after programmatically filling the textarea
    checkFormCompletion();
  }

  async function fillPage() {
    showButtonSpinner(fillPageBtn, true);
    showFillingStatus('Preparing to fill form fields...');

    try {
      const rows = Array.from(resultsList.querySelectorAll('.field-row'));
      const fields = [];
      const totalFields = rows.length;

      for (let i = 0; i < rows.length; i++) {
        // Check if user aborted
        if (isFillingAborted) {
          console.log('[Sidepanel] Filling aborted by user');
          return;
        }

        const row = rows[i];
        const displayName = row.querySelector('.field-name')?.textContent || '';
        const originalName = row.dataset ? row.dataset.fieldName || '' : '';
        const value = row.querySelector('.field-value')?.value || '';
        const primary = (originalName || displayName || '').trim();
        if (primary) fields.push({ name: primary, value });
        // Add a friendly alias when systemfield maps to a common label
        if (originalName && /^_systemfield_name$/i.test(originalName)) {
          fields.push({ name: 'Full Name', value });
          fields.push({ name: 'Name', value });
        }
      }

      // Check abort again before sending to page
      if (isFillingAborted) {
        console.log('[Sidepanel] Filling aborted by user before sending');
        return;
      }

      updateFillingStatus(`Filling ${fields.length} fields...`, 20);

      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (!tab?.id) return;

      const frames = await chrome.webNavigation.getAllFrames({ tabId: tab.id });
      const totalFrames = frames.length;

      for (let i = 0; i < frames.length; i++) {
        // Check if user aborted
        if (isFillingAborted) {
          console.log('[Sidepanel] Filling aborted during frame processing');
          return;
        }

        const frame = frames[i];
        const progress = 20 + ((i + 1) / totalFrames) * 60; // 20-80%
        updateFillingStatus(
          `Filling fields (${i + 1}/${totalFrames} frames)...`,
          progress
        );

        try {
          await chrome.tabs.sendMessage(
            tab.id,
            { type: 'applyFields', fields },
            { frameId: frame.frameId }
          );
          // Small delay between frames to allow UI to update
          await delay(100);
        } catch (_) {}
      }

      // Check abort before sync
      if (isFillingAborted) {
        console.log('[Sidepanel] Filling aborted before sync');
        return;
      }

      updateFillingStatus('Finalizing...', 90);

      // Sync profile with applied: true after form is filled
      // Note: Do NOT send resume_url/cover_letter_url - those are only sent on document generation
      // Use skipUrlFallback: true to prevent sending any old URLs from state
      console.log(
        '[Sidepanel] Form filled - syncing profile with applied: true (no document URLs)'
      );
      try {
        await syncRRProfileSnapshot({
          applied: true,
          cvText: cvEl?.value?.trim() || '',
          skipUrlFallback: true, // Don't fallback to old URLs in state
        });
        console.log('[Sidepanel] Profile sync after fill completed');
      } catch (syncError) {
        console.warn('[Sidepanel] Profile sync after fill failed:', syncError);
      }

      // Show success briefly
      updateFillingStatus('✓ Form filled successfully!', 100);
      await delay(1500);
    } catch (error) {
      console.error('[Sidepanel] Fill page error:', error);
      updateFillingStatus('Error filling form. Please try again.', 100);
      await delay(2000);
    } finally {
      showButtonSpinner(fillPageBtn, false);
      hideFillingStatus();
    }
  }

  // Analyze inputs and then auto-fill the page
  async function analyzeAndFill() {
    try {
      if (analyzeFastBtn) showButtonSpinner(analyzeFastBtn, true);
      await analyze();

      // Auto-fill immediately after analysis for seamless one-click experience
      // Wait a moment for results to render
      await new Promise((r) => setTimeout(r, 300));

      // Check if we have results to fill
      const rows = resultsList?.querySelectorAll('.field-row')?.length || 0;
      if (rows > 0) {
        console.log('[Sidepanel] Auto-filling', rows, 'fields');
        await fillPage();

        // Also try to upload any generated documents
        await autoUploadDocuments();
      }
    } catch (error) {
      console.error('[Sidepanel] analyzeAndFill error:', error);
    } finally {
      if (analyzeFastBtn) showButtonSpinner(analyzeFastBtn, false);
    }
  }

  // New: generation handlers
  // Helper function to clean markdown bold formatting from text
  function cleanBoldMarkdown(text) {
    if (!text) return text;
    // Remove **bold** and __bold__ markdown
    return text.replace(/\*\*([^*]+)\*\*/g, '$1').replace(/__([^_]+)__/g, '$1');
  }

  // Helper function to fix AI-generated letter-spaced text
  // Detects patterns like "S t r a t e g i c" and collapses to "Strategic"
  function fixLetterSpacedText(text) {
    if (!text) return text;

    // Pattern matches: word boundary, then sequences of single letter followed by space
    // e.g., "S t r a t e g i c" -> "Strategic"
    // Must have at least 3 letters to avoid false positives like "a b" or "I a"
    return text.replace(/\b([A-Za-z])((?:\s[A-Za-z]){2,})\b/g, (match) => {
      // Split by spaces and check if all parts are single letters
      const parts = match.split(/\s+/);
      if (parts.every((p) => p.length === 1)) {
        // Collapse letter-spaced text
        return parts.join('');
      }
      return match;
    });
  }

  // Comprehensive text cleaner for AI output
  function cleanAIGeneratedText(text) {
    if (!text) return text;
    let cleaned = text;
    // Fix letter-spaced text (AI emphasis like "S t r a t e g i c")
    cleaned = fixLetterSpacedText(cleaned);
    // Remove markdown bold
    cleaned = cleanBoldMarkdown(cleaned);
    // Remove zero-width and special unicode characters
    cleaned = cleaned.replace(/[\u200B-\u200D\uFEFF]/g, '');
    // Normalize non-breaking spaces to regular spaces
    cleaned = cleaned.replace(/\u00A0/g, ' ');
    // Collapse multiple spaces into one (but preserve newlines)
    cleaned = cleaned.replace(/[^\S\n]+/g, ' ');
    return cleaned;
  }

  function createTextFile(text, filename) {
    const content = text || '';
    if (typeof File === 'function') {
      try {
        return new File([content], filename, {
          type: 'text/plain;charset=utf-8',
          lastModified: Date.now(),
        });
      } catch (_) {}
    }
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    blob.name = filename;
    blob.lastModified = Date.now();
    return blob;
  }

  // Create a PDF blob from text content for upload - uses same professional formatting as download
  async function createPdfBlob(text, filename, isResume = true) {
    try {
      const JsPdfCtor = await loadJsPdfCtor();
      if (typeof JsPdfCtor !== 'function') {
        console.warn(
          '[Sidepanel] jsPDF not available, falling back to text file'
        );
        return createTextFile(text, filename.replace('.pdf', '.txt'));
      }

      const doc = new JsPdfCtor({ unit: 'pt', format: 'a4' });
      const margin = 54;
      const pageWidth = 595.28;
      const maxWidth = pageWidth - margin * 2;
      const pageHeight = 841.89;

      // CRITICAL: Reset character spacing to prevent letter spacing issues
      if (typeof doc.setCharSpace === 'function') {
        doc.setCharSpace(0);
      }

      // Helper to safely draw text without spacing issues
      const safeText = (str, x, yPos) => {
        if (typeof doc.setCharSpace === 'function') {
          doc.setCharSpace(0);
        }
        const cleanStr = String(str || '')
          .replace(/[\u200B-\u200D\uFEFF]/g, '')
          .replace(/\u00A0/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();
        if (cleanStr) {
          doc.text(cleanStr, x, yPos);
        }
      };

      // Helper to clean text and split it safely
      const safeSplit = (str, width) => {
        const clean = String(str || '')
          .replace(/[\u200B-\u200D\uFEFF]/g, '')
          .replace(/\u00A0/g, ' ')
          .trim();
        if (!clean) return [];
        return doc.splitTextToSize(clean, width);
      };

      // Professional color scheme
      const primaryColor = [0, 0, 0];
      const accentColor = [60, 60, 60];
      const lineColor = [180, 180, 180];

      // Normalize and pre-clean lines
      // Also fix AI-generated letter-spaced text like "S t r a t e g i c"
      const cleanedInput = fixLetterSpacedText(String(text || ''));
      const raw = cleanedInput.replace(/\r\n?/g, '\n');
      const rawLines = raw.split('\n');
      const lines = [];
      for (let i = 0; i < rawLines.length; i++) {
        let ln = (rawLines[i] || '').trimEnd();
        // Remove hidden unicode spacing characters
        ln = ln.replace(/[\u200B-\u200D\uFEFF]/g, '');
        // Fix any remaining letter-spaced words on this line
        ln = fixLetterSpacedText(ln);
        if (/^\s*[-_=\u2014]{3,}\s*$/.test(ln)) continue;
        if (ln.trim() === '') {
          if (lines.length && lines[lines.length - 1].trim() === '') continue;
          lines.push('');
        } else {
          lines.push(ln);
        }
      }

      let y = margin;
      const checkPageBreak = (requiredSpace) => {
        if (y + requiredSpace > pageHeight - margin) {
          doc.addPage();
          y = margin;
          return true;
        }
        return false;
      };

      const isCoverLetter = !isResume;

      // Cover Letter formatting
      if (isCoverLetter) {
        doc.setFont('times', 'normal');
        doc.setFontSize(11);
        doc.setTextColor(...primaryColor);

        let lineIndex = 0;
        let isSignatureSection = false;

        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          const trimmed = line.trim();

          if (
            /^(sincerely|best regards|regards|thank you|yours truly|respectfully)/i.test(
              trimmed
            )
          ) {
            isSignatureSection = true;
            y += 16;
          }

          if (!trimmed) {
            y += isSignatureSection ? 8 : 14;
            continue;
          }

          const isBullet = /^[-•*]\s/.test(trimmed);

          if (isBullet) {
            checkPageBreak(16);
            const bulletText = trimmed.replace(/^[-•*]\s*/, '');
            const textX = margin + 18;
            const bulletX = margin + 6;
            const lineH = 14;
            const chunks = safeSplit(bulletText, maxWidth - 20);
            doc.setFont('times', 'normal');
            doc.setFontSize(11);
            safeText('•', bulletX, y);
            for (let j = 0; j < chunks.length; j++) {
              safeText(chunks[j], textX, y);
              y += lineH;
            }
            y += 3;
            continue;
          }

          if (
            lineIndex < 5 &&
            /\d{1,2},?\s+\d{4}|[A-Z][a-z]+\s+\d{1,2},?\s+\d{4}/.test(trimmed)
          ) {
            checkPageBreak(16);
            doc.setFont('times', 'normal');
            doc.setFontSize(11);
            safeText(trimmed, margin, y);
            y += 20;
            lineIndex++;
            continue;
          }

          if (/^(Dear|To whom)/i.test(trimmed)) {
            y += 8;
            checkPageBreak(16);
            doc.setFont('times', 'normal');
            doc.setFontSize(11);
            safeText(trimmed, margin, y);
            y += 20;
            lineIndex++;
            continue;
          }

          checkPageBreak(16);
          doc.setFont('times', isSignatureSection ? 'italic' : 'normal');
          doc.setFontSize(11);
          const chunks = safeSplit(trimmed, maxWidth);
          for (const c of chunks) {
            checkPageBreak(14);
            safeText(c, margin, y);
            y += 14;
          }
          y += 2;
          lineIndex++;
        }
      } else {
        // Resume formatting - same as openPrintPdf
        let headerLines = [];
        let contentStartIndex = 0;
        for (let i = 0; i < Math.min(10, lines.length); i++) {
          const trimmed = lines[i].trim();
          if (!trimmed) continue;
          if (
            /^(EXPERIENCE|EDUCATION|SKILLS|SUMMARY|OBJECTIVE|PROJECTS|CERTIFICATIONS|AWARDS|PROFILE|TECHNICAL)/i.test(
              trimmed
            )
          ) {
            contentStartIndex = i;
            break;
          }
          headerLines.push(trimmed);
          if (headerLines.length >= 5) {
            contentStartIndex = i + 1;
            break;
          }
        }

        // Render professional header
        if (headerLines.length > 0) {
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(16);
          doc.setTextColor(...primaryColor);

          const nameLine = headerLines[0].toUpperCase();
          const nameChunks = safeSplit(nameLine, maxWidth);
          for (const chunk of nameChunks) {
            const chunkWidth = doc.getTextWidth(chunk);
            const centerX = margin + (maxWidth - chunkWidth) / 2;
            safeText(chunk, centerX, y);
            y += 18;
          }

          const contactInfo = headerLines.slice(1).join('  |  ');
          if (contactInfo) {
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(9);
            doc.setTextColor(...accentColor);
            const contactChunks = safeSplit(contactInfo, maxWidth);
            for (const chunk of contactChunks) {
              const chunkWidth = doc.getTextWidth(chunk);
              const centerX = margin + (maxWidth - chunkWidth) / 2;
              safeText(chunk, centerX, y);
              y += 11;
            }
          }

          y += 6;
          doc.setDrawColor(...lineColor);
          doc.setLineWidth(0.5);
          doc.line(margin, y, margin + maxWidth, y);
          y += 12;
        }

        // Multi-column bullet rendering for expertise/skills
        const renderMultiColumnBullets = (items, numColumns = 2) => {
          if (!items || items.length === 0) return;

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(9.5);
          doc.setTextColor(...primaryColor);

          const columnGap = 15;
          const columnWidth =
            (maxWidth - (numColumns - 1) * columnGap) / numColumns;
          const bulletX = 0;
          const textX = 10;
          const textAvailableWidth = columnWidth - textX - 2;
          const lineHeight = 11;

          // Fill row by row (left to right) to handle variable heights gracefully
          const rows = [];
          for (let i = 0; i < items.length; i += numColumns) {
            rows.push(items.slice(i, i + numColumns));
          }

          for (let r = 0; r < rows.length; r++) {
            const rowItems = rows[r];
            let maxRowHeight = 0;
            const rowContent = [];

            // First pass: calculate heights and prepare content for this row
            for (let c = 0; c < rowItems.length; c++) {
              const item = rowItems[c].trim();
              if (!item) {
                rowContent.push({ lines: [], height: 0 });
                continue;
              }

              // Use safeSplit to avoid character spacing issues
              const lines = safeSplit(item, textAvailableWidth);
              const height = (lines.length || 1) * lineHeight;

              if (height > maxRowHeight) maxRowHeight = height;
              rowContent.push({ lines, height });
            }

            maxRowHeight = Math.max(maxRowHeight, 14);

            // Check page break for the whole row
            checkPageBreak(maxRowHeight + 2);

            // Render the row
            const rowStartY = y;
            for (let c = 0; c < rowContent.length; c++) {
              const content = rowContent[c];
              if (content.lines.length === 0) continue;

              const colStartX = margin + c * (columnWidth + columnGap);

              // Draw bullet
              doc.setFontSize(8);
              safeText('•', colStartX + bulletX, rowStartY);
              doc.setFontSize(9.5);

              // Draw text lines with proper alignment
              let lineY = rowStartY;
              for (const line of content.lines) {
                safeText(line, colStartX + textX, lineY);
                lineY += lineHeight;
              }
            }

            y += maxRowHeight + 6;
          }

          y += 4;
        };

        let currentSection = '';
        let expertiseItems = [];
        let collectingExpertise = false;

        for (let i = contentStartIndex; i < lines.length; i++) {
          const line = lines[i];
          const trimmed = line.trim();

          const isHeader =
            /^(PROFESSIONAL EXPERIENCE|EXPERIENCE|EDUCATION|SKILLS|SUMMARY|OBJECTIVE|PROJECTS|CERTIFICATIONS|AWARDS|TECHNICAL|COMPETENCIES|EXPERTISE|RELEVANT PROJECTS|RELEVANT ACCOMPLISHMENTS|INDUSTRY TECHNOLOGY|INDUSTRY INFORMATION|AWARDS & VOLUNTEERISM|STEM MENTOR)$/i.test(
              trimmed
            );
          const isExpertiseHeader =
            /^(EXPERTISE|SKILLS|COMPETENCIES|TECHNICAL)$/i.test(trimmed);
          const isBullet = /^[-•*]\s/.test(trimmed);

          const monthRe =
            /(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t|tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)/i;
          const companyDateRe = new RegExp(
            monthRe.source +
              '\\s+\\d{4}\\s*[–—-]\\s*(Present|' +
              monthRe.source +
              '\\s+\\d{4})',
            'i'
          );
          const isCompanyDateLine = companyDateRe.test(trimmed);

          if (isHeader && collectingExpertise && expertiseItems.length > 0) {
            const avgLength =
              expertiseItems.reduce((sum, item) => sum + item.length, 0) /
              expertiseItems.length;
            const numCols = avgLength < 30 ? 3 : 2;
            renderMultiColumnBullets(expertiseItems, numCols);
            expertiseItems = [];
            collectingExpertise = false;
          }

          if (!trimmed) {
            if (collectingExpertise && expertiseItems.length > 0) {
              const avgLength =
                expertiseItems.reduce((sum, item) => sum + item.length, 0) /
                expertiseItems.length;
              const numCols = avgLength < 30 ? 3 : 2;
              renderMultiColumnBullets(expertiseItems, numCols);
              expertiseItems = [];
              collectingExpertise = false;
            }
            y += 4;
            continue;
          }

          if (isHeader) {
            const headerSpace = 28;
            if (checkPageBreak(headerSpace)) {
              y += 6;
            } else {
              y += 14;
            }
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(11);
            doc.setTextColor(...primaryColor);
            const headerText = trimmed.toUpperCase();
            const headerChunks = safeSplit(headerText, maxWidth);
            for (const chunk of headerChunks) {
              safeText(chunk, margin, y);
              y += 14;
            }
            doc.setDrawColor(...lineColor);
            doc.setLineWidth(0.5);
            doc.line(margin, y - 2, margin + maxWidth, y - 2);
            y += 8;

            currentSection = trimmed.toUpperCase();
            if (isExpertiseHeader) {
              collectingExpertise = true;
              expertiseItems = [];
            }
            continue;
          }

          if (isCompanyDateLine) {
            if (collectingExpertise && expertiseItems.length > 0) {
              const avgLength =
                expertiseItems.reduce((sum, item) => sum + item.length, 0) /
                expertiseItems.length;
              const numCols = avgLength < 30 ? 3 : 2;
              renderMultiColumnBullets(expertiseItems, numCols);
              expertiseItems = [];
              collectingExpertise = false;
            }

            y += 10;
            checkPageBreak(16);
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(10);
            doc.setTextColor(...primaryColor);

            const chunks = safeSplit(trimmed, maxWidth);
            for (const c of chunks) {
              safeText(c, margin, y);
              y += 13;
            }
            y += 2;
            continue;
          }

          if (isBullet) {
            const bulletText = trimmed.replace(/^[-•*]\s*/, '').trim();

            if (collectingExpertise) {
              const inlineItems = bulletText.split(/\s+•\s+/g).filter(Boolean);
              expertiseItems.push(...inlineItems);
              continue;
            }

            checkPageBreak(14);
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(9.5);
            doc.setTextColor(...primaryColor);
            const textX = margin + 14;
            const bulletXPos = margin + 4;
            const lineH = 13;

            const items = bulletText.split(/\s•\s+/g).filter(Boolean);
            for (let it = 0; it < items.length; it++) {
              const item = items[it].trim();
              const chunks = safeSplit(item, maxWidth - 16);
              doc.setFontSize(7);
              safeText('•', bulletXPos, y - 1);
              doc.setFontSize(9.5);
              for (let j = 0; j < chunks.length; j++) {
                safeText(chunks[j], textX, y);
                y += lineH;
              }
              if (it < items.length - 1) y += 2;
            }
            y += 3;
            continue;
          }

          if (
            collectingExpertise &&
            trimmed.length < 50 &&
            !trimmed.includes(':')
          ) {
            expertiseItems.push(trimmed);
            continue;
          }

          if (collectingExpertise && expertiseItems.length > 0) {
            const avgLength =
              expertiseItems.reduce((sum, item) => sum + item.length, 0) /
              expertiseItems.length;
            const numCols = avgLength < 30 ? 3 : 2;
            renderMultiColumnBullets(expertiseItems, numCols);
            expertiseItems = [];
            collectingExpertise = false;
          }

          checkPageBreak(14);
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(9.5);
          doc.setTextColor(...primaryColor);

          const chunks = safeSplit(trimmed, maxWidth);
          for (const c of chunks) {
            checkPageBreak(12);
            safeText(c, margin, y);
            y += 12;
          }
          y += 2;
        }

        // Render any remaining expertise items
        if (collectingExpertise && expertiseItems.length > 0) {
          const avgLength =
            expertiseItems.reduce((sum, item) => sum + item.length, 0) /
            expertiseItems.length;
          const numCols = avgLength < 30 ? 3 : 2;
          renderMultiColumnBullets(expertiseItems, numCols);
        }
      }

      // Get PDF as blob
      const pdfBlob = doc.output('blob');

      // Create a File object from the blob
      if (typeof File === 'function') {
        try {
          return new File([pdfBlob], filename, {
            type: 'application/pdf',
            lastModified: Date.now(),
          });
        } catch (_) {}
      }

      // Fallback: return blob with name property
      pdfBlob.name = filename;
      pdfBlob.lastModified = Date.now();
      return pdfBlob;
    } catch (error) {
      console.error('[Sidepanel] PDF creation failed:', error);
      // Fallback to text file
      return createTextFile(text, filename.replace('.pdf', '.txt'));
    }
  }

  async function syncRRAfterGeneration(
    kind,
    generatedContent,
    sourceCvText,
    backendUrl
  ) {
    try {
      console.log('='.repeat(60));
      console.log('[Sidepanel] ===== SYNC RR AFTER GENERATION =====');
      console.log('[Sidepanel] Document type:', kind);
      console.log('[Sidepanel] Backend URL provided:', backendUrl || 'NONE');
      console.log(
        '[Sidepanel] Existing resume URL:',
        generatedResumeUrl || 'NONE'
      );
      console.log(
        '[Sidepanel] Existing cover URL:',
        generatedCoverLetterUrl || 'NONE'
      );
      console.log('='.repeat(60));

      if (!window.RRIntegration?.ensureSession) {
        console.warn(
          '[Sidepanel] RRIntegration.ensureSession not available, skipping RR sync'
        );
        return;
      }

      const rrContext = await ensureRRSessionForCurrentJob();
      if (!rrContext) {
        console.warn(
          '[Sidepanel] ensureRRSessionForCurrentJob returned null, skipping RR sync'
        );
        return;
      }

      console.log('[Sidepanel] RR Session context:', {
        sessionId: rrContext.sessionId,
        jobId: rrContext.jobId,
      });

      // Step 1: ALWAYS upload the PDF to /v1/upload/extension-files
      // This ensures the RR backend has the file, even if our backend already returned a URL
      if (window.RRIntegration.uploadExtensionFiles) {
        console.log('[Sidepanel] Uploading PDF via /v1/upload/extension-files');

        const fileName =
          kind === 'resume'
            ? `generated-resume-${Date.now()}.pdf`
            : `generated-cover-letter-${Date.now()}.pdf`;
        const file = await createPdfBlob(
          generatedContent,
          fileName,
          kind === 'resume'
        );

        console.log(
          '[Sidepanel] Created PDF for upload:',
          fileName,
          'size:',
          file.size,
          'bytes',
          'type:',
          file.type
        );

        try {
          const uploadResult = await window.RRIntegration.uploadExtensionFiles({
            resumeFile: kind === 'resume' ? file : null,
            coverLetterFile: kind === 'cover' ? file : null,
          });

          console.log('[Sidepanel] Upload result:', uploadResult);

          // Store the uploaded URLs from RR backend (preferred over our backend URL)
          if (kind === 'resume' && uploadResult?.resume_url) {
            generatedResumeUrl = uploadResult.resume_url;
            console.log(
              '[Sidepanel] Updated generatedResumeUrl from RR upload:',
              generatedResumeUrl
            );
          } else if (kind === 'resume' && backendUrl) {
            // Fallback to backend URL if RR upload didn't return one
            generatedResumeUrl = backendUrl;
            console.log(
              '[Sidepanel] Using backend URL as fallback:',
              generatedResumeUrl
            );
          }
          if (kind === 'cover' && uploadResult?.cover_letter_url) {
            generatedCoverLetterUrl = uploadResult.cover_letter_url;
            console.log(
              '[Sidepanel] Updated generatedCoverLetterUrl from RR upload:',
              generatedCoverLetterUrl
            );
          } else if (kind === 'cover' && backendUrl) {
            // Fallback to backend URL if RR upload didn't return one
            generatedCoverLetterUrl = backendUrl;
            console.log(
              '[Sidepanel] Using backend URL as fallback:',
              generatedCoverLetterUrl
            );
          }
        } catch (uploadError) {
          console.error('[Sidepanel] File upload to RR failed:', uploadError);
          // Fallback to backend URL if upload fails
          if (backendUrl) {
            if (kind === 'resume') {
              generatedResumeUrl = backendUrl;
            } else {
              generatedCoverLetterUrl = backendUrl;
            }
            console.log(
              '[Sidepanel] Using backend URL as fallback after upload error:',
              backendUrl
            );
          }
        }
      } else if (backendUrl) {
        // Fallback: use backend URL if RR upload is not available
        console.log(
          '[Sidepanel] RR upload not available, using backend URL:',
          backendUrl
        );
        if (kind === 'resume') {
          generatedResumeUrl = backendUrl;
        } else {
          generatedCoverLetterUrl = backendUrl;
        }
      }

      // Step 3: Sync profile with both URLs
      const resume_url = generatedResumeUrl || '';
      const cover_letter_url = generatedCoverLetterUrl || '';

      console.log('='.repeat(60));
      console.log('[Sidepanel] ===== CALLING SYNC PROFILE =====');
      console.log('[Sidepanel] Final resume_url:', resume_url || 'EMPTY');
      console.log(
        '[Sidepanel] Final cover_letter_url:',
        cover_letter_url || 'EMPTY'
      );
      console.log('[Sidepanel] applied:', true);
      console.log('='.repeat(60));

      await syncRRProfileSnapshot({
        applied: true, // Mark as applied when generating documents
        cvText: kind === 'resume' ? generatedContent : sourceCvText,
        resume_url,
        cover_letter_url,
      });

      console.log('[Sidepanel] ===== SYNC COMPLETE =====');
    } catch (error) {
      console.error('[Sidepanel] ===== RR SYNC FAILED =====');
      console.error('[Sidepanel] Error:', error.message);
      console.error(error);
    }
  }

  async function generateDocument(kind) {
    const cvText = cvEl.value.trim();
    const jobDescriptionText = jdEl.value.trim();
    if (!cvText || !jobDescriptionText) {
      showDocumentPage(kind);
      if (kind === 'resume') {
        generatedCvEl.value =
          'Please provide both Resume/Assets and Job Description.';
      } else {
        generatedCoverEl.value =
          'Please provide both Resume/Assets and Job Description.';
      }
      return;
    }
    setLoading(
      true,
      kind === 'resume' ? 'Generating resume…' : 'Generating cover letter…'
    );
    try {
      if (CONFIG?.apiBaseUrl) {
        // Sanitize text to remove control characters that break JSON
        const sanitize = (text) => {
          return text
            .replace(/[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]/g, '') // Remove control chars except \n, \r, \t
            .replace(/\r\n/g, '\n') // Normalize line endings
            .replace(/\r/g, '\n');
        };

        const path =
          kind === 'resume' ? '/v1/generate/resume' : '/v1/generate/cover';
        const resp = await callBackend(path, {
          cvText: sanitize(cvText),
          jobDescriptionText: sanitize(jobDescriptionText),
          modelId: getSelectedModelId(),
        });
        if (!resp.ok) {
          // Don't show sign-in prompt for RR users - backend handles auth gracefully
          if (resp.status === 402 || resp.status === 429) {
            showLimitPrompt();
            throw new Error('Free trial used.');
          }
          // For any other error, just show the error message
          throw new Error(resp.error || 'Generation failed. Please try again.');
        }
        const text = resp.data?.text || '';
        // Clean AI-generated text: fix letter spacing, bold markdown, unicode issues
        const cleanedText = cleanAIGeneratedText(text);
        const resumeUrlFromBackend = resp.data?.resume_url;
        const coverUrlFromBackend = resp.data?.cover_letter_url;

        // Store the generated URLs globally for RR sync
        if (kind === 'resume' && resumeUrlFromBackend) {
          generatedResumeUrl = resumeUrlFromBackend;
          console.log(
            '[Sidepanel] Stored generated resume URL:',
            generatedResumeUrl
          );
        }
        if (kind === 'cover' && coverUrlFromBackend) {
          generatedCoverLetterUrl = coverUrlFromBackend;
          console.log(
            '[Sidepanel] Stored generated cover letter URL:',
            generatedCoverLetterUrl
          );
        }

        // Show the page and populate content
        showDocumentPage(kind);
        if (kind === 'resume') {
          generatedCvEl.value = cleanedText;
          if (resumeUrlFromBackend && resumeDirectLink) {
            resumeDirectLink.href = resumeUrlFromBackend;
            resumeDirectLink.target = '_blank';
            resumeDirectLink.download = '';
            resumeDirectLink.classList.remove('hidden');
          } else {
            updateDirectDownloadLink('resume', cleanedText);
          }
        } else {
          generatedCoverEl.value = cleanedText;
          if (coverUrlFromBackend && coverDirectLink) {
            coverDirectLink.href = coverUrlFromBackend;
            coverDirectLink.target = '_blank';
            coverDirectLink.download = '';
            coverDirectLink.classList.remove('hidden');
          } else {
            updateDirectDownloadLink('cover', cleanedText);
          }
        }
        // Log success atomically after generation completes
        await logGeneration(kind);
        await syncRRAfterGeneration(
          kind,
          cleanedText,
          cvText,
          kind === 'resume' ? resumeUrlFromBackend : coverUrlFromBackend
        );
      } else {
        const response = await chrome.runtime.sendMessage({
          type: kind === 'resume' ? 'generateResume' : 'generateCoverLetter',
          payload: {
            cvText,
            jobDescriptionText,
            modelId: getSelectedModelId(),
          },
        });
        if (!response || !response.ok) {
          const error = response?.error || 'Unknown error';
          showDocumentPage(kind);
          if (kind === 'resume') {
            generatedCvEl.value = `Error: ${error}`;
          } else {
            generatedCoverEl.value = `Error: ${error}`;
          }
          return;
        }
        // Clean AI-generated text: fix letter spacing, bold markdown, unicode issues
        const cleanedText = cleanAIGeneratedText(response.text || '');
        showDocumentPage(kind);
        if (kind === 'resume') {
          generatedCvEl.value = cleanedText;
          updateDirectDownloadLink('resume', cleanedText);
        } else {
          generatedCoverEl.value = cleanedText;
          updateDirectDownloadLink('cover', cleanedText);
        }
        // Log success for local generation path as well
        await logGeneration(kind);
        await syncRRAfterGeneration(kind, cleanedText, cvText);
      }
    } catch (error) {
      showDocumentPage(kind);
      const errorMsg = String(error);
      // Show the actual error message instead of generic "Please sign in"
      const displayMsg = errorMsg.replace('Error: ', '');
      if (kind === 'resume') {
        generatedCvEl.value =
          displayMsg || 'Generation failed. Please try again.';
      } else {
        generatedCoverEl.value =
          displayMsg || 'Generation failed. Please try again.';
      }
    } finally {
      setLoading(false);
    }
  }

  if (copyCvBtn)
    copyCvBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(generatedCvEl.value || '');
        copyCvBtn.textContent = 'Copied!';
        setTimeout(() => (copyCvBtn.textContent = 'Copy Resume'), 1200);
      } catch (_) {
        copyCvBtn.textContent = 'Error';
        setTimeout(() => (copyCvBtn.textContent = 'Copy Resume'), 1200);
      }
    });

  if (copyCoverBtn)
    copyCoverBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(generatedCoverEl.value || '');
        copyCoverBtn.textContent = 'Copied!';
        setTimeout(
          () => (copyCoverBtn.textContent = 'Copy Cover Letter'),
          1200
        );
      } catch (_) {
        copyCoverBtn.textContent = 'Error';
        setTimeout(
          () => (copyCoverBtn.textContent = 'Copy Cover Letter'),
          1200
        );
      }
    });

  function downloadBlobText(text, filename, mime) {
    try {
      const blob = new Blob([text], {
        type: mime || 'text/plain;charset=utf-8',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert('Export failed: ' + String(e));
    }
  }

  async function loadJsPdfCtor() {
    try {
      let ctor =
        (window.jspdf && window.jspdf.jsPDF) ||
        window.jsPDF ||
        window.jspPDF ||
        null;
      if (typeof ctor === 'function') {
        try {
          if (
            !window.jsPDF &&
            window.jspdf &&
            typeof window.jspdf.jsPDF === 'function'
          ) {
            window.jsPDF = window.jspdf.jsPDF;
          }
        } catch (_) {}
        return ctor;
      }
      const url = chrome.runtime.getURL('vendor/jspdf/jspdf.umd.min.js');
      await new Promise((resolve, reject) => {
        try {
          const s = document.createElement('script');
          s.src = url;
          s.onload = () => resolve();
          s.onerror = () => reject(new Error('Failed to load jsPDF script'));
          (document.head || document.documentElement).appendChild(s);
        } catch (e) {
          reject(e);
        }
      });
      ctor =
        (window.jspdf && window.jspdf.jsPDF) ||
        window.jsPDF ||
        window.jspPDF ||
        null;
      if (typeof ctor === 'function') {
        try {
          if (
            !window.jsPDF &&
            window.jspdf &&
            typeof window.jspdf.jsPDF === 'function'
          ) {
            window.jsPDF = window.jspdf.jsPDF;
          }
        } catch (_) {}
        return ctor;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  function updateDirectDownloadLink(kind, text) {
    if (!text) return;
    try {
      const blob = new Blob([text], {
        type: 'text/plain;charset=utf-8',
      });
      const url = URL.createObjectURL(blob);
      if (kind === 'resume') {
        if (resumeDownloadUrl) {
          try {
            URL.revokeObjectURL(resumeDownloadUrl);
          } catch (_) {}
        }
        resumeDownloadUrl = url;
        if (resumeDirectLink) {
          resumeDirectLink.href = url;
          resumeDirectLink.download = 'resume.txt';
          resumeDirectLink.classList.remove('hidden');
        }
      } else {
        if (coverDownloadUrl) {
          try {
            URL.revokeObjectURL(coverDownloadUrl);
          } catch (_) {}
        }
        coverDownloadUrl = url;
        if (coverDirectLink) {
          coverDirectLink.href = url;
          coverDirectLink.download = 'cover-letter.txt';
          coverDirectLink.classList.remove('hidden');
        }
      }
    } catch (e) {
      console.warn('[Downloads] Failed to create direct download link', e);
    }
  }

  async function openPrintPdf(text, title) {
    try {
      // Prefer jsPDF when available to avoid browser header/footer
      const JsPdfCtor = await loadJsPdfCtor();
      if (typeof JsPdfCtor === 'function') {
        const doc = new JsPdfCtor({ unit: 'pt', format: 'a4' });
        const canUse =
          !!doc &&
          typeof doc.text === 'function' &&
          typeof doc.save === 'function';
        if (canUse) {
          const isCoverLetter = title && /cover/i.test(title);
          const margin = 50; // Increased margin for better appearance
          const maxWidth = 595.28 - margin * 2; // A4 width in pt
          const pageHeight = 841.89;

          // CRITICAL: Reset character spacing to prevent letter spacing issues
          if (typeof doc.setCharSpace === 'function') {
            doc.setCharSpace(0);
          }

          // Helper to safely draw text without spacing issues
          const safeText = (str, x, yPos) => {
            // Reset char spacing before each draw
            if (typeof doc.setCharSpace === 'function') {
              doc.setCharSpace(0);
            }
            // Normalize the string to remove any hidden unicode spacing characters
            const cleanStr = String(str || '')
              .replace(/[\u200B-\u200D\uFEFF]/g, '') // Zero-width chars
              .replace(/\s+/g, ' ') // Normalize whitespace
              .trim();
            if (cleanStr) {
              doc.text(cleanStr, x, yPos);
            }
          };

          // Normalize and pre-clean lines: remove any textual horizontal rules and collapse extra blanks
          // Also fix AI-generated letter-spaced text like "S t r a t e g i c"
          const cleanedInput = fixLetterSpacedText(String(text || ''));
          const raw = cleanedInput.replace(/\r\n?/g, '\n');
          const rawLines = raw.split('\n');
          const lines = [];
          for (let i = 0; i < rawLines.length; i++) {
            let ln = (rawLines[i] || '').trimEnd();
            // Remove any hidden unicode spacing characters that could cause letter spacing
            ln = ln.replace(/[\u200B-\u200D\uFEFF]/g, '');
            // Fix any remaining letter-spaced words on this line
            ln = fixLetterSpacedText(ln);
            // Skip lines that are just underline/HR characters
            if (/^\s*[-_=\u2014]{3,}\s*$/.test(ln)) continue;
            // Collapse multiple empty lines into one
            if (ln.trim() === '') {
              if (lines.length && lines[lines.length - 1].trim() === '')
                continue;
              lines.push('');
            } else {
              lines.push(ln);
            }
          }
          let y = margin;

          // Helper to check if we need a new page
          const checkPageBreak = (requiredSpace) => {
            if (y + requiredSpace > pageHeight - margin) {
              doc.addPage();
              y = margin;
              return true;
            }
            return false;
          };

          // Helper to clean text and split it safely
          const safeSplit = (str, width) => {
            // Clean the string first
            const clean = String(str || '')
              .replace(/[\u200B-\u200D\uFEFF]/g, '') // Zero-width chars
              .replace(/\u00A0/g, ' ') // Non-breaking space to regular space
              .trim();
            if (!clean) return [];
            return doc.splitTextToSize(clean, width);
          };

          // Cover Letter formatting (business letter style)
          if (isCoverLetter) {
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(10);
            doc.setTextColor(0, 0, 0);

            for (let i = 0; i < lines.length; i++) {
              const line = lines[i];
              const trimmed = line.trim();

              if (!trimmed) {
                // Empty line - standard paragraph spacing
                y += 12;
                continue;
              }

              // Detect bullet points in cover letter
              const isBullet = /^[-•*]\s/.test(trimmed);

              if (isBullet) {
                // Consistent, straight bullets using text glyph and hanging indent
                checkPageBreak(14);
                const bulletText = trimmed.replace(/^[-•*]\s*/, '');
                const textX = margin + 12;
                const bulletX = margin + 2;
                const lineH = 12; // consistent line height
                const chunks = safeSplit(bulletText, maxWidth - 14);
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(10);
                // Draw bullet using text so baseline matches
                safeText('•', bulletX, y);
                for (let j = 0; j < chunks.length; j++) {
                  safeText(chunks[j], textX, y);
                  y += lineH;
                }
                // Minimal gap after bullet block
                y += 1;
                continue;
              }

              // Regular paragraph text
              checkPageBreak(14);
              const chunks = safeSplit(trimmed, maxWidth);
              for (const c of chunks) {
                checkPageBreak(12);
                safeText(c, margin, y);
                y += 12;
              }
              y += 1;
            }
          } else {
            // Resume formatting (compact, structured)
            // Parse header section (name and contact info on 1-2 lines)
            let headerLines = [];
            let contentStartIndex = 0;
            for (let i = 0; i < Math.min(10, lines.length); i++) {
              const trimmed = lines[i].trim();
              if (!trimmed) continue;
              // Stop at first section header
              if (
                /^(EXPERIENCE|EDUCATION|SKILLS|SUMMARY|OBJECTIVE|PROJECTS|CERTIFICATIONS|AWARDS|PROFILE|TECHNICAL)/i.test(
                  trimmed
                )
              ) {
                contentStartIndex = i;
                break;
              }
              headerLines.push(trimmed);
              if (headerLines.length >= 5) {
                contentStartIndex = i + 1;
                break;
              }
            }

            // Render professional multi-line header
            if (headerLines.length > 0) {
              // First line is name (bold, larger, centered)
              doc.setFont('helvetica', 'bold');
              doc.setFontSize(14);
              doc.setTextColor(0, 0, 0);
              const nameText = headerLines[0]
                .trim()
                .replace(/[\u200B-\u200D\uFEFF\u00A0]/g, ' ')
                .replace(/\s+/g, ' ');
              // Center the name
              const nameWidth = doc.getTextWidth(nameText);
              const nameX = margin + (maxWidth - nameWidth) / 2;
              safeText(nameText, nameX, y);
              y += 16;

              // Filter out empty lines and lines that are just link labels without URLs
              const contactLines = headerLines.slice(1).filter((line) => {
                const trimmed = line.trim();
                // Skip empty lines
                if (!trimmed) return false;
                // Skip lines that are just labels without URLs (e.g., "GitHub | LeetCode")
                // A valid link line should contain actual URLs or @ for email
                const hasUrl =
                  /\.(com|org|net|io|dev|co|me|us|edu|gov|info)/.test(trimmed);
                const hasEmail = /@/.test(trimmed);
                const hasPhone = /\d{3}[-.\s]?\d{3}[-.\s]?\d{4}/.test(trimmed);
                const isLocation = /^[A-Z][a-z]+.*,\s*[A-Z]{2}/.test(trimmed); // City, ST format
                // If line contains pipe separators, check each part
                if (trimmed.includes('|')) {
                  const parts = trimmed
                    .split('|')
                    .map((p) => p.trim())
                    .filter((p) => {
                      // Keep parts that have actual content (URLs, emails, phones)
                      const partHasUrl =
                        /\.(com|org|net|io|dev|co|me|us|edu|gov|info)/.test(p);
                      const partHasEmail = /@/.test(p);
                      const partHasPhone = /\d{3}[-.\s]?\d{3}[-.\s]?\d{4}/.test(
                        p
                      );
                      // Skip parts that are just labels like "GitHub" or "LeetCode" without URLs
                      const isJustLabel =
                        /^(GitHub|LeetCode|Portfolio|LinkedIn|Website|Blog)$/i.test(
                          p.replace(/[:\s]/g, '')
                        );
                      return (
                        (partHasUrl || partHasEmail || partHasPhone) &&
                        !isJustLabel
                      );
                    });
                  return parts.length > 0;
                }
                return hasUrl || hasEmail || hasPhone || isLocation;
              });

              // Render each contact line centered
              if (contactLines.length > 0) {
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(9);
                doc.setTextColor(60, 60, 60); // Slightly gray for contact info

                for (const contactLine of contactLines) {
                  // Clean up the line - remove empty pipe sections
                  let cleanLine = contactLine
                    .split('|')
                    .map((p) => p.trim())
                    .filter((p) => {
                      // Filter out empty parts and label-only parts
                      if (!p) return false;
                      const isJustLabel =
                        /^(GitHub|LeetCode|Portfolio|LinkedIn|Website|Blog)[:\s]*$/i.test(
                          p
                        );
                      return !isJustLabel;
                    })
                    .join(' | ');

                  if (cleanLine) {
                    const contactChunks = safeSplit(cleanLine, maxWidth);
                    for (const chunk of contactChunks) {
                      // Center the contact info
                      const chunkWidth = doc.getTextWidth(chunk);
                      const chunkX = margin + (maxWidth - chunkWidth) / 2;
                      safeText(chunk, chunkX, y);
                      y += 11;
                    }
                  }
                }
              }
              y += 6; // Space after header

              // Add a subtle separator line
              doc.setDrawColor(200, 200, 200);
              doc.setLineWidth(0.3);
              doc.line(margin, y, margin + maxWidth, y);
              y += 8;
            }

            // Helper: render skills/expertise in a proper multi-column grid
            const renderSkillsInColumns = (skillItems, numCols = 2) => {
              if (!skillItems || skillItems.length === 0) return;
              doc.setFont('helvetica', 'normal');
              doc.setFontSize(9.5);
              doc.setTextColor(0, 0, 0);

              const colWidth = Math.floor(maxWidth / numCols);
              const textIndent = 20;
              const lineHeight = 11;
              const itemSpacing = 2; // Spacing between individual skills

              // Split items into columns (distribute evenly)
              const itemsPerCol = Math.ceil(skillItems.length / numCols);
              const columns = [];
              for (let col = 0; col < numCols; col++) {
                const start = col * itemsPerCol;
                const end = Math.min(start + itemsPerCol, skillItems.length);
                columns.push(skillItems.slice(start, end));
              }

              // Track Y position for each column independently
              const columnYPositions = new Array(numCols).fill(y);

              // Find the column with the most items to determine when to stop
              const maxItems = Math.max(...columns.map((col) => col.length));

              // Render each item in each column independently
              for (let itemIdx = 0; itemIdx < maxItems; itemIdx++) {
                for (let col = 0; col < numCols; col++) {
                  if (itemIdx >= columns[col].length) continue;

                  const skill = columns[col][itemIdx].trim();
                  if (!skill) continue;

                  const colStartX = margin + col * colWidth;
                  const bulletX = colStartX + 2;
                  const textX = colStartX + textIndent;
                  const availableWidth = colWidth - textIndent - 8;

                  // Calculate height needed for this skill
                  const skillChunks = safeSplit(skill, availableWidth);
                  const itemHeight =
                    skillChunks.length * lineHeight + itemSpacing;

                  // Check page break for this specific column item
                  const currentY = columnYPositions[col];
                  if (currentY + itemHeight > pageHeight - margin) {
                    // Would overflow page - move to next page
                    doc.addPage();
                    columnYPositions[col] = margin;
                  }

                  // Draw bullet
                  safeText('•', bulletX, columnYPositions[col]);

                  // Draw skill text (wrap to multiple lines if needed)
                  for (let j = 0; j < skillChunks.length; j++) {
                    safeText(
                      skillChunks[j],
                      textX,
                      columnYPositions[col] + j * lineHeight
                    );
                  }

                  // Move this column's Y position down
                  columnYPositions[col] += itemHeight;
                }
              }

              // Set Y to the maximum of all column positions
              y = Math.max(...columnYPositions) + 4;
            };

            // First pass: identify EXPERTISE/SKILLS sections and collect their bullets
            let currentSection = '';
            let skillsSectionStart = -1;
            let skillsSectionEnd = -1;
            const skillSectionHeaders =
              /^(SKILLS|EXPERTISE|TECHNICAL|COMPETENCIES|TECHNICAL SKILLS|CORE COMPETENCIES|KEY SKILLS)$/i;

            // Scan to find skills section boundaries
            for (let i = contentStartIndex; i < lines.length; i++) {
              const trimmed = lines[i].trim();
              if (
                /^(PROFESSIONAL EXPERIENCE|EXPERIENCE|EDUCATION|SUMMARY|OBJECTIVE|PROJECTS|CERTIFICATIONS|AWARDS|RELEVANT PROJECTS|RELEVANT ACCOMPLISHMENTS|INDUSTRY TECHNOLOGY|INDUSTRY INFORMATION|AWARDS & VOLUNTEERISM|STEM MENTOR)$/i.test(
                  trimmed
                )
              ) {
                if (skillsSectionStart >= 0 && skillsSectionEnd < 0) {
                  skillsSectionEnd = i;
                }
                currentSection = trimmed.toUpperCase();
              } else if (skillSectionHeaders.test(trimmed)) {
                skillsSectionStart = i;
                skillsSectionEnd = -1;
                currentSection = 'SKILLS';
              }
            }
            // If skills section runs to end of document
            if (skillsSectionStart >= 0 && skillsSectionEnd < 0) {
              skillsSectionEnd = lines.length;
            }

            // Collect skill items from the skills section
            let collectedSkills = [];
            if (skillsSectionStart >= 0) {
              for (let i = skillsSectionStart + 1; i < skillsSectionEnd; i++) {
                const trimmed = lines[i].trim();
                if (!trimmed) continue;
                // Handle lines with multiple inline bullets: "• Skill1    • Skill2    • Skill3"
                if (trimmed.includes('•')) {
                  const parts = trimmed
                    .split(/\s*•\s*/)
                    .map((s) => s.trim())
                    .filter(Boolean);
                  collectedSkills.push(...parts);
                } else if (/^[-*]\s/.test(trimmed)) {
                  // Handle dash or asterisk bullets
                  collectedSkills.push(trimmed.replace(/^[-*]\s*/, '').trim());
                } else if (trimmed.includes(',')) {
                  // Handle comma-separated skills on one line
                  const parts = trimmed
                    .split(',')
                    .map((s) => s.trim())
                    .filter(Boolean);
                  collectedSkills.push(...parts);
                } else {
                  // Single skill per line
                  collectedSkills.push(trimmed);
                }
              }
            }

            // Process main content

            let expertiseItems = [];
            let inExpertiseSection = false;

            // Helper function to render expertise items in two columns
            const renderExpertiseTwoColumns = () => {
              if (expertiseItems.length === 0) return;

              doc.setFont('helvetica', 'normal');
              doc.setFontSize(9.5);
              const lineH = 12; // consistent spacing for resume bullets

              // Calculate column widths and positions
              const columnGap = 20;
              const columnWidth = (maxWidth - columnGap) / 2;
              const leftColumnX = margin;
              const rightColumnX = margin + columnWidth + columnGap;
              const bulletX = 2; // Offset from column start
              const textX = 12; // Offset from column start for text

              // Split items into two columns
              const midPoint = Math.ceil(expertiseItems.length / 2);
              const leftColumn = expertiseItems.slice(0, midPoint);
              const rightColumn = expertiseItems.slice(midPoint);

              // Find the maximum number of rows needed
              const maxRows = Math.max(leftColumn.length, rightColumn.length);

              // Render both columns row by row with perfect vertical alignment
              for (let row = 0; row < maxRows; row++) {
                // Calculate how many lines each item will take
                let leftLines = 1;
                let rightLines = 1;

                if (row < leftColumn.length) {
                  const leftItem = leftColumn[row];
                  const leftChunks = safeSplit(leftItem, columnWidth - textX);
                  leftLines = leftChunks.length || 1;
                }

                if (row < rightColumn.length) {
                  const rightItem = rightColumn[row];
                  const rightChunks = safeSplit(rightItem, columnWidth - textX);
                  rightLines = rightChunks.length || 1;
                }

                // Maximum lines needed for this row
                const maxRowHeight = Math.max(leftLines, rightLines) * lineH;

                // Check page break for the entire row (this may reset y if new page)
                checkPageBreak(maxRowHeight);

                // Get row start position after potential page break
                const rowStartY = y;

                // Render left column item
                if (row < leftColumn.length) {
                  const item = leftColumn[row];
                  const chunks = safeSplit(item, columnWidth - textX);
                  // Draw bullet at the start
                  safeText('•', leftColumnX + bulletX, rowStartY);
                  // Draw text lines
                  for (let j = 0; j < chunks.length; j++) {
                    safeText(
                      chunks[j],
                      leftColumnX + textX,
                      rowStartY + j * lineH
                    );
                  }
                }

                // Render right column item
                if (row < rightColumn.length) {
                  const item = rightColumn[row];
                  const chunks = safeSplit(item, columnWidth - textX);
                  // Draw bullet at the start (vertically aligned with left)
                  safeText('•', rightColumnX + bulletX, rowStartY);
                  // Draw text lines
                  for (let j = 0; j < chunks.length; j++) {
                    safeText(
                      chunks[j],
                      rightColumnX + textX,
                      rowStartY + j * lineH
                    );
                  }
                }

                // Move to next row based on maximum height
                y = rowStartY + maxRowHeight;
              }

              // Clear expertise items after rendering
              expertiseItems = [];
            };

            for (let i = contentStartIndex; i < lines.length; i++) {
              const line = lines[i];
              const trimmed = line.trim();

              // Detect section headers (ONLY standalone section titles, not job titles or other content)
              // Must match EXACT section header keywords and be relatively short
              const isHeader =
                /^(PROFESSIONAL EXPERIENCE|EXPERIENCE|EDUCATION|SKILLS|SUMMARY|OBJECTIVE|PROJECTS|CERTIFICATIONS|AWARDS|TECHNICAL|COMPETENCIES|EXPERTISE|RELEVANT PROJECTS|RELEVANT ACCOMPLISHMENTS|INDUSTRY TECHNOLOGY|INDUSTRY INFORMATION|AWARDS & VOLUNTEERISM|STEM MENTOR|TECHNICAL SKILLS|CORE COMPETENCIES|KEY SKILLS)$/i.test(
                  trimmed
                );

              // Check if this is a skills section header
              const isSkillsSectionHeader = skillSectionHeaders.test(trimmed);

              // Detect bullet points
              const isBullet = /^[-•*]\s/.test(trimmed);

              // Detect company/date header lines within EXPERIENCE section to add extra spacing
              const monthRe =
                /(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t|tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)/i;
              const companyDateRe = new RegExp(
                monthRe.source +
                  '\\s+\\d{4}\\s*[–—-]\\s*(Present|' +
                  monthRe.source +
                  '\\s+\\d{4})',
                'i'
              );
              const isCompanyDateLine = companyDateRe.test(trimmed);

              if (!trimmed) {
                // Empty line - minimal spacing (but continue collecting in expertise section)
                if (!inExpertiseSection) {
                  y += 4;
                }
                continue;
              }

              // Format section headers (bold, no underline)
              if (isHeader) {
                // If we were in expertise section, render collected items first
                if (inExpertiseSection) {
                  renderExpertiseTwoColumns();
                  inExpertiseSection = false;
                }

                // Check if this is the EXPERTISE section
                const isExpertiseHeader = /^EXPERTISE$/i.test(trimmed);
                inExpertiseSection = isExpertiseHeader;
                currentSection = trimmed.toUpperCase();

                // Ensure header + spacing fits on page
                const headerSpace = 20;
                if (checkPageBreak(headerSpace)) {
                  // New page started, minimal space before header
                  y += 4;
                } else {
                  y += 10; // Space before header on same page
                }
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(10);
                doc.setTextColor(0, 0, 0);
                const headerChunks = safeSplit(trimmed.toUpperCase(), maxWidth);
                for (const chunk of headerChunks) {
                  safeText(chunk, margin, y);
                  y += 12;
                }
                // No horizontal rule under headers; keep clean spacing
                y += 4; // Minimal space after header

                // If this is a skills section header, render collected skills in columns
                if (isSkillsSectionHeader && collectedSkills.length > 0) {
                  // Determine number of columns based on skill count and length
                  const avgLen =
                    collectedSkills.reduce((sum, s) => sum + s.length, 0) /
                    collectedSkills.length;
                  const numCols =
                    avgLen > 25 ? 2 : collectedSkills.length <= 6 ? 2 : 3;
                  renderSkillsInColumns(collectedSkills, numCols);
                  // Skip ahead past the skills section content (already rendered)
                  i = skillsSectionEnd - 1;
                }
                continue;
              }

              // Skip lines that are part of skills section (already rendered via columns)
              if (
                skillsSectionStart >= 0 &&
                i > skillsSectionStart &&
                i < skillsSectionEnd
              ) {
                continue;
              }

              // Add extra spacing before company/date header lines so entries are visually separated
              if (isCompanyDateLine) {
                // If we were in expertise section, render collected items first
                if (inExpertiseSection) {
                  renderExpertiseTwoColumns();
                  inExpertiseSection = false;
                }

                // Ensure a comfortable gap before each new company/date line
                y += 6;
                checkPageBreak(12);
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(9.5);
                const chunks = safeSplit(trimmed, maxWidth);
                for (const c of chunks) {
                  safeText(c, margin, y);
                  y += 12;
                }
                continue;
              }

              // Format bullet points (normal text, not bold)
              if (isBullet) {
                let bulletText = trimmed.replace(/^[-•*]\s*/, '');

                // If in expertise section, collect items instead of rendering
                if (inExpertiseSection) {
                  // Support lines that contain multiple inline bullets (split into separate items)
                  const items = bulletText.split(/\s•\s+/g).filter(Boolean);
                  expertiseItems.push(...items.map((item) => item.trim()));
                  continue;
                }

                // Regular bullet rendering for other sections
                checkPageBreak(12);
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(9.5);
                const textX = margin + 12;
                const bulletX = margin + 2;
                const lineH = 12; // consistent spacing for resume bullets
                // Support lines that contain multiple inline bullets (split into separate items)
                // But NOT for skills section (handled above)
                const items = bulletText.split(/\s{2,}•\s*/g).filter(Boolean);
                for (let it = 0; it < items.length; it++) {
                  const item = items[it].trim();
                  const chunks = safeSplit(item, maxWidth - 14);
                  // Use a text bullet to align baselines
                  safeText('•', bulletX, y);
                  for (let j = 0; j < chunks.length; j++) {
                    safeText(chunks[j], textX, y);
                    y += lineH;
                  }
                  // Small spacing between items if we split multiple bullets
                  if (it < items.length - 1) y += 1;
                }
                // small gap after a bullet block
                y += 1;
                continue;
              }

              // Regular text (all normal weight - no bold)
              // If we were in expertise section, render collected items first
              if (inExpertiseSection) {
                renderExpertiseTwoColumns();
                inExpertiseSection = false;
              }

              checkPageBreak(12);
              doc.setFont('helvetica', 'normal');
              doc.setFontSize(9);

              const chunks = safeSplit(trimmed, maxWidth);
              for (const c of chunks) {
                checkPageBreak(11);
                safeText(c, margin, y);
                y += 11;
              }
              y += 0.5; // Minimal gap between paragraphs
            }

            // Render any remaining expertise items at the end
            if (inExpertiseSection && expertiseItems.length > 0) {
              renderExpertiseTwoColumns();
            }
          }

          doc.save(((title || 'document') + '.pdf').toLowerCase());
          return;
        }
      }
      // If jsPDF is missing, prevent browser print (which adds headers/footers)
      alert('PDF export requires jsPDF and is unavailable right now.');
      return;
    } catch (e) {
      alert('PDF export failed: ' + String(e));
    }
  }

  // async function openPrintPdf(text, title) {
  //   try {
  //     // Prefer jsPDF when available to avoid browser header/footer
  //     const JsPdfCtor = await loadJsPdfCtor();
  //     if (typeof JsPdfCtor === 'function') {
  //       const doc = new JsPdfCtor({ unit: 'pt', format: 'a4' });
  //       const canUse =
  //         !!doc &&
  //         typeof doc.text === 'function' &&
  //         typeof doc.save === 'function';
  //       if (canUse) {
  //         const isCoverLetter = title && /cover/i.test(title);
  //         const margin = 54; // Professional 0.75" margin
  //         const pageWidth = 595.28;
  //         const maxWidth = pageWidth - margin * 2; // A4 width in pt
  //         const pageHeight = 841.89;

  //         // Professional color scheme
  //         const primaryColor = [0, 0, 0]; // Black for main text
  //         const accentColor = [60, 60, 60]; // Dark gray for secondary
  //         const lineColor = [180, 180, 180]; // Light gray for dividers

  //         // Normalize and pre-clean lines: remove any textual horizontal rules and collapse extra blanks
  //         const raw = String(text || '').replace(/\r\n?/g, '\n');
  //         const rawLines = raw.split('\n');
  //         const lines = [];
  //         for (let i = 0; i < rawLines.length; i++) {
  //           const ln = (rawLines[i] || '').trimEnd();
  //           // Skip lines that are just underline/HR characters
  //           if (/^\s*[-_=\u2014]{3,}\s*$/.test(ln)) continue;
  //           // Collapse multiple empty lines into one
  //           if (ln.trim() === '') {
  //             if (lines.length && lines[lines.length - 1].trim() === '')
  //               continue;
  //             lines.push('');
  //           } else {
  //             lines.push(ln);
  //           }
  //         }
  //         let y = margin;

  //         // Helper to check if we need a new page
  //         const checkPageBreak = (requiredSpace) => {
  //           if (y + requiredSpace > pageHeight - margin) {
  //             doc.addPage();
  //             y = margin;
  //             return true;
  //           }
  //           return false;
  //         };

  //         // Cover Letter formatting (professional business letter style)
  //         if (isCoverLetter) {
  //           doc.setFont('times', 'normal'); // Times for formal letters
  //           doc.setFontSize(11);
  //           doc.setTextColor(...primaryColor);

  //           let lineIndex = 0;
  //           let isFirstParagraph = true;
  //           let isSignatureSection = false;

  //           for (let i = 0; i < lines.length; i++) {
  //             const line = lines[i];
  //             const trimmed = line.trim();

  //             // Detect signature section (starts with "Sincerely," "Best regards," etc.)
  //             if (
  //               /^(sincerely|best regards|regards|thank you|yours truly|respectfully)/i.test(
  //                 trimmed
  //               )
  //             ) {
  //               isSignatureSection = true;
  //               y += 16; // Extra space before signature
  //             }

  //             if (!trimmed) {
  //               // Empty line - paragraph spacing
  //               y += isSignatureSection ? 8 : 14;
  //               isFirstParagraph = false;
  //               continue;
  //             }

  //             // Detect bullet points in cover letter
  //             const isBullet = /^[-•*]\s/.test(trimmed);

  //             if (isBullet) {
  //               // Professional bullet formatting
  //               checkPageBreak(16);
  //               const bulletText = trimmed.replace(/^[-•*]\s*/, '');
  //               const textX = margin + 18;
  //               const bulletX = margin + 6;
  //               const lineH = 14; // Better line spacing
  //               const chunks = doc.splitTextToSize(bulletText, maxWidth - 20);
  //               doc.setFont('times', 'normal');
  //               doc.setFontSize(11);
  //               // Draw bullet
  //               doc.text('•', bulletX, y);
  //               for (let j = 0; j < chunks.length; j++) {
  //                 doc.text(chunks[j], textX, y);
  //                 y += lineH;
  //               }
  //               y += 3; // Gap after bullet
  //               continue;
  //             }

  //             // Detect date line (usually near top)
  //             if (
  //               lineIndex < 5 &&
  //               /\d{1,2},?\s+\d{4}|[A-Z][a-z]+\s+\d{1,2},?\s+\d{4}/.test(
  //                 trimmed
  //               )
  //             ) {
  //               checkPageBreak(16);
  //               doc.setFont('times', 'normal');
  //               doc.setFontSize(11);
  //               doc.text(trimmed, margin, y);
  //               y += 20; // Extra space after date
  //               lineIndex++;
  //               continue;
  //             }

  //             // Detect salutation (Dear...)
  //             if (/^(Dear|To whom)/i.test(trimmed)) {
  //               y += 8; // Space before salutation
  //               checkPageBreak(16);
  //               doc.setFont('times', 'normal');
  //               doc.setFontSize(11);
  //               doc.text(trimmed, margin, y);
  //               y += 20; // Extra space after salutation
  //               lineIndex++;
  //               continue;
  //             }

  //             // Regular paragraph text
  //             checkPageBreak(16);
  //             doc.setFont('times', isSignatureSection ? 'italic' : 'normal');
  //             doc.setFontSize(11);
  //             const chunks = doc.splitTextToSize(trimmed, maxWidth);
  //             for (const c of chunks) {
  //               checkPageBreak(14);
  //               doc.text(c, margin, y);
  //               y += 14;
  //             }
  //             y += 2;
  //             lineIndex++;
  //           }
  //         } else {
  //           // Resume formatting (compact, structured)
  //           // Parse header section (name and contact info on 1-2 lines)
  //           let headerLines = [];
  //           let contentStartIndex = 0;
  //           for (let i = 0; i < Math.min(10, lines.length); i++) {
  //             const trimmed = lines[i].trim();
  //             if (!trimmed) continue;
  //             // Stop at first section header
  //             if (
  //               /^(EXPERIENCE|EDUCATION|SKILLS|SUMMARY|OBJECTIVE|PROJECTS|CERTIFICATIONS|AWARDS|PROFILE|TECHNICAL)/i.test(
  //                 trimmed
  //               )
  //             ) {
  //               contentStartIndex = i;
  //               break;
  //             }
  //             headerLines.push(trimmed);
  //             if (headerLines.length >= 5) {
  //               contentStartIndex = i + 1;
  //               break;
  //             }
  //           }

  //           // Render professional header (name centered or left-aligned, contact info on separate line)
  //           if (headerLines.length > 0) {
  //             // First line is name (bold, larger, centered)
  //             doc.setFont('helvetica', 'bold');
  //             doc.setFontSize(16); // Larger, more prominent name
  //             doc.setTextColor(...primaryColor);

  //             const nameLine = headerLines[0].toUpperCase(); // Name in uppercase for professionalism
  //             const nameWidth = doc.getTextWidth(nameLine);
  //             const nameX =
  //               nameWidth <= maxWidth
  //                 ? margin + (maxWidth - nameWidth) / 2
  //                 : margin; // Center if fits

  //             const nameChunks = doc.splitTextToSize(nameLine, maxWidth);
  //             for (const chunk of nameChunks) {
  //               const chunkWidth = doc.getTextWidth(chunk);
  //               const centerX = margin + (maxWidth - chunkWidth) / 2;
  //               doc.text(chunk, centerX, y);
  //               y += 18;
  //             }

  //             // Contact info on next line(s), smaller and centered
  //             const contactInfo = headerLines.slice(1).join('  |  '); // More spacious separator
  //             if (contactInfo) {
  //               doc.setFont('helvetica', 'normal');
  //               doc.setFontSize(9);
  //               doc.setTextColor(...accentColor);
  //               const contactChunks = doc.splitTextToSize(
  //                 contactInfo,
  //                 maxWidth
  //               );
  //               for (const chunk of contactChunks) {
  //                 const chunkWidth = doc.getTextWidth(chunk);
  //                 const centerX = margin + (maxWidth - chunkWidth) / 2;
  //                 doc.text(chunk, centerX, y);
  //                 y += 11;
  //               }
  //             }

  //             // Add a subtle divider line after header
  //             y += 6;
  //             doc.setDrawColor(...lineColor);
  //             doc.setLineWidth(0.5);
  //             doc.line(margin, y, margin + maxWidth, y);
  //             y += 12; // Space after header divider
  //           }

  //           // Helper function to render expertise/skills in multi-column layout with professional alignment
  //           const renderMultiColumnBullets = (items, numColumns = 2) => {
  //             if (!items || items.length === 0) return;

  //             doc.setFont('helvetica', 'normal');
  //             doc.setFontSize(9.5);
  //             doc.setTextColor(...primaryColor);

  //             const columnGap = 15; // Gap between columns
  //             const columnWidth =
  //               (maxWidth - (numColumns - 1) * columnGap) / numColumns;
  //             const bulletX = 0;
  //             const textX = 10;
  //             const textAvailableWidth = columnWidth - textX - 2;
  //             const lineHeight = 11;

  //             // Fill row by row (left to right) to handle variable heights gracefully
  //             // Group items into rows
  //             const rows = [];
  //             for (let i = 0; i < items.length; i += numColumns) {
  //               rows.push(items.slice(i, i + numColumns));
  //             }

  //             for (let r = 0; r < rows.length; r++) {
  //               const rowItems = rows[r];
  //               let maxRowHeight = 0;
  //               const rowContent = []; // { lines, height }

  //               // First pass: calculate heights and prepare content for this row
  //               for (let c = 0; c < rowItems.length; c++) {
  //                 const item = rowItems[c].trim();
  //                 if (!item) {
  //                   rowContent.push({ lines: [], height: 0 });
  //                   continue;
  //                 }

  //                 // Use splitTextToSize with proper options to avoid character spacing issues
  //                 const lines = doc.splitTextToSize(item, textAvailableWidth, {
  //                   fontSize: 9.5,
  //                 });
  //                 const height = lines.length * lineHeight;

  //                 if (height > maxRowHeight) maxRowHeight = height;
  //                 rowContent.push({ lines, height });
  //               }

  //               maxRowHeight = Math.max(maxRowHeight, 14); // Minimum row height

  //               // Check page break for the whole row
  //               checkPageBreak(maxRowHeight + 2);

  //               // Render the row
  //               const rowStartY = y;
  //               for (let c = 0; c < rowContent.length; c++) {
  //                 const content = rowContent[c];
  //                 if (content.lines.length === 0) continue;

  //                 const colStartX = margin + c * (columnWidth + columnGap);

  //                 // Draw bullet
  //                 doc.setFontSize(8);
  //                 doc.text('•', colStartX + bulletX, rowStartY);
  //                 doc.setFontSize(9.5);

  //                 // Draw text lines with proper alignment
  //                 let lineY = rowStartY;
  //                 for (const line of content.lines) {
  //                   // Ensure text doesn't exceed column boundary
  //                   const trimmedLine = String(line).trim();
  //                   if (trimmedLine) {
  //                     doc.text(trimmedLine, colStartX + textX, lineY, {
  //                       maxWidth: textAvailableWidth,
  //                       align: 'left',
  //                     });
  //                   }
  //                   lineY += lineHeight;
  //                 }
  //               }

  //               y += maxRowHeight + 6; // Move down for next row
  //             }

  //             y += 4; // Final spacing after block
  //           };

  //           // Track current section for special formatting
  //           let currentSection = '';
  //           let expertiseItems = [];
  //           let collectingExpertise = false;

  //           // Process main content
  //           for (let i = contentStartIndex; i < lines.length; i++) {
  //             const line = lines[i];
  //             const trimmed = line.trim();

  //             // Detect section headers (ONLY standalone section titles, not job titles or other content)
  //             // Must match EXACT section header keywords and be relatively short
  //             const isHeader =
  //               /^(PROFESSIONAL EXPERIENCE|EXPERIENCE|EDUCATION|SKILLS|SUMMARY|OBJECTIVE|PROJECTS|CERTIFICATIONS|AWARDS|TECHNICAL|COMPETENCIES|EXPERTISE|RELEVANT PROJECTS|RELEVANT ACCOMPLISHMENTS|INDUSTRY TECHNOLOGY|INDUSTRY INFORMATION|AWARDS & VOLUNTEERISM|STEM MENTOR)$/i.test(
  //                 trimmed
  //               );

  //             // Check if this is an EXPERTISE-type section
  //             const isExpertiseHeader =
  //               /^(EXPERTISE|SKILLS|COMPETENCIES|TECHNICAL)$/i.test(trimmed);

  //             // Detect bullet points
  //             const isBullet = /^[-•*]\s/.test(trimmed);

  //             // Detect company/date header lines within EXPERIENCE section to add extra spacing
  //             const monthRe =
  //               /(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t|tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)/i;
  //             const companyDateRe = new RegExp(
  //               monthRe.source +
  //                 '\\s+\\d{4}\\s*[–—-]\\s*(Present|' +
  //                 monthRe.source +
  //                 '\\s+\\d{4})',
  //               'i'
  //             );
  //             const isCompanyDateLine = companyDateRe.test(trimmed);

  //             // If we hit a new header and were collecting expertise, render the collected items
  //             if (
  //               isHeader &&
  //               collectingExpertise &&
  //               expertiseItems.length > 0
  //             ) {
  //               // Determine number of columns based on item count and length
  //               const avgLength =
  //                 expertiseItems.reduce((sum, item) => sum + item.length, 0) /
  //                 expertiseItems.length;
  //               const numCols = avgLength < 30 ? 3 : 2;
  //               renderMultiColumnBullets(expertiseItems, numCols);
  //               expertiseItems = [];
  //               collectingExpertise = false;
  //             }

  //             if (!trimmed) {
  //               // Empty line - minimal spacing
  //               // If collecting expertise, render what we have so far
  //               if (collectingExpertise && expertiseItems.length > 0) {
  //                 const avgLength =
  //                   expertiseItems.reduce((sum, item) => sum + item.length, 0) /
  //                   expertiseItems.length;
  //                 const numCols = avgLength < 30 ? 3 : 2;
  //                 renderMultiColumnBullets(expertiseItems, numCols);
  //                 expertiseItems = [];
  //                 collectingExpertise = false;
  //               }
  //               y += 4;
  //               continue;
  //             }

  //             // Format section headers (bold with subtle underline)
  //             if (isHeader) {
  //               // Ensure header + spacing fits on page
  //               const headerSpace = 28;
  //               if (checkPageBreak(headerSpace)) {
  //                 // New page started, minimal space before header
  //                 y += 6;
  //               } else {
  //                 y += 14; // Space before header on same page
  //               }
  //               doc.setFont('helvetica', 'bold');
  //               doc.setFontSize(11); // Slightly larger section headers
  //               doc.setTextColor(...primaryColor);
  //               const headerText = trimmed.toUpperCase();
  //               const headerChunks = doc.splitTextToSize(headerText, maxWidth);
  //               for (const chunk of headerChunks) {
  //                 doc.text(chunk, margin, y);
  //                 y += 14;
  //               }

  //               // Add subtle underline under section header
  //               doc.setDrawColor(...lineColor);
  //               doc.setLineWidth(0.5);
  //               doc.line(margin, y - 2, margin + maxWidth, y - 2);
  //               y += 8; // Space after header line

  //               // Track section and start collecting if expertise-type
  //               currentSection = trimmed.toUpperCase();
  //               if (isExpertiseHeader) {
  //                 collectingExpertise = true;
  //                 expertiseItems = [];
  //               }
  //               continue;
  //             }

  //             // Add extra spacing before company/date header lines so entries are visually separated
  //             if (isCompanyDateLine) {
  //               // If we were collecting expertise, stop and render
  //               if (collectingExpertise && expertiseItems.length > 0) {
  //                 const avgLength =
  //                   expertiseItems.reduce((sum, item) => sum + item.length, 0) /
  //                   expertiseItems.length;
  //                 const numCols = avgLength < 30 ? 3 : 2;
  //                 renderMultiColumnBullets(expertiseItems, numCols);
  //                 expertiseItems = [];
  //                 collectingExpertise = false;
  //               }

  //               // Ensure a comfortable gap before each new company/date line
  //               y += 10;
  //               checkPageBreak(16);

  //               // Company/date lines should be bold and slightly larger
  //               doc.setFont('helvetica', 'bold');
  //               doc.setFontSize(10);
  //               doc.setTextColor(...primaryColor);

  //               const chunks = doc.splitTextToSize(trimmed, maxWidth);
  //               for (const c of chunks) {
  //                 doc.text(c, margin, y);
  //                 y += 13;
  //               }
  //               y += 2; // Small gap after company line
  //               continue;
  //             }

  //             // Format bullet points
  //             if (isBullet) {
  //               const bulletText = trimmed.replace(/^[-•*]\s*/, '').trim();

  //               // If in expertise section, collect for multi-column rendering
  //               if (collectingExpertise) {
  //                 // Check for inline bullets (multiple items on one line)
  //                 const inlineItems = bulletText
  //                   .split(/\s+•\s+/g)
  //                   .filter(Boolean);
  //                 expertiseItems.push(...inlineItems);
  //                 continue;
  //               }

  //               // Professional bullet formatting for experience sections
  //               checkPageBreak(14);
  //               doc.setFont('helvetica', 'normal');
  //               doc.setFontSize(9.5);
  //               doc.setTextColor(...primaryColor);
  //               const textX = margin + 14;
  //               const bulletX = margin + 4;
  //               const lineH = 13; // Slightly more spacing for readability

  //               // Support lines that contain multiple inline bullets (split into separate items)
  //               const items = bulletText.split(/\s•\s+/g).filter(Boolean);
  //               for (let it = 0; it < items.length; it++) {
  //                 const item = items[it].trim();
  //                 const chunks = doc.splitTextToSize(item, maxWidth - 16);
  //                 // Use a small bullet point
  //                 doc.setFontSize(7);
  //                 doc.text('•', bulletX, y - 1);
  //                 doc.setFontSize(9.5);
  //                 for (let j = 0; j < chunks.length; j++) {
  //                   doc.text(chunks[j], textX, y);
  //                   y += lineH;
  //                 }
  //                 // Small spacing between items if we split multiple bullets
  //                 if (it < items.length - 1) y += 2;
  //               }
  //               // Gap after bullet block
  //               y += 3;
  //               continue;
  //             }

  //             // Regular text (all normal weight - no bold)
  //             // If in expertise section and text looks like a skill item, collect it
  //             if (
  //               collectingExpertise &&
  //               trimmed.length < 50 &&
  //               !trimmed.includes(':')
  //             ) {
  //               expertiseItems.push(trimmed);
  //               continue;
  //             }

  //             // If we were collecting expertise but hit regular text, render and stop
  //             if (collectingExpertise && expertiseItems.length > 0) {
  //               const avgLength =
  //                 expertiseItems.reduce((sum, item) => sum + item.length, 0) /
  //                 expertiseItems.length;
  //               const numCols = avgLength < 30 ? 3 : 2;
  //               renderMultiColumnBullets(expertiseItems, numCols);
  //               expertiseItems = [];
  //               collectingExpertise = false;
  //             }

  //             checkPageBreak(14);
  //             doc.setFont('helvetica', 'normal');
  //             doc.setFontSize(9.5);
  //             doc.setTextColor(...primaryColor);

  //             const chunks = doc.splitTextToSize(trimmed, maxWidth);
  //             for (const c of chunks) {
  //               checkPageBreak(12);
  //               doc.text(c, margin, y);
  //               y += 12;
  //             }
  //             y += 2; // Small gap between paragraphs
  //           }

  //           // Render any remaining expertise items at end of document
  //           if (collectingExpertise && expertiseItems.length > 0) {
  //             const avgLength =
  //               expertiseItems.reduce((sum, item) => sum + item.length, 0) /
  //               expertiseItems.length;
  //             const numCols = avgLength < 30 ? 3 : 2;
  //             renderMultiColumnBullets(expertiseItems, numCols);
  //           }
  //         }

  //         doc.save(((title || 'document') + '.pdf').toLowerCase());
  //         return;
  //       }
  //     }
  //     // If jsPDF is missing, prevent browser print (which adds headers/footers)
  //     alert('PDF export requires jsPDF and is unavailable right now.');
  //     return;
  //   } catch (e) {
  //     alert('PDF export failed: ' + String(e));
  //   }
  // }

  function exportDoc(text, filename) {
    const html = `<!doctype html><html><head><meta charset="utf-8"></head><body><pre>${(
      text || ''
    )
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')}</pre></body></html>`;
    downloadBlobText(html, filename, 'application/msword');
  }

  if (copyAllBtn)
    copyAllBtn.addEventListener('click', async () => {
      try {
        const fieldRows = Array.from(
          resultsList.querySelectorAll('.field-row')
        );
        const fields = fieldRows.map((row) => {
          const name = row.querySelector('.field-name').textContent || '';
          const value = row.querySelector('.field-value').value || '';
          return { name, value };
        });
        const json = JSON.stringify({ fields }, null, 2);
        await navigator.clipboard.writeText(json);
        copyAllBtn.textContent = 'Copied!';
        setTimeout(() => (copyAllBtn.textContent = 'Copy All (JSON)'), 1200);
      } catch (_) {
        copyAllBtn.textContent = 'Error';
        setTimeout(() => (copyAllBtn.textContent = 'Copy All (JSON)'), 1200);
      }
    });

  // Form completion checking
  if (jdEl) jdEl.addEventListener('input', checkFormCompletion);
  if (formEl) formEl.addEventListener('input', checkFormCompletion);
  if (cvEl) cvEl.addEventListener('input', checkFormCompletion);

  // Generate button opens modal with safe loading guard
  if (analyzeBtn) {
    analyzeBtn.addEventListener('click', () => {
      try {
        setLoading(true, 'Preparing Smart Application…');
      } catch (_) {}
      setTimeout(() => {
        const generatorPage = $('generatorPage');
        const mainContainer = $('mainContainer');
        if (generatorPage) {
          generatorPage.classList.remove('hidden');
          if (mainContainer) mainContainer.classList.add('hidden');
          // Setup generator page UI components
          setupGeneratorAIModelSelector();
          setupGeneratorUserMenu();
        }
        try {
          setLoading(false);
        } catch (_) {}
      }, 400);
    });
  }

  if (clearBtn) clearBtn.addEventListener('click', clearInputs);
  if (scanJDBtn) scanJDBtn.addEventListener('click', scanJobDescription);
  if (scanFormBtn) scanFormBtn.addEventListener('click', scanApplicationForm);
  if (scanJDFastBtn)
    scanJDFastBtn.addEventListener('click', scanJobDescription);
  if (scanFormFastBtn)
    scanFormFastBtn.addEventListener('click', scanApplicationForm);
  if (assetFileInput) {
    console.log('Adding change listener to assetFileInput');
    assetFileInput.addEventListener('change', handleAssetUpload);
  } else {
    console.error('assetFileInput not found, cannot add event listener');
  }

  // Wire up Upload CV button to trigger file input
  const uploadCvBtn = $('uploadCvBtn');
  if (uploadCvBtn && assetFileInput) {
    uploadCvBtn.addEventListener('click', () => {
      assetFileInput.click();
    });
  }

  // Generator Page handlers
  const generatorPage = $('generatorPage');
  const generatorBackBtn = $('generatorBackBtn');
  const autoFillBtn = $('autoFillBtn');
  const genResumeBtn = $('genResumeBtn');
  const genCoverBtn = $('genCoverBtn');
  const resetFormBtn = $('resetFormBtn');
  const docBackBtn = $('docBackBtn');

  // Separate pages for Resume vs Cover Letter
  let currentDocumentKind = '';

  function showDocumentPage(kind) {
    try {
      currentDocumentKind = kind === 'resume' ? 'resume' : 'cover';
      const isResume = currentDocumentKind === 'resume';

      // Show the appropriate page, hide the other
      if (resumePage) {
        if (isResume) {
          resumePage.classList.remove('hidden');
        } else {
          resumePage.classList.add('hidden');
        }
      }

      if (coverPage) {
        if (!isResume) {
          coverPage.classList.remove('hidden');
        } else {
          coverPage.classList.add('hidden');
        }
      }

      // Hide legacy documents section
      if (documentsSection) {
        documentsSection.classList.add('hidden');
      }
    } catch (e) {
      console.error('Error showing document page:', e);
    }
  }

  function hideAllDocumentPages() {
    try {
      if (resumePage) resumePage.classList.add('hidden');
      if (coverPage) coverPage.classList.add('hidden');
      if (documentsSection) documentsSection.classList.add('hidden');
      if (resultsSection) resultsSection.classList.add('hidden');
    } catch (_) {}
  }

  function showResultsPage() {
    try {
      hideAllDocumentPages();
      if (resultsSection) resultsSection.classList.remove('hidden');
    } catch (_) {}
  }

  function closeGeneratorPage() {
    if (generatorPage) generatorPage.classList.add('hidden');
    const mainContainer = $('mainContainer');
    if (mainContainer) mainContainer.classList.remove('hidden');
  }

  if (generatorBackBtn)
    generatorBackBtn.addEventListener('click', closeGeneratorPage);

  // Close results overlay (documents view)
  if (docBackBtn && documentsSection) {
    docBackBtn.addEventListener('click', () => {
      documentsSection.classList.add('hidden');
    });
  }

  // Back buttons for separate pages
  if (resumeBackBtn) {
    resumeBackBtn.addEventListener('click', () => {
      hideAllDocumentPages();
    });
  }

  if (coverBackBtn) {
    coverBackBtn.addEventListener('click', () => {
      hideAllDocumentPages();
    });
  }

  if (resultsBackBtn) {
    resultsBackBtn.addEventListener('click', () => {
      hideAllDocumentPages();
    });
  }

  // Download dropdown handlers for Resume
  if (downloadResumeBtn && resumeDownloadMenu) {
    downloadResumeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      resumeDownloadMenu.classList.toggle('hidden');
    });

    resumeDownloadMenu.addEventListener('click', (e) => {
      const target = e.target.closest('.download-menu-item');
      if (target) {
        const format = target.getAttribute('data-format');
        if (format) {
          exportByFormat('cv', format);
          resumeDownloadMenu.classList.add('hidden');
        }
      }
    });

    document.addEventListener('click', (e) => {
      if (
        !downloadResumeBtn.contains(e.target) &&
        !resumeDownloadMenu.contains(e.target)
      ) {
        resumeDownloadMenu.classList.add('hidden');
      }
    });
  }

  // Download dropdown handlers for Cover Letter
  if (downloadCoverBtn && coverDownloadMenu) {
    downloadCoverBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      coverDownloadMenu.classList.toggle('hidden');
    });

    coverDownloadMenu.addEventListener('click', (e) => {
      const target = e.target.closest('.download-menu-item');
      if (target) {
        const format = target.getAttribute('data-format');
        if (format) {
          exportByFormat('cover', format);
          coverDownloadMenu.classList.add('hidden');
        }
      }
    });

    document.addEventListener('click', (e) => {
      if (
        !downloadCoverBtn.contains(e.target) &&
        !coverDownloadMenu.contains(e.target)
      ) {
        coverDownloadMenu.classList.add('hidden');
      }
    });
  }

  if (autoFillBtn) {
    autoFillBtn.addEventListener('click', async () => {
      console.log(
        '[Sidepanel] Auto-Fill Fields clicked - clearing cache and sending fresh request'
      );
      closeGeneratorPage();

      // STEP 1: Clear previous results immediately
      clearResults();

      // STEP 2: Send fresh request (no cache)
      await analyzeAndFill();

      // After results shown, optionally prompt to fill now
      try {
        const rows = resultsList?.querySelectorAll('.field-row')?.length || 0;
        if (rows > 0) {
          // Provide an inline CTA to fill rather than auto-filling immediately
          notesEl?.insertAdjacentHTML(
            'afterbegin',
            '<div class="notes-meta">Review results, then click Fill Page to apply.</div>'
          );
        }
      } catch (_) {}
    });
  }

  if (genResumeBtn) {
    genResumeBtn.addEventListener('click', async () => {
      closeGeneratorPage();
      await generateDocument('resume');
    });
  }

  if (genCoverBtn) {
    genCoverBtn.addEventListener('click', async () => {
      closeGeneratorPage();
      await generateDocument('cover');
    });
  }

  if (resetFormBtn) {
    resetFormBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to reset all form data?')) {
        clearInputs();
        closeModal();
      }
    });
  }
  if (fillPageBtn) fillPageBtn.addEventListener('click', fillPage);
  if (analyzeFastBtn) analyzeFastBtn.addEventListener('click', analyzeAndFill);
  if (generateCvBtn)
    generateCvBtn.addEventListener('click', () => generateDocument('resume'));
  if (generateCoverLetterBtn)
    generateCoverLetterBtn.addEventListener('click', () =>
      generateDocument('cover')
    );
  if (saveByokBtn) saveByokBtn.addEventListener('click', saveByok);
  if (clearByokBtn) clearByokBtn.addEventListener('click', clearByok);

  // Theme handling removed: always use light theme
  function applyLightTheme() {
    try {
      document.documentElement.setAttribute('data-theme', 'light');
    } catch (_) {}
  }

  if ($('exportCvTxtBtn'))
    $('exportCvTxtBtn').addEventListener('click', () => {
      const text = generatedCvEl?.value || '';
      if (!text) return alert('No resume text to export.');
      downloadBlobText(text, 'resume.txt', 'text/plain;charset=utf-8');
    });

  if ($('exportCvPdfBtn'))
    $('exportCvPdfBtn').addEventListener('click', () => {
      const text = generatedCvEl?.value || '';
      if (!text) return alert('No resume text to export.');
      openPrintPdf(text, 'Resume');
    });

  if ($('exportCvDocBtn'))
    $('exportCvDocBtn').addEventListener('click', () => {
      const text = generatedCvEl?.value || '';
      if (!text) return alert('No resume text to export.');
      exportDoc(text, 'resume.doc');
    });

  if ($('exportCoverTxtBtn'))
    $('exportCoverTxtBtn').addEventListener('click', () => {
      const text = generatedCoverEl?.value || '';
      if (!text) return alert('No cover letter text to export.');
      downloadBlobText(text, 'cover-letter.txt', 'text/plain;charset=utf-8');
    });

  if ($('exportCoverPdfBtn'))
    $('exportCoverPdfBtn').addEventListener('click', () => {
      const text = generatedCoverEl?.value || '';
      if (!text) return alert('No cover letter text to export.');
      openPrintPdf(text, 'Cover Letter');
    });

  if ($('exportCoverDocBtn'))
    $('exportCoverDocBtn').addEventListener('click', () => {
      const text = generatedCoverEl?.value || '';
      if (!text) return alert('No cover letter text to export.');
      exportDoc(text, 'cover-letter.doc');
    });

  function exportByFormat(kind, format) {
    const text =
      kind === 'cv'
        ? generatedCvEl?.value || ''
        : generatedCoverEl?.value || '';
    if (!text)
      return alert(
        `No ${kind === 'cv' ? 'resume' : 'cover letter'} text to export.`
      );
    if (format === 'txt') {
      downloadBlobText(text, kind === 'cv' ? 'resume.txt' : 'cover-letter.txt');
    } else if (format === 'pdf') {
      openPrintPdf(text, kind === 'cv' ? 'Resume' : 'Cover Letter');
    } else if (format === 'doc') {
      exportDoc(text, kind === 'cv' ? 'resume.doc' : 'cover-letter.doc');
    }
  }

  // Legacy download button handlers (kept for backward compatibility with old HTML)
  const legacyDownloadCvBtn = $('downloadCvBtn');
  const cvFormatSel = $('cvFormat');
  if (legacyDownloadCvBtn && cvFormatSel)
    legacyDownloadCvBtn.addEventListener('click', () => {
      const fmt = cvFormatSel?.value || 'txt';
      exportByFormat('cv', fmt);
    });

  const legacyDownloadCoverBtn = $('downloadCoverBtn');
  const coverFormatSel = $('coverFormat');
  if (legacyDownloadCoverBtn && coverFormatSel)
    legacyDownloadCoverBtn.addEventListener('click', () => {
      const fmt = coverFormatSel?.value || 'txt';
      exportByFormat('cover', fmt);
    });

  // Compact download menu
  const downloadMenuBtn = $('downloadMenuBtn');
  const downloadMenu = $('downloadMenu');
  if (downloadMenuBtn && downloadMenu) {
    downloadMenuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      downloadMenu.classList.toggle('hidden');
      try {
        filterDownloadMenuForKind(currentDocumentKind || 'resume');
      } catch (_) {}
    });
    downloadMenu.addEventListener('click', (e) => {
      const target = e.target;
      if (!(target instanceof HTMLElement)) return;
      const kind = target.getAttribute('data-kind');
      const fmt = target.getAttribute('data-fmt');
      if (kind && fmt) {
        exportByFormat(kind === 'cv' ? 'cv' : 'cover', fmt);
        downloadMenu.classList.add('hidden');
      }
    });
    document.addEventListener('click', (e) => {
      const t = e.target;
      if (!(t instanceof Node)) return;
      if (!downloadMenu.contains(t) && t !== downloadMenuBtn) {
        downloadMenu.classList.add('hidden');
      }
    });
  }

  async function getActiveTabUrl() {
    // Prefer URL from the content script (page context) to handle redirects/SPA nav
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (tab && tab.id != null) {
        try {
          const res = await chrome.tabs.sendMessage(tab.id, {
            type: 'getJobMeta',
          });
          if (res && typeof res.url === 'string' && res.url) return res.url;
        } catch (_) {}
      }
    } catch (_) {}
    // Fallback to the tab URL if content script is unavailable
    try {
      const tabs = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      return tabs && tabs[0] ? tabs[0].url || '' : '';
    } catch (_) {
      return '';
    }
  }

  async function logApplication(entry) {
    const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
    if (!base) return;
    try {
      // Ensure we always have a valid auth token (Firebase or legacy Supabase)
      let jwt = getAuthAccessToken();
      if (!jwt) {
        jwt = await getLatestAccessToken();
      }
      if (!jwt) {
        console.warn(
          '[Tracker] No auth token available, skipping logApplication'
        );
        return;
      }

      const res = await fetch(`${base}/v1/apps/log`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${jwt}`,
        },
        credentials: 'include',
        body: JSON.stringify({
          date_applied: new Date().toISOString(),
          job_url: entry?.job_url || '',
          job_title: entry?.job_title || '',
          company_name: entry?.company_name || '',
          job_description: entry?.job_description || '',
          location: entry?.location || '',
          resume_generated: !!entry?.resume_generated,
          cover_letter_generated: !!entry?.cover_letter_generated,
          notes: entry?.notes || '',
        }),
      });

      if (!res.ok) {
        const text = await res.text().catch(() => '');
        console.warn(
          '[Tracker] Failed to log application',
          res.status,
          text || res.statusText
        );
      }
    } catch (err) {
      console.warn('[Tracker] Error while logging application', err);
    }
  }

  // Log a successful document generation (resume or cover)
  async function logGeneration(kind) {
    try {
      const jobUrl =
        cachedJobUrl || cachedJobMeta.url || (await getActiveTabUrl());
      await logApplication({
        job_url: jobUrl,
        job_title: cachedJobMeta.jobTitle || '',
        company_name: cachedJobMeta.company || guessCompanyName(jdEl.value),
        job_description: jdEl.value,
        notes: kind === 'resume' ? 'Generate resume' : 'Generate cover letter',
        resume_generated: kind === 'resume',
        cover_letter_generated: kind === 'cover',
      });
    } catch (_) {}
  }

  async function getJobMetaFromPage() {
    try {
      const res = await chrome.tabs.sendMessage(
        (
          await chrome.tabs.query({ active: true, currentWindow: true })
        )[0].id,
        { type: 'getJobMeta' }
      );
      if (res && res.ok)
        return {
          jobTitle: res.jobTitle || '',
          company: res.company || '',
          url: res.url || '',
          jobId: res.jobId || '',
        };
    } catch (_) {}
    return { jobTitle: '', company: '', url: '', jobId: '' };
  }

  function guessCompanyName(text) {
    const m = (text || '').match(/Company[:\-\s]+(.+?)(\n|$)/i);
    return (m && m[1] && m[1].trim()) || '';
  }

  function guessJobTitle(text) {
    // Disable guessing: always return empty to avoid wrong titles
    return '';
  }

  // Wire up tracker open button
  const openTrackerBtn = document.getElementById('openTrackerBtn');
  if (openTrackerBtn) {
    openTrackerBtn.addEventListener('click', async () => {
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) return;
      const site = base.replace(/\/api$/, '');
      const jwt = await getLatestAccessToken();
      const url = jwt
        ? `${site}/tracker#t=${encodeURIComponent(jwt)}`
        : `${site}/tracker`;
      try {
        await chrome.tabs.create({ url });
      } catch (_) {
        window.open(url, '_blank');
      }
    });
  }

  // Remove old click-based logging (now logged after successful generation)

  // Check if user needs onboarding
  async function checkOnboardingStatus() {
    try {
      // First check local storage
      const { onboardingComplete, profileCompleteness } =
        await chrome.storage.local.get([
          'onboardingComplete',
          'profileCompleteness',
        ]);

      if (onboardingComplete === true) {
        console.log(
          `[Sidepanel] Onboarding marked complete in local storage (${
            profileCompleteness || 'unknown'
          }%)`
        );
        return true;
      }

      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) {
        console.log('[Sidepanel] No API base URL, checking local storage only');
        return false;
      }

      const token = getAuthAccessToken() || (await getLatestAccessToken());
      if (!token) {
        console.log('[Sidepanel] No auth token, checking local storage only');
        return false;
      }

      console.log('[Sidepanel] Checking onboarding status from backend...');
      const headers = { Authorization: `Bearer ${token}` };
      const res = await fetch(`${base}/v1/profile/sync`, {
        method: 'GET',
        headers,
        credentials: 'include',
      });

      if (res.ok) {
        const data = await res.json();
        const profile = data?.profile;

        console.log('[Sidepanel] Profile data:', {
          onboarding_completed: profile?.onboarding_completed,
          completeness_score: profile?.completeness_score,
          has_name: !!profile?.full_name,
          has_email: !!profile?.email,
          has_cv: !!profile?.cv_text,
          has_skills: !!profile?.top_skills?.length,
        });

        // Check if onboarding is completed (>= 30% threshold)
        if (profile?.onboarding_completed) {
          console.log(
            `[Sidepanel] Onboarding completed in database (${
              profile?.completeness_score || 'unknown'
            }%)`
          );
          return true;
        }

        // Check completeness score if available
        if (profile?.completeness_score >= 30) {
          console.log(
            `[Sidepanel] Profile completeness >= 30% (${profile.completeness_score}%), marking onboarding complete`
          );
          await chrome.storage.local.set({
            onboardingComplete: true,
            profileCompleteness: profile.completeness_score,
          });
          return true;
        }

        // Also check if user has any meaningful profile data (legacy check)
        const hasBasicInfo = profile?.full_name && profile?.email;
        const hasCV = profile?.cv_text && profile.cv_text.length > 100;
        const hasSkills = profile?.top_skills && profile.top_skills.length > 0;

        // If user has answered some questions, consider onboarding done
        if (hasBasicInfo && (hasCV || hasSkills)) {
          console.log(
            '[Sidepanel] User has meaningful profile data, skipping onboarding'
          );
          return true;
        }

        console.log('[Sidepanel] User needs onboarding');
        return false;
      }

      console.log('[Sidepanel] Backend check failed, status:', res.status);
      return false;
    } catch (err) {
      console.error('[Sidepanel] Error checking onboarding status:', err);
      // Check local storage as fallback
      const { onboardingComplete } = await chrome.storage.local.get(
        'onboardingComplete'
      );
      return onboardingComplete === true;
    }
  }

  // Load saved CV from storage and display in Step 3
  async function loadSavedCV() {
    try {
      const { userCV } = await chrome.storage.local.get(['userCV']);

      if (userCV && cvEl) {
        cvEl.value = userCV;
        const wordCount = userCV.split(/\s+/).filter(Boolean).length;
        const charCount = userCV.length;

        // Update status message
        if (assetStatusEl) {
          assetStatusEl.innerHTML = `
            <div style="display: flex; align-items: center; gap: 8px; padding: 12px; background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; margin-top: 12px;">
              <span style="font-size: 18px;">✅</span>
              <div style="flex: 1;">
                <strong style="color: #16a34a; display: block; margin-bottom: 4px;">Resume Loaded</strong>
                <span style="color: #15803d; font-size: 13px;">${wordCount} words, ${charCount} characters</span>
              </div>
            </div>
          `;
        }

        console.log(
          `[Sidepanel] Loaded saved CV (${charCount} characters, ${wordCount} words)`
        );
      } else {
        console.log('[Sidepanel] No saved CV found');
      }
    } catch (error) {
      console.error('[Sidepanel] Error loading saved CV:', error);
    }
  }

  document.addEventListener('DOMContentLoaded', async () => {
    console.log('[Sidepanel] DOMContentLoaded - Extension starting up');
    applyLightTheme();
    await loadConfig();
    await loadOrCreateClientId();
    await RRIntegration.init();

    // Check authentication before showing main interface
    let isAuthenticated = await checkAuthentication();
    if (!isAuthenticated && RRIntegration.hasAuthToken()) {
      isAuthenticated = true;
    }
    if (!isAuthenticated) {
      showAuthRequired();
      return;
    }
    // Check if user needs onboarding; if so, open profile-setup in a new tab,
    // but still show the main side panel UI (no redirect inside panel).
    const hasCompletedOnboarding = await checkOnboardingStatus();
    if (!hasCompletedOnboarding) {
      console.log(
        '[Sidepanel] User needs onboarding - opening profile setup in new tab'
      );
      try {
        chrome.tabs.create({
          url: chrome.runtime.getURL('profile-setup.html'),
        });
      } catch (_) {
        try {
          window.open(chrome.runtime.getURL('profile-setup.html'), '_blank');
        } catch (_) {}
      }
    }

    // User is authenticated; show main plugin interface regardless of onboarding
    hideAuthRequired();

    await initAuthSession();

    // Sync profile from RR API if we have a token
    try {
      const token = await getLatestAccessToken();
      if (token && typeof syncProfileFromRR === 'function') {
        console.log('[Sidepanel] Checking if profile needs refresh...');
        const needsSync =
          typeof needsRefresh === 'function' ? await needsRefresh() : true;
        if (needsSync) {
          console.log('[Sidepanel] Syncing profile from RR API on startup...');
          const profile = await syncProfileFromRR(token);
          if (profile) {
            console.log('[Sidepanel] ✅ Profile synced on startup');
          }
        } else {
          console.log('[Sidepanel] Profile is fresh, skipping sync');
        }
      }
    } catch (error) {
      console.warn('[Sidepanel] Error syncing profile on startup:', error);
    }

    await loadByok();
    await loadModelSelection();
    // Preload jsPDF so PDF export always works
    try {
      await loadJsPdfCtor();
    } catch (_) {}
    refreshApiKeyStatus();
    refreshAuthStatus();

    // Setup UI components
    setupAIModelSelector();
    setupUserMenu();
    checkFormCompletion();

    // Load saved CV if available
    await loadSavedCV();

    // Re-run button handler
    // rerunBtn removed
  });

  if (modelSelect) {
    modelSelect.addEventListener('change', saveModelSelection);
  }

  // Listen for storage changes (e.g., logout from profile page)
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'sync') return;

    const fb = changes.firebaseSession;

    const sessionRemoved = fb && fb.oldValue && !fb.newValue;

    if (sessionRemoved) {
      console.log(
        '[Sidepanel] Session removed via storage change - logging out'
      );
      rememberAuthSession(null);
      currentUserEmail = '';
      showAuthRequired();
    }
  });

  // Listen for save custom answers requests from content.js
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'saveCustomAnswers') {
      (async () => {
        try {
          if (!window.JobApAIProfile?.saveCustomAnswer) {
            console.log('[Sidepanel] Profile sync not loaded yet');
            return;
          }

          const fields = msg.fields || [];
          let savedCount = 0;

          for (const field of fields) {
            if (field.name && field.value) {
              await window.JobApAIProfile.saveCustomAnswer(
                field.name,
                field.value
              );
              savedCount++;
            }
          }

          console.log(
            `[Sidepanel] Saved ${savedCount} custom answers for reuse`
          );
        } catch (e) {
          console.error('[Sidepanel] Error saving custom answers:', e);
        }
      })();
      return true;
    }
  });
})();
