## Contributing

### Code Style

- Prefer descriptive names and clear, multi-line code.
- Avoid deep nesting; use guard clauses.
- Only add comments for non-obvious rationale and invariants.
- Do not commit secrets or API keys.

### Extension Guidelines

- Keep all scripts external (no inline JS in HTML).
- Avoid `eval` and dynamic script injection.
- Update `manifest.json` permissions conservatively; justify any additions.
- Test side panel flows and content script behavior on common job sites.

### Backend Guidelines

- Use typed handlers in `route.ts` files and return `NextResponse` with CORS via `withCORS`.
- Validate inputs and handle error statuses explicitly.
- Keep provider-specific code in `lib/*` and avoid leaking keys.

### PR Checklist

- Description of change and scope
- Manual test notes (extension + backend)
- Security/privacy considerations
- Screenshots for UI changes
