# Privacy Policy - Reverse Recruiting Chrome Extension

**Last Updated:** December 16, 2024

## Overview

The Reverse Recruiting Chrome Extension ("Extension") is designed to help job seekers efficiently fill out job application forms using their stored profile information. This privacy policy explains what data we collect, how we use it, and how we protect it.

## Data Collection

### Data You Provide

The Extension collects the following information that you explicitly provide:

1. **Profile Information**

   - Full name, email, phone number
   - Location/address information
   - LinkedIn URL, GitHub URL, portfolio URL
   - Work authorization status
   - Security clearance level (if applicable)

2. **Professional Information**

   - Current job title and professional summary
   - Years of experience (total, technical, management)
   - Skills and certifications
   - Education details (degree, field of study, university, graduation year)

3. **Job Preferences**

   - Preferred job types (full-time, part-time, contract, etc.)
   - Preferred industries
   - Salary expectations
   - Willingness to relocate

4. **Resume/CV Content**

   - Text content from uploaded resumes (used for form filling)
   - Resume excerpts (up to 4000 characters) for profile sync

5. **Custom Answers**
   - Responses to common application questions
   - These are saved for reuse across applications

### Data Collected Automatically

1. **Form Field Detection**

   - The Extension scans web pages to detect form fields for auto-filling
   - This data is processed locally and not transmitted to servers

2. **Authentication Tokens**
   - Session tokens for maintaining your logged-in state
   - Stored securely in Chrome's local storage

## How We Use Your Data

Your data is used exclusively for the following purposes:

1. **Form Auto-Filling** - To populate job application forms with your profile data
2. **Resume/Cover Letter Generation** - To create tailored documents using AI
3. **Profile Sync** - To backup your profile and enable cross-device access
4. **Authentication** - To verify your identity and maintain sessions

## Data Storage

### Local Storage

- All profile data is stored locally in Chrome's `chrome.storage.local`
- Authentication sessions are stored in `chrome.storage.sync`
- Data never leaves your device unless you explicitly sync it

### Server Storage (Optional)

When you choose to sync your profile:

- Profile data is transmitted securely via HTTPS to our servers
- Data is stored in encrypted databases
- You can delete your server-side data at any time

## Data Sharing

We do **NOT**:

- Sell your data to third parties
- Share your data with advertisers
- Use your data for personalized advertising
- Share your data with data brokers

We **DO** share data with:

- **Our backend servers** - For profile sync and AI-powered features
- **OpenAI/Google AI** - For resume/cover letter generation (data is processed, not stored)
- **Firebase** - For authentication services only

## Third-Party Services

The Extension uses the following third-party services:

| Service                 | Purpose                        | Data Shared               |
| ----------------------- | ------------------------------ | ------------------------- |
| Firebase Authentication | User login/signup              | Email, name (for account) |
| OpenAI API              | Resume/cover letter generation | CV text, job descriptions |
| Google Gemini API       | AI text processing             | CV text, job descriptions |
| Our Backend API         | Profile sync, AI processing    | Profile data, CV excerpts |

## Data Security

We implement the following security measures:

1. **HTTPS Encryption** - All data transmitted to servers uses TLS encryption
2. **Secure Storage** - Chrome's secure storage APIs are used for local data
3. **Token-Based Auth** - Bearer tokens with expiration for API authentication
4. **No Plain Text Passwords** - Passwords are never stored in the extension

## Your Rights

You have the right to:

1. **Access** - View all data stored by the extension
2. **Export** - Download your profile data
3. **Delete** - Remove all local and server-side data
4. **Opt-Out** - Disable server sync and use extension locally only

### How to Delete Your Data

**Local Data:**

1. Right-click the extension icon
2. Select "Remove from Chrome"
3. All local data is automatically deleted

**Server Data:**

1. Contact support@reverserecruiting.io
2. Request account and data deletion
3. We will process your request within 30 days

## Permissions Justification

### Why We Request These Permissions

| Permission                    | Reason                                                                                                                                                                                                                                             |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `storage`                     | To save your profile data locally for form filling                                                                                                                                                                                                 |
| `sidePanel`                   | To display the extension's main interface                                                                                                                                                                                                          |
| `tabs`                        | To open the profile page and detect active tab URL                                                                                                                                                                                                 |
| `webNavigation`               | To scan all frames on job application pages - many ATS systems (Greenhouse, Lever) use iframes for their forms                                                                                                                                     |
| `<all_urls>` (content script) | **Required** to detect and fill forms on ANY job application site. Job applications exist on thousands of ATS platforms (Greenhouse, Lever, Workday, etc.) and company career pages. Restricting to specific sites would break core functionality. |

### Host Permissions

| Host                       | Reason                       |
| -------------------------- | ---------------------------- |
| `reverserecruiting.io`     | Our main website and API     |
| `api.reverserecruiting.io` | Backend API for profile sync |
| `googleapis.com`           | Firebase authentication      |
| `rrextension-*.run.app`    | Backend API servers          |

## Web Browsing Activity

**Important:** This extension does **NOT** collect web browsing history or track your browsing activity. The content script only:

- Detects form fields when you're on a page
- Fills forms when you explicitly request it
- Communicates with our website (reverserecruiting.io) for authentication

## Children's Privacy

This Extension is not intended for users under 18 years of age. We do not knowingly collect data from children.

## Changes to This Policy

We may update this privacy policy from time to time. We will notify users of significant changes via:

- Email notification (if you have an account)
- In-extension notification
- Updated "Last Updated" date at the top of this policy

## Contact Us

If you have questions about this privacy policy or your data:

- **Email:** privacy@reverserecruiting.io
- **Website:** https://reverserecruiting.io/privacy

## Chrome Web Store Compliance

This extension complies with:

- [Chrome Web Store Developer Program Policies](https://developer.chrome.com/docs/webstore/program-policies/)
- [Chrome Web Store User Data Policy](https://developer.chrome.com/docs/webstore/program-policies/user-data-faq/)
- Limited Use requirements for user data

### Limited Use Compliance Statement

The use of information received from Google APIs will adhere to the Chrome Web Store User Data Policy, including the Limited Use requirements.

---

## Summary for Chrome Web Store Submission

### Single Purpose Declaration

This extension has a single, clear purpose: **Helping users fill out job application forms efficiently using their stored profile information.**

### Data Use Certification

- ✅ We only collect data necessary for the extension's primary function
- ✅ We do not sell user data
- ✅ We do not use data for advertising
- ✅ We transmit data securely via HTTPS
- ✅ Users can delete their data at any time
