## Environment & Configuration

### Extension

- `chrome.storage.sync` keys:
  - `openaiApiKey` — user-provided BYOK
  - `openaiModel` — selected model (default `gpt-5-mini`)
- `config.json`:
  - `apiBaseUrl` — backend base URL (e.g., `http://localhost:3000/api` or your Vercel URL)
  - `supabaseUrl` — Supabase project URL
  - `supabaseAnonKey` — Supabase anon key (client)
  - `upgradeUrl` — optional link for upgrade/plan

### Backend (Vercel Next.js)

Define in `.env.local` (dev) and Vercel project settings (prod):

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE` (server-only)
- `OPENAI_API_KEY` (server-only, optional if using BYOK only)
- `GEMINI_API_KEY` (optional)
- `CLAUDE_API_KEY` or `ANTHROPIC_API_KEY` (optional)
- `TRIAL_LIMIT_USES` (default 100)
- `TRIAL_DURATION_DAYS` (default 365)
- `SITE_URL` (for CORS origin fallback)

### CORS & Host Permissions

- Manifest `host_permissions` must include your backend domains.
- Backend sets CORS via `vercel-backend/lib/cors.ts` and reflects `Origin` or `SITE_URL`.

### Security Notes

- Never commit real secrets to the repo or extension bundle.
- Keep BYOK strictly in `chrome.storage.sync`; do not log keys.
- Validate API inputs server-side and avoid echoing secrets.





