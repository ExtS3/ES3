# Profile Sync Flow Documentation

## Overview

The extension now has a complete profile synchronization system that:
1. Fetches user profile from Reverse Recruiting API (`/api/auth/me`)
2. Stores profile data in `chrome.storage.local`
3. Displays profile information on the profile page
4. Sends profile data to AI when analyzing job forms

## Architecture

### Components

1. **profile-storage.js** - Centralized profile management utility
2. **profile-setup.js** - Profile setup page (fetches and displays)
3. **profile.js** - Main profile page (fetches and displays)
4. **sidepanel.js** - Main extension UI (uses profile for AI analysis)
5. **content.js** - Receives token from dashboard via `postMessage`

### Data Flow

```
RR Dashboard (postMessage: RR_EXTENSION_INIT)
    ↓ (sends JWT token)
content.js (receives token, stores in rrIntegrationState.authToken)
    ↓
sidepanel.js (on startup or token receive)
    ↓
syncProfileFromRR(token) [profile-storage.js]
    ↓
fetchProfileFromRR(token) → GET /api/auth/me
    ↓
mapRRProfileToExtension(response)
    ↓
saveProfile(profile) → chrome.storage.local
    ↓
Profile available for:
    - Display on profile pages
    - AI analysis in sidepanel
    - Form autofill
```

## API Integration

### Endpoint
- **URL**: `https://api.reverserecruiting.io/api/auth/me`
- **Method**: GET
- **Auth**: Bearer token (JWT)
- **Response**:
```json
{
  "success": true,
  "data": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe",
    "resumeUrl": "https://...",
    "resumeSummary": "5+ years...",
    "linkedinUrl": "https://linkedin.com/in/...",
    "targetRole": ["Software Engineer", "Data Scientist"],
    "experienceLevel": "senior",
    "preferredLocations": ["San Francisco, CA", "Remote"],
    "workType": ["remote", "hybrid"],
    "keywords": ["React", "Node.js", "TypeScript"],
    "minSalary": 150000,
    "status": "active",
    "createdAt": "2025-12-16T...",
    "updatedAt": "2025-12-16T..."
  }
}
```

### Field Mapping

| API Field | Extension Field | Usage |
|-----------|----------------|-------|
| `name` | `full_name` | User's full name |
| `email` | `email` | Email address |
| `resumeUrl` | `cv_url` | Resume PDF URL |
| `resumeSummary` | `cv_text`, `professional_summary` | Resume text for AI |
| `linkedinUrl` | `linkedin_url` | LinkedIn profile |
| `targetRole` | `role_preferences`, `current_job_title` | Job roles |
| `experienceLevel` | `experience_level`, `years_total_experience` | Experience |
| `preferredLocations` | `locations`, `location` | Work locations |
| `workType` | `job_types` | Remote/hybrid/onsite |
| `keywords` | `top_skills` | Skills/keywords |
| `minSalary` | `expected_salary_min` | Salary expectation |

## Token Management

### Token Priority (in order)
1. **rrIntegrationState.authToken** - From RR dashboard via `postMessage`
2. **rrAuthToken** - Direct storage
3. **firebaseSession.access_token** - Firebase auth (legacy)

### Token Flow
```javascript
// 1. Dashboard sends token
window.postMessage({
  type: 'RR_EXTENSION_INIT',
  token: 'jwt_token_here',
  user: { email: '...', name: '...' }
}, '*');

// 2. content.js receives and stores
await chrome.storage.local.set({
  rrIntegrationState: {
    authToken: token,
    user: user,
    ...
  }
});

// 3. Extension components retrieve
const state = await chrome.storage.local.get('rrIntegrationState');
const token = state.rrIntegrationState?.authToken;
```

## Profile Storage Functions

### Core Functions (profile-storage.js)

#### `syncProfileFromRR(token)`
Main sync function - fetches, maps, and stores profile.
```javascript
const profile = await syncProfileFromRR(token);
// Returns: { full_name, email, cv_text, ... }
```

#### `getProfile()`
Retrieve stored profile from chrome.storage.
```javascript
const profile = await getProfile();
// Returns: stored profile object or null
```

#### `getProfileForAI()`
Format profile as text for AI analysis.
```javascript
const profileText = await getProfileForAI();
// Returns: "Name: John Doe\nEmail: john@...\n..."
```

#### `needsRefresh()`
Check if profile is older than 1 hour.
```javascript
const shouldSync = await needsRefresh();
// Returns: true/false
```

## Usage in Extension

### 1. Profile Setup Page (profile-setup.js)

```javascript
async function loadExistingProfile() {
  const token = getTokenFromStorage();
  
  // Sync from RR API using utility
  const syncedProfile = await syncProfileFromRR(token);
  
  if (syncedProfile) {
    // Profile is now stored and ready to use
    fillFormWithProfile(syncedProfile);
  }
}
```

### 2. Sidepanel Analysis (sidepanel.js)

```javascript
async function analyze() {
  // Get profile data for AI
  let profileForAI = '';
  if (typeof getProfileForAI === 'function') {
    profileForAI = await getProfileForAI();
  }
  
  // Combine with CV text
  const combinedCVText = profileForAI 
    ? `${profileForAI}\n\n--- Additional Resume Details ---\n${cvText}` 
    : cvText;
  
  // Send to AI
  const result = await analyzeOptimized({
    cvText: combinedCVText,
    jobDescriptionText,
    formText,
    ...
  });
}
```

### 3. Auto-Sync on Login

```javascript
// In sidepanel.js - when token is received
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'rrIntegrationStateUpdated') {
    const token = msg?.payload?.authToken;
    
    // Auto-sync profile
    if (typeof syncProfileFromRR === 'function') {
      const profile = await syncProfileFromRR(token);
      console.log('✅ Profile synced on login');
    }
  }
});
```

### 4. Auto-Sync on Startup

```javascript
// In sidepanel.js - DOMContentLoaded
document.addEventListener('DOMContentLoaded', async () => {
  const token = await getLatestAccessToken();
  
  // Check if profile needs refresh
  if (token && await needsRefresh()) {
    const profile = await syncProfileFromRR(token);
    console.log('✅ Profile synced on startup');
  }
});
```

## Profile Data Structure

### Stored Format (chrome.storage.local)
```javascript
{
  userProfile: {
    // Basic Info
    full_name: "John Doe",
    email: "john@example.com",
    phone: "",
    
    // Resume
    cv_text: "5+ years of full-stack development...",
    cv_url: "https://storage.../resume.pdf",
    
    // Social Links
    linkedin_url: "https://linkedin.com/in/johndoe",
    portfolio_url: "",
    github_url: "",
    
    // Job Preferences
    role_preferences: ["Software Engineer", "Data Scientist"],
    experience_level: "senior",
    locations: ["San Francisco, CA", "Remote"],
    current_job_title: "Software Engineer",
    years_total_experience: 8,
    
    // Skills
    top_skills: ["React", "Node.js", "TypeScript", "AWS"],
    
    // Additional
    professional_summary: "5+ years...",
    expected_salary_min: 150000,
    job_types: ["remote", "hybrid"],
    status: "active",
    
    // Metadata
    user_id: "uuid",
    created_at: "2025-12-16T...",
    updated_at: "2025-12-16T...",
    source: "reverse_recruiting",
    last_synced: "2025-12-16T..."
  },
  profileLastUpdated: "2025-12-16T...",
  userCV: "5+ years of full-stack development..." // For backward compatibility
}
```

### AI Format (from getProfileForAI())
```
Name: John Doe
Email: john@example.com
Location: San Francisco, CA, Remote
LinkedIn: https://linkedin.com/in/johndoe
Current Role: Software Engineer
Experience Level: senior
Years of Experience: 8
Target Roles: Software Engineer, Data Scientist
Skills: React, Node.js, TypeScript, AWS
Work Type Preferences: remote, hybrid
Minimum Salary: $150000

Professional Summary:
5+ years of full-stack development experience with React, Node.js, and AWS...
```

## Benefits

### For Users
- ✅ **Automatic Profile Sync** - No manual data entry
- ✅ **Consistent Data** - Same profile across dashboard and extension
- ✅ **Better AI Results** - AI has complete profile context
- ✅ **Real-time Updates** - Profile syncs when dashboard updates

### For AI Analysis
- ✅ **Complete Context** - AI gets structured profile data + resume
- ✅ **Better Matching** - AI can match skills, experience, preferences
- ✅ **Accurate Answers** - AI uses verified profile data, not guesses

### For Development
- ✅ **Centralized Logic** - All profile operations in one utility
- ✅ **Easy Maintenance** - Single source of truth
- ✅ **Extensible** - Easy to add new profile fields

## Debugging

### Console Logs

**Successful Sync:**
```
[ProfileStorage] Fetching profile from /api/auth/me...
[ProfileStorage] ✅ Successfully fetched profile from RR API
[ProfileStorage] Profile data: { success: true, data: {...} }
[ProfileStorage] Mapped profile: { name: "John Doe", email: "...", ... }
[ProfileStorage] ✅ Profile saved to storage
[ProfileStorage] ✅ Profile sync complete
```

**Using Profile for AI:**
```
[Sidepanel] ✅ Using stored profile data for AI analysis
[Sidepanel] Profile length: 1234 characters
[ProfileStorage] ✅ Profile loaded from storage
[ProfileStorage] Last updated: 2025-12-16T...
[ProfileStorage] Formatted profile for AI: 1234 characters
```

### Common Issues

**401 Unauthorized:**
- Token is invalid or expired
- Check token source in logs
- Ensure dashboard sent `RR_EXTENSION_INIT`

**No Profile Data:**
- Check if token exists: `chrome.storage.local.get('rrIntegrationState')`
- Check if profile is stored: `chrome.storage.local.get('userProfile')`
- Check console for sync errors

**Profile Not Updating:**
- Profile caches for 1 hour
- Force refresh by clearing: `chrome.storage.local.remove('userProfile')`
- Or wait for auto-refresh

## Testing

### Manual Testing Steps

1. **Open RR Dashboard**
2. **Click "Open Extension" button** (sends `RR_EXTENSION_INIT`)
3. **Check Console Logs**:
   ```
   [Content] ✅ RR_EXTENSION_INIT received
   [Content] ✅ Token persisted to storage
   [Sidepanel] Syncing profile from RR API...
   [ProfileStorage] ✅ Profile sync complete
   ```
4. **Open Profile Setup Page**
   - Should auto-fill with RR data
5. **Analyze a Job Form**
   - Check logs for "Using stored profile data"
6. **Verify Storage**:
   ```javascript
   chrome.storage.local.get(['userProfile', 'profileLastUpdated'], (data) => {
     console.log(data);
   });
   ```

### Expected Behavior

- ✅ Profile syncs on first login
- ✅ Profile syncs when token is received
- ✅ Profile syncs on startup (if > 1 hour old)
- ✅ Profile is used for AI analysis
- ✅ Profile displays on profile pages
- ✅ Profile updates when dashboard updates

## Future Enhancements

- [ ] Add profile edit capability in extension
- [ ] Sync profile changes back to RR API
- [ ] Add profile photo support
- [ ] Add work history/education from API
- [ ] Add custom answers sync
- [ ] Add profile validation
- [ ] Add offline mode with cached profile




























