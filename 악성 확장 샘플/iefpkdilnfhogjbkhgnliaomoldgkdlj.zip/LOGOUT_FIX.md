# Logout Fix Summary

## Problem

When clicking "Logout" on the profile page, the user was logged out from the profile page but the extension sidepanel remained logged in, showing the authenticated state.

## Root Cause

The profile page was clearing storage and redirecting to `onboarding.html`, but:

1. The sidepanel wasn't listening for storage changes
2. The profile page was trying to redirect instead of just closing
3. No communication between profile page and sidepanel

## Solution

### 1. Profile Page (`profile.js`)

**Changes:**

- Clear `supabaseSession` from `chrome.storage.sync`
- Clear all local storage items (profile, CV, custom answers, etc.)
- Clear session cache using `chrome.storage.session.clear()`
- Send a `logout` message to background script (for future cleanup)
- **Close the profile window** instead of redirecting to onboarding

```javascript
// Clear session cache
if (chrome?.storage?.session) {
  await chrome.storage.session.clear().catch(() => {});
}

// Send message to background script
try {
  await chrome.runtime.sendMessage({ type: 'logout' });
} catch (e) {
  console.log('[Profile] Background message failed (expected):', e);
}

// Close profile window and let sidepanel detect logout
window.close();
```

### 2. Sidepanel (`sidepanel.js`)

**Changes:**

- Added `chrome.storage.onChanged` listener to detect when `supabaseSession` is removed
- When session is removed, automatically show the auth screen

```javascript
// Listen for storage changes (e.g., logout from profile page)
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'sync' && changes.supabaseSession) {
    // Session was removed (logout)
    if (!changes.supabaseSession.newValue && changes.supabaseSession.oldValue) {
      console.log('[Sidepanel] Session removed - logging out');
      supabaseSession = null;
      currentUserEmail = '';
      showAuthRequired();
    }
  }
});
```

## How It Works Now

1. User clicks "Logout" on profile page
2. Profile page clears all auth-related storage
3. Profile window closes
4. Sidepanel detects the storage change via `onChanged` listener
5. Sidepanel automatically shows the login/signup screen
6. User is now logged out across the entire extension

## Benefits

- ✅ Logout works consistently across all extension pages
- ✅ No orphaned sessions
- ✅ Clean UX - profile window closes, sidepanel updates automatically
- ✅ Session cache is properly cleared
- ✅ All user data is removed on logout

## Testing

1. Open extension sidepanel (should be logged in)
2. Click profile icon to open profile page
3. Click "Logout" button
4. Profile page closes
5. Sidepanel automatically shows login screen
6. Extension is fully logged out
