# Smart Onboarding Flow Implementation

## Overview

Implemented intelligent onboarding detection that shows onboarding only for first-time users or users who haven't answered any onboarding questions. All profile data is persisted to Supabase for long-term storage.

## Features

### 1. **Smart Onboarding Detection**

The extension now checks if a user needs onboarding based on:

- `onboarding_completed` flag in database
- Presence of basic profile data (name, email)
- Presence of CV or skills data

**Logic:**

- ✅ Skip onboarding if user has completed it before
- ✅ Skip onboarding if user has meaningful profile data (CV + skills)
- ❌ Show onboarding for brand new users
- ❌ Show onboarding if user has no profile data

### 2. **Long-term Storage in Supabase**

All profile data is automatically synced to Supabase:

- ✅ Basic information (name, email, phone, location, etc.)
- ✅ Skills and education
- ✅ Job preferences
- ✅ Professional summary
- ✅ Resume/CV text
- ✅ Interview question answers
- ✅ Onboarding completion status

### 3. **Data Persistence**

Profile data is stored in multiple places for reliability:

- **Local Storage** (`chrome.storage.local`): Fast access, immediate availability
- **Sync Storage** (`chrome.storage.sync`): Syncs across user's devices
- **Supabase Database**: Long-term persistence, accessible from backend

## Implementation Details

### Sidepanel (`sidepanel.js`)

Added `checkOnboardingStatus()` function that:

1. Fetches user profile from backend
2. Checks `onboarding_completed` flag
3. Validates profile completeness
4. Redirects to onboarding if needed

```javascript
async function checkOnboardingStatus() {
  // Fetch profile from backend
  const res = await fetch(`${base}/v1/profile/sync`, {
    method: 'GET',
    headers: { Authorization: `Bearer ${token}` },
  });

  const data = await res.json();
  const profile = data?.profile;

  // Check if onboarding is completed
  if (profile?.onboarding_completed) {
    return true;
  }

  // Check if user has meaningful data
  const hasBasicInfo = profile?.full_name && profile?.email;
  const hasCV = profile?.cv_text && profile.cv_text.length > 100;
  const hasSkills = profile?.top_skills && profile.top_skills.length > 0;

  return hasBasicInfo && (hasCV || hasSkills);
}
```

### Profile Setup (`profile-setup.js`)

Updated `finishSetup()` to:

1. Collect all profile data
2. Save locally
3. Sync to Supabase with `onboardingComplete: true`
4. Include interview question answers
5. Redirect to sidepanel

```javascript
const payload = {
  profile: {
    // ... all profile fields ...
    onboardingComplete: true, // Mark as completed
  },
  customAnswers: customAnswers
    ? Object.entries(customAnswers).map(([question, answer]) => ({
        question,
        answer,
      }))
    : [],
};

await fetch(`${base}/v1/profile/sync`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  },
  body: JSON.stringify(payload),
});
```

### Profile Page (`profile.js`)

Updated `saveProfile()` to:

1. Collect interview answers
2. Save to local storage
3. Sync everything to Supabase
4. Always mark `onboardingComplete: true`

## User Flow

### First-Time User

1. User signs up/logs in
2. Extension checks onboarding status → **Not completed**
3. Redirects to `profile-setup.html`
4. User completes onboarding (uploads resume, fills info)
5. Data synced to Supabase with `onboarding_completed = true`
6. Redirects to sidepanel
7. ✅ User can now use the extension

### Returning User

1. User logs in
2. Extension checks onboarding status → **Completed**
3. Loads profile data from Supabase
4. Shows main sidepanel interface
5. ✅ User can immediately start using the extension

### User Who Partially Completed Onboarding

1. User logs in
2. Extension checks onboarding status
3. Finds profile data (name, email, CV, skills)
4. Considers onboarding complete
5. Shows main sidepanel interface
6. ✅ User doesn't have to redo onboarding

## Database Schema

The backend stores profile data in `user_profiles` table:

```sql
user_profiles (
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES auth.users,
  full_name text,
  email text,
  phone text,
  location text,
  linkedin_url text,
  portfolio_url text,
  github_url text,
  work_authorization text,
  security_clearance text,
  professional_summary text,
  current_job_title text,
  years_total_experience integer,
  highest_degree text,
  field_of_study text,
  university text,
  graduation_year text,
  top_skills jsonb,
  certifications jsonb,
  job_types jsonb,
  expected_salary_min text,
  expected_salary_max text,
  willing_to_relocate text,
  cv_text text,
  onboarding_completed boolean DEFAULT false,
  onboarding_completed_at timestamp,
  completeness_score integer,
  created_at timestamp DEFAULT now(),
  updated_at timestamp DEFAULT now()
)
```

Interview answers are stored in `custom_answers` table:

```sql
custom_answers (
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES auth.users,
  profile_id uuid REFERENCES user_profiles,
  question_text text,
  question_normalized text,
  answer_text text,
  question_category text,
  keywords jsonb,
  times_used integer DEFAULT 1,
  last_used_at timestamp,
  created_at timestamp DEFAULT now()
)
```

## Benefits

1. **Better UX**: Users don't have to redo onboarding every time
2. **Data Persistence**: All data is safely stored in Supabase
3. **Fast Access**: Local cache provides instant access
4. **Cross-Device Sync**: Profile syncs across user's devices
5. **Smart Detection**: Intelligently determines if onboarding is needed
6. **Flexible**: Works even if user partially completes onboarding

## Testing

### Test Case 1: New User

1. Sign up with new account
2. Should see onboarding page
3. Complete onboarding
4. Should redirect to sidepanel
5. Refresh extension
6. Should stay on sidepanel (not redirect to onboarding)

### Test Case 2: Returning User

1. Log in with existing account (completed onboarding)
2. Should go directly to sidepanel
3. Should not see onboarding page

### Test Case 3: Partial Onboarding

1. Log in with account that has some data but no `onboarding_completed` flag
2. If user has name, email, and CV → skip onboarding
3. If user has minimal data → show onboarding

### Test Case 4: Logout and Login

1. Complete onboarding
2. Logout
3. Login again
4. Should skip onboarding and go to sidepanel
5. Profile data should be loaded from Supabase
