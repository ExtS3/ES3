# Cloud SQL and Firebase Setup Commands

Run these commands to set up your Google Cloud infrastructure.

**Prerequisites:**

- `gcloud` CLI installed and authenticated
- Project ID: `jobapai` (or replace with your project)

---

## Step 1: Enable Required APIs

```bash
# Set your project
gcloud config set project jobapai

# Enable APIs
gcloud services enable \
  sqladmin.googleapis.com \
  identitytoolkit.googleapis.com \
  storage.googleapis.com \
  secretmanager.googleapis.com \
  run.googleapis.com
```

---

## Step 2: Create Cloud SQL Instance

```bash
# Create PostgreSQL instance (db-f1-micro for cost-effective start)
gcloud sql instances create jobapai-db \
  --database-version=POSTGRES_15 \
  --tier=db-f1-micro \
  --region=us-south1 \
  --root-password=$(openssl rand -base64 32) \
  --storage-type=SSD \
  --storage-size=10GB \
  --backup \
  --backup-start-time=03:00 \
  --maintenance-window-day=SUN \
  --maintenance-window-hour=4

# Create database
gcloud sql databases create jobapai --instance=jobapai-db

# Generate app password
APP_PASSWORD=$(openssl rand -base64 32)
echo "App password: $APP_PASSWORD"

# Create application user
gcloud sql users create jobapai-app \
  --instance=jobapai-db \
  --password=$APP_PASSWORD

# Save connection name
CONNECTION_NAME=$(gcloud sql instances describe jobapai-db --format="value(connectionName)")
echo "Connection name: $CONNECTION_NAME"
```

---

## Step 3: Set Up Cloud SQL Proxy (Local Development)

```bash
# Download Cloud SQL Proxy
curl -o cloud-sql-proxy https://storage.googleapis.com/cloud-sql-connectors/cloud-sql-proxy/v2.8.0/cloud-sql-proxy.linux.amd64
chmod +x cloud-sql-proxy
sudo mv cloud-sql-proxy /usr/local/bin/

# Start proxy (run in separate terminal)
cloud-sql-proxy $CONNECTION_NAME

# Test connection
psql "host=127.0.0.1 port=5432 dbname=jobapai user=jobapai-app password=$APP_PASSWORD"
```

---

## Step 4: Run Database Schema

```bash
# Connect to database
psql "host=127.0.0.1 port=5432 dbname=jobapai user=jobapai-app password=$APP_PASSWORD"

# Run schema files (inside psql)
\i vercel-backend/user_profiles.sql
\i vercel-backend/tracker.sql
\i vercel-backend/supabase.sql

# Verify setup
\i vercel-backend/verify_supabase_setup.sql

# Exit psql
\q
```

---

## Step 5: Create Cloud Storage Bucket

```bash
# Create bucket
gsutil mb -l us-south1 gs://jobapai-user-files

# Set public access prevention
gsutil pap set enforced gs://jobapai-user-files

# Set lifecycle (delete old files after 90 days)
cat > /tmp/lifecycle.json << 'EOF'
{
  "lifecycle": {
    "rule": [
      {
        "action": {"type": "Delete"},
        "condition": {"age": 90}
      }
    ]
  }
}
EOF

gsutil lifecycle set /tmp/lifecycle.json gs://jobapai-user-files

# Set CORS for extension access
cat > /tmp/cors.json << 'EOF'
[
  {
    "origin": ["chrome-extension://*", "http://localhost:*"],
    "method": ["GET", "PUT", "POST"],
    "responseHeader": ["Content-Type", "Content-Disposition"],
    "maxAgeSeconds": 3600
  }
]
EOF

gsutil cors set /tmp/cors.json gs://jobapai-user-files
```

---

## Step 6: Set Up Secrets

```bash
# Store database password in Secret Manager
echo -n "$APP_PASSWORD" | gcloud secrets create db-password --data-file=-

# Get Cloud Run service account
SERVICE_ACCOUNT=$(gcloud run services describe jobapai --region=us-south1 --format="value(spec.template.spec.serviceAccountName)" 2>/dev/null || echo "")

# If no service account, use default
if [ -z "$SERVICE_ACCOUNT" ]; then
  PROJECT_NUMBER=$(gcloud projects describe jobapai --format="value(projectNumber)")
  SERVICE_ACCOUNT="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"
fi

echo "Service account: $SERVICE_ACCOUNT"

# Grant access to secret
gcloud secrets add-iam-policy-binding db-password \
  --member="serviceAccount:$SERVICE_ACCOUNT" \
  --role="roles/secretmanager.secretAccessor"

# Grant Cloud SQL Client role
gcloud projects add-iam-policy-binding jobapai \
  --member="serviceAccount:$SERVICE_ACCOUNT" \
  --role="roles/cloudsql.client"

# Grant Storage Object Admin (for file uploads)
gsutil iam ch serviceAccount:$SERVICE_ACCOUNT:objectAdmin gs://jobapai-user-files
```

---

## Step 7: Configure Identity Platform

```bash
# Enable Identity Platform
gcloud identity toolkit-config update --enable-email-password

# Get configuration for frontend
gcloud alpha iap web get-iam-policy --format=json

# Or via Firebase Console:
# 1. Go to https://console.firebase.google.com
# 2. Select your project
# 3. Go to Authentication > Sign-in method
# 4. Enable Email/Password and Google providers
# 5. Add authorized domains (chrome-extension://* won't work here, add via console)
# 6. Get Web API Key from Project Settings
```

**Get Firebase Config:**

```bash
# Install firebase-tools
npm install -g firebase-tools

# Login
firebase login

# Get config
firebase projects:list
firebase apps:list --project=jobapai

# Add a web app if needed
firebase apps:create web jobapai-extension --project=jobapai

# Get config
firebase apps:sdkconfig web --project=jobapai
```

---

## Step 8: Update Cloud Run Service

```bash
# Update Cloud Run to connect to Cloud SQL and use secrets
gcloud run services update jobapai \
  --region=us-south1 \
  --add-cloudsql-instances=$CONNECTION_NAME \
  --set-env-vars="DB_HOST=/cloudsql/$CONNECTION_NAME" \
  --set-env-vars="DB_USER=jobapai-app" \
  --set-env-vars="DB_NAME=jobapai" \
  --set-env-vars="DB_PORT=5432" \
  --set-env-vars="GOOGLE_CLOUD_PROJECT=jobapai" \
  --set-env-vars="STORAGE_BUCKET=jobapai-user-files" \
  --update-secrets=DB_PASSWORD=db-password:latest
```

---

## Step 9: Deploy Backend

```bash
cd vercel-backend

# Install dependencies
npm install

# Build
npm run build

# Deploy (if not already deployed)
gcloud run deploy jobapai \
  --source . \
  --region=us-south1 \
  --platform=managed \
  --allow-unauthenticated \
  --add-cloudsql-instances=$CONNECTION_NAME \
  --set-env-vars="DB_HOST=/cloudsql/$CONNECTION_NAME,DB_USER=jobapai-app,DB_NAME=jobapai,DB_PORT=5432,GOOGLE_CLOUD_PROJECT=jobapai,STORAGE_BUCKET=jobapai-user-files" \
  --update-secrets=DB_PASSWORD=db-password:latest
```

---

## Step 10: Verify Setup

```bash
# Test database connection
cloud-sql-proxy $CONNECTION_NAME &
psql "host=127.0.0.1 port=5432 dbname=jobapai user=jobapai-app password=$APP_PASSWORD" -c "SELECT COUNT(*) FROM user_profiles;"

# Test Cloud Run health
CLOUD_RUN_URL=$(gcloud run services describe jobapai --region=us-south1 --format="value(status.url)")
curl $CLOUD_RUN_URL/api/health

# Test storage bucket
echo "test" > /tmp/test.txt
gsutil cp /tmp/test.txt gs://jobapai-user-files/test.txt
gsutil rm gs://jobapai-user-files/test.txt
```

---

## Cost Optimization Tips

**Reduce Cloud SQL costs:**

```bash
# Stop instance when not in use (dev only)
gcloud sql instances patch jobapai-db --activation-policy=NEVER

# Start when needed
gcloud sql instances patch jobapai-db --activation-policy=ALWAYS
```

**Monitor costs:**

```bash
# Set up billing budget alert
gcloud billing budgets create \
  --billing-account=YOUR_BILLING_ACCOUNT_ID \
  --display-name="JobAp AI Monthly Budget" \
  --budget-amount=30USD \
  --threshold-rule=percent=50 \
  --threshold-rule=percent=90
```

---

## Environment Variables Summary

**For Cloud Run:**

- `DB_HOST`: `/cloudsql/jobapai:us-south1:jobapai-db`
- `DB_USER`: `jobapai-app`
- `DB_NAME`: `jobapai`
- `DB_PORT`: `5432`
- `DB_PASSWORD`: (from Secret Manager)
- `GOOGLE_CLOUD_PROJECT`: `jobapai`
- `STORAGE_BUCKET`: `jobapai-user-files`

**For Local Development:**

- `DB_HOST`: `127.0.0.1`
- `DB_USER`: `jobapai-app`
- `DB_NAME`: `jobapai`
- `DB_PORT`: `5432`
- `DB_PASSWORD`: (your app password)
- `GOOGLE_APPLICATION_CREDENTIALS`: `/path/to/service-account-key.json`
- `STORAGE_BUCKET`: `jobapai-user-files`

---

## Troubleshooting

**Connection refused:**

- Ensure Cloud SQL Proxy is running
- Check firewall rules
- Verify service account has `cloudsql.client` role

**Authentication errors:**

- Verify Firebase config in frontend
- Check ID token is being sent in Authorization header
- Ensure service account has proper IAM roles

**Storage upload errors:**

- Verify CORS configuration
- Check IAM permissions on bucket
- Ensure signed URLs are not expired

