# Onboarding 30% Threshold & Tracker Redirect

## Summary

Updated onboarding to mark completion at **30% profile completeness** instead of 100%, and redirect users to the **tracker page** after successful onboarding.

## Changes Made

### 1. **Profile Completeness Calculation**

**File:** `profile-setup.js`

Added a function to calculate profile completeness percentage:

```javascript
function calculateCompleteness(data) {
  const fields = [
    data.fullName,
    data.email,
    data.phone,
    data.location,
    data.linkedIn,
    data.portfolio,
    data.github,
    data.currentRole,
    data.yearsExperience,
    data.degree,
    data.major,
    data.university,
    data.gradYear,
    data.workAuthorization,
    data.jobTypes?.length > 0 ? 'yes' : '',
    data.skills?.length > 0 ? 'yes' : '',
    data.summary,
    cvText,
  ];

  const filledFields = fields.filter((f) => f && String(f).trim()).length;
  const totalFields = fields.length;
  const percentage = Math.round((filledFields / totalFields) * 100);

  console.log(
    `[ProfileSetup] Profile completeness: ${percentage}% (${filledFields}/${totalFields} fields)`
  );
  return percentage;
}
```

**Fields Counted (18 total):**

1. Full Name
2. Email
3. Phone
4. Location
5. LinkedIn
6. Portfolio
7. GitHub
8. Current Role
9. Years Experience
10. Degree
11. Major
12. University
13. Graduation Year
14. Work Authorization
15. Job Types (array)
16. Skills (array)
17. Professional Summary
18. CV Text

### 2. **30% Threshold Logic**

**File:** `profile-setup.js`

```javascript
async function finishSetup(skipped = false) {
  if (!skipped) {
    const data = collectProfileData();
    const profile = createInitialProfile(data);

    // Calculate completeness
    const completeness = calculateCompleteness(data);
    const isComplete = completeness >= 30; // 30% threshold

    // Save profile...

    // Mark onboarding as complete locally if >= 30%
    await chrome.storage.local.set({
      onboardingComplete: isComplete,
      profileCompleteness: completeness,
    });

    console.log(
      `[ProfileSetup] Onboarding ${
        isComplete ? 'complete' : 'incomplete'
      } (${completeness}%)`
    );
  }
}
```

### 3. **Backend Sync with Completeness**

**File:** `profile-setup.js`

Now sends completeness data to backend:

```javascript
const payload = {
  profile: {
    // ... all profile fields ...
    onboardingComplete: isComplete, // true if >= 30%
    completenessScore: completeness, // actual percentage
  },
  customAnswers: [ ... ]
};
```

### 4. **Redirect to Tracker Page**

**File:** `profile-setup.js`

After onboarding completion, redirects to tracker:

```javascript
// Redirect to tracker page if complete, otherwise sidepanel
const targetPage = !skipped && isComplete ? 'tracker.html' : 'sidepanel.html';

// Check if tracker.html exists, fallback to opening tracker URL
try {
  const trackerUrl = chrome.runtime.getURL('tracker.html');
  const response = await fetch(trackerUrl);
  if (response.ok && !skipped && isComplete) {
    window.location.href = 'tracker.html';
  } else {
    // Tracker.html doesn't exist, open tracker page in new tab
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await resp.json();
    const base = (cfg?.apiBaseUrl || '').replace(/\/$/, '');
    if (base && !skipped && isComplete) {
      chrome.tabs.create({ url: `${base}/tracker` });
    }
    window.location.href = 'sidepanel.html';
  }
} catch (e) {
  // Fallback to sidepanel
  window.location.href = 'sidepanel.html';
}
```

### 5. **Sidepanel Checks Completeness**

**File:** `sidepanel.js`

Updated to check completeness score:

```javascript
async function checkOnboardingStatus() {
  // Check local storage first
  const { onboardingComplete, profileCompleteness } =
    await chrome.storage.local.get([
      'onboardingComplete',
      'profileCompleteness',
    ]);

  if (onboardingComplete === true) {
    console.log(
      `[Sidepanel] Onboarding complete (${profileCompleteness || 'unknown'}%)`
    );
    return true;
  }

  // Check backend
  const profile = await fetchProfile();

  // Check if completeness >= 30%
  if (profile?.completeness_score >= 30) {
    console.log(
      `[Sidepanel] Profile completeness >= 30% (${profile.completeness_score}%)`
    );
    await chrome.storage.local.set({
      onboardingComplete: true,
      profileCompleteness: profile.completeness_score,
    });
    return true;
  }

  return false;
}
```

## How It Works

### Scenario 1: Minimal Profile (30% - 6 fields)

User fills out:

- ✅ Full Name
- ✅ Email
- ✅ Phone
- ✅ Location
- ✅ LinkedIn
- ✅ CV Upload

**Result:**

- Completeness: 33% (6/18 fields)
- Onboarding: ✅ **Complete**
- Redirect: → **Tracker Page**

### Scenario 2: Partial Profile (50% - 9 fields)

User fills out:

- ✅ Full Name
- ✅ Email
- ✅ Phone
- ✅ Location
- ✅ LinkedIn
- ✅ Current Role
- ✅ Years Experience
- ✅ Skills
- ✅ CV Upload

**Result:**

- Completeness: 50% (9/18 fields)
- Onboarding: ✅ **Complete**
- Redirect: → **Tracker Page**

### Scenario 3: Incomplete Profile (< 30% - 5 fields)

User fills out:

- ✅ Full Name
- ✅ Email
- ✅ Phone
- ✅ Location
- ✅ LinkedIn

**Result:**

- Completeness: 28% (5/18 fields)
- Onboarding: ❌ **Incomplete**
- Redirect: → **Sidepanel** (will redirect back to onboarding on next load)

### Scenario 4: Full Profile (100% - 18 fields)

User fills out all fields.

**Result:**

- Completeness: 100% (18/18 fields)
- Onboarding: ✅ **Complete**
- Redirect: → **Tracker Page**

## Benefits

### 1. **Lower Barrier to Entry** ✅

- Users don't need to fill out 100% of fields
- Can start using the app faster
- Less friction in onboarding

### 2. **Flexible Completion** ✅

- 30% = ~6 fields (bare minimum)
- Most users will exceed this easily
- Can always complete profile later

### 3. **Better UX** ✅

- Redirects to tracker page (main feature)
- Shows user where to start applying
- Immediate value after onboarding

### 4. **Smart Tracking** ✅

- Stores completeness percentage
- Can show progress bar later
- Backend tracks completion status

## Completeness Calculation

### Minimum to Complete (30% = 6 fields)

**Essential Fields (recommended):**

1. Full Name ⭐
2. Email ⭐
3. Phone ⭐
4. Location ⭐
5. LinkedIn ⭐
6. CV Upload ⭐

**OR any combination of 6+ fields from:**

- Portfolio URL
- GitHub URL
- Current Role
- Years Experience
- Degree
- Major
- University
- Graduation Year
- Work Authorization
- Job Types
- Skills
- Professional Summary

## Testing

### Test Case 1: Minimum Profile

1. Upload CV
2. Fill: Name, Email, Phone, Location, LinkedIn
3. Click "Finish Setup"
4. Should show: "33% complete, onboarding complete"
5. Should redirect to tracker page ✅

### Test Case 2: Skip Most Fields

1. Upload CV only
2. Fill: Name, Email
3. Click "Finish Setup"
4. Should show: "17% complete, onboarding incomplete"
5. Should redirect to sidepanel
6. Next load: redirects back to onboarding ✅

### Test Case 3: Full Profile

1. Fill all 18 fields
2. Click "Finish Setup"
3. Should show: "100% complete, onboarding complete"
4. Should redirect to tracker page ✅

### Test Case 4: Check Console Logs

```
[ProfileSetup] Profile completeness: 33% (6/18 fields)
[ProfileSetup] Profile saved successfully (33% complete, onboarding: complete)
[ProfileSetup] Syncing profile to database...
[ProfileSetup] Profile synced to database with onboarding completed
[ProfileSetup] Onboarding complete (33%), redirecting to tracker
```

## Tracker Page Redirect

### If `tracker.html` exists:

```
✅ Redirects to tracker.html (local extension page)
```

### If `tracker.html` doesn't exist:

```
✅ Opens tracker page in new tab: https://your-backend.com/tracker
✅ Redirects sidepanel to sidepanel.html
```

### Fallback:

```
✅ Always falls back to sidepanel.html if anything fails
```

## Backend Integration

The backend should handle:

1. **Save completeness score:**

```typescript
{
  completeness_score: 33,
  onboarding_completed: true
}
```

2. **Return completeness on GET:**

```typescript
{
  profile: {
    completeness_score: 33,
    onboarding_completed: true,
    ...
  }
}
```

3. **Update onboarding_completed based on threshold:**

```typescript
if (profile.completeness_score >= 30) {
  profile.onboarding_completed = true;
}
```

## Future Improvements

1. **Progress Bar**

   - Show completeness percentage in UI
   - Visual indicator of profile completion
   - Encourage users to complete more fields

2. **Smart Suggestions**

   - "Complete 3 more fields to reach 50%"
   - Highlight important missing fields
   - Gamification elements

3. **Adjustable Threshold**

   - Admin can change 30% threshold
   - Different thresholds for different user types
   - A/B test optimal threshold

4. **Field Weighting**
   - Some fields worth more than others
   - CV upload = 20%, Name = 5%, etc.
   - More accurate completeness calculation
