/**
 * Profile Setup Wizard for JobApAI
 * Handles multi-step profile collection and CV extraction
 */

import {
  createInitialProfile,
  saveUserProfile,
  extractProfileFromCV,
} from './profile-utils.js';
import {
  syncProfileToDatabase,
  saveCustomAnswer,
  getCachedAnswer,
} from './profile-sync.js';

// Current step
let currentStep = 1; // Start at Welcome
const totalSteps = 6; // Upload integrated into Step 2; old Step 4 removed

// Extracted profile data
let extractedProfile = null;
let cvText = '';

// Get CONFIG
let CONFIG = null;

function resolveRrBase(cfg = CONFIG) {
  return (
    cfg?.rrApiBaseUrl ||
    cfg?.rrProductionApiBaseUrl ||
    cfg?.activeRrBaseUrl ||
    ''
  ).replace(/\/$/, '');
}
(async () => {
  try {
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    CONFIG = await resp.json();
  } catch (e) {
    console.error('[ProfileSetup] Error loading config:', e);
  }
})();
// Interview Templates: dynamic inputs + save to custom answers
function setupInterviewTemplates() {
  const container = document.getElementById('interviewTemplates');
  if (!container) return;

  const cards = Array.from(container.querySelectorAll('.question-card'));
  cards.forEach(async (card) => {
    const ta = card.querySelector('textarea.field-input');
    if (!ta) return;

    const question = ta.getAttribute('data-question') || '';
    const statusEl = card.querySelector('.question-status');

    // Prefill from cache
    try {
      const cache = await getCachedAnswer(question);
      if (cache?.found && cache.answer) {
        ta.value = cache.answer;
        if (statusEl) statusEl.style.display = 'flex';
      }
    } catch (_) {}

    // Save on blur and debounce on input
    let saveTimer = null;
    const doSave = async () => {
      const val = ta.value.trim();
      if (!val) {
        if (statusEl) statusEl.style.display = 'none';
        return;
      }
      if (statusEl) {
        statusEl.textContent = 'Saving…';
        statusEl.style.display = 'flex';
      }
      const r = await saveCustomAnswer(question, val, 'interview_template');
      if (statusEl) {
        statusEl.textContent = r?.success ? 'Saved' : 'Save failed';
      }
    };
    ta.addEventListener('blur', doSave);
    ta.addEventListener('input', () => {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(doSave, 800);
    });
  });
}

// Heuristic: derive a clean full name from CV/header/links if AI returns noisy value
function deriveFullName(cv, aiName = '', email = '', linkedIn = '') {
  const titleCase = (s) =>
    s
      .toLowerCase()
      .split(/[^a-zA-Z]+/)
      .filter(Boolean)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');

  // 1) If LinkedIn handle looks like a name
  if (linkedIn) {
    const m = linkedIn.match(/linkedin\.com\/in\/([a-z0-9\-_%]+)/i);
    if (m && m[1]) {
      const cand = titleCase(m[1].replace(/[-_%]+/g, ' '));
      if (cand.split(' ').length >= 2 && cand.length <= 40) return cand;
    }
  }
  // 2) If email local-part looks like firstname.lastname
  if (email) {
    const local = String(email).split('@')[0];
    if (local && /[a-z]/i.test(local)) {
      const cand = titleCase(local.replace(/[._-]+/g, ' '));
      if (cand.split(' ').length >= 2 && cand.length <= 40) return cand;
    }
  }
  // 3) First non-empty line: take leading capitalized tokens until a lowercase word appears
  const firstLine =
    (cv || '').split(/\n+/).find((l) => l.trim().length > 0) || '';
  const tokens = firstLine.trim().split(/\s+/);
  const picked = [];
  for (const t of tokens) {
    if (/^[A-Z][a-z]+/.test(t)) picked.push(t.replace(/[^a-zA-Z]/g, ''));
    else break;
    if (picked.length >= 4) break; // cap
  }
  if (picked.length >= 2) return picked.join(' ');

  // 4) Fallback to aiName cleaned
  if (aiName) {
    const cleaned = aiName.replace(/[,|].*$/, '').trim();
    const parts = cleaned.split(/\s+/).slice(0, 4);
    return parts.join(' ');
  }
  return '';
}

// Event delegation for all buttons with data-action
document.addEventListener('click', (e) => {
  const target = e.target.closest('[data-action]');
  if (!target) return;

  e.preventDefault();
  const action = target.getAttribute('data-action');

  console.log('[ProfileSetup] Button clicked:', action);

  // Call the appropriate function
  const actionMap = {
    nextStep: () => nextStep(),
    prevStep: () => prevStep(),
    gotoResume: () => gotoResumeUpload(),
    skipSetup: () => skipSetup(),
    skipCV: () => skipCV(),
    skipPreferences: () => skipPreferences(),
    skipCommonQuestions: () => skipCommonQuestions(),
    finishSetup: () => finishSetup(),
    editProfile: () => editProfile(),
  };

  if (actionMap[action]) {
    try {
      actionMap[action]();
    } catch (error) {
      console.error('[ProfileSetup] Error executing action:', action, error);
    }
  } else {
    console.warn('[ProfileSetup] Unknown action:', action);
  }
});

// Step navigation
function nextStep() {
  if (currentStep < totalSteps) {
    // Validate current step
    if (!validateStep(currentStep)) {
      return;
    }

    currentStep++;
    showStep(currentStep);
    updateProgress();
  }
}

function prevStep() {
  if (currentStep > 1) {
    currentStep--;
    showStep(currentStep);
    updateProgress();
  }
}

function showStep(step) {
  // Hide all steps
  document.querySelectorAll('.step-container').forEach((el) => {
    el.classList.remove('active');
  });

  // Show current step
  const stepEl = document.getElementById(`step${step}`);
  if (stepEl) {
    stepEl.classList.add('active');
  }

  // Initialize dynamic UI when entering Common Questions (step 5)
  if (step === 5) {
    console.log('[ProfileSetup] Entered Step 5 (Common Questions).', {
      cvLen: (cvText || '').length,
      hasExtractedProfile: !!extractedProfile,
    });
    setupInterviewTemplates();
    // Interactive generation removed; background generation remains
    const manualBtn = document.getElementById('manualGenBtn');
    if (manualBtn) {
      manualBtn.onclick = async () => {
        try {
          manualBtn.disabled = true;
          await aiGenerateInterviewAnswers();
        } finally {
          manualBtn.disabled = false;
        }
      };
    }
  }

  // Special handling for final step
  if (step === 6) {
    showProfileSummary();
  }

  // If on resume step (now Step 2), pre-fill status and allow reuse
  if (step === 2) {
    // If we already have a stored userCV, reflect that in UI
    chrome.storage.local.get(['userCV']).then((res) => {
      if (res?.userCV && uploadStatus) {
        cvText = res.userCV;
        const wordCount = cvText.split(/\s+/).filter(Boolean).length;
        const charCount = cvText.length;

        uploadStatus.innerHTML = `
          <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 16px; margin-top: 16px;">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
              <span style="font-size: 20px;">✅</span>
              <strong style="color: #16a34a;">Resume Already Uploaded</strong>
            </div>
            <p style="color: #15803d; margin: 8px 0; font-size: 14px;">
              Your resume is saved and ready to use (${wordCount} words, ${charCount} characters)
            </p>
            <p style="color: #15803d; margin: 0; font-size: 13px;">
              💡 You can continue to the next step or upload a different resume if needed.
            </p>
          </div>
        `;

        // Enable next button
        const nextBtn = document.querySelector('#step2 .btn.btn-primary');
        if (nextBtn) nextBtn.disabled = false;

        console.log(
          `[ProfileSetup] Reusing saved CV (${charCount} characters, ${wordCount} words)`
        );
      }
    });
  }
}

function gotoResumeUpload() {
  console.log('[ProfileSetup] Navigating to resume upload (Step 2)');
  currentStep = 2; // Jump to Step 2 (now includes resume upload)
  showStep(currentStep);
  updateProgress();
}

function updateProgress() {
  const progress = (currentStep / totalSteps) * 100;
  const progressFill = document.getElementById('progressFill');
  if (progressFill) {
    progressFill.style.width = progress + '%';
  }
}

function validateStep(step) {
  if (step === 2) {
    // Validate basic info
    const fullName = document.getElementById('fullName').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const location = document.getElementById('location').value.trim();

    if (!fullName || !email || !phone || !location) {
      alert('Please fill in all required fields');
      return false;
    }

    // Basic email validation
    if (!email.includes('@')) {
      alert('Please enter a valid email');
      return false;
    }
  }

  if (step === 3) {
    // Validate work authorization
    const workAuth = document.getElementById('workAuth').value;
    if (!workAuth) {
      alert('Please select your work authorization status');
      return false;
    }
  }

  return true;
}

// CV Upload handling
const uploadZone = document.getElementById('uploadZone');
const cvFileInput = document.getElementById('cvFile');
const uploadStatus = document.getElementById('uploadStatus');
const confirmModal = document.getElementById('confirmModal');
const confirmFullName = document.getElementById('confirmFullName');
const confirmEmail = document.getElementById('confirmEmail');
const confirmPhone = document.getElementById('confirmPhone');
const confirmLocation = document.getElementById('confirmLocation');
const confirmLinkedIn = document.getElementById('confirmLinkedIn');
const confirmCancelBtn = document.getElementById('confirmCancelBtn');
const confirmSaveBtn = document.getElementById('confirmSaveBtn');

if (uploadZone && cvFileInput) {
  // Click to upload
  uploadZone.addEventListener('click', () => {
    cvFileInput.click();
  });

  // Drag and drop
  uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.classList.add('dragging');
  });

  uploadZone.addEventListener('dragleave', () => {
    uploadZone.classList.remove('dragging');
  });

  uploadZone.addEventListener('drop', async (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragging');

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      await handleCVUpload(files[0]);
    }
  });

  // File input change
  cvFileInput.addEventListener('change', async (e) => {
    if (e.target.files.length > 0) {
      await handleCVUpload(e.target.files[0]);
    }
  });
}

async function handleCVUpload(file) {
  try {
    // Check if replacing existing CV
    const { userCV } = await chrome.storage.local.get(['userCV']);
    const isReplacing = !!userCV;

    uploadStatus.textContent = isReplacing
      ? '🔄 Replacing resume and extracting profile...'
      : 'Uploading and extracting profile...';
    uploadStatus.style.color = '#6366f1';

    // Read file
    const text = await readFile(file);
    cvText = text;

    if (isReplacing) {
      console.log(
        `[ProfileSetup] Replacing existing CV with new upload (${text.length} characters)`
      );
    }

    uploadStatus.textContent = '✨ Extracting profile with AI...';

    // Extract profile using AI (Gemini 2.5 Flash Lite for speed and accuracy)
    const profile = await extractProfileFromCV(
      text,
      CONFIG?.apiBaseUrl,
      'gemini-2.5-flash-lite'
    );

    extractedProfile = profile;

    // Pre-fill fields
    const derivedName = deriveFullName(
      cvText,
      profile.fullName || '',
      profile.email || '',
      profile.linkedIn || ''
    );
    if (derivedName) document.getElementById('fullName').value = derivedName;
    else if (profile.fullName)
      document.getElementById('fullName').value = profile.fullName;
    if (profile.email) document.getElementById('email').value = profile.email;
    if (profile.phone) document.getElementById('phone').value = profile.phone;
    if (profile.location)
      document.getElementById('location').value = profile.location;
    if (profile.linkedIn)
      document.getElementById('linkedIn').value = profile.linkedIn;
    if (profile.portfolio)
      document.getElementById('portfolio').value = profile.portfolio;
    if (profile.github)
      document.getElementById('github').value = profile.github;
    if (profile.currentRole)
      document.getElementById('currentRole').value = profile.currentRole;
    if (profile.yearsExperience)
      document.getElementById('yearsExperience').value =
        profile.yearsExperience;
    if (profile.highestDegree)
      document.getElementById('degree').value = profile.highestDegree;
    if (profile.fieldOfStudy)
      document.getElementById('major').value = profile.fieldOfStudy;
    if (profile.university)
      document.getElementById('university').value = profile.university;
    if (profile.graduationYear)
      document.getElementById('gradYear').value = profile.graduationYear;

    // Show extracted data
    showExtractedProfile(profile);

    uploadStatus.textContent = '✅ Profile extracted successfully!';
    uploadStatus.style.color = '#10b981';

    // Persist CV for reuse and backend sync later
    try {
      console.log(
        `[ProfileSetup] Saving CV text (${cvText.length} characters)`
      );
      await chrome.storage.local.set({ userCV: cvText });
      console.log('[ProfileSetup] CV text saved successfully');
    } catch (error) {
      console.error('[ProfileSetup] Error saving CV text:', error);
    }

    // Kick off background generation of common interview answers
    try {
      generateInterviewAnswersInBackground();
    } catch (e) {
      console.warn(
        '[ProfileSetup] Could not start background interview generation:',
        e
      );
    }

    // Enable continue button; stay on this page (no modal, no auto-advance)
    const nextBtn = document.getElementById('cvNextBtn');
    if (nextBtn) nextBtn.disabled = false;
    if (confirmModal) confirmModal.style.display = 'none';
  } catch (e) {
    console.error('[ProfileSetup] CV upload error:', e);
    uploadStatus.textContent = '❌ Error extracting profile. Please try again.';
    uploadStatus.style.color = '#ef4444';
  }
}

function showExtractedProfile(profile) {
  const container = document.getElementById('aiExtraction');
  const dataEl = document.getElementById('extractedData');

  if (!container || !dataEl) return;

  let html = '';
  if (profile.professionalSummary) {
    html += `<p style="margin: 0 0 12px 0; font-size: 14px; color: #666;">${profile.professionalSummary}</p>`;
  }
  if (profile.topSkills && profile.topSkills.length > 0) {
    html +=
      '<div style="margin-bottom: 12px;"><strong style="font-size: 13px; color: #333;">Skills:</strong><br>';
    profile.topSkills.forEach((skill) => {
      html += `<span class="skill-tag">${skill}</span>`;
    });
    html += '</div>';
  }
  if (profile.yearsExperience) {
    html += `<p style="margin: 4px 0; font-size: 13px; color: #666;"><strong>Experience:</strong> ${profile.yearsExperience} years</p>`;
  }
  if (profile.highestDegree) {
    html += `<p style="margin: 4px 0; font-size: 13px; color: #666;"><strong>Education:</strong> ${profile.highestDegree}`;
    if (profile.university) html += ` from ${profile.university}`;
    html += '</p>';
  }
  dataEl.innerHTML = html;
  container.style.display = 'block';
}

function openConfirmModal() {
  if (!confirmModal) return;
  // Sync inputs from current form values
  if (confirmFullName)
    confirmFullName.value = document.getElementById('fullName')?.value || '';
  if (confirmEmail)
    confirmEmail.value = document.getElementById('email')?.value || '';
  if (confirmPhone)
    confirmPhone.value = document.getElementById('phone')?.value || '';
  if (confirmLocation)
    confirmLocation.value = document.getElementById('location')?.value || '';
  if (confirmLinkedIn)
    confirmLinkedIn.value = document.getElementById('linkedIn')?.value || '';

  confirmModal.style.display = 'flex';

  if (confirmCancelBtn) {
    confirmCancelBtn.onclick = () => {
      confirmModal.style.display = 'none';
    };
  }
  if (confirmSaveBtn) {
    confirmSaveBtn.onclick = () => {
      // Write back edits
      if (confirmFullName)
        document.getElementById('fullName').value = confirmFullName.value;
      if (confirmEmail)
        document.getElementById('email').value = confirmEmail.value;
      if (confirmPhone)
        document.getElementById('phone').value = confirmPhone.value;
      if (confirmLocation)
        document.getElementById('location').value = confirmLocation.value;
      if (confirmLinkedIn)
        document.getElementById('linkedIn').value = confirmLinkedIn.value;

      confirmModal.style.display = 'none';
      // Advance to next step (Basic Information now confirmed)
      currentStep = 2; // ensure we are at Basic Info
      nextStep();
    };
  }
}

async function readFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = async (e) => {
      const arrayBuffer = e.target.result;

      if (file.type === 'application/pdf') {
        // Parse PDF
        try {
          const text = await parsePDF(arrayBuffer);
          resolve(text);
        } catch (err) {
          reject(err);
        }
      } else if (file.type.includes('word') || file.name.endsWith('.docx')) {
        // For now, just reject DOCX (would need mammoth.js)
        reject(
          new Error('DOCX parsing not yet supported. Please use PDF or TXT.')
        );
      } else {
        // Plain text
        const text = new TextDecoder().decode(arrayBuffer);
        resolve(text);
      }
    };

    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(file);
  });
}

async function parsePDF(arrayBuffer) {
  // Use PDF.js if available
  if (typeof pdfjsLib !== 'undefined') {
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';

    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item) => item.str).join(' ');
      fullText += pageText + '\n';
    }

    return fullText;
  } else {
    throw new Error('PDF.js not loaded');
  }
}

// Skip functions
async function skipSetup() {
  // Mark onboarding as skipped (incomplete) and close the tab
  await chrome.storage.local.set({
    onboardingComplete: false,
    profileCompleteness: 0,
  });
  console.log('[ProfileSetup] Skipped setup, closing tab');

  // Try window.close() first, fall back to chrome.tabs API
  try {
    window.close();
  } catch (_) {}

  // If window.close() didn't work (e.g., tab wasn't opened by script), use chrome.tabs
  setTimeout(async () => {
    try {
      const tab = await chrome.tabs.getCurrent();
      if (tab?.id) {
        await chrome.tabs.remove(tab.id);
      }
    } catch (e) {
      console.warn('[ProfileSetup] Could not close tab:', e);
    }
  }, 100);
}

function skipCV() {
  document.getElementById('cvNextBtn').disabled = false;
}

function skipPreferences() {
  nextStep();
}

function skipCommonQuestions() {
  nextStep();
}

// Show profile summary
function showProfileSummary() {
  const summaryEl = document.getElementById('profileSummary');
  if (!summaryEl) return;

  const data = collectProfileData();

  let html =
    '<h3 style="margin: 0 0 16px 0; font-size: 16px; color: #333;">Your Profile</h3>';

  if (data.fullName) {
    html += `<p style="margin: 8px 0; font-size: 14px;"><strong>Name:</strong> ${data.fullName}</p>`;
  }
  if (data.email) {
    html += `<p style="margin: 8px 0; font-size: 14px;"><strong>Email:</strong> ${data.email}</p>`;
  }
  if (data.location) {
    html += `<p style="margin: 8px 0; font-size: 14px;"><strong>Location:</strong> ${data.location}</p>`;
  }
  if (data.workAuthorization) {
    html += `<p style="margin: 8px 0; font-size: 14px;"><strong>Work Auth:</strong> ${data.workAuthorization}</p>`;
  }
  if (data.jobTypes && data.jobTypes.length > 0) {
    html += `<p style="margin: 8px 0; font-size: 14px;"><strong>Job Types:</strong> ${data.jobTypes.join(
      ', '
    )}</p>`;
  }
  if (extractedProfile?.topSkills && extractedProfile.topSkills.length > 0) {
    html += `<p style="margin: 8px 0; font-size: 14px;"><strong>Skills:</strong> ${extractedProfile.topSkills
      .slice(0, 5)
      .join(', ')}</p>`;
  }

  // Display interview answers
  if (data.interviewAnswers && data.interviewAnswers.length > 0) {
    html += `<p style="margin: 16px 0 8px 0; font-size: 14px; font-weight: 600;">Interview Questions Answered: ${data.interviewAnswers.length}</p>`;
    html +=
      '<div style="max-height: 200px; overflow-y: auto; padding: 8px; background: #f9fafb; border-radius: 8px;">';
    data.interviewAnswers.forEach((qa, idx) => {
      html += `<p style="margin: 4px 0; font-size: 13px;"><strong>${idx + 1}. ${
        qa.question
      }:</strong> ${qa.answer.slice(0, 100)}${
        qa.answer.length > 100 ? '...' : ''
      }</p>`;
    });
    html += '</div>';
  }

  summaryEl.innerHTML = html;

  // Calculate and show completeness
  const completeness = calculateCompleteness(data);
  const badge = document.getElementById('completenessPercent');
  if (badge) {
    badge.textContent = completeness + '% Complete';
  }
}

// Manual trigger: run the same background generation pipeline on demand
async function aiGenerateInterviewAnswers() {
  try {
    const statusEl = document.getElementById('interviewGenStatus');
    const statusText = statusEl?.querySelector('.status-text');
    if (statusEl) {
      statusEl.style.display = 'block';
      statusEl.className = 'status-banner loading';
      if (statusText) statusText.textContent = 'Generating answers with AI…';
    }

    // Reuse the robust background generator to avoid duplicate logic
    await generateInterviewAnswersInBackground();
  } catch (e) {
    console.error('[ProfileSetup] AI generate interview answers error:', e);
    const statusEl = document.getElementById('interviewGenStatus');
    const statusText = statusEl?.querySelector('.status-text');
    if (statusEl && statusText)
      statusText.textContent = 'Generation failed. Please try again.';
  }
}

let interviewAutoGenerated = false;
async function maybeAutoGenerateInterviewAnswers() {
  try {
    if (interviewAutoGenerated) return;
    // Ensure we have CV text available
    if (!cvText) {
      const res = await chrome.storage.local.get('userCV');
      cvText = res?.userCV || '';
    }
    if (!cvText || cvText.trim().length < 100) {
      const statusEl = document.getElementById('interviewGenStatus');
      if (statusEl)
        statusEl.textContent = 'Upload your resume to auto-generate answers.';
      return;
    }
    interviewAutoGenerated = true;
    await aiGenerateInterviewAnswers();
  } catch (e) {
    console.error('[ProfileSetup] maybeAutoGenerateInterviewAnswers error:', e);
  }
}

// Background task: generate canonical interview answers after CV upload
async function generateInterviewAnswersInBackground() {
  try {
    const statusEl = document.getElementById('interviewGenStatus');
    const statusText = statusEl?.querySelector('.status-text');

    if (statusEl) {
      statusEl.style.display = 'block';
      statusEl.className = 'status-banner loading';
      if (statusText) statusText.textContent = 'Preparing interview answers…';
    }

    // Ensure we have CV
    if (!cvText) {
      const res = await chrome.storage.local.get('userCV');
      cvText = res?.userCV || '';
    }

    // Collect questions from DOM (they exist even if step 5 not active)
    const container = document.getElementById('interviewTemplates');
    const areas = Array.from(
      container?.querySelectorAll('textarea.field-input[data-question]') || []
    );
    if (areas.length === 0) return;

    const formText = areas
      .map((ta, idx) => {
        const q = ta.getAttribute('data-question') || `Question ${idx + 1}`;
        return `FIELD: type=textarea name=q${idx + 1} id=q${
          idx + 1
        } label=${q}`;
      })
      .join('\n');

    const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
    if (!base) return;

    const role = (document.getElementById('currentRole')?.value || '').trim();
    const skills = Array.isArray(extractedProfile?.topSkills)
      ? extractedProfile.topSkills.slice(0, 10).join(', ')
      : '';
    const jobDescriptionText = `Interview preparation for role: ${
      role || 'General Professional'
    }.\nSkills/context: ${skills || 'N/A'}.`;

    const payload = {
      cvText: cvText,
      jobDescriptionText,
      formText,
      modelId: 'gemini-2.5-flash-lite',
    };

    // Get auth token (Firebase first, RR fallback)
    const sessionData = await chrome.storage.sync.get(['firebaseSession']);
    let token = sessionData.firebaseSession?.access_token || '';
    if (!token) {
      const localToken = await chrome.storage.local
        .get('rrAuthToken')
        .catch(() => ({}));
      token = localToken?.rrAuthToken || '';
    }

    if (!token) {
      console.warn('[ProfileSetup] Missing auth token for AI generation');
      if (statusEl && statusText) {
        statusEl.className = 'status-banner error';
        statusText.textContent = 'Please sign in to generate answers.';
      }
      return;
    }

    const res = await fetch(`${base}/v1/analyze-form`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      credentials: 'include',
      body: JSON.stringify(payload),
    });

    if (res.status === 401) {
      if (statusEl && statusText) {
        statusEl.className = 'status-banner error';
        statusText.textContent = 'Session expired. Please sign in again.';
      }
      throw new Error('Unauthorized');
    }

    // Robust parse (text -> JSON with fallback recovery)
    let raw = await res.text();
    // Pre-clean common wrappers like Markdown code fences and broken separators
    raw = raw
      .replace(/```+[a-zA-Z]*\n?/g, '')
      .replace(/```/g, '')
      // Fix missing commas between adjacent objects: '}{' or newline separated
      .replace(/\}\s*\n\s*\{/g, '},{')
      // Fix dash/• between objects
      .replace(/\}(\s*[-•–—]\s*)\{/g, '},{')
      .trim();
    let data = {};
    try {
      data = JSON.parse(raw);
    } catch (e) {
      console.log(
        '[ProfileSetup] JSON parse failed, attempting recovery...',
        e.message
      );

      // Try multiple recovery strategies
      let recovered = false;

      // Strategy 1: Extract and clean JSON
      try {
        const match = raw.match(/\{[\s\S]*\}/);
        if (match) {
          let hopeful = match[0];
          // Same separator fixes inside the object
          hopeful = hopeful
            .replace(/\}\s*\n\s*\{/g, '},{')
            .replace(/\}(\s*[-•–—]\s*)\{/g, '},{');
          // Fix unquoted keys
          hopeful = hopeful.replace(
            /([\{,]\s*)([A-Za-z0-9_]+)\s*:/g,
            '$1"$2":'
          );
          // Fix trailing commas
          hopeful = hopeful.replace(/,(\s*[}\]])/g, '$1');
          // Fix single quotes (but preserve apostrophes in values)
          hopeful = hopeful.replace(/'([^']*)':/g, '"$1":'); // Keys
          data = JSON.parse(hopeful);
          console.log('[ProfileSetup] Recovery successful (strategy 1)!');
          recovered = true;
        }
      } catch (e2) {
        console.log('[ProfileSetup] Strategy 1 failed:', e2.message);
      }

      // Strategy 2: Line-by-line reconstruction (if strategy 1 failed)
      if (!recovered) {
        try {
          // Find the "fields" array specifically
          const fieldsMatch = raw.match(
            /(?:\"fields\"|fields)\s*:\s*\[([\s\S]*?)\]/
          );
          if (fieldsMatch) {
            // Manually reconstruct just the fields array
            const fieldsStr = fieldsMatch[1];
            const fields = [];

            // Split by object boundaries
            const objects = fieldsStr.split(/\},\s*\{/);
            objects.forEach((obj) => {
              try {
                // Clean up the object string
                let cleaned = obj.trim();
                if (!cleaned.startsWith('{')) cleaned = '{' + cleaned;
                if (!cleaned.endsWith('}')) cleaned = cleaned + '}';

                // Fix common issues
                cleaned = cleaned.replace(
                  /([\{,]\s*)([A-Za-z0-9_]+)\s*:/g,
                  '$1"$2":'
                );
                cleaned = cleaned.replace(/,(\s*[}\]])/g, '$1');

                const parsed = JSON.parse(cleaned);
                if (parsed.name || parsed.label) {
                  fields.push(parsed);
                }
              } catch (e3) {
                // Skip malformed objects
              }
            });

            if (fields.length > 0) {
              data = { fields };
              console.log(
                `[ProfileSetup] Recovery successful (strategy 2)! Recovered ${fields.length} fields`
              );
              recovered = true;
            }
          }
        } catch (e3) {
          console.log('[ProfileSetup] Strategy 2 failed:', e3.message);
        }
      }

      // If all strategies failed, log and return error
      if (!recovered) {
        console.error('[ProfileSetup] All recovery strategies failed');
        console.log(
          '[ProfileSetup] Raw response (first 2000 chars):',
          raw.slice(0, 2000)
        );
        data = {
          error: 'Failed to parse AI response',
          raw: raw.slice(0, 5000),
        };
      }
    }
    const bgFields = Array.isArray(data?.fields)
      ? data.fields
      : Array.isArray(data?.result?.fields)
      ? data.result.fields
      : [];
    if (!res.ok || bgFields.length === 0) {
      if (statusEl) {
        statusEl.style.display = 'none'; // Hide the banner instead of showing error
      }
      console.warn(
        '[ProfileSetup] Background interview generation failed:',
        data
      );
      return;
    }

    // Apply to DOM immediately (fill empty textareas)
    const byLabel = new Map();
    bgFields.forEach((f) => {
      if (f?.name || f?.label) {
        byLabel.set(String(f.name || f.label).toLowerCase(), f.value || '');
      }
    });

    let filledNow = 0;
    for (const ta of areas) {
      const q = (ta.getAttribute('data-question') || '').toLowerCase();
      const val = byLabel.get(q);
      if (val && !ta.value.trim()) {
        ta.value = val;
        filledNow++;
        // Find and show the status indicator in the card
        const card = ta.closest('.question-card');
        if (card) {
          const statusIndicator = card.querySelector('.question-status');
          if (statusIndicator) {
            statusIndicator.textContent = 'Saved';
            statusIndicator.style.display = 'flex';
          }
        }
      }
    }

    // Save to local cache and database
    let saved = 0;
    for (const f of bgFields) {
      const q = (f?.name || f?.label || '').trim();
      const a = (f?.value || '').trim();
      if (!q || !a) continue;
      try {
        await saveCustomAnswer(q, a, 'interview_template');
        saved++;
      } catch (_) {}
    }

    if (statusEl && statusText) {
      statusEl.className = 'status-banner success';
      statusText.textContent = saved
        ? `Prepared ${saved} interview answers and auto-filled ${filledNow} fields`
        : 'No answers generated.';
    }

    console.log(
      `[ProfileSetup] Background interview answers saved: ${saved}, filled now: ${filledNow}`
    );
  } catch (e) {
    console.error('[ProfileSetup] Background interview generation error:', e);
    // Hide loading banner on error
    const statusEl = document.getElementById('interviewGenStatus');
    if (statusEl) {
      statusEl.style.display = 'none';
    }
  }
}

// Collect all profile data
function collectProfileData() {
  const jobTypes = Array.from(
    document.querySelectorAll('#step4 input[type="checkbox"]:checked')
  ).map((cb) => cb.value);

  // Read from form first
  const formData = {
    fullName: document.getElementById('fullName')?.value || '',
    email: document.getElementById('email')?.value || '',
    phone: document.getElementById('phone')?.value || '',
    location: document.getElementById('location')?.value || '',
    linkedIn: document.getElementById('linkedIn')?.value || '',
    portfolio: document.getElementById('portfolio')?.value || '',
    github: document.getElementById('github')?.value || '',
    currentRole: document.getElementById('currentRole')?.value || '',
    yearsExperience: document.getElementById('yearsExperience')?.value || '',
    degree: document.getElementById('degree')?.value || '',
    major: document.getElementById('major')?.value || '',
    university: document.getElementById('university')?.value || '',
    gradYear: document.getElementById('gradYear')?.value || '',
    workAuthorization: document.getElementById('workAuth')?.value || '',
    securityClearance: document.getElementById('clearance')?.value || 'None',
    jobTypes: jobTypes,
    salaryMin: document.getElementById('salaryMin')?.value || '',
    salaryMax: document.getElementById('salaryMax')?.value || '',
    relocate: document.getElementById('relocate')?.value || '',
    referralSource: document.getElementById('referralSource')?.value || '',
    notice: document.getElementById('notice')?.value || '',
    interviewAvail: document.getElementById('interviewAvail')?.value || '',
    interviewAnswers: Array.from(
      document.querySelectorAll(
        '#interviewTemplates textarea.field-input[data-question]'
      )
    )
      .map((ta) => ({
        question: ta.getAttribute('data-question'),
        answer: ta.value.trim(),
      }))
      .filter((qa) => qa.answer), // Only include answered questions
  };

  // Merge AI-extracted values only when the corresponding form field is empty
  const preferForm = (formVal, aiVal) => {
    const v = String(formVal ?? '').trim();
    return v ? formVal : aiVal ?? '';
  };

  return {
    ...formData,
    skills: extractedProfile?.topSkills || [],
    summary: preferForm('', extractedProfile?.professionalSummary || ''),
    currentRole: preferForm(
      formData.currentRole,
      extractedProfile?.currentRole
    ),
    yearsExperience: preferForm(
      formData.yearsExperience,
      extractedProfile?.yearsExperience || 0
    ),
    degree: preferForm(formData.degree, extractedProfile?.highestDegree),
    major: preferForm(formData.major, extractedProfile?.fieldOfStudy),
    university: preferForm(formData.university, extractedProfile?.university),
    gradYear: preferForm(formData.gradYear, extractedProfile?.graduationYear),
    certifications: extractedProfile?.certifications || [],
    source: extractedProfile ? 'ai-extracted' : 'manual',
  };
}

// Calculate profile completeness percentage
function calculateCompleteness(data) {
  const fields = [
    data.fullName,
    data.email,
    data.phone,
    data.location,
    data.linkedIn,
    data.portfolio,
    data.github,
    data.currentRole,
    data.yearsExperience,
    data.degree,
    data.major,
    data.university,
    data.gradYear,
    data.workAuthorization,
    data.jobTypes?.length > 0 ? 'yes' : '',
    data.skills?.length > 0 ? 'yes' : '',
    data.summary,
    cvText,
  ];

  const filledFields = fields.filter((f) => f && String(f).trim()).length;
  const totalFields = fields.length;
  const percentage = Math.round((filledFields / totalFields) * 100);

  console.log(
    `[ProfileSetup] Profile completeness: ${percentage}% (${filledFields}/${totalFields} fields)`
  );
  return percentage;
}

// Finish setup
async function finishSetup(skipped = false) {
  try {
    let completeness = 0;
    let isComplete = false;

    if (!skipped) {
      const data = collectProfileData();
      const profile = createInitialProfile(data);

      // Calculate completeness
      completeness = calculateCompleteness(data);
      isComplete = completeness >= 30; // 30% threshold

      // Save to storage
      const saved = await saveUserProfile(profile);

      if (!saved) {
        alert('Error saving profile. Please try again.');
        return;
      }

      // Also save CV text if available
      if (cvText) {
        console.log(
          `[ProfileSetup] Saving CV text in finishSetup (${cvText.length} characters)`
        );
        await chrome.storage.local.set({ userCV: cvText });
        console.log('[ProfileSetup] CV text saved in finishSetup');
      } else {
        console.warn('[ProfileSetup] No CV text to save in finishSetup');
      }

      console.log(
        `[ProfileSetup] Profile saved successfully (${completeness}% complete, onboarding: ${
          isComplete ? 'complete' : 'incomplete'
        })`
      );

      // Sync to database with onboarding_completed flag
      let syncSuccess = false;
      try {
        const resp = await fetch(chrome.runtime.getURL('config.json'));
        const cfg = await resp.json();
        const base = resolveRrBase(cfg);
        const storage = await chrome.storage.sync.get(['firebaseSession']);
        let token = storage.firebaseSession?.access_token || '';
        if (!token) {
          const localToken = await chrome.storage.local
            .get('rrAuthToken')
            .catch(() => ({}));
          token = localToken?.rrAuthToken || '';
        }

        if (base && token) {
          const payload = {
            profile: {
              full_name: data.fullName,
              email: data.email,
              phone: data.phone,
              location: data.location,
              linkedIn: data.linkedIn, // backend maps linkedIn -> linkedin_url
              portfolio: data.portfolio, // correct key expected by backend
              github: data.github, // correct key expected by backend
              workAuthorization: data.workAuthorization,
              securityClearance: data.securityClearance,
              jobTypes: data.jobTypes,
              salaryMin: data.salaryMin, // backend maps to expected_salary_min
              salaryMax: data.salaryMax, // backend maps to expected_salary_max
              relocate: data.relocate, // backend maps to willing_to_relocate
              skills: data.skills,
              degree: data.degree,
              major: data.major,
              university: data.university,
              gradYear: data.gradYear,
              yearsExperience: data.yearsExperience,
              currentRole: data.currentRole,
              summary: data.summary,
              cvText: cvText || '',
              source: data.source || 'manual',
              onboardingComplete: isComplete, // Mark as completed if >= 30%
              completenessScore: completeness, // Send actual percentage
            },
            // Use interview answers from collected form data
            customAnswers: data.interviewAnswers
              ? data.interviewAnswers.map((qa) => ({
                  question: qa.question,
                  answer: qa.answer,
                }))
              : [],
          };

          console.log(
            `[ProfileSetup] Syncing ${payload.customAnswers.length} interview answers to database`
          );

          console.log('[ProfileSetup] Syncing profile to database...');
          const syncRes = await fetch(`${base}/v1/profile/sync`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
            credentials: 'include',
            body: JSON.stringify(payload),
          });

          if (syncRes.ok) {
            const syncData = await syncRes.json();
            console.log(
              '[ProfileSetup] Profile synced to database with onboarding completed:',
              syncData
            );
            syncSuccess = true;
          } else {
            const errorText = await syncRes.text();
            console.error(
              '[ProfileSetup] Database sync failed:',
              syncRes.status,
              errorText
            );
          }
        } else {
          console.warn(
            '[ProfileSetup] No base URL or token available for sync'
          );
        }
      } catch (e) {
        console.error('[ProfileSetup] Sync error:', e);
      }

      // Mark onboarding as complete locally if >= 30% (regardless of sync status)
      await chrome.storage.local.set({
        onboardingComplete: isComplete,
        profileCompleteness: completeness,
      });

      // Add a small delay to ensure storage is written
      await new Promise((resolve) => setTimeout(resolve, 500));

      console.log(
        `[ProfileSetup] Onboarding ${
          isComplete ? 'complete' : 'incomplete'
        } (${completeness}%), redirecting to ${
          isComplete ? 'tracker' : 'sidepanel'
        }`
      );
    } else {
      // Skipped onboarding - mark as incomplete
      await chrome.storage.local.set({
        onboardingComplete: false,
        profileCompleteness: 0,
      });
    }

    // Redirect to tracker page if complete (>= 30%), otherwise sidepanel
    if (!skipped && isComplete) {
      console.log('[ProfileSetup] Redirecting to tracker page...');
      try {
        const resp = await fetch(chrome.runtime.getURL('config.json'));
        const cfg = await resp.json();
        let base = (cfg?.apiBaseUrl || '').replace(/\/$/, '');

        // Remove /api suffix if present (tracker is at root, not under /api)
        if (base.endsWith('/api')) {
          base = base.slice(0, -4);
        }

        if (base) {
          const trackerUrl = `${base}/tracker`;
          console.log('[ProfileSetup] Opening tracker:', trackerUrl);

          // Open tracker in new tab
          await chrome.tabs.create({ url: trackerUrl });

          // Close the profile setup window after a short delay
          setTimeout(() => {
            window.close();
          }, 500);
        } else {
          console.warn(
            '[ProfileSetup] No API base URL configured, redirecting to sidepanel'
          );
          window.location.href = 'sidepanel.html';
        }
      } catch (e) {
        console.error('[ProfileSetup] Error opening tracker:', e);
        window.location.href = 'sidepanel.html';
      }
    } else {
      // Not complete or skipped - go to sidepanel
      console.log('[ProfileSetup] Redirecting to sidepanel...');
      window.location.href = 'sidepanel.html';
    }
  } catch (e) {
    console.error('[ProfileSetup] Error finishing setup:', e);
    alert('Error saving profile. Please try again.');
  }
}

function editProfile() {
  currentStep = 2;
  showStep(2);
  updateProgress();
}

// Initialize on DOM load
console.log('[ProfileSetup] Script loaded, initializing...');

// Load PDF.js
const script = document.createElement('script');
script.src = 'vendor/pdfjs/pdf.min.js';
document.head.appendChild(script);

script.onload = () => {
  if (typeof pdfjsLib !== 'undefined') {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdfjs/pdf.worker.min.js';
    console.log('[ProfileSetup] PDF.js loaded successfully');
  }
};

// Log when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log('[ProfileSetup] DOM loaded, ready for user interaction');
  });
} else {
  console.log('[ProfileSetup] DOM already loaded');
}

// Load existing profile data from database for returning users
/**
 * Fetch user profile from RR /api/auth/me endpoint
 * @param {string} token - JWT token
 * @returns {Promise<object|null>} - User profile data or null
 */
async function fetchRRAuthMe(token) {
  try {
    console.log('[ProfileSetup] Fetching profile from /api/auth/me...');
    console.log(
      '[ProfileSetup] Using token (first 20 chars):',
      token.substring(0, 20) + '...'
    );

    const RR_API_BASE = 'https://api.reverserecruiting.io';
    const url = `${RR_API_BASE}/api/auth/me`;

    console.log('[ProfileSetup] Request URL:', url);
    console.log('[ProfileSetup] Request headers:', {
      Authorization: `Bearer ${token.substring(0, 20)}...`,
      'Content-Type': 'application/json',
    });

    const res = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    console.log('[ProfileSetup] Response status:', res.status);
    console.log('[ProfileSetup] Response headers:', {
      'content-type': res.headers.get('content-type'),
      'content-length': res.headers.get('content-length'),
    });

    if (!res.ok) {
      const status = res.status;
      let errorBody = '';
      try {
        errorBody = await res.text();
      } catch (_) {}

      console.warn(
        `[ProfileSetup] /api/auth/me failed with status ${status}:`,
        errorBody?.slice(0, 500)
      );

      if (status === 401) {
        console.warn('[ProfileSetup] Token invalid or expired');
        console.warn('[ProfileSetup] This might mean:');
        console.warn('  1. Token is not from the RR dashboard');
        console.warn('  2. Token has expired');
        console.warn('  3. Token format is incorrect');
        console.warn(
          '[ProfileSetup] Please ensure you received the token via RR_EXTENSION_INIT postMessage'
        );
      } else if (status === 404) {
        console.warn('[ProfileSetup] User not found in RR database');
      } else if (status === 500) {
        console.warn('[ProfileSetup] Server error - please try again later');
      }

      return null;
    }

    const data = await res.json();

    console.log('[ProfileSetup] /api/auth/me SUCCESS!');
    // Do not log full profile payload (may contain PII / signed resume URLs)
    try {
      const d = data?.data || data || {};
      console.log('[ProfileSetup] /api/auth/me summary:', {
        hasName: !!d.name,
        hasEmail: !!d.email,
        hasPhoneNumber:
          d.phoneNumber != null && String(d.phoneNumber).trim() !== '',
        hasResumeUrl: !!d.resumeUrl,
        hasResumeSummary: !!d.resumeSummary,
        targetRoleCount: Array.isArray(d.targetRole) ? d.targetRole.length : 0,
        preferredLocationsCount: Array.isArray(d.preferredLocations)
          ? d.preferredLocations.length
          : 0,
      });
    } catch (_) {}

    return data;
  } catch (error) {
    console.error('[ProfileSetup] Error fetching /api/auth/me:', error);
    console.error('[ProfileSetup] Error details:', {
      name: error.name,
      message: error.message,
      stack: error.stack?.split('\n').slice(0, 3).join('\n'),
    });
    return null;
  }
}

/**
 * Map /api/auth/me response to extension profile format
 * @param {object} response - Response from /api/auth/me
 * @returns {object} - Mapped profile data
 */
function mapAuthMeToProfile(response) {
  if (!response) return null;

  console.log('[ProfileSetup] Mapping /api/auth/me data to profile format');

  // Extract data from response wrapper
  const authMeData = response.data || response;

  if (!authMeData) {
    console.warn('[ProfileSetup] No data in /api/auth/me response');
    return null;
  }

  // Map the actual API response structure to our profile structure
  const profile = {
    // Basic Info
    full_name: authMeData.name || '',
    email: authMeData.email || '',
    phone: authMeData.phone || '', // May not be in response

    // Resume/CV - Use ONLY raw parsed text (resume_text or cv_text), NEVER use summary
    // resume_text/cv_text contains the full parsed CV text, resumeSummary is just a summary and should NOT be used
    cv_text: authMeData.resume_text || authMeData.cv_text || '',
    cv_url: authMeData.resumeUrl || '',

    // Social Links
    linkedin_url: authMeData.linkedinUrl || '',
    portfolio_url: authMeData.portfolioUrl || '',
    github_url: authMeData.githubUrl || '',

    // Job Preferences
    role_preferences: authMeData.targetRole || [], // targetRole array
    experience_level: authMeData.experienceLevel || '', // "senior", "mid", "junior"
    locations: authMeData.preferredLocations || [], // preferredLocations array

    // Work Details
    current_job_title:
      (authMeData.targetRole && authMeData.targetRole[0]) || '', // Use first target role
    years_total_experience: null, // Not in API response, derive from experienceLevel if needed

    // Education (not in current API response)
    highest_degree: '',
    field_of_study: '',
    university: '',
    graduation_year: null,

    // Skills & Certifications
    top_skills: authMeData.keywords || [], // keywords array
    certifications: [],

    // Additional
    professional_summary: authMeData.resumeSummary || '',
    work_authorization: '', // Not in API response
    security_clearance: '', // Not in API response

    // Salary
    expected_salary_min: authMeData.minSalary || null,

    // Work Type
    job_types: authMeData.workType || [], // ["remote", "hybrid", "onsite"]

    // Status
    status: authMeData.status || '',

    // Metadata
    user_id: authMeData.id || '',
    created_at: authMeData.createdAt || '',
    updated_at: authMeData.updatedAt || '',
  };

  console.log('[ProfileSetup] Mapped profile:', {
    name: profile.full_name,
    email: profile.email,
    hasResumeSummary: !!profile.cv_text,
    resumeSummaryLength: profile.cv_text?.length || 0,
    resumeUrl: profile.cv_url,
    targetRoles: profile.role_preferences?.length || 0,
    locations: profile.locations?.length || 0,
    experienceLevel: profile.experience_level,
    keywords: profile.top_skills?.length || 0,
    minSalary: profile.expected_salary_min,
    workType: profile.job_types,
  });

  return profile;
}

async function loadExistingProfile() {
  try {
    console.log('[ProfileSetup] Loading existing profile data...');

    // Get auth token - try multiple sources
    const storage = await chrome.storage.sync.get(['firebaseSession']);
    const localStorage = await chrome.storage.local.get([
      'rrAuthToken',
      'rrIntegrationState',
    ]);

    let token = '';
    let tokenSource = '';

    // Priority 1: RR Integration State authToken (from dashboard postMessage RR_EXTENSION_INIT)
    if (localStorage.rrIntegrationState?.authToken) {
      token = localStorage.rrIntegrationState.authToken;
      tokenSource = 'rrIntegrationState.authToken';
    }
    // Priority 2: Direct RR Auth Token
    else if (localStorage.rrAuthToken) {
      token = localStorage.rrAuthToken;
      tokenSource = 'rrAuthToken';
    }
    // Priority 3: Firebase Session
    else if (storage.firebaseSession?.access_token) {
      token = storage.firebaseSession.access_token;
      tokenSource = 'firebaseSession';
    }

    console.log('[ProfileSetup] Token source:', tokenSource);
    console.log('[ProfileSetup] Token length:', token ? token.length : 0);
    // Do not log token contents (privacy/security)
    console.log('[ProfileSetup] Token present:', !!token);

    // Debug: Log full storage state
    console.log('[ProfileSetup] Storage debug:', {
      hasFirebaseSession: !!storage.firebaseSession,
      firebaseSessionKeys: storage.firebaseSession
        ? Object.keys(storage.firebaseSession)
        : [],
      hasRRAuthToken: !!localStorage.rrAuthToken,
      hasRRIntegrationState: !!localStorage.rrIntegrationState,
      rrIntegrationStateKeys: localStorage.rrIntegrationState
        ? Object.keys(localStorage.rrIntegrationState)
        : [],
      rrIntegrationStateAuthToken: localStorage.rrIntegrationState?.authToken
        ? 'EXISTS'
        : 'MISSING',
    });

    if (!token) {
      console.warn('[ProfileSetup] ⚠️ No auth token found!');
      console.warn('[ProfileSetup] To use /api/auth/me, you need to:');
      console.warn('  1. Open the extension from the RR dashboard');
      console.warn('  2. Dashboard will send RR_EXTENSION_INIT with token');
      console.warn('  3. Token will be stored in rrIntegrationState.authToken');
      return null;
    }

    // Get config
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await resp.json();
    const base = resolveRrBase(cfg);

    // Try to fetch from RR /api/auth/me first using profile-storage utility
    if (
      cfg.rrApiBaseUrl ||
      cfg.rrProductionApiBaseUrl ||
      tokenSource === 'rrIntegrationState.authToken'
    ) {
      console.log(
        '[ProfileSetup] Syncing profile from RR /api/auth/me using profile-storage...'
      );

      // Use the centralized profile storage utility
      const syncedProfile = await syncProfileFromRR(token);

      if (syncedProfile) {
        console.log(
          '[ProfileSetup] ✅ Successfully synced and stored profile from RR API'
        );

        return {
          profile: syncedProfile,
          customAnswers: [],
          employment: [],
          synced_at: syncedProfile.last_synced || new Date().toISOString(),
        };
      }

      console.log(
        '[ProfileSetup] No profile data from /api/auth/me, continuing with legacy flow'
      );
    }

    if (!base) {
      console.warn('[ProfileSetup] No API base URL configured');
      return null;
    }

    // Fetch profile from legacy backend
    const res = await fetch(`${base}/v1/profile/sync`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    if (!res.ok) {
      let body = '';
      try {
        body = await res.text();
      } catch (_) {}
      console.warn(
        '[ProfileSetup] Failed to fetch profile:',
        res.status,
        body?.slice(0, 500)
      );
      return null;
    }

    const data = await res.json();
    const profile = data?.profile;
    const customAnswers = data?.customAnswers || [];

    if (!profile) {
      console.log('[ProfileSetup] No profile data found');
      return null;
    }

    console.log('[ProfileSetup] Profile loaded:', {
      fullName: profile.full_name,
      email: profile.email,
      hasCV: !!profile.cv_text,
      cvLength: profile.cv_text?.length || 0,
      interviewQuestions: customAnswers.length,
    });

    // Return full response including customAnswers
    return {
      profile,
      customAnswers,
      employment: data?.employment || [],
      synced_at: data?.synced_at,
    };
  } catch (e) {
    console.error('[ProfileSetup] Error loading profile:', e);
    return null;
  }
}

// Pre-fill form fields with existing profile data
function fillFormWithProfile(profile) {
  if (!profile) return;

  console.log('[ProfileSetup] Pre-filling form with existing data');

  // Update welcome message for returning users
  const welcomeTitle = document.getElementById('welcomeTitle');
  const welcomeSubtitle = document.getElementById('welcomeSubtitle');
  const welcomeInfoBox = document.getElementById('welcomeInfoBox');

  if (welcomeTitle && welcomeSubtitle && welcomeInfoBox) {
    welcomeTitle.textContent = '👋 Welcome Back!';
    welcomeSubtitle.textContent =
      'Your profile is already set up. You can review and update your information below.';
    welcomeInfoBox.innerHTML = `
      <p style="margin: 0; color: var(--text-secondary); font-size: 14px; line-height: 1.6;">
        ✓ Profile: ${profile.full_name || 'Not set'}<br>
        ✓ Resume: ${
          profile.cv_text
            ? `Saved (${Math.round(profile.cv_text.length / 1000)}KB)`
            : 'Not uploaded'
        }<br>
        ✓ Contact: ${profile.email || 'Not set'}
      </p>
    `;
    console.log('[ProfileSetup] Updated welcome message for returning user');
  }

  // Map profile fields to form inputs
  // Note: Database uses snake_case, form uses camelCase
  const fieldMappings = {
    full_name: 'fullName',
    email: 'email',
    phone: 'phone',
    location: 'location',
    linkedin_url: 'linkedIn',
    portfolio_url: 'portfolio',
    github_url: 'github',
    work_authorization: 'workAuth',
    security_clearance: 'clearance',
    current_job_title: 'currentRole', // DB: current_job_title
    years_total_experience: 'yearsExperience', // DB: years_total_experience
    highest_degree: 'degree',
    field_of_study: 'major',
    university: 'university',
    graduation_year: 'gradYear',
    top_skills: 'skills', // JSONB array in DB
    certifications: 'certifications', // JSONB array in DB
    professional_summary: 'summary',
  };

  // Fill text inputs
  Object.entries(fieldMappings).forEach(([profileKey, formId]) => {
    const input = document.getElementById(formId);
    if (
      input &&
      profile[profileKey] !== null &&
      profile[profileKey] !== undefined
    ) {
      // Handle JSONB arrays (convert to comma-separated strings)
      if (Array.isArray(profile[profileKey])) {
        input.value = profile[profileKey].join(', ');
      } else {
        input.value = profile[profileKey];
      }
    }
  });

  // Handle locations array (preferredLocations from /api/auth/me)
  if (
    profile.locations &&
    Array.isArray(profile.locations) &&
    profile.locations.length > 0
  ) {
    const locationInput = document.getElementById('location');
    if (locationInput && !locationInput.value) {
      // Use first location if location field is empty
      locationInput.value = profile.locations[0];
      console.log(
        '[ProfileSetup] Set location from preferredLocations:',
        profile.locations[0]
      );
    }
  }

  // Handle role_preferences array (targetRole from /api/auth/me)
  if (
    profile.role_preferences &&
    Array.isArray(profile.role_preferences) &&
    profile.role_preferences.length > 0
  ) {
    const currentRoleInput = document.getElementById('currentRole');
    if (currentRoleInput && !currentRoleInput.value) {
      // Use first role preference if current role is empty
      currentRoleInput.value = profile.role_preferences[0];
      console.log(
        '[ProfileSetup] Set current role from targetRole:',
        profile.role_preferences[0]
      );
    }
  }

  // Handle experience_level (experienceLevel from /api/auth/me: "senior", "mid", "junior")
  if (profile.experience_level) {
    console.log(
      '[ProfileSetup] Experience level from API:',
      profile.experience_level
    );

    // Map experience level to years if yearsExperience field is empty
    const yearsExpInput = document.getElementById('yearsExperience');
    if (yearsExpInput && !yearsExpInput.value) {
      const experienceLevelMap = {
        junior: 2,
        mid: 5,
        senior: 8,
        lead: 10,
        staff: 12,
        principal: 15,
      };
      const estimatedYears =
        experienceLevelMap[profile.experience_level.toLowerCase()] || 0;
      if (estimatedYears > 0) {
        yearsExpInput.value = estimatedYears;
        console.log(
          '[ProfileSetup] Estimated years from experience level:',
          estimatedYears
        );
      }
    }
  }

  // Handle job_types array (workType from /api/auth/me: ["remote", "hybrid", "onsite"])
  if (
    profile.job_types &&
    Array.isArray(profile.job_types) &&
    profile.job_types.length > 0
  ) {
    console.log(
      '[ProfileSetup] Work types from API:',
      profile.job_types.join(', ')
    );
    // Could be used to populate work preference fields if they exist
  }

  // Handle expected_salary_min (minSalary from /api/auth/me)
  if (profile.expected_salary_min) {
    const salaryMinInput = document.getElementById('salaryMin');
    if (salaryMinInput && !salaryMinInput.value) {
      salaryMinInput.value = profile.expected_salary_min;
      console.log(
        '[ProfileSetup] Set minimum salary:',
        profile.expected_salary_min
      );
    }
  }

  // Handle CV text
  if (profile.cv_text) {
    cvText = profile.cv_text;
    // Save to local storage
    chrome.storage.local.set({ userCV: profile.cv_text });

    // Update upload status to show existing CV
    const uploadStatus = document.getElementById('uploadStatus');
    if (uploadStatus) {
      const wordCount = profile.cv_text.split(/\s+/).filter(Boolean).length;
      const charCount = profile.cv_text.length;

      uploadStatus.innerHTML = `
        <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 16px; margin-top: 16px;">
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
            <span style="font-size: 20px;">✅</span>
            <strong style="color: #16a34a;">Resume Already Saved</strong>
          </div>
          <p style="color: #15803d; margin: 8px 0; font-size: 14px;">
            Your resume is saved and ready to use (${wordCount} words, ${charCount} characters)
          </p>
          <p style="color: #15803d; margin: 0; font-size: 13px;">
            💡 You can upload a new resume below if you want to update it.
          </p>
        </div>
      `;
    }
  }

  console.log('[ProfileSetup] Form pre-filled successfully');
}

// Load interview questions from database
async function loadInterviewQuestions(customAnswers) {
  // Normalize customAnswers into an array of objects so callers can pass either
  // the DB array format or the legacy { question: answer } map from storage.
  if (customAnswers && !Array.isArray(customAnswers)) {
    if (typeof customAnswers === 'object') {
      customAnswers = Object.entries(customAnswers)
        .filter(
          ([question, answer]) =>
            typeof question === 'string' && typeof answer === 'string'
        )
        .map(([question, answer]) => ({
          question_text: question,
          question_normalized: question.toLowerCase().replace(/[^\w\s]/g, ''),
          answer_text: answer,
        }));
    } else {
      customAnswers = [];
    }
  }

  if (!customAnswers || customAnswers.length === 0) {
    console.log('[ProfileSetup] No interview questions found');
    return;
  }

  console.log(
    `[ProfileSetup] Loading ${customAnswers.length} interview questions`
  );

  // Pre-fill interview question textareas
  const container = document.getElementById('interviewTemplates');
  if (!container) {
    console.warn('[ProfileSetup] Interview templates container not found');
    return;
  }

  const textareas = container.querySelectorAll(
    'textarea.field-input[data-question]'
  );

  textareas.forEach((textarea) => {
    const question = textarea.getAttribute('data-question');
    if (!question) return;

    // Find matching answer from database
    const normalized = question.toLowerCase().replace(/[^\w\s]/g, '');
    const match = customAnswers.find(
      (a) =>
        (a.question_normalized || '').toLowerCase() === normalized ||
        (a.question_text || '').toLowerCase() === question.toLowerCase()
    );

    if (match && match.answer_text) {
      textarea.value = match.answer_text;

      // Find and show the status badge in the question card
      const card = textarea.closest('.question-card');
      if (card) {
        const statusBadge = card.querySelector('.question-status');
        if (statusBadge) {
          statusBadge.textContent = 'Saved';
          statusBadge.style.display = 'flex';
        }
      }

      console.log(`[ProfileSetup] Loaded answer for "${question}"`);
    }
  });

  // Also save to local storage for immediate access
  const customAnswersMap = {};
  customAnswers.forEach((a) => {
    if (a.question_text && a.answer_text) {
      customAnswersMap[a.question_text] = a.answer_text;
    }
  });

  await chrome.storage.local.set({ customAnswers: customAnswersMap });
  console.log('[ProfileSetup] Interview questions saved to local storage');
}

// Check if user is authenticated and load existing data
(async () => {
  try {
    const storage = await chrome.storage.sync.get(['firebaseSession']);
    const session = storage.firebaseSession;
    if (!session || !session.access_token) {
      console.warn(
        '[ProfileSetup] No auth session found, but allowing profile setup'
      );
      // Allow profile setup even without auth - they can complete it later
    } else {
      console.log(
        '[ProfileSetup] User authenticated, proceeding with profile setup'
      );

      // Load and pre-fill existing profile data for returning users
      const existingProfile = await loadExistingProfile();
      if (existingProfile) {
        // existingProfile is the data from GET /v1/profile/sync
        // It contains: { profile, employment, customAnswers, synced_at }
        const profileData = existingProfile.profile || existingProfile;
        const customAnswers = existingProfile.customAnswers || [];

        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', async () => {
            fillFormWithProfile(profileData);
            await loadInterviewQuestions(customAnswers);
          });
        } else {
          fillFormWithProfile(profileData);
          await loadInterviewQuestions(customAnswers);
        }
      }
    }
  } catch (e) {
    console.error('[ProfileSetup] Auth check error:', e);
  }
})();
