/**
 * Bridge to expose profile sync functions globally
 * This allows sidepanel.js to call profile sync without using ES6 imports
 */

import { bidirectionalSync, saveCustomAnswer } from './profile-sync.js';

// Expose globally for sidepanel.js
window.JobApAIProfile = window.JobApAIProfile || {};
window.JobApAIProfile.syncOnLogin = bidirectionalSync;
window.JobApAIProfile.saveCustomAnswer = saveCustomAnswer;

console.log('[ProfileSyncBridge] Profile sync functions exposed globally');






