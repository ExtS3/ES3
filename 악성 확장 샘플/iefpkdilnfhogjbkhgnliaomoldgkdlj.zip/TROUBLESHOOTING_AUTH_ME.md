# Troubleshooting /api/auth/me Integration

## Common Issues and Solutions

### Issue 1: 401 Unauthorized - "Invalid token"

**Error Message:**
```
[ProfileSetup] /api/auth/me failed with status 401: {"success":false,"error":"Invalid token","message":"The provided token is invalid or expired"}
[ProfileSetup] Token invalid or expired
```

**Root Causes:**

#### 1. Token Not From RR Dashboard
The most common cause is using the wrong token. The `/api/auth/me` endpoint requires a specific JWT token from the Reverse Recruiting dashboard.

**Solution:**
- Open the extension **from the RR dashboard**, not directly
- The dashboard sends the token via `postMessage` with type `RR_EXTENSION_INIT`
- Check console logs for: `[Content] ✅ RR_EXTENSION_INIT received`

#### 2. Using Firebase Token Instead of RR Token
The extension has multiple token sources, and the wrong one might be selected.

**Check Token Source:**
Look for this log:
```
[ProfileSetup] Token source: rrIntegrationState.authToken  ✅ CORRECT
[ProfileSetup] Token source: firebaseSession              ❌ WRONG
```

**Solution:**
- Ensure `rrIntegrationState.authToken` exists in storage
- Check: `chrome.storage.local.get(['rrIntegrationState'], console.log)`

#### 3. Token Expired
JWT tokens have an expiration time.

**Solution:**
- Log out and log back in to the RR dashboard
- Reopen the extension from the dashboard
- Token will be refreshed automatically

### Issue 2: No Token Found

**Error Message:**
```
[ProfileSetup] ⚠️ No auth token found!
[ProfileSetup] To use /api/auth/me, you need to:
  1. Open the extension from the RR dashboard
  2. Dashboard will send RR_EXTENSION_INIT with token
  3. Token will be stored in rrIntegrationState.authToken
```

**Root Cause:**
Extension was opened directly, not from the RR dashboard.

**Solution:**
1. Go to the RR dashboard: `https://app.reverserecruiting.io`
2. Log in to your account
3. Click the extension icon or "Test Extension" button
4. Dashboard will send the token via `postMessage`

### Issue 3: 404 Not Found - "User not found"

**Error Message:**
```
[ProfileSetup] /api/auth/me failed with status 404
[ProfileSetup] User not found in RR database
```

**Root Cause:**
User account doesn't exist in the RR backend database.

**Solution:**
- Verify you're logged in with the correct account
- Check if your account was created successfully
- Contact support if the issue persists

### Issue 4: 500 Server Error

**Error Message:**
```
[ProfileSetup] /api/auth/me failed with status 500
[ProfileSetup] Server error - please try again later
```

**Root Cause:**
Backend server issue.

**Solution:**
- Wait a few minutes and try again
- Check if the API is down: `https://api.reverserecruiting.io/health`
- Contact backend team if issue persists

## Debugging Steps

### Step 1: Check Token Storage

Open browser console and run:
```javascript
// Check all token sources
chrome.storage.local.get(['rrAuthToken', 'rrIntegrationState'], (data) => {
  console.log('Local Storage:', data);
});

chrome.storage.sync.get(['firebaseSession'], (data) => {
  console.log('Sync Storage:', data);
});
```

**Expected Output (when working):**
```javascript
{
  rrIntegrationState: {
    authToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",  // Long JWT string
    user: { id: "123", email: "user@example.com" },
    jobId: "...",
    updatedAt: 1234567890
  }
}
```

### Step 2: Verify Token Format

A valid JWT token has 3 parts separated by dots:
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
```

**Check:**
```javascript
const token = "your_token_here";
console.log('Token parts:', token.split('.').length);  // Should be 3
console.log('Token length:', token.length);  // Usually 200-500 chars
```

### Step 3: Test API Directly

Test the endpoint with your token:
```javascript
const token = "your_token_here";
fetch('https://api.reverserecruiting.io/api/auth/me', {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
})
.then(r => r.json())
.then(data => console.log('API Response:', data))
.catch(err => console.error('API Error:', err));
```

**Expected Success Response:**
```json
{
  "id": "user123",
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "+1234567890",
  "resume_text": "...",
  "linkedin_url": "https://linkedin.com/in/johndoe",
  "role_preferences": ["Software Engineer"],
  "locations": ["San Francisco, CA"],
  ...
}
```

### Step 4: Check Console Logs

Look for these specific log messages in order:

#### ✅ Successful Flow:
```
[ProfileSetup] Loading existing profile data...
[ProfileSetup] Token source: rrIntegrationState.authToken
[ProfileSetup] Token length: 456
[ProfileSetup] Token (first 30 chars): eyJhbGciOiJIUzI1NiIsInR5cCI6...
[ProfileSetup] Attempting to fetch from RR /api/auth/me endpoint
[ProfileSetup] Fetching profile from /api/auth/me...
[ProfileSetup] Request URL: https://api.reverserecruiting.io/api/auth/me
[ProfileSetup] Response status: 200
[ProfileSetup] /api/auth/me SUCCESS!
[ProfileSetup] Response data: { ... }
[ProfileSetup] Mapping /api/auth/me data to profile format
[ProfileSetup] Mapped profile: { name: "John Doe", email: "...", ... }
[ProfileSetup] Successfully loaded profile from /api/auth/me
```

#### ❌ Failed Flow (No Token):
```
[ProfileSetup] Loading existing profile data...
[ProfileSetup] Storage debug: { hasRRIntegrationState: false, ... }
[ProfileSetup] ⚠️ No auth token found!
[ProfileSetup] To use /api/auth/me, you need to:
  1. Open the extension from the RR dashboard
  ...
```

#### ❌ Failed Flow (Invalid Token):
```
[ProfileSetup] Loading existing profile data...
[ProfileSetup] Token source: firebaseSession
[ProfileSetup] Token length: 234
[ProfileSetup] Fetching profile from /api/auth/me...
[ProfileSetup] Response status: 401
[ProfileSetup] /api/auth/me failed with status 401: {"success":false,"error":"Invalid token"}
[ProfileSetup] Token invalid or expired
[ProfileSetup] This might mean:
  1. Token is not from the RR dashboard
  2. Token has expired
  3. Token format is incorrect
```

### Step 5: Verify RR_EXTENSION_INIT Reception

Check if the extension received the token from the dashboard:

```javascript
// In content script console
window.addEventListener('message', (event) => {
  if (event.data.type === 'RR_EXTENSION_INIT') {
    console.log('✅ RR_EXTENSION_INIT received!', {
      hasToken: !!event.data.token,
      tokenLength: event.data.token?.length,
      user: event.data.user
    });
  }
});
```

**Expected Output:**
```
✅ RR_EXTENSION_INIT received! {
  hasToken: true,
  tokenLength: 456,
  user: { id: "123", email: "user@example.com" }
}
```

## Quick Fixes

### Fix 1: Clear Storage and Retry
```javascript
// Clear all tokens
chrome.storage.local.remove(['rrAuthToken', 'rrIntegrationState']);
chrome.storage.sync.remove(['firebaseSession']);

// Then reopen extension from dashboard
```

### Fix 2: Force Token Refresh
1. Go to RR dashboard
2. Log out
3. Log back in
4. Click "Test Extension" button
5. Extension should receive fresh token

### Fix 3: Manual Token Injection (for testing)
```javascript
// Get token from dashboard team
const testToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";

// Inject into storage
chrome.storage.local.set({
  rrIntegrationState: {
    authToken: testToken,
    user: { id: "test", email: "test@example.com" },
    updatedAt: Date.now()
  }
});

// Reload profile setup page
```

## Token Flow Diagram

```
┌─────────────────────────────────────────────────────────┐
│                    RR Dashboard                          │
│  (https://app.reverserecruiting.io)                     │
└────────────────────┬────────────────────────────────────┘
                     │
                     │ User clicks "Test Extension"
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│  postMessage({ type: 'RR_EXTENSION_INIT', token: ... }) │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│              Content Script (content.js)                 │
│  - Receives postMessage                                  │
│  - Extracts token from data.token or data.access_token  │
│  - Calls persistRRToken(token)                          │
│  - Stores in rrIntegrationState.authToken               │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│           Chrome Storage (local)                         │
│  {                                                       │
│    rrIntegrationState: {                                │
│      authToken: "eyJhbGci...",  ← THIS IS THE TOKEN    │
│      user: {...},                                       │
│      jobId: "...",                                      │
│      updatedAt: 1234567890                              │
│    }                                                     │
│  }                                                       │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│         Profile Setup (profile-setup.js)                 │
│  - Reads rrIntegrationState.authToken                   │
│  - Calls fetchRRAuthMe(token)                           │
│  - Sends GET /api/auth/me with Bearer token             │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│         RR Backend API                                   │
│  https://api.reverserecruiting.io/api/auth/me          │
│  - Validates JWT token                                   │
│  - Returns user profile data                             │
└─────────────────────────────────────────────────────────┘
```

## Contact Support

If none of these solutions work:

1. **Collect Debug Info:**
   ```javascript
   // Run in console
   chrome.storage.local.get(null, (data) => {
     console.log('Full Local Storage:', JSON.stringify(data, null, 2));
   });
   ```

2. **Share Console Logs:**
   - Copy all `[ProfileSetup]` logs
   - Copy all `[Content]` logs related to RR_EXTENSION_INIT

3. **Provide Details:**
   - Browser version
   - Extension version
   - Steps to reproduce
   - When did it last work?

4. **Contact:**
   - Backend team: For API issues
   - Extension team: For token storage issues
   - Dashboard team: For postMessage issues

## Prevention

### Best Practices

1. **Always Open from Dashboard**
   - Don't open extension directly
   - Use dashboard's "Test Extension" button
   - Ensures fresh token is sent

2. **Check Token Expiration**
   - Tokens typically expire after 24 hours
   - Reopen from dashboard daily
   - Consider implementing token refresh

3. **Monitor Console**
   - Keep console open during development
   - Watch for token-related warnings
   - Check for RR_EXTENSION_INIT reception

4. **Test Token Before Using**
   - Verify token exists before API calls
   - Check token format (3 parts, 200+ chars)
   - Test with direct fetch first

## Summary

**Most Common Issue:** Using the wrong token (firebaseSession instead of rrIntegrationState.authToken)

**Quick Fix:** Open extension from RR dashboard, not directly

**Verification:** Check console for `[ProfileSetup] Token source: rrIntegrationState.authToken`

**Success Indicator:** `[ProfileSetup] /api/auth/me SUCCESS!`




























