Place the following PNG icons here before publishing to the Chrome Web Store:

- icon16.png (16x16)
- icon32.png (32x32)
- icon48.png (48x48)
- icon128.png (128x128)

They must be square PNGs. Update the artwork as desired; filenames must match the manifest entries. 