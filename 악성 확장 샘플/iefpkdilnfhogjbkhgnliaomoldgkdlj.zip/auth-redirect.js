// auth-redirect.js
// NOTE: Must be external (no inline script) to comply with MV3 CSP.

import { getRedirectResult } from './firebase-auth.js';

function showError(message) {
  try {
    const el = document.getElementById('error');
    if (!el) return;
    el.textContent = message;
    el.style.display = 'block';
  } catch (_) {}
}

(async () => {
  try {
    const result = await getRedirectResult();

    if (result?.error) {
      showError(result.error);
      setTimeout(() => window.close(), 3000);
      return;
    }

    if (result?.user && result?.session) {
      window.close();
      return;
    }

    showError('Sign in cancelled or failed.');
    setTimeout(() => window.close(), 2000);
  } catch (error) {
    console.error('[Auth Redirect] Error:', error);
    showError(error?.message || 'An error occurred');
    setTimeout(() => window.close(), 3000);
  }
})();





























