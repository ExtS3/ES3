(() => {
  const apiKeyInput = document.getElementById('apiKey');
  const saveBtn = document.getElementById('saveBtn');
  const revealBtn = document.getElementById('revealBtn');
  const statusEl = document.getElementById('status');

  async function load() {
    try {
      const { openaiApiKey } = await chrome.storage.sync.get(['openaiApiKey']);
      if (openaiApiKey) {
        apiKeyInput.value = openaiApiKey;
      }
    } catch (_) {
      // ignore
    }
  }

  async function save() {
    const key = apiKeyInput.value.trim();
    try {
      await chrome.storage.sync.set({ openaiApiKey: key });
      statusEl.textContent = 'Saved.';
      setTimeout(() => (statusEl.textContent = ''), 1200);
    } catch (e) {
      statusEl.textContent = 'Failed to save key.';
      setTimeout(() => (statusEl.textContent = ''), 1600);
    }
  }

  function toggleReveal() {
    if (apiKeyInput.type === 'password') {
      apiKeyInput.type = 'text';
      revealBtn.textContent = 'Hide';
    } else {
      apiKeyInput.type = 'password';
      revealBtn.textContent = 'Reveal';
    }
  }

  saveBtn.addEventListener('click', save);
  revealBtn.addEventListener('click', toggleReveal);

  document.addEventListener('DOMContentLoaded', load);
})();
