# Chrome Web Store Submission Checklist

Use this checklist to ensure your extension meets all Chrome Web Store requirements before submission.

## Pre-Submission Requirements

### 1. Developer Account Setup

- [ ] Enable 2-Step Verification on your Google account ([Required](https://myaccount.google.com/security))
- [ ] Pay the one-time $5 developer registration fee
- [ ] Verify your email address in the Developer Dashboard

### 2. Privacy Policy

- [ ] Create a privacy policy page hosted at a public URL (e.g., `https://reverserecruiting.io/privacy`)
- [ ] Privacy policy must disclose:
  - [ ] What data is collected
  - [ ] How data is used
  - [ ] Who data is shared with
  - [ ] How users can delete their data
- [ ] Add the privacy policy URL to the Developer Dashboard

### 3. Manifest.json Verification

- [x] `manifest_version` is 3
- [x] `name` is clear and descriptive (no keyword stuffing)
- [x] `description` accurately describes functionality
- [x] `version` follows semantic versioning
- [x] No localhost URLs in `host_permissions`
- [x] Permissions are minimal and justified
- [x] Icons are provided in all required sizes (16, 32, 48, 128)

### 4. Code Requirements

- [x] No obfuscated code
- [x] No minification that hides functionality
- [x] No external script loading via `<script>` tags
- [x] No `eval()` or `Function()` constructor with remote code
- [x] All functionality is self-contained in the extension package

## Store Listing Requirements

### 5. Extension Name & Description

- [ ] Name is unique and descriptive (max 45 characters)
- [ ] Short description is compelling (max 132 characters)
- [ ] Full description explains:
  - [ ] What the extension does
  - [ ] Key features
  - [ ] How to use it
  - [ ] Why users need the permissions requested

### 6. Visual Assets

- [ ] Extension icon (128x128 PNG, no alpha on edges)
- [ ] At least 1 screenshot (1280x800 or 640x400)
- [ ] Screenshots show actual extension functionality
- [ ] Optional: Promotional images (440x280, 920x680, 1400x560)

### 7. Category Selection

- [ ] Select appropriate category: **Productivity** (recommended)
- [ ] Set appropriate content rating (likely "Everyone")

## Privacy Declarations in Developer Dashboard

### 8. Data Use Certifications

When submitting, you'll need to certify the following in the Developer Dashboard:

#### Single Purpose Description

```
Help users fill out job application forms efficiently by auto-filling forms with their stored profile information, and generating AI-tailored resumes and cover letters.
```

#### Permission Justifications

| Permission      | Justification                                                                                                                                                                               |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `storage`       | Required to save user profile data locally for form auto-filling. Without this, users would need to re-enter their information for every application.                                       |
| `sidePanel`     | Required to display the main extension interface where users manage their profile and generate documents.                                                                                   |
| `tabs`          | Required to open the profile settings page in a new tab and detect which website the user is on to show relevant job information.                                                           |
| `webNavigation` | Required to scan all frames on job application pages. Many job sites use iframes for their forms (e.g., Greenhouse, Lever), so we need to access all frames to detect and fill form fields. |

#### Host Permission Justifications

| Host                               | Justification                                                                                                    |
| ---------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| `reverserecruiting.io/*`           | Our main website - required for user authentication and displaying the Reverse Recruiting dashboard integration. |
| `api.reverserecruiting.io/*`       | Our backend API - required for profile sync, AI document generation, and user authentication.                    |
| `identitytoolkit.googleapis.com/*` | Firebase Authentication - required for secure user login/signup with Google Sign-In.                             |
| `securetoken.googleapis.com/*`     | Firebase token refresh - required to maintain secure authentication sessions.                                    |
| `*.run.app/*`                      | Google Cloud Run backend services - required for AI processing and profile sync.                                 |

#### Content Script `<all_urls>` Justification

```
This extension's primary function is to auto-fill job application forms. Job applications exist on thousands of different websites including:
- ATS platforms: Greenhouse, Lever, Workday, iCIMS, BambooHR, Ashby
- Job boards: LinkedIn, Indeed, Glassdoor
- Company career pages on their own domains

Restricting content scripts to specific URLs would prevent the extension from working on the vast majority of job applications. The content script:
1. Only activates when the user opens the extension
2. Does NOT collect browsing history
3. Does NOT track user behavior
4. Only reads form fields to enable auto-filling
5. Only communicates with reverserecruiting.io for authentication
```

### 9. Data Collection Declarations

When asked "Does your extension collect user data?", answer **YES** and specify:

| Data Type                           | Collected | Reason                                                   |
| ----------------------------------- | --------- | -------------------------------------------------------- |
| Personally identifiable information | Yes       | User profile for form filling (name, email, phone, etc.) |
| Health information                  | No        | -                                                        |
| Financial and payment information   | No        | -                                                        |
| Authentication information          | Yes       | Login credentials for user accounts                      |
| Personal communications             | No        | -                                                        |
| Location                            | Yes       | User-provided location for job applications              |
| Web history                         | No        | -                                                        |
| User activity                       | No        | -                                                        |
| Website content                     | Yes       | Form field detection for auto-filling                    |

### 10. Remote Code Policy

- [x] Extension does NOT execute remotely hosted code
- [x] All JavaScript is bundled within the extension
- [x] AI processing happens server-side, only results are returned

## Common Rejection Reasons to Avoid

### ❌ Things That Will Get You Rejected

1. **Keyword Stuffing** - Don't repeat keywords excessively in description
2. **Misleading Functionality** - Don't claim features that don't work
3. **Missing Privacy Policy** - MUST have a privacy policy URL
4. **Excessive Permissions** - Don't request permissions you don't use
5. **Deceptive UI** - Don't mimic browser/OS warnings
6. **External Code Execution** - Don't load and execute remote JavaScript
7. **Obfuscated Code** - Code must be readable (minification is OK)

### ✅ Best Practices

1. **Clear Description** - Explain exactly what the extension does
2. **Honest Screenshots** - Show real functionality
3. **Minimal Permissions** - Only request what you need
4. **Responsive Support** - Provide a working support email
5. **Regular Updates** - Keep the extension maintained

## Post-Submission

### 11. Review Process

- Review typically takes 1-3 business days
- May take longer for extensions requesting sensitive permissions
- You'll receive email notification of approval or rejection

### 12. If Rejected

- Read the rejection reason carefully
- Make required changes
- Resubmit with a detailed explanation of changes
- You can appeal if you believe the rejection was in error

## Recommended Store Description

```
Reverse Recruiting - AI Job Application Assistant

Stop typing the same information on every job application. Reverse Recruiting automatically fills out job application forms using your saved profile.

✨ KEY FEATURES:
• Auto-fill job applications with one click
• Generate AI-tailored resumes for each job
• Create customized cover letters instantly
• Save custom answers for common questions
• Works on all major job boards and ATS platforms

🎯 HOW IT WORKS:
1. Set up your profile once with your work history and preferences
2. Navigate to any job application
3. Click the extension to auto-fill the form
4. Review and submit!

🔒 PRIVACY FIRST:
• Your data is stored locally on your device
• Optional cloud sync for cross-device access
• We never sell your data or use it for advertising
• Delete your data anytime

💼 SUPPORTED PLATFORMS:
Greenhouse, Lever, Workday, BambooHR, iCIMS, Ashby, LinkedIn Jobs, Indeed, Glassdoor, and thousands more company career pages.

📧 SUPPORT:
Questions? Contact us at support@reverserecruiting.io

🔗 Privacy Policy: https://reverserecruiting.io/privacy
🔗 Terms of Service: https://reverserecruiting.io/terms
```

## Final Checklist Before Submission

- [ ] Privacy policy is live at a public URL
- [ ] All screenshots are accurate and current
- [ ] Extension has been tested on multiple sites
- [ ] No console errors in normal usage
- [ ] All permissions are justified in the submission form
- [ ] Contact email is valid and monitored
- [ ] Version number is incremented from any previous submission

---

_Last Updated: December 16, 2024_
