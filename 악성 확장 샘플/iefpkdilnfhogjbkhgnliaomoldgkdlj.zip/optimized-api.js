/**
 * Optimized API client for JobApAI
 * Implements caching, compression, streaming, and abort controllers
 */

import {
  getCVProfile,
  setCVProfile,
  getJDCache,
  setJDCache,
  getResponseCache,
  setResponseCache,
  getSessionCache,
  setSessionCache,
} from './cache-utils.js';

import {
  compressCV,
  compressJD,
  compressForm,
  normalizeText,
  generateCVSummary,
  createCompactCV,
} from './compress-utils.js';

import {
  getUserProfile,
  prePopulateFromProfile,
  buildProfileContext,
} from './profile-utils.js';

import { getCachedAnswer, saveCustomAnswer } from './profile-sync.js';

// Global abort controller for canceling stale requests
let currentAbortController = null;

/**
 * Helper: Get cached answers for form fields
 */
async function getCachedAnswersForForm(formText, alreadyFilledFields) {
  try {
    // Extract field labels from form text
    const fieldRegex = /FIELD:.*?label=([^\n]+)/gi;
    const matches = [...formText.matchAll(fieldRegex)];

    const alreadyFilledSet = new Set(
      alreadyFilledFields.map((f) => f.name.toLowerCase())
    );

    const cachedFields = [];

    for (const match of matches) {
      const label = match[1].trim();

      // Skip if already filled
      if (alreadyFilledSet.has(label.toLowerCase())) {
        continue;
      }

      // Check for cached answer
      const cached = await getCachedAnswer(label);

      if (cached.found && cached.answer) {
        cachedFields.push({
          name: label,
          value: cached.answer,
          source: 'cached',
          timesUsed: cached.timesUsed,
        });
      }
    }

    return cachedFields;
  } catch (error) {
    console.error('[OptimizedAPI] Error getting cached answers:', error);
    return [];
  }
}

/**
 * Optimized analyze function with caching and compression
 */
export async function analyzeOptimized({
  cvText,
  jobDescriptionText,
  formText,
  formHtml,
  modelId,
  apiBaseUrl,
  onProgress,
  onChunk,
  useStreaming = true,
}) {
  // Lazy-load heavy deps when needed (content script executes fast otherwise)
  // Note: compress-utils and cache-utils are already split; keep main client lean
  // Abort any in-flight request
  if (currentAbortController) {
    currentAbortController.abort();
  }
  currentAbortController = new AbortController();
  const signal = currentAbortController.signal;

  try {
    // Step 1: Try response cache first (RAG reuse)
    onProgress?.('Checking cache...');
    const cached = await getResponseCache(cvText, jobDescriptionText, formText);
    if (cached) {
      console.log('[OptimizedAPI] Using cached response');
      return { result: cached, fromCache: true, elapsedMs: 0 };
    }
    console.log('[OptimizedAPI] Cache miss - sending fresh request');

    // Step 1.5: Get user profile for pre-fill and context
    const userProfile = await getUserProfile();
    const preFilled = userProfile
      ? prePopulateFromProfile(formText, userProfile)
      : [];
    const profileContext = userProfile ? buildProfileContext(userProfile) : '';

    if (preFilled.length > 0) {
      console.log(
        `[OptimizedAPI] Pre-filled ${preFilled.length} fields from profile`
      );
    }

    // Step 1.6: Check cached answers for remaining fields
    const cachedAnswers = await getCachedAnswersForForm(formText, preFilled);

    // Merge profile pre-fill and cached answers
    const allPreFilled = [...preFilled, ...cachedAnswers];

    if (cachedAnswers.length > 0) {
      console.log(
        `[OptimizedAPI] Found ${cachedAnswers.length} cached answers from previous applications`
      );
    }

    // Step 2: Check CV profile cache
    onProgress?.('Analyzing CV...');
    let cvProfile = await getCVProfile(cvText);
    if (!cvProfile) {
      // Generate and cache CV profile
      const compact = createCompactCV(cvText);
      await setCVProfile(cvText, compact.summary);
      cvProfile = compact.summary;
    }

    // Step 3: Check JD cache
    onProgress?.('Processing job description...');
    let jdSummary = await getJDCache(jobDescriptionText);
    if (!jdSummary) {
      // Compress and cache JD
      const compressed = compressJD(jobDescriptionText);
      jdSummary = compressed;
      await setJDCache(jobDescriptionText, compressed);
    }

    // Step 4: Build RAG-style minimal inputs
    onProgress?.('Preparing analysis...');

    // Reduce CV to relevant slices for the current form (keep name/contact header + skills + recent roles)
    function pickRelevantCVForForm(fullCv, form) {
      if (!fullCv) return '';
      const lines = fullCv.split(/\n+/);
      const keep = [];

      // Always keep first 8 lines (usually name/contact)
      for (let i = 0; i < Math.min(8, lines.length); i++) keep.push(lines[i]);

      // Extract hints from form labels
      const labels = [
        ...String(form || '').matchAll(/FIELD:.*?label=([^\n]+)/gi),
      ].map((m) => (m[1] || '').toLowerCase());

      const keywords = new Set(
        labels
          .flatMap((l) => l.split(/[^a-z0-9+]+/i))
          .filter((t) => t && t.length > 2)
      );

      // Walk lines and keep those that match label keywords or belong to Skills/Experience sections
      let inSkills = false;
      let inExperience = false;
      for (const ln of lines) {
        const lower = ln.toLowerCase();
        if (/^(skills|technical|core competencies)/i.test(ln)) {
          inSkills = true;
          inExperience = false;
          keep.push(ln);
          continue;
        }
        if (/^(experience|employment|work history)/i.test(ln)) {
          inSkills = false;
          inExperience = true;
          keep.push(ln);
          continue;
        }
        if (/^education/i.test(ln)) {
          inSkills = false;
          inExperience = false;
        }

        const hasKeyword = [...keywords].some((k) => lower.includes(k));
        const isBullet = /^[-•*]\s/.test(ln);
        if (
          hasKeyword ||
          (inSkills && isBullet) ||
          (inExperience && ln.length < 120)
        ) {
          keep.push(ln);
        }
        if (keep.join('\n').length > 9000) break; // safety bound
      }

      return keep.join('\n');
    }

    const compressedCV =
      pickRelevantCVForForm(cvText, formText) || compressCV(cvText);
    const compressedForm = compressForm(formText);

    // Step 5: Make API call (use streaming if available)
    const started = Date.now();

    if (useStreaming) {
      // Use streaming endpoint
      onProgress?.('Starting analysis (streaming)...');
      const aiResult = await callStreamingAPI({
        cvText: compressedCV,
        jobDescriptionText: jdSummary,
        formText: compressedForm,
        formHtml: formHtml || '',
        profileContext,
        modelId,
        apiBaseUrl,
        signal,
        onChunk,
      });

      // Merge all pre-filled (profile + cached) + AI results
      const mergedResult = mergeResults(allPreFilled, aiResult);

      const elapsedMs = Date.now() - started;

      // Save to response cache for reuse
      await setResponseCache(
        cvText,
        jobDescriptionText,
        formText,
        mergedResult
      );

      // Learn: persist AI answers for future reuse
      try {
        const fields = Array.isArray(mergedResult?.fields)
          ? mergedResult.fields
          : [];
        for (const f of fields) {
          if (
            f?.name &&
            typeof f.value === 'string' &&
            f.value.trim().length >= 8 &&
            f.value.length <= 5000
          ) {
            await saveCustomAnswer(String(f.name), String(f.value));
          }
        }
      } catch (e) {
        console.warn('[OptimizedAPI] Save answers skipped:', e);
      }

      return {
        result: mergedResult,
        fromCache: false,
        elapsedMs,
        preFilledCount: allPreFilled.length,
        profileFilledCount: preFilled.length,
        cachedAnswersCount: cachedAnswers.length,
      };
    } else {
      // Use regular endpoint
      onProgress?.('Analyzing...');
      const aiResult = await callRegularAPI({
        cvText: compressedCV,
        jobDescriptionText: jdSummary,
        formText: compressedForm,
        formHtml: formHtml || '',
        profileContext,
        modelId,
        apiBaseUrl,
        signal,
      });

      // Merge all pre-filled (profile + cached) + AI results
      const mergedResult = mergeResults(allPreFilled, aiResult);

      const elapsedMs = Date.now() - started;

      // Save to response cache for reuse
      await setResponseCache(
        cvText,
        jobDescriptionText,
        formText,
        mergedResult
      );

      // Learn: persist AI answers for future reuse
      try {
        const fields = Array.isArray(mergedResult?.fields)
          ? mergedResult.fields
          : [];
        for (const f of fields) {
          if (
            f?.name &&
            typeof f.value === 'string' &&
            f.value.trim().length >= 8 &&
            f.value.length <= 5000
          ) {
            await saveCustomAnswer(String(f.name), String(f.value));
          }
        }
      } catch (e) {
        console.warn('[OptimizedAPI] Save answers skipped:', e);
      }

      return {
        result: mergedResult,
        fromCache: false,
        elapsedMs,
        preFilledCount: allPreFilled.length,
        profileFilledCount: preFilled.length,
        cachedAnswersCount: cachedAnswers.length,
      };
    }
  } catch (e) {
    if (e.name === 'AbortError') {
      throw new Error('Request cancelled');
    }
    throw e;
  } finally {
    currentAbortController = null;
  }
}

/**
 * Merge pre-filled fields with AI results
 */
function mergeResults(preFilled, aiResult) {
  if (!preFilled || preFilled.length === 0) {
    return aiResult;
  }

  // Create a map of pre-filled field names (case-insensitive)
  const preFilledMap = new Map();
  preFilled.forEach((field) => {
    preFilledMap.set(field.name.toLowerCase(), field);
  });

  // Filter out AI fields that are already pre-filled
  const aiFields = aiResult.fields || [];
  const filteredAIFields = aiFields.filter((field) => {
    return !preFilledMap.has(field.name.toLowerCase());
  });

  // Combine: pre-filled first, then AI fields
  return {
    fields: [...preFilled, ...filteredAIFields],
  };
}

/**
 * Call streaming API endpoint
 */
async function callStreamingAPI({
  cvText,
  jobDescriptionText,
  formText,
  formHtml,
  profileContext,
  modelId,
  apiBaseUrl,
  signal,
  onChunk,
}) {
  // Get auth headers
  const headers = {
    'Content-Type': 'application/json',
  };

  // Add auth token and API keys from chrome.storage
  try {
    const storage = await chrome.storage.sync.get([
      'firebaseSession',
      'openaiApiKey',
      'geminiApiKey',
      'claudeApiKey',
    ]);

    let authToken = storage.firebaseSession?.access_token || '';
    if (!authToken) {
      const localToken = await chrome.storage.local
        .get('rrAuthToken')
        .catch(() => ({}));
      authToken = localToken?.rrAuthToken || '';
    }
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }

    // Add API keys
    if (storage.openaiApiKey) {
      headers['x-openai-key'] = storage.openaiApiKey;
    }
    if (storage.geminiApiKey) {
      headers['x-gemini-key'] = storage.geminiApiKey;
    }
    if (storage.claudeApiKey) {
      headers['x-claude-key'] = storage.claudeApiKey;
    }
  } catch (e) {
    console.error('[OptimizedAPI] Error getting API keys:', e);
  }

  const response = await fetch(`${apiBaseUrl}/v1/analyze-form-stream`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      cvText: normalizeText(cvText),
      jobDescriptionText: normalizeText(jobDescriptionText),
      formText: normalizeText(formText),
      formHtml: formHtml ? normalizeText(formHtml).slice(0, 30000) : '',
      profileContext: profileContext || '',
      modelId,
    }),
    signal,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'API error');
  }

  // Parse SSE stream
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let result = null;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      if (!line.trim()) continue;

      if (line.startsWith('event: ')) {
        const event = line.slice(7).trim();
        const nextLine = lines.shift();
        if (!nextLine || !nextLine.startsWith('data: ')) continue;

        try {
          const data = JSON.parse(nextLine.slice(6));

          if (event === 'chunk') {
            onChunk?.(data.text);
          } else if (event === 'done') {
            result = data.result;
          } else if (event === 'error') {
            throw new Error(data.error);
          } else if (event === 'status') {
            // Progress update
          }
        } catch (e) {
          if (e.message) throw e;
          // Ignore parse errors for individual events
        }
      }
    }
  }

  if (!result) {
    throw new Error('No result from streaming API');
  }

  return result;
}

/**
 * Call regular API endpoint (fallback)
 */
async function callRegularAPI({
  cvText,
  jobDescriptionText,
  formText,
  formHtml,
  profileContext,
  modelId,
  apiBaseUrl,
  signal,
}) {
  // Get auth headers
  const headers = {
    'Content-Type': 'application/json',
  };

  // Add auth token and API keys from chrome.storage
  try {
    const storage = await chrome.storage.sync.get([
      'firebaseSession',
      'openaiApiKey',
      'geminiApiKey',
      'claudeApiKey',
    ]);

    let authToken = storage.firebaseSession?.access_token || '';
    if (!authToken) {
      const localToken = await chrome.storage.local
        .get('rrAuthToken')
        .catch(() => ({}));
      authToken = localToken?.rrAuthToken || '';
    }
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }

    // Add API keys
    if (storage.openaiApiKey) {
      headers['x-openai-key'] = storage.openaiApiKey;
    }
    if (storage.geminiApiKey) {
      headers['x-gemini-key'] = storage.geminiApiKey;
    }
    if (storage.claudeApiKey) {
      headers['x-claude-key'] = storage.claudeApiKey;
    }
  } catch (e) {
    console.error('[OptimizedAPI] Error getting API keys:', e);
  }

  const response = await fetch(`${apiBaseUrl}/v1/analyze-form`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      cvText: normalizeText(cvText),
      jobDescriptionText: normalizeText(jobDescriptionText),
      formText: normalizeText(formText),
      formHtml: formHtml ? normalizeText(formHtml).slice(0, 30000) : '', // Include HTML for better AI understanding
      profileContext: profileContext || '',
      modelId,
    }),
    signal,
  });

  if (!response.ok) {
    if (response.status === 401) {
      throw new Error('AUTH_REQUIRED');
    }
    if (
      response.status === 402 ||
      response.status === 429 ||
      response.status === 403
    ) {
      throw new Error('LIMIT_REACHED');
    }
    const error = await response.json();
    throw new Error(error.error || 'API error');
  }

  const data = await response.json();
  return data.result || data.data?.result || data.data;
}

/**
 * Cancel any in-flight request
 */
export function cancelCurrentRequest() {
  if (currentAbortController) {
    currentAbortController.abort();
    currentAbortController = null;
  }
}

/**
 * Preload CV profile (can be called when CV is updated)
 */
export async function preloadCVProfile(cvText) {
  try {
    const existing = await getCVProfile(cvText);
    if (!existing) {
      const compact = createCompactCV(cvText);
      await setCVProfile(cvText, compact.summary);
      console.log('[OptimizedAPI] CV profile cached');
    }
  } catch (e) {
    console.error('[OptimizedAPI] Error preloading CV:', e);
  }
}

/**
 * Preload JD cache (can be called when JD is scanned)
 */
export async function preloadJDCache(jdText) {
  try {
    const existing = await getJDCache(jdText);
    if (!existing) {
      const compressed = compressJD(jdText);
      await setJDCache(jdText, compressed);
      console.log('[OptimizedAPI] JD cached');
    }
  } catch (e) {
    console.error('[OptimizedAPI] Error preloading JD:', e);
  }
}
