/**
 * Validation Utilities
 * Comprehensive validation functions for all form fields across the extension
 */

(() => {
  'use strict';

  const ValidationUtils = {
    /**
     * Email validation (RFC 5322 compliant)
     * @param {string} email - Email address to validate
     * @returns {boolean} - True if valid
     */
    validateEmail(email) {
      const trimmed = String(email || '').trim();
      if (!trimmed) return false;
      
      const re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
      return re.test(trimmed);
    },

    /**
     * Password strength validation
     * @param {string} password - Password to validate
     * @returns {object} - {valid: boolean, errors: string[]}
     */
    validatePassword(password) {
      const errors = [];
      
      if (!password || password.length < 8) {
        errors.push('Password must be at least 8 characters');
      }
      if (!/[a-z]/.test(password)) {
        errors.push('Password must contain at least one lowercase letter');
      }
      if (!/[A-Z]/.test(password)) {
        errors.push('Password must contain at least one uppercase letter');
      }
      if (!/[0-9]/.test(password)) {
        errors.push('Password must contain at least one number');
      }
      
      return {
        valid: errors.length === 0,
        errors,
        strength: this.getPasswordStrength(password)
      };
    },

    /**
     * Get password strength score
     * @param {string} password - Password to evaluate
     * @returns {string} - 'weak', 'medium', 'strong', or 'very-strong'
     */
    getPasswordStrength(password) {
      if (!password) return 'weak';
      
      let score = 0;
      
      // Length
      if (password.length >= 8) score++;
      if (password.length >= 12) score++;
      if (password.length >= 16) score++;
      
      // Character types
      if (/[a-z]/.test(password)) score++;
      if (/[A-Z]/.test(password)) score++;
      if (/[0-9]/.test(password)) score++;
      if (/[^a-zA-Z0-9]/.test(password)) score++; // Special characters
      
      if (score <= 3) return 'weak';
      if (score <= 5) return 'medium';
      if (score <= 6) return 'strong';
      return 'very-strong';
    },

    /**
     * Name validation
     * @param {string} name - Name to validate
     * @returns {boolean} - True if valid
     */
    validateName(name) {
      const trimmed = String(name || '').trim();
      if (trimmed.length < 2) return false;
      
      // Allow letters, spaces, hyphens, apostrophes, and common international characters
      return /^[a-zA-ZÀ-ÿ\s'-]+$/.test(trimmed);
    },

    /**
     * URL validation
     * @param {string} url - URL to validate
     * @returns {boolean} - True if valid
     */
    validateURL(url) {
      if (!url) return false;
      
      try {
        const urlObj = new URL(url);
        return ['http:', 'https:'].includes(urlObj.protocol);
      } catch (_) {
        return false;
      }
    },

    /**
     * Phone number validation (international format)
     * @param {string} phone - Phone number to validate
     * @returns {boolean} - True if valid
     */
    validatePhone(phone) {
      if (!phone) return false;
      
      // Remove all non-digit characters for validation
      const digits = phone.replace(/\D/g, '');
      
      // Accept 10-15 digits (covers most international formats)
      return digits.length >= 10 && digits.length <= 15;
    },

    /**
     * LinkedIn URL validation
     * @param {string} url - LinkedIn URL to validate
     * @returns {boolean} - True if valid
     */
    validateLinkedInURL(url) {
      if (!this.validateURL(url)) return false;
      
      try {
        const urlObj = new URL(url);
        return (
          (urlObj.hostname === 'linkedin.com' || urlObj.hostname === 'www.linkedin.com') &&
          urlObj.pathname.includes('/in/')
        );
      } catch (_) {
        return false;
      }
    },

    /**
     * GitHub URL validation
     * @param {string} url - GitHub URL to validate
     * @returns {boolean} - True if valid
     */
    validateGitHubURL(url) {
      if (!this.validateURL(url)) return false;
      
      try {
        const urlObj = new URL(url);
        return (
          (urlObj.hostname === 'github.com' || urlObj.hostname === 'www.github.com') &&
          urlObj.pathname.length > 1
        );
      } catch (_) {
        return false;
      }
    },

    /**
     * Portfolio/Website URL validation
     * @param {string} url - Portfolio URL to validate
     * @returns {boolean} - True if valid
     */
    validatePortfolioURL(url) {
      return this.validateURL(url);
    },

    /**
     * ZIP/Postal code validation (flexible for international)
     * @param {string} zip - ZIP/Postal code to validate
     * @param {string} country - Optional country code (US, UK, CA, etc.)
     * @returns {boolean} - True if valid
     */
    validateZipCode(zip, country = 'US') {
      if (!zip) return false;
      
      const patterns = {
        US: /^\d{5}(-\d{4})?$/, // 12345 or 12345-6789
        UK: /^[A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2}$/i, // SW1A 1AA
        CA: /^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/i, // K1A 0B1
        DE: /^\d{5}$/, // 12345
        FR: /^\d{5}$/, // 75001
        JP: /^\d{3}-?\d{4}$/, // 123-4567
        AU: /^\d{4}$/, // 2000
        IN: /^\d{6}$/, // 110001
      };
      
      const pattern = patterns[country.toUpperCase()] || /^[A-Z0-9\s-]{3,10}$/i;
      return pattern.test(zip.trim());
    },

    /**
     * Date validation (YYYY-MM-DD format)
     * @param {string} date - Date string to validate
     * @returns {boolean} - True if valid
     */
    validateDate(date) {
      if (!date) return false;
      
      const dateObj = new Date(date);
      return dateObj instanceof Date && !isNaN(dateObj.getTime());
    },

    /**
     * Age validation (must be 18+)
     * @param {string} birthDate - Birth date (YYYY-MM-DD)
     * @returns {boolean} - True if 18 or older
     */
    validateAge(birthDate) {
      if (!this.validateDate(birthDate)) return false;
      
      const today = new Date();
      const birth = new Date(birthDate);
      let age = today.getFullYear() - birth.getFullYear();
      const monthDiff = today.getMonth() - birth.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
      }
      
      return age >= 18;
    },

    /**
     * Required field validation
     * @param {string} value - Value to validate
     * @returns {boolean} - True if not empty
     */
    validateRequired(value) {
      return String(value || '').trim().length > 0;
    },

    /**
     * Minimum length validation
     * @param {string} value - Value to validate
     * @param {number} minLength - Minimum length
     * @returns {boolean} - True if meets minimum
     */
    validateMinLength(value, minLength) {
      return String(value || '').trim().length >= minLength;
    },

    /**
     * Maximum length validation
     * @param {string} value - Value to validate
     * @param {number} maxLength - Maximum length
     * @returns {boolean} - True if within maximum
     */
    validateMaxLength(value, maxLength) {
      return String(value || '').trim().length <= maxLength;
    },

    /**
     * Numeric validation
     * @param {string} value - Value to validate
     * @returns {boolean} - True if numeric
     */
    validateNumeric(value) {
      return !isNaN(parseFloat(value)) && isFinite(value);
    },

    /**
     * Range validation
     * @param {number} value - Value to validate
     * @param {number} min - Minimum value
     * @param {number} max - Maximum value
     * @returns {boolean} - True if within range
     */
    validateRange(value, min, max) {
      const num = parseFloat(value);
      return !isNaN(num) && num >= min && num <= max;
    },

    /**
     * File extension validation
     * @param {string} filename - Filename to validate
     * @param {string[]} allowedExtensions - Array of allowed extensions (e.g., ['pdf', 'doc', 'docx'])
     * @returns {boolean} - True if extension is allowed
     */
    validateFileExtension(filename, allowedExtensions) {
      if (!filename) return false;
      
      const ext = filename.split('.').pop().toLowerCase();
      return allowedExtensions.map(e => e.toLowerCase()).includes(ext);
    },

    /**
     * File size validation
     * @param {number} sizeInBytes - File size in bytes
     * @param {number} maxSizeInMB - Maximum size in MB
     * @returns {boolean} - True if within size limit
     */
    validateFileSize(sizeInBytes, maxSizeInMB) {
      const maxBytes = maxSizeInMB * 1024 * 1024;
      return sizeInBytes <= maxBytes;
    },

    /**
     * Sanitize string (remove HTML tags and dangerous characters)
     * @param {string} str - String to sanitize
     * @returns {string} - Sanitized string
     */
    sanitizeString(str) {
      if (!str) return '';
      
      return String(str)
        .replace(/<[^>]*>/g, '') // Remove HTML tags
        .replace(/[<>'"]/g, '') // Remove dangerous characters
        .trim();
    },

    /**
     * Format phone number for display
     * @param {string} phone - Phone number to format
     * @param {string} format - Format type ('US', 'INTERNATIONAL')
     * @returns {string} - Formatted phone number
     */
    formatPhone(phone, format = 'US') {
      const digits = phone.replace(/\D/g, '');
      
      if (format === 'US' && digits.length === 10) {
        return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
      }
      
      if (format === 'INTERNATIONAL') {
        return `+${digits}`;
      }
      
      return phone;
    },

    /**
     * Get validation error message
     * @param {string} fieldName - Name of the field
     * @param {string} validationType - Type of validation that failed
     * @returns {string} - Error message
     */
    getErrorMessage(fieldName, validationType) {
      const messages = {
        required: `${fieldName} is required.`,
        email: 'Please enter a valid email address.',
        url: 'Please enter a valid URL (starting with http:// or https://).',
        phone: 'Please enter a valid phone number (10-15 digits).',
        linkedin: 'Please enter a valid LinkedIn profile URL (e.g., https://linkedin.com/in/username).',
        github: 'Please enter a valid GitHub profile URL (e.g., https://github.com/username).',
        name: 'Please enter a valid name (letters, spaces, hyphens only).',
        password: 'Password must be at least 8 characters with letters and numbers.',
        minLength: `${fieldName} is too short.`,
        maxLength: `${fieldName} is too long.`,
        numeric: `${fieldName} must be a number.`,
        date: 'Please enter a valid date.',
        age: 'You must be at least 18 years old.',
      };
      
      return messages[validationType] || `${fieldName} is invalid.`;
    }
  };

  // Export for use in other scripts
  if (typeof window !== 'undefined') {
    window.ValidationUtils = ValidationUtils;
  }
  
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = ValidationUtils;
  }
})();




























