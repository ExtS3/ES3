# Interview Generation Error Handling Fix

## Issues Fixed

### 1. ❌ Banner Stuck in "Loading" State

**Problem:** When background generation failed, the banner showed "Generation failed (will retry later)" but kept the loading spinner visible.

**Solution:** Now hides the banner completely on failure instead of showing an error message.

```javascript
// Before
if (!res.ok || bgFields.length === 0) {
  statusEl.className = 'status-banner'; // Shows error but keeps visible
  statusText.textContent = 'Generation failed (will retry later).';
}

// After
if (!res.ok || bgFields.length === 0) {
  statusEl.style.display = 'none'; // Completely hides the banner
}
```

**Rationale:** If background generation fails, it's better to silently retry later than to show a persistent error that clutters the UI. The answers will be cached once they succeed.

### 2. ❌ JSON Parsing Errors

**Problem:** AI responses sometimes contained malformed JSON:

- Unquoted property names
- Trailing commas
- Single quotes instead of double quotes
- Extra prose before/after JSON

**Error Example:**

```
Expected double-quoted property name in JSON at position 6863 (line 49 column 7)
```

**Enhanced Solution:** Multi-step JSON recovery process:

```javascript
try {
  data = JSON.parse(raw);
} catch (e) {
  console.log(
    '[ProfileSetup] JSON parse failed, attempting recovery...',
    e.message
  );
  try {
    // Extract JSON object from raw text
    const match = raw.match(/\{[\s\S]*\}/);
    if (match) {
      let hopeful = match[0];

      // Fix 1: Unquoted keys → "key":
      hopeful = hopeful.replace(/([\{,]\s*)([A-Za-z0-9_]+)\s*:/g, '$1"$2":');

      // Fix 2: Trailing commas → remove
      hopeful = hopeful.replace(/,(\s*[}\]])/g, '$1');

      // Fix 3: Single quotes → double quotes
      hopeful = hopeful.replace(/'/g, '"');

      data = JSON.parse(hopeful);
      console.log('[ProfileSetup] Recovery successful!');
    }
  } catch (e2) {
    console.error('[ProfileSetup] Recovery failed:', e2.message);
    console.log(
      '[ProfileSetup] Raw response (first 1000 chars):',
      raw.slice(0, 1000)
    );
    data = { error: 'Failed to parse AI response', raw: raw.slice(0, 5000) };
  }
}
```

### 3. ❌ Uncaught Exceptions

**Problem:** If any error occurred in the background generation, it could crash without hiding the loading banner.

**Solution:** Added catch block to ensure banner is always hidden on error:

```javascript
} catch (e) {
  console.error('[ProfileSetup] Background interview generation error:', e);
  // Hide loading banner on error
  const statusEl = document.getElementById('interviewGenStatus');
  if (statusEl) {
    statusEl.style.display = 'none';
  }
}
```

## Debug Logging Improvements

Added detailed console logs to help diagnose issues:

1. **Parse attempt**: `[ProfileSetup] JSON parse failed, attempting recovery...`
2. **Recovery attempt**: `[ProfileSetup] Attempting to parse cleaned JSON...`
3. **Recovery success**: `[ProfileSetup] Recovery successful!`
4. **Recovery failure**: `[ProfileSetup] Recovery failed: <error message>`
5. **Raw response**: First 1000 characters of the response for debugging

## User Experience Flow

### ✅ Success Case

```
1. User uploads CV
2. Orange banner appears: "Preparing interview answers…" 🔄
3. AI generates answers (gemini-2.5-flash-lite)
4. Answers fill into cards
5. Green banner: "Prepared 12 interview answers and auto-filled 12 fields" ✅
6. Each card shows "Saved ✓" badge
```

### ⚠️ Failure Case (Silent)

```
1. User uploads CV
2. Orange banner appears: "Preparing interview answers…" 🔄
3. AI returns malformed JSON or fails
4. JSON recovery attempts to fix it
5. If recovery fails → Banner disappears (no error shown)
6. User can still manually fill questions
7. System will retry on next CV upload
```

## Why Silent Failure?

**Decision:** Hide the banner instead of showing "Generation failed"

**Reasons:**

1. **Non-blocking**: Users can still manually fill questions
2. **Retry-friendly**: Will automatically retry on next profile save or CV upload
3. **Cleaner UX**: No persistent error messages cluttering the UI
4. **Already cached**: If generation succeeds later, answers are saved and reused
5. **Background task**: This is a nice-to-have enhancement, not a critical feature

## Testing Scenarios

### ✅ Valid JSON Response

```json
{
  "fields": [
    { "name": "Tell me about yourself", "value": "I am a..." },
    { "name": "Greatest strength", "value": "My greatest..." }
  ]
}
```

→ Parses successfully, fills cards

### ✅ Unquoted Keys (Fixed by Recovery)

```json
{
  "fields": [{ "name": "Tell me about yourself", "value": "I am a..." }]
}
```

→ Recovery adds quotes, parses successfully

### ✅ Trailing Commas (Fixed by Recovery)

```json
{
  "fields": [{ "name": "Tell me about yourself", "value": "I am a..." }]
}
```

→ Recovery removes trailing commas, parses successfully

### ✅ Single Quotes (Fixed by Recovery)

```json
{
  "fields": [{ "name": "Tell me about yourself", "value": "I am a..." }]
}
```

→ Recovery converts to double quotes, parses successfully

### ⚠️ Completely Invalid JSON

```
This is some prose text that isn't JSON at all.
```

→ Recovery fails, banner hides, logs error with raw response

## Related Files

- `/home/stationone/Desktop/up/ancilia/chromeextension2/profile-setup.js` (lines 896-999)
- `/home/stationone/Desktop/up/ancilia/chromeextension2/INTERVIEW_GENERATION_UI_UPDATE.md`
- `/home/stationone/Desktop/up/ancilia/chromeextension2/INTERVIEW_QUESTIONS_REDESIGN.md`

## Future Improvements

- [ ] Retry logic with exponential backoff
- [ ] Fallback to a different AI model if one fails consistently
- [ ] User notification (optional): "AI suggestions available" when generation succeeds
- [ ] Manual "Regenerate with AI" button for failed cases
