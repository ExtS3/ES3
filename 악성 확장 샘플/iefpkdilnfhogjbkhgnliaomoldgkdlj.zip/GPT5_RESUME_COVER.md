# GPT-5 for Resume and Cover Letter Generation

## Summary

Updated the backend to use **GPT-5 Mini** as the default model for resume and cover letter generation, ensuring higher quality outputs.

## Changes Made

### 1. Resume Generation (`generateResumeText`)

**File:** `vercel-backend/lib/openai.ts`

**Before:**

```typescript
const ui = String(modelId || '')
  .trim()
  .toLowerCase();
// ... provider checks ...
return callOpenAIText({ apiKey, system, user });
```

**After:**

```typescript
const ui = String(modelId || 'gpt-5-mini') // Default to GPT-5 Mini
  .trim()
  .toLowerCase();
// ... provider checks ...
// Default to GPT-5 Mini for resume generation
return callOpenAIText({ apiKey, system, user, preferredModel: 'gpt-5-mini' });
```

### 2. Cover Letter Generation (`generateCoverText`)

**File:** `vercel-backend/lib/openai.ts`

**Before:**

```typescript
const ui = String(modelId || '')
  .trim()
  .toLowerCase();
// ... provider checks ...
return callOpenAIText({ apiKey, system, user });
```

**After:**

```typescript
const ui = String(modelId || 'gpt-5-mini') // Default to GPT-5 Mini
  .trim()
  .toLowerCase();
// ... provider checks ...
// Default to GPT-5 Mini for cover letter generation
return callOpenAIText({ apiKey, system, user, preferredModel: 'gpt-5-mini' });
```

### 3. Updated `callOpenAIText` Function

**File:** `vercel-backend/lib/openai.ts`

Added `preferredModel` parameter to allow specifying a preferred model:

```typescript
async function callOpenAIText({
  apiKey,
  system,
  user,
  preferredModel, // New parameter
}: {
  apiKey: string;
  system: string;
  user: string;
  preferredModel?: string; // Optional
}) {
  const preferred = preferredModel
    ? [preferredModel] // Use specified model if provided
    : (process.env.OPENAI_MODEL || 'gpt-5-nano')
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
  const fallbacks = ['gpt-5-mini', 'gpt-5-nano'];
  const models = Array.from(new Set([...preferred, ...fallbacks]));
  // ... rest of function
}
```

## How It Works

### Model Selection Priority

1. **User Selects Model in UI** → Uses that model (Gemini, Claude, Grok, or specific GPT model)
2. **No Model Selected** → Defaults to **GPT-5 Mini**
3. **GPT-5 Mini Fails** → Falls back to **GPT-5 Nano**
4. **All Fail** → Returns error

### Example Flow

**Scenario 1: User selects GPT-4o Mini**

```
User clicks "Generate Resume" with GPT-4o Mini selected
→ Backend receives modelId: 'gpt-4o-mini'
→ Uses GPT-4o Mini for generation
```

**Scenario 2: User has no model selected (default)**

```
User clicks "Generate Resume" with default model
→ Backend receives modelId: undefined or empty
→ Defaults to 'gpt-5-mini'
→ Uses GPT-5 Mini for generation
```

**Scenario 3: User selects Gemini**

```
User clicks "Generate Resume" with Gemini selected
→ Backend receives modelId: 'gemini-2.5-flash'
→ Routes to Gemini API (not OpenAI)
→ Uses Gemini for generation
```

## Benefits

### 1. **Higher Quality Output**

- GPT-5 Mini provides better:
  - Resume formatting
  - Cover letter writing
  - Professional tone
  - Attention to detail

### 2. **Better Default Experience**

- New users get high-quality results by default
- No need to manually select GPT-5
- Consistent quality across all generations

### 3. **Flexibility**

- Users can still choose other models (Gemini, Claude, Grok)
- Power users can select specific models for their needs
- Falls back gracefully if GPT-5 Mini is unavailable

### 4. **Cost-Effective**

- GPT-5 Mini is faster than GPT-5 Pro
- More cost-effective than GPT-4o
- Better quality than GPT-5 Nano

## Model Comparison

| Model            | Speed    | Quality  | Cost   | Best For                             |
| ---------------- | -------- | -------- | ------ | ------------------------------------ |
| **GPT-5 Mini**   | ⚡⚡⚡   | ⭐⭐⭐⭐ | 💰💰   | **Resume & Cover Letters** (Default) |
| GPT-5 Nano       | ⚡⚡⚡⚡ | ⭐⭐⭐   | 💰     | Quick drafts                         |
| GPT-4o Mini      | ⚡⚡     | ⭐⭐⭐⭐ | 💰💰💰 | Alternative option                   |
| Gemini 2.5 Flash | ⚡⚡⚡⚡ | ⭐⭐⭐   | 💰     | Fast generation                      |
| Claude 3.5 Haiku | ⚡⚡⚡   | ⭐⭐⭐⭐ | 💰💰   | Creative writing                     |

## Testing

### Test Resume Generation

1. Open extension sidepanel
2. Add resume/CV and job description
3. Click "Generate Resume"
4. Should use GPT-5 Mini by default
5. Check console logs: `[OpenAI] Using model: gpt-5-mini`

### Test Cover Letter Generation

1. Open extension sidepanel
2. Add resume/CV and job description
3. Click "Generate Cover Letter"
4. Should use GPT-5 Mini by default
5. Check console logs: `[OpenAI] Using model: gpt-5-mini`

### Test Model Selection

1. Select different model from dropdown (e.g., Gemini)
2. Generate resume or cover letter
3. Should use selected model (not GPT-5 Mini)
4. Check console logs for correct model

## Environment Variables

You can override the default model using environment variables:

```bash
# .env file
OPENAI_MODEL=gpt-5-mini,gpt-5-nano  # Preferred models (comma-separated)
```

## Backward Compatibility

✅ **Fully backward compatible**

- Existing code continues to work
- No breaking changes
- Users who selected specific models still use those models
- Only affects default behavior when no model is selected

## Future Improvements

1. **Model Performance Tracking**

   - Track which models produce best results
   - A/B test different models
   - Optimize based on user feedback

2. **Smart Model Selection**

   - Auto-select best model based on:
     - CV length
     - Job description complexity
     - User preferences

3. **Model-Specific Prompts**
   - Optimize prompts for each model
   - Leverage model-specific strengths
