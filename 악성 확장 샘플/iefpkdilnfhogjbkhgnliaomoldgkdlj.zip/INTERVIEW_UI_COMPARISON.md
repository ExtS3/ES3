# Interview Questions UI - Before & After Comparison

## Visual Layout Comparison

### 🔴 OLD LAYOUT (Hard to Read)

```
┌────────────────────────────────────────────────────────────┐
│ Interview Questions                                        │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  Tell me about yourself  │ [Small cramped textarea]      │
│                          │                                 │
├──────────────────────────┼─────────────────────────────────┤
│  Greatest strength       │ [Small cramped textarea]      │
│                          │                                 │
├──────────────────────────┼─────────────────────────────────┤
│  Greatest weakness       │ [Small cramped textarea]      │
│                          │                                 │
└────────────────────────────────────────────────────────────┘

PROBLEMS:
❌ Questions squished in 260px column
❌ Answers cramped in remaining space
❌ Hard to read at a glance
❌ Unprofessional appearance
❌ No visual hierarchy
❌ Status indicators dynamically added (inconsistent)
```

### 🟢 NEW CARD LAYOUT (Clear & Professional)

```
┌────────────────────────────────────────────────────────────┐
│ Interview Questions                                        │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│  ① Tell me about yourself                      Saved ✓    │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  [Large, comfortable full-width textarea]                 │
│  [Share your professional background...]                  │
│                                                            │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│  ② Greatest strength                           Saved ✓    │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  [Large, comfortable full-width textarea]                 │
│  [Describe your top professional strength...]             │
│                                                            │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│  ③ Greatest weakness                                       │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  [Large, comfortable full-width textarea]                 │
│  [Share a weakness and how you're improving...]           │
│                                                            │
└────────────────────────────────────────────────────────────┘

BENEFITS:
✅ Full-width cards (easy to scan)
✅ Question prominently at top with number badge
✅ Large textarea (100px min-height, resizable)
✅ Professional card design with shadows
✅ Clear visual hierarchy
✅ Built-in status badges with checkmarks
✅ Hover effects and focus states
✅ Context-specific helpful placeholders
```

## Interaction States

### Card Hover

```
Default State:          Hover State:
┌─────────────┐        ┌═══════════════┐
│ Question    │   →    ║ Question      ║  ← Green border
│             │        ║               ║     + shadow
│ [textarea]  │        ║ [textarea]    ║
└─────────────┘        └═══════════════┘
```

### Textarea Focus

```
Inactive:               Active (Typing):
┌─────────────┐        ┌═══════════════┐
│ Question    │   →    ║ Question      ║  ← Green glow
│             │        ║               ║     (3px shadow)
│ [textarea]  │        ║ [TYPING...]   ║  ← White bg
└─────────────┘        └═══════════════┘
```

### Status Badge States

```
Empty:                  Saving:                Saved:
┌─────────────┐        ┌─────────────┐        ┌─────────────┐
│ Question    │        │ Question    │        │ Question  ✓ │
│         (hidden)      │    Saving…  │        │    Saved    │
│             │        │             │        │             │
└─────────────┘        └─────────────┘        └─────────────┘
```

## Key Improvements

### 1. Readability

- **Before**: Questions cramped in narrow column (260px)
- **After**: Full-width cards with prominent question headers

### 2. Answer Space

- **Before**: Textarea squeezed into remaining space with `flex: 1`
- **After**: Full card width, minimum 100px height, vertically resizable

### 3. Visual Hierarchy

- **Before**: Flat, no clear structure
- **After**: Numbered badges (①②③), bold titles, separated cards

### 4. Professional Appearance

- **Before**: Basic flex layout, no polish
- **After**: Card shadows, hover effects, smooth transitions

### 5. User Feedback

- **Before**: Small gray text indicators
- **After**: Green checkmark badges with icons, clear "Saving…" states

### 6. Placeholders

- **Before**: Generic "Write your canonical answer once (2–5 sentences)"
- **After**: Specific guidance per question
  - "Share your professional background and key accomplishments"
  - "Describe your top professional strength with a specific example"
  - "Explain how you resolved a professional disagreement"

## Technical Advantages

### CSS

- Uses CSS variables for consistent brand colors
- Smooth transitions (0.2s ease) for all interactions
- Focus-within for card-level focus indication
- Proper z-index layering for hover/focus effects

### JavaScript

- Cleaner DOM queries (`.question-card` instead of complex selectors)
- Uses `closest()` for parent card lookup
- Status elements already in DOM (no dynamic creation)
- Better event delegation structure

### Accessibility

- Clear focus indicators (green glow)
- Keyboard navigation friendly
- Status changes are screen-reader friendly
- Proper semantic HTML structure

## Result

A **modern, professional, and highly readable** interface that makes answering interview questions feel less overwhelming and more organized.
