(() => {
  'use strict';

  // DOM Elements
  const $ = (id) => document.getElementById(id);
  const onboardingContainer = $('onboardingContainer');
  const loadingScreen = $('loadingScreen');
  const loadingTitle = $('loadingTitle');
  const loadingSubtitle = $('loadingSubtitle');

  // Auth Toggle
  const toggleText = $('toggleText');
  const toggleAuthLink = $('toggleAuthLink');

  // Form Elements
  const authForm = $('authForm');
  const nameField = $('nameField');
  const nameInput = $('nameInput');
  const nameError = $('nameError');
  const emailInput = $('emailInput');
  const emailError = $('emailError');
  const passwordInput = $('passwordInput');
  const passwordHelper = $('passwordHelper');
  const passwordError = $('passwordError');
  const togglePasswordBtn = $('togglePasswordBtn');
  const forgotPasswordContainer = $('forgotPasswordContainer');
  const forgotPasswordLink = $('forgotPasswordLink');
  const checkboxField = $('checkboxField');
  const updatesCheckbox = $('updatesCheckbox');
  const submitBtn = $('submitBtn');
  const submitBtnText = $('submitBtnText');
  const submitSpinner = $('submitSpinner');
  const googleSignInBtn = $('googleSignInBtn');
  const googleBtnText = $('googleBtnText');
  const statusMessage = $('statusMessage');

  // State
  let CONFIG = {
    apiBaseUrl: '',
  };
  let isSignUpMode = true; // Start with sign up by default
  let authSession = null;

  // Utility Functions
  function showElement(el) {
    if (el) el.classList.remove('hidden');
  }

  function hideElement(el) {
    if (el) el.classList.add('hidden');
  }

  function setButtonLoading(btn, textEl, spinnerEl, isLoading) {
    if (!btn) return;
    btn.disabled = isLoading;
    if (textEl) textEl.style.display = isLoading ? 'none' : '';
    if (spinnerEl) {
      if (isLoading) {
        spinnerEl.classList.remove('hidden');
      } else {
        spinnerEl.classList.add('hidden');
      }
    }
  }

  function showStatus(message, type = 'info') {
    if (!statusMessage) return;
    statusMessage.textContent = message;
    statusMessage.className = `status-message ${type}`;
    showElement(statusMessage);
    setTimeout(() => {
      if (type === 'success' || type === 'error') {
        // Keep visible for longer
      }
    }, 5000);
  }

  function hideStatus() {
    if (statusMessage) {
      hideElement(statusMessage);
      statusMessage.textContent = '';
    }
  }

  function showLoadingScreen(title, subtitle) {
    if (loadingTitle) loadingTitle.textContent = title;
    if (loadingSubtitle) loadingSubtitle.textContent = subtitle;
    if (loadingScreen) showElement(loadingScreen);
    if (onboardingContainer) hideElement(onboardingContainer);
  }

  function hideLoadingScreen() {
    if (loadingScreen) hideElement(loadingScreen);
    if (onboardingContainer) showElement(onboardingContainer);
  }

  // ========== VALIDATION FUNCTIONS ==========

  function validateEmail(email) {
    // RFC 5322 compliant email validation
    const re =
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    return re.test(email.trim());
  }

  function validatePassword(password) {
    // At least 8 characters, with letters and numbers
    return (
      password.length >= 8 &&
      /[a-zA-Z]/.test(password) &&
      /[0-9]/.test(password)
    );
  }

  function validateName(name) {
    // At least 2 characters, only letters, spaces, hyphens, and apostrophes
    const trimmed = name.trim();
    return trimmed.length >= 2 && /^[a-zA-Z\s'-]+$/.test(trimmed);
  }

  function validateURL(url) {
    // Validate URL format
    try {
      const urlObj = new URL(url);
      return ['http:', 'https:'].includes(urlObj.protocol);
    } catch (_) {
      return false;
    }
  }

  function validatePhone(phone) {
    // Remove all non-digit characters for validation
    const digits = phone.replace(/\D/g, '');
    // Accept 10-15 digits (international format)
    return digits.length >= 10 && digits.length <= 15;
  }

  function validateLinkedInURL(url) {
    // Validate LinkedIn profile URL
    if (!validateURL(url)) return false;
    try {
      const urlObj = new URL(url);
      return (
        urlObj.hostname.includes('linkedin.com') &&
        urlObj.pathname.includes('/in/')
      );
    } catch (_) {
      return false;
    }
  }

  function validateGitHubURL(url) {
    // Validate GitHub profile URL
    if (!validateURL(url)) return false;
    try {
      const urlObj = new URL(url);
      return (
        urlObj.hostname.includes('github.com') && urlObj.pathname.length > 1
      );
    } catch (_) {
      return false;
    }
  }

  function validatePortfolioURL(url) {
    // Validate portfolio/website URL
    return validateURL(url);
  }

  function showFieldError(inputEl, errorEl, message) {
    if (inputEl) {
      inputEl.classList.add('error');
      inputEl.setAttribute('aria-invalid', 'true');
    }
    if (errorEl) {
      errorEl.textContent = message;
      showElement(errorEl);
    }
  }

  function hideFieldError(inputEl, errorEl) {
    if (inputEl) {
      inputEl.classList.remove('error');
      inputEl.removeAttribute('aria-invalid');
    }
    if (errorEl) {
      errorEl.textContent = '';
      hideElement(errorEl);
    }
  }

  // Auth Mode Toggle
  function updateAuthMode() {
    if (isSignUpMode) {
      // Sign Up Mode
      showElement(nameField);
      showElement(checkboxField);
      hideElement(forgotPasswordContainer);
      showElement(passwordHelper);

      if (toggleText) toggleText.textContent = 'Already have an account?';
      if (toggleAuthLink) toggleAuthLink.textContent = 'Log in';
      if (submitBtnText) submitBtnText.textContent = 'Continue with email';
      if (googleBtnText) googleBtnText.textContent = 'Continue with Google';
    } else {
      // Log In Mode
      hideElement(nameField);
      hideElement(checkboxField);
      showElement(forgotPasswordContainer);
      hideElement(passwordHelper);

      if (toggleText) toggleText.textContent = "Don't have an account?";
      if (toggleAuthLink) toggleAuthLink.textContent = 'Sign up for free';
      if (submitBtnText) submitBtnText.textContent = 'Log in';
      if (googleBtnText) googleBtnText.textContent = 'Log in with Google';
    }

    // Clear errors and status
    hideStatus();
    hideFieldError(nameInput, nameError);
    hideFieldError(emailInput, emailError);
    hideFieldError(passwordInput, passwordError);
  }

  // Toggle Auth Mode
  if (toggleAuthLink) {
    toggleAuthLink.addEventListener('click', (e) => {
      e.preventDefault();
      isSignUpMode = !isSignUpMode;
      updateAuthMode();
    });
  }

  // Password Toggle
  if (togglePasswordBtn) {
    togglePasswordBtn.addEventListener('click', () => {
      const type = passwordInput.type === 'password' ? 'text' : 'password';
      passwordInput.type = type;

      // Update icon
      const img = togglePasswordBtn.querySelector('img');
      if (type === 'text') {
        // Show "eye open" icon (password visible)
        img.src = 'images/eye_open.svg';
        img.alt = 'Hide password';
      } else {
        // Show "eye closed" icon (password hidden)
        img.src = 'images/eye_closed.svg';
        img.alt = 'Show password';
      }
    });
  }

  // ========== REAL-TIME VALIDATION ==========

  // Name validation (only in signup mode)
  if (nameInput) {
    nameInput.addEventListener('blur', () => {
      if (!isSignUpMode) return; // Skip if in login mode

      const name = nameInput.value.trim();
      if (!name) {
        // Don't show error if field is empty on blur (not required)
        hideFieldError(nameInput, nameError);
        return;
      }

      if (!validateName(name)) {
        showFieldError(
          nameInput,
          nameError,
          'Please enter a valid name (letters, spaces, hyphens only).'
        );
      } else {
        hideFieldError(nameInput, nameError);
      }
    });

    nameInput.addEventListener('input', () => {
      // Clear error on input
      hideFieldError(nameInput, nameError);
    });
  }

  // Email validation
  if (emailInput) {
    emailInput.addEventListener('blur', () => {
      const email = emailInput.value.trim();
      if (!email) {
        hideFieldError(emailInput, emailError);
        return;
      }

      if (!validateEmail(email)) {
        showFieldError(
          emailInput,
          emailError,
          'Please enter a valid email address.'
        );
      } else {
        hideFieldError(emailInput, emailError);
      }
    });

    emailInput.addEventListener('input', () => {
      // Clear error on input
      hideFieldError(emailInput, emailError);
    });
  }

  // Password validation
  if (passwordInput) {
    passwordInput.addEventListener('blur', () => {
      if (!isSignUpMode) return; // Only validate strength in signup mode

      const password = passwordInput.value;
      if (!password) {
        hideFieldError(passwordInput, passwordError);
        return;
      }

      if (!validatePassword(password)) {
        showFieldError(
          passwordInput,
          passwordError,
          'Password must be at least 8 characters with letters and numbers.'
        );
      } else {
        hideFieldError(passwordInput, passwordError);
      }
    });

    passwordInput.addEventListener('input', () => {
      // Clear error on input
      hideFieldError(passwordInput, passwordError);
    });
  }

  // Forgot Password
  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener('click', async (e) => {
      e.preventDefault();

      const email = emailInput.value.trim();
      if (!email) {
        showStatus('Please enter your email address first.', 'error');
        emailInput.focus();
        return;
      }

      if (!validateEmail(email)) {
        showStatus('Please enter a valid email address.', 'error');
        emailInput.focus();
        return;
      }

      try {
        showLoadingScreen('Sending reset email...', 'Please wait a moment.');

        const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
        const res = await fetch(`${base}/v1/auth/forgot-password`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ email }),
        });

        hideLoadingScreen();

        if (!res.ok) {
          let data;
          try {
            data = await res.json();
          } catch {
            const text = await res.text();
            data = { error: text };
          }
          const rawMsg = String(data?.error || 'Failed to send reset email');

          // Handle rate limiting
          if (
            res.status === 429 ||
            /over_email_send_rate_limit/i.test(rawMsg)
          ) {
            const secMatch = rawMsg.match(/after\s+(\d+)\s*seconds?/i);
            const seconds = secMatch ? parseInt(secMatch[1], 10) : 60;
            showStatus(
              `Please wait ${seconds}s before requesting another reset email.`,
              'warning'
            );
          } else {
            throw new Error(rawMsg);
          }
          return;
        }

        showStatus(
          'Password reset email sent! Please check your inbox.',
          'success'
        );
      } catch (err) {
        hideLoadingScreen();
        showStatus('Failed to send reset email. Please try again.', 'error');
        console.error('Forgot password error:', err);
      }
    });
  }

  // Config Loading
  async function loadConfig() {
    try {
      const url = chrome.runtime.getURL('config.json');
      const res = await fetch(url);
      if (res.ok) {
        CONFIG = await res.json();
      }
    } catch (err) {
      console.error('Failed to load config:', err);
    }
  }

  // Session Management
  async function loadSession() {
    try {
      const stored = await chrome.storage.sync.get(['firebaseSession']);
      if (stored?.firebaseSession) {
        authSession = stored.firebaseSession;
      }
    } catch (err) {
      console.error('Failed to load session:', err);
    }
  }

  async function saveSession(session) {
    try {
      authSession = session;
      await chrome.storage.sync.set({ firebaseSession: session });
    } catch (err) {
      console.error('Failed to save session:', err);
    }
  }

  async function clearSession() {
    try {
      authSession = null;
      await chrome.storage.sync.remove(['firebaseSession']);
    } catch (err) {
      console.error('Failed to clear session:', err);
    }
  }

  function getAccessToken() {
    if (authSession?.access_token) return authSession.access_token;
    try {
      const rrToken = window.RRIntegration?.getAuthToken?.();
      if (rrToken) return rrToken;
    } catch (_) {}
    return '';
  }

  // Check if already authenticated
  async function checkAuth() {
    try {
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) return false;

      const token = getAccessToken();
      const headers = token ? { Authorization: `Bearer ${token}` } : {};

      const res = await fetch(`${base}/v1/auth/me`, {
        method: 'GET',
        headers,
        credentials: 'include',
      });

      if (res.ok) {
        const data = await res.json();
        if (data?.ok) {
          // Already authenticated - redirect to main app
          showLoadingScreen(
            'Welcome back!',
            'Redirecting to your workspace...'
          );
          setTimeout(() => {
            // Close onboarding and open side panel or redirect
            if (chrome.sidePanel) {
              chrome.sidePanel.open().catch(() => {
                // If side panel doesn't work, close window
                window.close();
              });
            } else {
              window.close();
            }
          }, 1500);
          return true;
        }
      }

      return false;
    } catch (err) {
      console.error('Auth check error:', err);
      return false;
    }
  }

  // Google Sign In
  if (googleSignInBtn) {
    googleSignInBtn.addEventListener('click', async () => {
      try {
        const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
        if (!base) {
          showStatus(
            'Backend not configured. Please contact support.',
            'error'
          );
          return;
        }

        showLoadingScreen(
          isSignUpMode
            ? 'Signing up with Google...'
            : 'Signing in with Google...',
          'You will be redirected to complete authentication.'
        );

        const site = base.replace(/\/api$/, '');
        const redirectTo = `${site}/tracker`;
        const url = `${base}/v1/auth/google/start?redirect_to=${encodeURIComponent(
          redirectTo
        )}`;

        // Open in new tab
        await chrome.tabs.create({ url });

        // Poll for authentication
        const pollInterval = setInterval(async () => {
          const authed = await checkAuth();
          if (authed) {
            clearInterval(pollInterval);
          }
        }, 2000);

        // Stop polling after 60 seconds
        setTimeout(() => {
          clearInterval(pollInterval);
          hideLoadingScreen();
        }, 60000);
      } catch (err) {
        hideLoadingScreen();
        showStatus('Google sign-in failed. Please try again.', 'error');
        console.error('Google sign-in error:', err);
      }
    });
  }

  // Form Submission
  if (authForm) {
    authForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      // Clear previous errors
      hideStatus();
      if (emailError) hideElement(emailError);
      if (passwordError) hideElement(passwordError);

      // Get form values
      const name = nameInput.value.trim();
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();
      const agreedToUpdates = updatesCheckbox.checked;

      // Validation
      let hasError = false;

      // Name validation (signup only)
      if (isSignUpMode) {
        if (!name) {
          showFieldError(nameInput, nameError, 'Please enter your full name.');
          nameInput.focus();
          return;
        }
        if (!validateName(name)) {
          showFieldError(
            nameInput,
            nameError,
            'Please enter a valid name (letters, spaces, hyphens only).'
          );
          nameInput.focus();
          return;
        }
      }

      // Email validation
      if (!email) {
        showFieldError(emailInput, emailError, 'Email is required.');
        hasError = true;
        if (!hasError) emailInput.focus();
      } else if (!validateEmail(email)) {
        showFieldError(
          emailInput,
          emailError,
          'Please enter a valid email address.'
        );
        hasError = true;
        if (!hasError) emailInput.focus();
      }

      // Password validation
      if (!password) {
        showFieldError(passwordInput, passwordError, 'Password is required.');
        hasError = true;
        if (!hasError) passwordInput.focus();
      } else if (isSignUpMode && !validatePassword(password)) {
        showFieldError(
          passwordInput,
          passwordError,
          'Password must be at least 8 characters with letters and numbers.'
        );
        hasError = true;
        if (!hasError) passwordInput.focus();
      }

      if (hasError) {
        return;
      }

      // Submit
      setButtonLoading(submitBtn, submitBtnText, submitSpinner, true);

      try {
        const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
        if (!base) {
          throw new Error('Backend not configured');
        }

        if (isSignUpMode) {
          // Sign Up
          showLoadingScreen(
            'Creating your account...',
            'This will only take a moment.'
          );

          const res = await fetch(`${base}/v1/auth/signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
              name,
              email,
              password,
              marketingConsent: agreedToUpdates,
              agreedToTerms: true,
            }),
          });

          const data = await res.json().catch(() => ({}));

          if (!res.ok || !data?.ok) {
            hideLoadingScreen();

            // Handle specific errors
            if (data?.error && /already exists/i.test(data.error)) {
              // Email already registered - offer to switch to sign in
              emailError.innerHTML =
                'This email is already registered. <a href="#" id="switchToSignInLink" style="color: #6366f1; text-decoration: underline; cursor: pointer;">Sign in instead?</a>';
              showElement(emailError);

              // Add click handler to switch to sign-in mode
              const switchLink = document.getElementById('switchToSignInLink');
              if (switchLink) {
                switchLink.addEventListener('click', (e) => {
                  e.preventDefault();
                  hideElement(emailError);
                  // Switch to sign-in mode
                  isSignUpMode = false;
                  updateAuthMode();
                });
              }
            } else {
              throw new Error(data?.error || 'Sign up failed');
            }
            return;
          }

          // Save session if provided
          if (data?.access_token) {
            await saveSession({ access_token: data.access_token });
          }

          if (data?.requiresConfirmation) {
            hideLoadingScreen();
            showStatus(
              'Account created! Check your email to confirm, then sign in.',
              'success'
            );
          } else {
            // Success - show welcome screen and redirect to profile setup
            showLoadingScreen(
              'Welcome to ReverseRecruiting!',
              'Setting up your profile...'
            );

            // Redirect to profile setup after 1 second
            setTimeout(() => {
              window.location.href = 'profile-setup.html';
            }, 1000);
          }
        } else {
          // Sign In
          showLoadingScreen('Signing in...', 'Please wait a moment.');

          const res = await fetch(`${base}/v1/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ email, password }),
          });

          const data = await res.json().catch(() => ({}));

          if (!res.ok || !data?.ok) {
            hideLoadingScreen();

            // Handle specific errors
            if (res.status === 401 || /invalid/i.test(data?.error || '')) {
              // Check if it's an email not found error
              if (
                data?.error &&
                /not found|doesn't exist|no user/i.test(data.error)
              ) {
                emailError.innerHTML =
                  'No account found with this email. <a href="#" id="switchToSignUpLink" style="color: #6366f1; text-decoration: underline; cursor: pointer;">Create an account?</a>';
                showElement(emailError);

                // Add click handler to switch to sign-up mode
                const switchLink =
                  document.getElementById('switchToSignUpLink');
                if (switchLink) {
                  switchLink.addEventListener('click', (e) => {
                    e.preventDefault();
                    hideElement(emailError);
                    // Switch to sign-up mode
                    isSignUpMode = true;
                    updateAuthMode();
                  });
                }
              } else {
                // Generic invalid credentials
                passwordError.textContent = 'Invalid email or password.';
                showElement(passwordError);
              }
            } else {
              throw new Error(data?.error || 'Login failed');
            }
            return;
          }

          // Save session
          if (data?.access_token) {
            await saveSession({ access_token: data.access_token });
          }

          // Success - check if profile setup is complete
          const { onboardingComplete } = await chrome.storage.local.get(
            'onboardingComplete'
          );

          if (onboardingComplete) {
            // Profile already setup - go directly to sidepanel
            showLoadingScreen('Welcome Back!', 'Opening your workspace...');
            setTimeout(() => {
              if (chrome.sidePanel) {
                chrome.sidePanel.open().catch(() => window.close());
              } else {
                window.close();
              }
            }, 1000);
          } else {
            // First time - redirect to profile setup
            showLoadingScreen(
              'Welcome Back!',
              "Let's complete your profile..."
            );
            setTimeout(() => {
              window.location.href = 'profile-setup.html';
            }, 1000);
          }
        }
      } catch (err) {
        hideLoadingScreen();
        showStatus(
          err.message || 'An error occurred. Please try again.',
          'error'
        );
        console.error('Auth error:', err);
      } finally {
        setButtonLoading(submitBtn, submitBtnText, submitSpinner, false);
      }
    });
  }

  // Initialize
  async function init() {
    await loadConfig();
    await loadSession();

    // Check if already authenticated
    const isAuthed = await checkAuth();
    if (!isAuthed) {
      // Show onboarding form
      hideLoadingScreen();
      updateAuthMode();
    }
  }

  // Start
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
