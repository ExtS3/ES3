# Reverse Recruiting ↔ Chrome Extension Integration

## Overview

This document defines the integration contract between the Reverse Recruiting platform and the JobAp AI Chrome Extension.

---

## Integration Flow

```
┌─────────────────────┐         ┌──────────────────────┐
│  Reverse Recruiting │         │  Chrome Extension    │
│   (Frontend/BE)     │         │   (Content/BG)       │
└──────────┬──────────┘         └──────────┬───────────┘
           │                               │
           │  1. User clicks "Apply"       │
           │─────────────────────────────>│
           │                               │
           │  2. Launch extension          │
           │  + Send job data & token      │
           │─────────────────────────────>│
           │                               │
           │                               │  3. Auto-fill form
           │                               │  4. Generate resume
           │                               │  5. Generate cover letter
           │                               │  6. Submit application
           │                               │
           │  7. POST application status   │
           │<─────────────────────────────│
           │  + Resume URL                 │
           │  + Cover letter URL           │
           │  + Auto-fill metadata         │
           │                               │
           │  8. Update job dashboard      │
           │                               │
```

---

## 1. Reverse Recruiting → Extension (Launch Payload)

### Method: `window.postMessage` or `chrome.runtime.sendMessage`

**Recommended: `chrome.runtime.sendMessage` for direct communication**

### Payload Structure

```typescript
interface ReverseRecruitingPayload {
  type: 'REVERSE_RECRUITING_APPLY';
  timestamp: string; // ISO 8601
  token: string; // Firebase ID token for authentication
  userProfile: UserProfile;
  job: JobMetadata;
  settings: ApplicationSettings;
}

interface UserProfile {
  // Basic Info
  user_id: string;
  full_name: string;
  email: string;
  phone?: string;
  location?: string;

  // Social/Links
  linkedin_url?: string;
  portfolio_url?: string;
  github_url?: string;

  // Professional Info
  current_job_title?: string;
  years_total_experience?: number;
  professional_summary?: string;

  // Education
  highest_degree?: string;
  field_of_study?: string;
  university?: string;
  graduation_year?: string;

  // Skills & Preferences
  top_skills?: string[]; // ["JavaScript", "React", "Node.js"]
  certifications?: string[];
  job_types?: string[]; // ["Full-time", "Remote"]
  preferred_industries?: string[];

  // Work Authorization
  work_authorization?: string; // "US Citizen", "Work Permit", etc.
  security_clearance?: string;

  // Salary & Availability
  expected_salary_min?: number;
  expected_salary_max?: number;
  willing_to_relocate?: boolean;
  notice_required?: string; // "Immediate", "2 weeks", etc.
  interview_availability?: string;

  // CV & History
  cv_text?: string; // Full CV text for AI processing
  cv_url?: string; // Link to stored CV PDF
  employment_history?: EmploymentRecord[];

  // Interview Answers (pre-saved common questions)
  interview_answers?: InterviewAnswer[];
}

interface EmploymentRecord {
  company_name: string;
  job_title: string;
  location?: string;
  start_date: string; // "2020-01"
  end_date: string; // "2023-06" or "Present"
  is_current: boolean;
  description?: string;
  achievements?: string[];
  technologies_used?: string[];
}

interface InterviewAnswer {
  question: string;
  answer: string;
  category?: string; // "behavioral", "technical", etc.
  last_used?: string; // ISO timestamp
}

interface JobMetadata {
  // Job Identification
  job_id: string; // Your internal job ID
  external_job_id?: string; // Job board's ID
  posting_url: string; // URL to job posting
  application_url?: string; // Direct application URL if different

  // Job Details
  title: string;
  company: string;
  company_logo_url?: string;
  location: string;
  remote: boolean;
  job_type: string; // "Full-time", "Contract", etc.

  // Job Description
  description_html: string; // Full HTML job description
  description_text: string; // Plain text version for AI
  requirements?: string[];
  responsibilities?: string[];

  // Additional Context
  salary_range?: {
    min: number;
    max: number;
    currency: string;
  };
  benefits?: string[];
  application_deadline?: string; // ISO date

  // Application Form (if pre-parsed)
  form_schema?: FormField[];

  // Tracking
  source: string; // "linkedin", "indeed", "company_website", etc.
  posted_date?: string;
  recruiter_name?: string;
  recruiter_email?: string;
}

interface FormField {
  id: string;
  type: string; // "text", "textarea", "select", "file", etc.
  label: string;
  name: string;
  required: boolean;
  placeholder?: string;
  options?: string[]; // For select/radio fields
  validation?: {
    pattern?: string;
    min?: number;
    max?: number;
  };
}

interface ApplicationSettings {
  // Generation Settings
  auto_generate_resume: boolean; // Force resume generation
  auto_generate_cover_letter: boolean; // Force cover letter generation
  resume_template?: string; // "modern", "classic", "compact"

  // Auto-fill Settings
  auto_fill_forms: boolean;
  auto_submit: boolean; // Submit after filling (use with caution)

  // AI Model Overrides
  analysis_model?: string; // Override default "grok-4-fast-non-reasoning"
  generation_model?: string; // Override default "gpt-5-mini"

  // Callback Settings
  callback_url?: string; // URL to POST status updates
  webhook_secret?: string; // For verifying webhook authenticity
}
```

### Example Payload

```json
{
  "type": "REVERSE_RECRUITING_APPLY",
  "timestamp": "2025-01-15T10:30:00Z",
  "token": "eyJhbGciOiJSUzI1NiIsImtpZCI6Ij...",
  "userProfile": {
    "user_id": "abc123",
    "full_name": "Jane Smith",
    "email": "jane@example.com",
    "phone": "+1-555-0100",
    "location": "San Francisco, CA",
    "linkedin_url": "https://linkedin.com/in/janesmith",
    "current_job_title": "Senior Software Engineer",
    "years_total_experience": 8,
    "top_skills": ["JavaScript", "React", "Node.js", "PostgreSQL"],
    "cv_text": "JANE SMITH\nSenior Software Engineer...",
    "interview_answers": [
      {
        "question": "Tell me about yourself",
        "answer": "I'm a senior software engineer with 8 years..."
      }
    ]
  },
  "job": {
    "job_id": "job-456",
    "posting_url": "https://company.com/jobs/senior-engineer",
    "title": "Senior Full Stack Engineer",
    "company": "TechCorp Inc",
    "location": "Remote",
    "remote": true,
    "job_type": "Full-time",
    "description_text": "We are seeking a Senior Full Stack Engineer...",
    "requirements": [
      "5+ years of web development experience",
      "Strong React and Node.js skills"
    ]
  },
  "settings": {
    "auto_generate_resume": true,
    "auto_generate_cover_letter": true,
    "auto_fill_forms": true,
    "auto_submit": false,
    "callback_url": "https://your-api.com/api/v1/applications/job-456/status"
  }
}
```

---

## 2. Extension → Reverse Recruiting (Status Updates)

### Method: POST to callback URL

**Endpoint**: `POST {callback_url}`

**Authentication**: `Authorization: Bearer {token}`

### Status Update Payload

```typescript
interface ApplicationStatusUpdate {
  job_id: string;
  status: ApplicationStatus;
  timestamp: string; // ISO 8601

  // Generated Assets
  resume?: GeneratedDocument;
  cover_letter?: GeneratedDocument;

  // Auto-fill Results
  auto_fill?: AutoFillResults;

  // Metadata
  metadata: ApplicationMetadata;

  // Error Info (if status is 'error')
  error?: ErrorInfo;
}

type ApplicationStatus =
  | 'started' // Extension opened, processing started
  | 'analyzing' // AI analyzing job description
  | 'generating_resume' // Generating tailored resume
  | 'generating_cover' // Generating cover letter
  | 'auto_filling' // Auto-filling application form
  | 'ready' // Ready for user review
  | 'submitted' // Application submitted
  | 'error'; // Error occurred

interface GeneratedDocument {
  type: 'resume' | 'cover_letter';
  url: string; // Cloud Storage signed URL (valid for 7 days)
  file_name: string;
  file_size: number; // bytes
  generated_at: string; // ISO timestamp
  model_used: string; // "gpt-5-mini"

  // Metadata
  content_preview?: string; // First 200 chars
  sections?: string[]; // ["experience", "education", "skills"]
}

interface AutoFillResults {
  fields_total: number;
  fields_filled: number;
  fields_skipped: number;
  fill_percentage: number; // 0-100

  // Detailed field mapping
  fields: FilledField[];
}

interface FilledField {
  field_id: string;
  field_label: string;
  field_type: string;
  value: string | string[];
  source: 'profile' | 'cv' | 'ai_generated' | 'custom_answer';
  confidence?: number; // 0-1 (AI confidence score)
}

interface ApplicationMetadata {
  extension_version: string;
  models_used: {
    analysis: string;
    resume: string;
    cover_letter: string;
  };
  tokens_used?: {
    analysis: number;
    resume: number;
    cover_letter: number;
    total: number;
  };
  duration_ms: {
    analysis: number;
    resume: number;
    cover_letter: number;
    auto_fill: number;
    total: number;
  };
  user_interactions: {
    manual_edits: number;
    regenerations: number;
    field_overrides: number;
  };
}

interface ErrorInfo {
  code: string; // "PARSE_ERROR", "API_ERROR", "AUTH_ERROR", etc.
  message: string;
  details?: string;
  recoverable: boolean;
  retry_suggested: boolean;
}
```

### Example Status Updates

**1. Started**

```json
{
  "job_id": "job-456",
  "status": "started",
  "timestamp": "2025-01-15T10:30:05Z",
  "metadata": {
    "extension_version": "2.1.0",
    "models_used": {
      "analysis": "grok-4-fast-non-reasoning",
      "resume": "gpt-5-mini",
      "cover_letter": "gpt-5-mini"
    },
    "duration_ms": {
      "total": 0
    },
    "user_interactions": {
      "manual_edits": 0,
      "regenerations": 0,
      "field_overrides": 0
    }
  }
}
```

**2. Resume Generated**

```json
{
  "job_id": "job-456",
  "status": "generating_resume",
  "timestamp": "2025-01-15T10:30:15Z",
  "resume": {
    "type": "resume",
    "url": "https://storage.googleapis.com/jobapai-user-files/resumes/user-abc123/job-456-resume.pdf?X-Goog-Signature=...",
    "file_name": "Jane_Smith_Resume_TechCorp.pdf",
    "file_size": 45678,
    "generated_at": "2025-01-15T10:30:15Z",
    "model_used": "gpt-5-mini",
    "sections": ["header", "summary", "experience", "education", "skills"]
  },
  "metadata": {
    "extension_version": "2.1.0",
    "models_used": {
      "analysis": "grok-4-fast-non-reasoning",
      "resume": "gpt-5-mini",
      "cover_letter": "gpt-5-mini"
    },
    "tokens_used": {
      "resume": 3500
    },
    "duration_ms": {
      "resume": 8200,
      "total": 8200
    },
    "user_interactions": {
      "manual_edits": 0,
      "regenerations": 0,
      "field_overrides": 0
    }
  }
}
```

**3. Submitted**

```json
{
  "job_id": "job-456",
  "status": "submitted",
  "timestamp": "2025-01-15T10:32:00Z",
  "resume": {
    "type": "resume",
    "url": "https://storage.googleapis.com/...",
    "file_name": "Jane_Smith_Resume_TechCorp.pdf",
    "file_size": 45678,
    "generated_at": "2025-01-15T10:30:15Z",
    "model_used": "gpt-5-mini"
  },
  "cover_letter": {
    "type": "cover_letter",
    "url": "https://storage.googleapis.com/...",
    "file_name": "Jane_Smith_Cover_Letter_TechCorp.pdf",
    "file_size": 23456,
    "generated_at": "2025-01-15T10:30:45Z",
    "model_used": "gpt-5-mini"
  },
  "auto_fill": {
    "fields_total": 15,
    "fields_filled": 14,
    "fields_skipped": 1,
    "fill_percentage": 93,
    "fields": [
      {
        "field_id": "first_name",
        "field_label": "First Name",
        "field_type": "text",
        "value": "Jane",
        "source": "profile",
        "confidence": 1.0
      },
      {
        "field_id": "cover_letter",
        "field_label": "Why do you want this role?",
        "field_type": "textarea",
        "value": "I am excited about this opportunity because...",
        "source": "ai_generated",
        "confidence": 0.92
      }
    ]
  },
  "metadata": {
    "extension_version": "2.1.0",
    "models_used": {
      "analysis": "grok-4-fast-non-reasoning",
      "resume": "gpt-5-mini",
      "cover_letter": "gpt-5-mini"
    },
    "tokens_used": {
      "analysis": 1200,
      "resume": 3500,
      "cover_letter": 2800,
      "total": 7500
    },
    "duration_ms": {
      "analysis": 2100,
      "resume": 8200,
      "cover_letter": 6500,
      "auto_fill": 4200,
      "total": 21000
    },
    "user_interactions": {
      "manual_edits": 2,
      "regenerations": 0,
      "field_overrides": 1
    }
  }
}
```

**4. Error**

```json
{
  "job_id": "job-456",
  "status": "error",
  "timestamp": "2025-01-15T10:30:30Z",
  "error": {
    "code": "API_ERROR",
    "message": "Failed to generate resume",
    "details": "API quota exceeded",
    "recoverable": true,
    "retry_suggested": true
  },
  "metadata": {
    "extension_version": "2.1.0",
    "duration_ms": {
      "total": 25000
    }
  }
}
```

---

## 3. API Endpoints Required

### Reverse Recruiting Backend

**POST `/api/v1/applications/:jobId/status`**

- Receives status updates from extension
- Authenticated via Bearer token
- Updates job dashboard in real-time

**GET `/api/v1/applications/:jobId`** (optional)

- Extension can fetch current application state
- Useful for resuming interrupted applications

### Chrome Extension Backend (Already Exists)

- `POST /v1/extract-profile` - Extract profile from CV
- `POST /v1/analyze-form` - Analyze job form with AI
- `POST /v1/generate/resume` - Generate tailored resume
- `POST /v1/generate/cover` - Generate cover letter
- `GET/POST /v1/profile/sync` - Sync user profile

---

## 4. Security Considerations

### Authentication

- Use Firebase ID tokens (JWT) for all requests
- Tokens expire after 1 hour, extension handles refresh
- Backend verifies token with Firebase Admin SDK

### CORS

- Extension origin: `chrome-extension://[extension-id]`
- Add to allowed origins in Cloud Run

### Webhook Verification (Optional)

```typescript
// Verify webhook signature
const signature = req.headers['x-webhook-signature'];
const payload = JSON.stringify(req.body);
const expectedSignature = crypto
  .createHmac('sha256', webhookSecret)
  .update(payload)
  .digest('hex');

if (signature !== expectedSignature) {
  return res.status(401).json({ error: 'Invalid signature' });
}
```

---

## 5. Implementation Steps

### Reverse Recruiting Frontend

```javascript
// 1. Listen for "Apply" button click
applyButton.addEventListener('click', async () => {
  // 2. Get user profile and job data
  const userProfile = await fetchUserProfile();
  const job = getCurrentJob();
  const token = await getFirebaseToken();

  // 3. Send message to extension
  chrome.runtime.sendMessage(
    EXTENSION_ID,
    {
      type: 'REVERSE_RECRUITING_APPLY',
      timestamp: new Date().toISOString(),
      token,
      userProfile,
      job,
      settings: {
        auto_generate_resume: true,
        auto_generate_cover_letter: true,
        auto_fill_forms: true,
        auto_submit: false,
        callback_url: `${API_BASE}/api/v1/applications/${job.id}/status`,
      },
    },
    (response) => {
      console.log('Extension response:', response);
    }
  );
});
```

### Reverse Recruiting Backend

```typescript
// POST /api/v1/applications/:jobId/status
export async function POST(req: Request) {
  // 1. Verify Firebase token
  const token = req.headers.get('authorization')?.substring(7);
  const { user, error } = await verifyIdToken(token);
  if (error)
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  // 2. Parse payload
  const update: ApplicationStatusUpdate = await req.json();

  // 3. Update database
  await db.query(
    `UPDATE applications 
     SET status = $1, 
         resume_url = $2, 
         cover_letter_url = $3,
         updated_at = NOW()
     WHERE job_id = $4 AND user_id = $5`,
    [
      update.status,
      update.resume?.url,
      update.cover_letter?.url,
      update.job_id,
      user.id,
    ]
  );

  // 4. Broadcast update to frontend (WebSocket/SSE)
  broadcastUpdate(user.id, update);

  return NextResponse.json({ success: true });
}
```

### Chrome Extension (Background Script)

```javascript
// Listen for messages from Reverse Recruiting
chrome.runtime.onMessageExternal.addListener(
  async (request, sender, sendResponse) => {
    if (request.type === 'REVERSE_RECRUITING_APPLY') {
      // 1. Store auth token
      await chrome.storage.sync.set({
        firebaseSession: {
          access_token: request.token,
        },
      });

      // 2. Store profile and job data
      await chrome.storage.local.set({
        reverseRecruitingJob: request.job,
        userProfile: request.userProfile,
        applicationSettings: request.settings,
      });

      // 3. Open extension in new tab or side panel
      await chrome.tabs.create({
        url: chrome.runtime.getURL('sidepanel.html?source=reverse-recruiting'),
      });

      // 4. Send initial status update
      await sendStatusUpdate(request.settings.callback_url, request.token, {
        job_id: request.job.job_id,
        status: 'started',
        timestamp: new Date().toISOString(),
        metadata: {
          extension_version: chrome.runtime.getManifest().version,
          models_used: {
            analysis: 'grok-4-fast-non-reasoning',
            resume: 'gpt-5-mini',
            cover_letter: 'gpt-5-mini',
          },
          duration_ms: { total: 0 },
          user_interactions: {
            manual_edits: 0,
            regenerations: 0,
            field_overrides: 0,
          },
        },
      });

      sendResponse({ success: true });
    }
  }
);

async function sendStatusUpdate(callbackUrl, token, update) {
  if (!callbackUrl) return;

  try {
    const res = await fetch(callbackUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(update),
    });

    if (!res.ok) {
      console.error('Status update failed:', await res.text());
    }
  } catch (error) {
    console.error('Status update error:', error);
  }
}
```

---

## 6. Testing

### Test Payload

```bash
# Send test message to extension
chrome.runtime.sendMessage(
  'YOUR_EXTENSION_ID',
  {
    type: 'REVERSE_RECRUITING_APPLY',
    timestamp: new Date().toISOString(),
    token: 'test-token',
    userProfile: { /* ... */ },
    job: { /* ... */ },
    settings: { /* ... */ }
  },
  (response) => console.log(response)
);
```

### Mock Callback Server

```javascript
// Simple Express server to receive status updates
const express = require('express');
const app = express();
app.use(express.json());

app.post('/api/v1/applications/:jobId/status', (req, res) => {
  console.log('Received update:', req.body);
  res.json({ success: true });
});

app.listen(3000, () => console.log('Listening on port 3000'));
```

---

## 7. Summary Checklist

### Reverse Recruiting Team

- [ ] Implement "Apply" button handler
- [ ] Collect and format user profile data
- [ ] Send message to extension with payload
- [ ] Implement webhook endpoint to receive status updates
- [ ] Update job dashboard UI with real-time status
- [ ] Store generated resume/cover letter URLs
- [ ] Handle error states

### Chrome Extension Team (Us)

- [ ] Add listener for external messages
- [ ] Parse and validate incoming payload
- [ ] Store auth token and user profile
- [ ] Auto-launch extension with job context
- [ ] Send status updates to callback URL
- [ ] Upload generated documents to Cloud Storage
- [ ] Return signed URLs with 7-day expiry

---

**Questions? Contact the extension team or check the implementation examples above.**

