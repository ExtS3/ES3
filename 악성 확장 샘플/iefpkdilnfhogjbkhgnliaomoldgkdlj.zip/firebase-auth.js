/**
 * Firebase Auth Client SDK for Chrome Extension (frontend pages)
 * Uses Firebase compat SDK loaded from local vendor scripts.
 *
 * NOTE: This module assumes that:
 *   - vendor/firebase/firebase-app-compat.js
 *   - vendor/firebase/firebase-auth-compat.js
 * have already been loaded in the page, providing a global `firebase` object.
 */

let firebaseApp = null;
let firebaseAuth = null;

// Firebase configuration for Reverse Recruiting backend project
const firebaseConfig = {
  apiKey: 'AIzaSyCCNJxco3gHrlaqi0XfKRAFpM1jUDPrbiQ',
  authDomain: 'reverse-recruiting-backend.firebaseapp.com',
  projectId: 'reverse-recruiting-backend',
  storageBucket: 'reverse-recruiting-backend.firebasestorage.app',
  messagingSenderId: '142692177063',
  appId: '1:142692177063:web:0f72c7e5c9c9d77a85b782',
  measurementId: 'G-Q8333PY0SV',
};

function getCompatAuth() {
  if (firebaseAuth) return firebaseAuth;

  if (typeof firebase === 'undefined') {
    throw new Error(
      'Firebase SDK not loaded. Ensure firebase-app-compat and firebase-auth-compat are included.'
    );
  }

  // Initialize only once
  if (firebase.apps && firebase.apps.length) {
    firebaseApp = firebase.app();
  } else {
    firebaseApp = firebase.initializeApp(firebaseConfig);
  }
  firebaseAuth = firebase.auth();

  return firebaseAuth;
}

export async function initializeFirebase() {
  // For compatibility with previous API; now just returns compat auth.
  return getCompatAuth();
}

/**
 * Sign up with email and password
 * Replaces: supabase.auth.signUp()
 */
export async function signUpWithEmail(email, password) {
  try {
    const auth = getCompatAuth();
    const userCredential = await auth.createUserWithEmailAndPassword(
      email,
      password
    );

    // Get ID token
    const idToken = await userCredential.user.getIdToken();

    return {
      user: {
        id: userCredential.user.uid,
        email: userCredential.user.email,
        email_verified: userCredential.user.emailVerified,
      },
      session: {
        access_token: idToken,
        user: userCredential.user,
      },
      error: null,
    };
  } catch (error) {
    console.error('[Firebase] Sign up error:', error);
    return {
      user: null,
      session: null,
      error: error.message,
    };
  }
}

/**
 * Sign in with email and password
 * Replaces: supabase.auth.signInWithPassword()
 */
export async function signInWithEmail(email, password) {
  try {
    const auth = getCompatAuth();
    const userCredential = await auth.signInWithEmailAndPassword(
      email,
      password
    );

    // Get ID token
    const idToken = await userCredential.user.getIdToken();

    // Store session in Chrome storage
    await chrome.storage.sync.set({
      firebaseSession: {
        access_token: idToken,
        user: {
          id: userCredential.user.uid,
          email: userCredential.user.email,
        },
      },
    });

    return {
      user: {
        id: userCredential.user.uid,
        email: userCredential.user.email,
        email_verified: userCredential.user.emailVerified,
      },
      session: {
        access_token: idToken,
        user: userCredential.user,
      },
      error: null,
    };
  } catch (error) {
    console.error('[Firebase] Sign in error:', error);
    return {
      user: null,
      session: null,
      error: error.message,
    };
  }
}

/**
 * Sign in with Google (using Firebase web OAuth redirect - no Chrome Identity)
 * Replaces: supabase.auth.signInWithOAuth({ provider: 'google' })
 *
 * Opens a popup window pointing to the backend callback page, which handles Firebase OAuth.
 * Works entirely with Firebase web OAuth - no Chrome extension ID needed.
 */
export async function signInWithGoogle() {
  return new Promise((resolve, reject) => {
    // Get callback URL from config
    (async () => {
      // Use API route for auth callback (more reliable than page route)
      let callbackUrl = 'https://159.203.120.48.nip.io/rrext/api/auth-callback';
      try {
        const configRes = await fetch(chrome.runtime.getURL('config.json'));
        const config = await configRes.json();
        if (config.apiBaseUrl) {
          // Use the API base URL directly and append /auth-callback
          const base = config.apiBaseUrl.replace(/\/$/, '');
          callbackUrl = `${base}/auth-callback`;
        }
      } catch (e) {
        console.warn(
          '[Firebase Auth] Could not load config, using default callback URL'
        );
      }

      // Store pending state
      await chrome.storage.local.set({
        firebaseAuthPending: true,
        firebaseAuthTimestamp: Date.now(),
      });

      // Open callback page in popup - it will handle the OAuth flow
      const popup = window.open(
        `${callbackUrl}?source=extension`,
        'firebase-auth',
        'width=500,height=600,scrollbars=yes'
      );

      if (!popup) {
        await chrome.storage.local.remove(['firebaseAuthPending']);
        reject(
          new Error('Popup blocked. Please allow popups for this extension.')
        );
        return;
      }

      // Listen for message from callback page after redirect completes
      const messageListener = async (event) => {
        // Accept messages from the callback domain
        const callbackOrigin = new URL(callbackUrl).origin;
        if (event.origin !== callbackOrigin) {
          return;
        }

        if (event.data && event.data.type === 'FIREBASE_AUTH_RESULT') {
          window.removeEventListener('message', messageListener);
          clearInterval(checkClosed);
          await chrome.storage.local.remove(['firebaseAuthPending']);

          // Close popup
          setTimeout(() => {
            if (!popup.closed) popup.close();
          }, 500);

          if (event.data.error) {
            reject(new Error(event.data.error));
          } else if (event.data.user && event.data.session) {
            // Store session in Chrome storage
            await chrome.storage.sync.set({
              firebaseSession: {
                access_token: event.data.session.access_token,
                user: {
                  id: event.data.user.id,
                  email: event.data.user.email,
                },
              },
            });

            resolve({
              user: event.data.user,
              session: event.data.session,
              error: null,
            });
          } else {
            reject(new Error('No user data received'));
          }
        }
      };

      window.addEventListener('message', messageListener);

      // Handle popup closed without result
      const checkClosed = setInterval(() => {
        if (popup.closed) {
          clearInterval(checkClosed);
          window.removeEventListener('message', messageListener);
          chrome.storage.local.remove(['firebaseAuthPending']);
          reject(new Error('Sign-in popup was closed'));
        }
      }, 500);

      // Cleanup after 5 minutes
      setTimeout(() => {
        clearInterval(checkClosed);
        window.removeEventListener('message', messageListener);
        chrome.storage.local.remove(['firebaseAuthPending']);
        if (!popup.closed) {
          popup.close();
        }
      }, 5 * 60 * 1000);
    })();
  });
}

/**
 * Get redirect result after signInWithRedirect completes
 * Call this from auth-redirect.html after redirect
 */
export async function getRedirectResult() {
  try {
    const auth = getCompatAuth();
    const result = await auth.getRedirectResult();

    if (result.user) {
    // Get ID token
      const idToken = await result.user.getIdToken();

    // Store session in Chrome storage
    await chrome.storage.sync.set({
      firebaseSession: {
        access_token: idToken,
        user: {
            id: result.user.uid,
            email: result.user.email,
          },
      },
    });

      await chrome.storage.local.remove(['firebaseRedirectPending']);

    return {
      user: {
          id: result.user.uid,
          email: result.user.email,
          email_verified: result.user.emailVerified,
          displayName: result.user.displayName,
          photoURL: result.user.photoURL,
      },
      session: {
        access_token: idToken,
          user: result.user,
        },
        error: null,
      };
    }

    return {
      user: null,
      session: null,
      error: null,
    };
  } catch (error) {
    console.error('[Firebase] Get redirect result error:', error);
    await chrome.storage.local.remove(['firebaseRedirectPending']);
    return {
      user: null,
      session: null,
      error: error.message,
    };
  }
}

/**
 * Sign out
 * Replaces: supabase.auth.signOut()
 */
export async function signOut() {
  try {
    const auth = getCompatAuth();
    await auth.signOut();

    // Clear Chrome storage
    await chrome.storage.sync.remove(['firebaseSession']);
    await chrome.storage.local.clear();

    return { error: null };
  } catch (error) {
    console.error('[Firebase] Sign out error:', error);
    return { error: error.message };
  }
}

/**
 * Get current user session
 * Replaces: supabase.auth.getSession()
 */
export async function getSession() {
  try {
    const auth = getCompatAuth();
    const user = auth.currentUser;

    if (!user) {
      // Check Chrome storage
      const { firebaseSession } = await chrome.storage.sync.get([
        'firebaseSession',
      ]);
      if (firebaseSession) {
        return {
          session: firebaseSession,
          error: null,
        };
      }
      return { session: null, error: null };
    }

    const idToken = await user.getIdToken();

    return {
      session: {
        access_token: idToken,
        user: {
          id: user.uid,
          email: user.email,
        },
      },
      error: null,
    };
  } catch (error) {
    console.error('[Firebase] Get session error:', error);
    return { session: null, error: error.message };
  }
}

/**
 * Get current user
 * Replaces: supabase.auth.getUser()
 */
export async function getUser() {
  try {
    const auth = getCompatAuth();
    const user = auth.currentUser;

    if (!user) {
      return { user: null, error: null };
    }

    return {
      user: {
        id: user.uid,
        email: user.email,
        email_verified: user.emailVerified,
      },
      error: null,
    };
  } catch (error) {
    return { user: null, error: error.message };
  }
}

/**
 * Listen to auth state changes
 * Replaces: supabase.auth.onAuthStateChange()
 */
export async function onAuthStateChange(callback) {
  try {
    const auth = getCompatAuth();

    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user) {
        const idToken = await user.getIdToken();
        callback('SIGNED_IN', {
          access_token: idToken,
          user: {
            id: user.uid,
            email: user.email,
          },
        });
      } else {
        callback('SIGNED_OUT', null);
      }
    });

    return {
      data: {
        subscription: {
          unsubscribe,
        },
      },
    };
  } catch (error) {
    console.error('[Firebase] Auth state listener error:', error);
    return { data: null, error };
  }
}

/**
 * Send password reset email
 */
export async function resetPassword(email) {
  try {
    const auth = getCompatAuth();
    await auth.sendPasswordResetEmail(email);
    return { error: null };
  } catch (error) {
    console.error('[Firebase] Password reset error:', error);
    return { error: error.message };
  }
}

/**
 * Update user email
 */
export async function updateEmail(newEmail) {
  try {
    const auth = getCompatAuth();
    const user = auth.currentUser;

    if (!user) {
      return { error: 'No user logged in' };
    }

    await user.updateEmail(newEmail);
    return { error: null };
  } catch (error) {
    console.error('[Firebase] Update email error:', error);
    return { error: error.message };
  }
}

/**
 * Update user password
 */
export async function updatePassword(newPassword) {
  try {
    const auth = getCompatAuth();
    const user = auth.currentUser;

    if (!user) {
      return { error: 'No user logged in' };
    }

    await user.updatePassword(newPassword);
    return { error: null };
  } catch (error) {
    console.error('[Firebase] Update password error:', error);
    return { error: error.message };
  }
}
