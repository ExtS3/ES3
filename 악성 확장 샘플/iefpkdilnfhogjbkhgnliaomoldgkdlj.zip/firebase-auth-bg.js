/**
 * Firebase Auth for Background Service Worker
 * This runs in the background.js context where external scripts are allowed
 */

console.log('[Firebase Background] Starting initialization...');

// Import Firebase from local files (more reliable than CDN)
try {
  importScripts('vendor/firebase/firebase-app-compat.js');
  console.log('[Firebase Background] firebase-app-compat loaded');
} catch (error) {
  console.error(
    '[Firebase Background] Failed to load firebase-app-compat:',
    error
  );
  console.error(
    '[Firebase Background] Make sure vendor/firebase/ directory exists with Firebase SDK files'
  );
}

try {
  importScripts('vendor/firebase/firebase-auth-compat.js');
  console.log('[Firebase Background] firebase-auth-compat loaded');
} catch (error) {
  console.error(
    '[Firebase Background] Failed to load firebase-auth-compat:',
    error
  );
}

// Check if Firebase loaded
if (typeof firebase === 'undefined') {
  console.error('[Firebase Background] Firebase SDK failed to load!');
  console.error(
    '[Firebase Background] Please download Firebase SDK to vendor/firebase/ directory'
  );
} else {
  console.log('[Firebase Background] Firebase SDK loaded successfully');
}

// Firebase configuration
const firebaseConfig = {
  apiKey: 'AIzaSyCCNJxco3gHrlaqi0XfKRAFpM1jUDPrbiQ',
  authDomain: 'reverse-recruiting-backend.firebaseapp.com',
  projectId: 'reverse-recruiting-backend',
  storageBucket: 'reverse-recruiting-backend.firebasestorage.app',
  messagingSenderId: '142692177063',
  appId: '1:142692177063:web:0f72c7e5c9c9d77a85b782',
  measurementId: 'G-Q8333PY0SV',
};
firebase.initializeApp(firebaseConfig);


const auth = firebase.auth();

console.log('[Firebase Background] Initialized');

/**
 * Handle messages from content scripts/sidepanel
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[Firebase Background] Received message:', request);

  if (request.type === 'FIREBASE_AUTH') {
    // Check if Firebase is loaded
    if (typeof firebase === 'undefined' || !auth) {
      console.error('[Firebase Background] Firebase not initialized!');
      sendResponse({
        error: 'Firebase not initialized. Please reload the extension.',
      });
      return true;
    }

    handleFirebaseAuth(request.action, request.data)
      .then((result) => {
        console.log(
          '[Firebase Background] Action successful:',
          request.action,
          result
        );
        sendResponse(result);
      })
      .catch((error) => {
        console.error(
          '[Firebase Background] Action failed:',
          request.action,
          error
        );
        sendResponse({ error: error.message || 'Authentication failed' });
      });
    return true; // Keep channel open for async response
  }
});

/**
 * Handle Firebase Auth actions
 */
async function handleFirebaseAuth(action, data) {
  try {
    switch (action) {
      case 'SIGN_IN_EMAIL':
        return await signInWithEmail(data.email, data.password);

      case 'SIGN_UP_EMAIL':
        return await signUpWithEmail(data.email, data.password);

      case 'SIGN_IN_GOOGLE':
        return await signInWithGoogle();

      case 'SIGN_OUT':
        return await signOut();

      case 'GET_USER':
        return await getCurrentUser();

      case 'RESET_PASSWORD':
        return await resetPassword(data.email);

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  } catch (error) {
    console.error('[Firebase Background] Error:', error);
    throw error;
  }
}

/**
 * Sign in with email/password
 */
async function signInWithEmail(email, password) {
  const userCredential = await auth.signInWithEmailAndPassword(email, password);
  const idToken = await userCredential.user.getIdToken();

  // Store in Chrome storage
  await chrome.storage.sync.set({
    firebaseSession: {
      access_token: idToken,
      user: {
        id: userCredential.user.uid,
        email: userCredential.user.email,
      },
    },
  });

  return {
    user: {
      id: userCredential.user.uid,
      email: userCredential.user.email,
      email_verified: userCredential.user.emailVerified,
    },
    session: {
      access_token: idToken,
    },
  };
}

/**
 * Sign up with email/password
 */
async function signUpWithEmail(email, password) {
  const userCredential = await auth.createUserWithEmailAndPassword(
    email,
    password
  );
  const idToken = await userCredential.user.getIdToken();

  return {
    user: {
      id: userCredential.user.uid,
      email: userCredential.user.email,
      email_verified: userCredential.user.emailVerified,
    },
    session: {
      access_token: idToken,
    },
  };
}

/**
 * Sign in with Google (uses Chrome Identity API + Firebase)
 */
async function signInWithGoogle() {
  // Use Chrome Identity API to get Google OAuth token
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, async (token) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      if (!token) {
        reject(new Error('No auth token received'));
        return;
      }

      try {
        // Sign in to Firebase with the Google token
        const credential = firebase.auth.GoogleAuthProvider.credential(
          null,
          token
        );
        const userCredential = await auth.signInWithCredential(credential);
        const idToken = await userCredential.user.getIdToken();

        // Store in Chrome storage
        await chrome.storage.sync.set({
          firebaseSession: {
            access_token: idToken,
            user: {
              id: userCredential.user.uid,
              email: userCredential.user.email,
            },
          },
        });

        resolve({
          user: {
            id: userCredential.user.uid,
            email: userCredential.user.email,
            email_verified: userCredential.user.emailVerified,
            displayName: userCredential.user.displayName,
            photoURL: userCredential.user.photoURL,
          },
          session: {
            access_token: idToken,
          },
        });
      } catch (error) {
        reject(error);
      }
    });
  });
}

/**
 * Sign out
 */
async function signOut() {
  await auth.signOut();
  await chrome.storage.sync.remove(['firebaseSession']);
  await chrome.storage.local.clear();
  return { success: true };
}

/**
 * Get current user
 */
async function getCurrentUser() {
  const user = auth.currentUser;

  if (!user) {
    // Check Chrome storage
    const { firebaseSession } = await chrome.storage.sync.get([
      'firebaseSession',
    ]);
    if (firebaseSession) {
      return {
        user: firebaseSession.user,
        session: firebaseSession,
      };
    }
    return { user: null, session: null };
  }

  const idToken = await user.getIdToken();

  return {
    user: {
      id: user.uid,
      email: user.email,
      email_verified: user.emailVerified,
      displayName: user.displayName,
      photoURL: user.photoURL,
    },
    session: {
      access_token: idToken,
    },
  };
}

/**
 * Reset password
 */
async function resetPassword(email) {
  await auth.sendPasswordResetEmail(email);
  return { success: true };
}

/**
 * Listen for auth state changes
 */
auth.onAuthStateChanged(async (user) => {
  console.log(
    '[Firebase Background] Auth state changed:',
    user?.email || 'signed out'
  );

  if (user) {
    // Update stored session
    const idToken = await user.getIdToken();
    await chrome.storage.sync.set({
      firebaseSession: {
        access_token: idToken,
        user: {
          id: user.uid,
          email: user.email,
        },
      },
    });
  }
});
