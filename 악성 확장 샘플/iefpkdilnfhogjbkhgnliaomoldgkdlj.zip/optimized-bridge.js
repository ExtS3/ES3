import { analyzeOptimized } from './optimized-api.js';
window.JobApAIOptimized = { analyzeOptimized };
