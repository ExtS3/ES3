(() => {
  'use strict';

  // Email/password signup enabled
  const EMAIL_PASSWORD_AUTH_ENABLED = true;

  // DOM Elements
  const $ = (id) => document.getElementById(id);
  const onboardingContainer = $('onboardingContainer');
  const loadingScreen = $('loadingScreen');
  const loadingTitle = $('loadingTitle');
  const loadingSubtitle = $('loadingSubtitle');

  // Form Elements
  const authForm = $('authForm');
  const nameInput = $('nameInput');
  const emailInput = $('emailInput');
  const emailError = $('emailError');
  const passwordInput = $('passwordInput');
  const passwordHelper = $('passwordHelper');
  const passwordError = $('passwordError');
  const nameError = $('nameError');
  const togglePasswordBtn = $('togglePasswordBtn');
  const updatesCheckbox = $('updatesCheckbox');
  const submitBtn = $('submitBtn');
  const submitBtnText = $('submitBtnText');
  const submitSpinner = $('submitSpinner');
  const googleSignInBtn = $('googleSignInBtn');
  const statusMessage = $('statusMessage');

  // State
  let CONFIG = {
    apiBaseUrl: '',
    rrApiBaseUrl: '',
    rrProductionApiBaseUrl: '',
  };

  function resolveRrApiBase() {
    return (
      CONFIG?.rrApiBaseUrl ||
      CONFIG?.rrProductionApiBaseUrl ||
      ''
    ).replace(/\/$/, '');
  }
  let authSession = null;

  // Utility Functions
  function showElement(el) {
    if (el) el.classList.remove('hidden');
  }

  function hideElement(el) {
    if (el) el.classList.add('hidden');
  }

  function setButtonLoading(btn, textEl, spinnerEl, isLoading) {
    if (!btn) return;
    btn.disabled = isLoading;
    if (textEl) textEl.style.display = isLoading ? 'none' : '';
    if (spinnerEl) {
      if (isLoading) {
        spinnerEl.classList.remove('hidden');
      } else {
        spinnerEl.classList.add('hidden');
      }
    }
  }

  function showStatus(message, type = 'info') {
    if (!statusMessage) return;
    statusMessage.textContent = message;
    statusMessage.className = `status-message ${type}`;
    showElement(statusMessage);
  }

  function hideStatus() {
    if (statusMessage) {
      hideElement(statusMessage);
      statusMessage.textContent = '';
    }
  }

  function showLoadingScreen(title, subtitle) {
    if (loadingTitle) loadingTitle.textContent = title;
    if (loadingSubtitle) loadingSubtitle.textContent = subtitle;
    if (loadingScreen) showElement(loadingScreen);
    if (onboardingContainer) hideElement(onboardingContainer);
  }

  function hideLoadingScreen() {
    if (loadingScreen) hideElement(loadingScreen);
    if (onboardingContainer) showElement(onboardingContainer);
  }

  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  function validatePassword(password) {
    return (
      password.length >= 8 &&
      /[a-zA-Z]/.test(password) &&
      /[0-9]/.test(password)
    );
  }

  // Password Toggle (email/password auth disabled)
  if (EMAIL_PASSWORD_AUTH_ENABLED && togglePasswordBtn && passwordInput) {
    togglePasswordBtn.addEventListener('click', () => {
      const type = passwordInput.type === 'password' ? 'text' : 'password';
      passwordInput.type = type;

      const svg = togglePasswordBtn.querySelector('svg');
      if (type === 'text') {
        svg.innerHTML =
          '<path d="M10 6.5C8.34315 6.5 7 7.84315 7 9.5C7 11.1569 8.34315 12.5 10 12.5C11.6569 12.5 13 11.1569 13 9.5C13 7.84315 11.6569 6.5 10 6.5Z" stroke="currentColor" stroke-width="1.5"/><path d="M1 9.5C2.5 6.5 5.5 4 10 4C14.5 4 17.5 6.5 19 9.5C17.5 12.5 14.5 15 10 15C5.5 15 2.5 12.5 1 9.5Z" stroke="currentColor" stroke-width="1.5"/>';
      } else {
        svg.innerHTML =
          '<path d="M3.75 3.13L12.5 13.75M6.88 7.69C6.32 8.28 6 9.1 6 10C6 11.66 7.34 13 9 13C9.9 13 10.72 12.68 11.31 12.12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M1.25 5.36C2.5 7.5 5.5 11.5 10 11.5C11.5 11.5 12.75 11 13.75 10.25M8.38 4.38C8.75 4.13 9.25 4 10 4C14.5 4 17.5 8 18.75 10.15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><line x1="2.5" y1="2.5" x2="17.5" y2="17.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>';
      }
    });
  }

  // Config Loading
  async function loadConfig() {
    try {
      const url = chrome.runtime.getURL('config.json');
      const res = await fetch(url);
      if (res.ok) {
        CONFIG = await res.json();
      }
    } catch (err) {
      console.error('Failed to load config:', err);
    }
  }

  // Session Management
  async function loadSession() {
    try {
      const stored = await chrome.storage.sync.get(['firebaseSession']);
      if (stored?.firebaseSession) {
        authSession = stored.firebaseSession;
      }
    } catch (err) {
      console.error('Failed to load session:', err);
    }
  }

  async function saveSession(session) {
    try {
      authSession = session;
      await chrome.storage.sync.set({ firebaseSession: session });
    } catch (err) {
      console.error('Failed to save session:', err);
    }
  }

  function getAccessToken() {
    return authSession?.access_token || '';
  }

  // Check if already authenticated
  async function checkAuth() {
    try {
      const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
      if (!base) return false;

      const token = getAccessToken();
      const headers = token ? { Authorization: `Bearer ${token}` } : {};

      const res = await fetch(`${base}/v1/auth/me`, {
        method: 'GET',
        headers,
        credentials: 'include',
      });

      if (res.ok) {
        const data = await res.json();
        if (data?.ok) {
          showLoadingScreen(
            'Welcome back! 👋',
            'Redirecting to your workspace...'
          );
          setTimeout(() => {
            if (chrome.sidePanel) {
              chrome.sidePanel.open().catch(() => window.close());
            } else {
              window.close();
            }
          }, 1500);
          return true;
        }
      }

      return false;
    } catch (err) {
      console.error('Auth check error:', err);
      return false;
    }
  }

  // Google Sign In – Firebase Web SDK via firebase-auth.js (no Chrome Identity)
  if (googleSignInBtn) {
    googleSignInBtn.addEventListener('click', async () => {
      try {
        showLoadingScreen(
          'Signing in with Google...',
          'Completing authentication with JobApAI.'
        );

        const module = await import(chrome.runtime.getURL('firebase-auth.js'));
        if (!module?.signInWithGoogle) {
          throw new Error('Firebase Google sign-in not available');
        }
        const response = await module.signInWithGoogle();

        if (!response) {
          throw new Error('No response from Firebase Google sign-in.');
        }
        if (response.error) {
          throw new Error(response.error);
        }
        if (!response.user || !response.session) {
          throw new Error('No user data received from Google');
        }

        await saveSession(response.session);

        try {
          const base = resolveRrApiBase();
          if (base) {
            const profileData = {
              email: response.user.email,
              full_name: response.user.displayName || '',
              source: 'google',
              onboardingComplete: false,
            };
            await fetch(`${base}/v1/profile/sync`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${response.session.access_token}`,
              },
              credentials: 'include',
              body: JSON.stringify({ profile: profileData }),
            }).catch(() => {});
          }
        } catch (e) {
          console.warn('[Signup] Optional profile sync failed:', e);
        }

        showLoadingScreen(
          'Signed in with Google! 🎉',
          'Opening JobApAI in the side panel...'
        );

        setTimeout(async () => {
          try {
            if (chrome.sidePanel && chrome.sidePanel.open) {
              await chrome.sidePanel.open().catch(() => {});
            }
          } catch (_) {}
          window.close();
        }, 1500);
      } catch (err) {
        hideLoadingScreen();
        showStatus(
          err?.message || 'Google sign-in failed. Please try again.',
          'error'
        );
        console.error('Google sign-in error:', err);
      }
    });
  }

  // Form Submission (email/password auth disabled)
  if (
    EMAIL_PASSWORD_AUTH_ENABLED &&
    authForm &&
    nameInput &&
    emailInput &&
    passwordInput &&
    updatesCheckbox
  ) {
    authForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      // Clear previous errors
      hideStatus();
      if (emailError) hideElement(emailError);
      if (passwordError) hideElement(passwordError);
      if (nameError) hideElement(nameError);

      // Get form values
      const name = nameInput.value.trim();
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();
      const agreedToUpdates = updatesCheckbox.checked;

      // Validation
      let hasError = false;

      if (!name) {
        nameError.textContent = 'Name is required.';
        showElement(nameError);
        hasError = true;
      }

      if (!email) {
        emailError.textContent = 'Email is required.';
        showElement(emailError);
        hasError = true;
      } else if (!validateEmail(email)) {
        emailError.textContent = 'Invalid email address.';
        showElement(emailError);
        hasError = true;
      }

      if (!password) {
        passwordError.textContent = 'Password is required.';
        showElement(passwordError);
        hasError = true;
      } else if (!validatePassword(password)) {
        passwordError.textContent =
          'Use 8+ characters with mixed case and numbers.';
        showElement(passwordError);
        hasError = true;
      }

      if (hasError) {
        return;
      }

      // Submit signup
      setButtonLoading(submitBtn, submitBtnText, submitSpinner, true);

      try {
        const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
        if (!base) {
          throw new Error('Backend not configured');
        }

        showLoadingScreen(
          'Creating your account...',
          'This will only take a moment.'
        );

        const res = await fetch(`${base}/v1/auth/signup`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            name,
            email,
            password,
            marketingConsent: agreedToUpdates,
            agreedToTerms: true,
          }),
        });

        const data = await res.json().catch(() => ({}));

        if (!res.ok || !data?.ok) {
          hideLoadingScreen();

          if (data?.error && /already exists/i.test(data.error)) {
            emailError.textContent =
              'Account already exists with this email. Sign in to continue.';
            showElement(emailError);
          } else {
            throw new Error(data?.error || 'Sign up failed');
          }
          return;
        }

        if (data?.access_token) {
          await saveSession({ access_token: data.access_token });
        }

        if (data?.requiresConfirmation) {
          hideLoadingScreen();
          showStatus(
            'Account created! Check your email to confirm, then sign in.',
            'success'
          );
        } else {
          showLoadingScreen(
            'Welcome to ReverseRecruiting!',
            'Opening your workspace...'
          );

          setTimeout(() => {
            // Close this window - user will access main interface via side panel
            window.close();
          }, 1500);
        }
      } catch (err) {
        hideLoadingScreen();
        showStatus(
          err.message || 'An error occurred. Please try again.',
          'error'
        );
        console.error('Signup error:', err);
      } finally {
        setButtonLoading(submitBtn, submitBtnText, submitSpinner, false);
      }
    });
  }

  // Initialize
  async function init() {
    await loadConfig();
    await loadSession();

    const isAuthed = await checkAuth();
    if (!isAuthed) {
      hideLoadingScreen();
    }
  }

  // Start
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
