/**
 * Profile Sync Utility
 * Syncs user profile between chrome.storage.local and Supabase database
 *
 * Strategy:
 * - Local storage is source of truth for immediate use (fast)
 * - Database is backup and enables cross-device sync
 * - Sync happens: on login, after profile update, periodically (every 5 min if changed)
 */

import { getUserProfile, saveUserProfile } from './profile-utils.js';

const RR_STATE_KEY = 'rrIntegrationState';
const MAX_RESUME_SNIPPET = 4000;

// Get API base URL and auth token
async function getConfig() {
  try {
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const config = await resp.json();
    if (
      config &&
      !config.activeRrBaseUrl &&
      (config.rrApiBaseUrl || config.rrProductionApiBaseUrl)
    ) {
      config.activeRrBaseUrl =
        config.rrApiBaseUrl || config.rrProductionApiBaseUrl;
    }
    return config;
  } catch (e) {
    console.error('[ProfileSync] Error loading config:', e);
    return { apiBaseUrl: 'https://jobapai-323731579339.us-south1.run.app' };
  }
}

async function getAuthToken() {
  try {
    const syncResult = await chrome.storage.sync.get(['firebaseSession']);
    const session = syncResult.firebaseSession;
    if (session?.access_token) {
      return session.access_token;
    }
    const rrState = await getRRIntegrationState();
    if (rrState?.authToken) {
      return rrState.authToken;
    }
    const localResult = await chrome.storage.local.get('rrAuthToken');
    return localResult?.rrAuthToken || null;
  } catch (e) {
    console.error('[ProfileSync] Error getting auth token:', e);
    return null;
  }
}

async function getRRIntegrationState() {
  try {
    const stored = await chrome.storage.local.get([
      RR_STATE_KEY,
      'rrAuthToken',
    ]);
    const state = stored?.[RR_STATE_KEY] || {};
    if (!state.authToken && stored?.rrAuthToken) {
      state.authToken = stored.rrAuthToken;
    }
    return state;
  } catch (error) {
    console.warn('[ProfileSync] Failed to read RR integration state:', error);
    return {};
  }
}

async function updateRRIntegrationState(update) {
  if (!update || typeof update !== 'object') return;
  try {
    const stored = await chrome.storage.local.get(RR_STATE_KEY);
    const current = stored?.[RR_STATE_KEY] || {};
    const next = { ...current, ...update, updatedAt: Date.now() };
    await chrome.storage.local.set({ [RR_STATE_KEY]: next });
    try {
      await chrome.runtime.sendMessage({
        type: 'rrIntegrationStateUpdated',
        payload: next,
      });
    } catch (_) {}
  } catch (error) {
    console.warn('[ProfileSync] Failed to update RR integration state:', error);
  }
}

function resolveRrApiBase(config) {
  if (!config) return '';
  const base =
    config.activeRrBaseUrl ||
    config.rrApiBaseUrl ||
    config.rrProductionApiBaseUrl ||
    '';
  return typeof base === 'string' ? base.replace(/\/$/, '') : '';
}

function pickArray(value) {
  return Array.isArray(value) ? value.filter(Boolean) : [];
}

function buildProfileSnapshot(profile, cvText = '') {
  const essential = profile.essential || {};
  const preferences = profile.preferences || {};
  const professional = profile.professional || {};
  const skills = profile.skills || {};
  const education = skills.education || {};
  const years =
    typeof skills.yearsExperience === 'object'
      ? skills.yearsExperience || {}
      : {
          total:
            skills.yearsExperience ||
            profile.yearsExperience ||
            essential.yearsExperience ||
            0,
        };

  return {
    full_name: essential.fullName || '',
    headline: professional.summary || professional.currentRole || '',
    email: essential.email || '',
    phone: essential.phone || '',
    location: essential.location || '',
    linkedin_url: essential.linkedIn || '',
    portfolio_url:
      essential.portfolio ||
      essential.portfolioUrl ||
      profile.portfolio ||
      profile.portfolioUrl ||
      '',
    github_url:
      essential.github ||
      essential.githubUrl ||
      profile.github ||
      profile.githubUrl ||
      '',
    current_role: professional.currentRole || '',
    job_types: pickArray(preferences.jobTypes || profile.jobTypes),
    preferred_industries: pickArray(
      preferences.preferredIndustries || profile.preferredIndustries
    ),
    skills: pickArray(skills.topSkills || profile.topSkills),
    certifications: pickArray(skills.certifications || profile.certifications),
    years_experience: normalizeNumber(
      typeof years === 'object' ? years.total ?? 0 : years || 0
    ),
    years_management_experience: normalizeNumber(
      typeof years === 'object' ? years.management ?? 0 : 0
    ),
    years_technical_experience: normalizeNumber(
      typeof years === 'object' ? years.technical ?? 0 : 0
    ),
    education: {
      degree: education.highestDegree || profile.degree || '',
      field_of_study: education.fieldOfStudy || profile.major || '',
      university: education.university || profile.university || '',
      graduation_year: education.graduationYear || profile.gradYear || '',
    },
    salary_expectation: {
      min:
        preferences.expectedSalaryMin ||
        preferences.salaryMin ||
        profile.salaryMin ||
        '',
      max:
        preferences.expectedSalaryMax ||
        preferences.salaryMax ||
        profile.salaryMax ||
        '',
    },
    willingness_to_relocate:
      preferences.willingToRelocate ||
      preferences.relocate ||
      profile.relocate ||
      '',
    work_authorization: essential.workAuthorization || '',
    security_clearance: essential.securityClearance || '',
    resume_excerpt: (cvText || '').slice(0, MAX_RESUME_SNIPPET),
    metadata: {
      source: profile.metadata?.source || 'manual',
      onboarding_complete:
        profile.metadata?.onboardingComplete !== undefined
          ? profile.metadata.onboardingComplete
          : true,
      completeness: profile.metadata?.completeness || 0,
    },
  };
}

async function syncProfileToReverseRecruiting({
  config,
  token,
  profile,
  cvText,
  rrState,
}) {
  const base = resolveRrApiBase(config);
  if (!base) return null;
  const state = rrState || (await getRRIntegrationState());
  if (!state?.sessionId) {
    console.warn('[ProfileSync] No RR session_id available, skipping RR sync');
    return null;
  }
  const authToken = state.authToken || token;
  if (!authToken) {
    console.warn('[ProfileSync] No RR auth token available, skipping RR sync');
    return null;
  }

  // Skip RR sync if resume_url is missing (backend requires it)
  if (!state.resumeUrl) {
    console.warn('[ProfileSync] No resume_url available, skipping RR sync');
    return null;
  }

  const payload = {
    session_id: state.sessionId,
    resume_url: state.resumeUrl,
    cover_letter_url: state.coverLetterUrl || '',
    profile_snapshot: buildProfileSnapshot(profile, cvText),
    applied: typeof state.applied === 'boolean' ? state.applied : true,
  };

  const response = await fetch(`${base}/v1/profile/sync`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${authToken}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const error = await response.text().catch(() => '');
    throw new Error(
      error || `Reverse Recruiting sync failed (${response.status})`
    );
  }

  const json = await response.json().catch(() => ({}));
  const data = json?.data || json || {};

  const delta = {};
  if (data.resume_url) delta.resumeUrl = data.resume_url;
  if (data.cover_letter_url) delta.coverLetterUrl = data.cover_letter_url;
  if (typeof data.applied === 'boolean') delta.applied = data.applied;
  if (Object.keys(delta).length) {
    await updateRRIntegrationState(delta);
  }

  console.log(
    '[ProfileSync] ✅ Profile snapshot synced via Reverse Recruiting API'
  );
  return data;
}

function normalizeNumber(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string') {
    const parsed = parseFloat(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  return 0;
}

function buildProfilePayload(profile, cvText = '') {
  const essential = profile.essential || {};
  const preferences = profile.preferences || {};
  const professional = profile.professional || {};
  const commonAnswers = profile.commonAnswers || {};
  const skills = profile.skills || {};
  const years =
    typeof skills.yearsExperience === 'object'
      ? skills.yearsExperience || {}
      : skills.yearsExperience;
  const education = skills.education || {};

  const yearsTotal =
    typeof years === 'object'
      ? years?.total ?? 0
      : years ?? profile.yearsExperience ?? 0;

  return {
    fullName: essential.fullName || '',
    email: essential.email || '',
    phone: essential.phone || '',
    location: essential.location || '',
    linkedIn: essential.linkedIn || '',
    portfolio:
      essential.portfolio ||
      essential.portfolioUrl ||
      profile.portfolio ||
      profile.portfolioUrl ||
      '',
    github:
      essential.github ||
      essential.githubUrl ||
      profile.github ||
      profile.githubUrl ||
      '',
    workAuthorization: essential.workAuthorization || '',
    securityClearance: essential.securityClearance || 'None',

    jobTypes: Array.isArray(preferences.jobTypes) ? preferences.jobTypes : [],
    preferredIndustries: Array.isArray(preferences.preferredIndustries)
      ? preferences.preferredIndustries
      : [],
    salaryMin:
      preferences.expectedSalaryMin ||
      preferences.salaryMin ||
      profile.salaryMin ||
      '',
    salaryMax:
      preferences.expectedSalaryMax ||
      preferences.salaryMax ||
      profile.salaryMax ||
      '',
    relocate:
      preferences.willingToRelocate ||
      profile.relocate ||
      preferences.relocate ||
      '',

    referralSource:
      commonAnswers.referralSource ||
      profile.referralSource ||
      preferences.referralSource ||
      '',
    notice:
      commonAnswers.noticeRequired ||
      profile.notice ||
      preferences.notice ||
      '',
    interviewAvail:
      commonAnswers.availableForInterview || profile.interviewAvail || '',

    summary: professional.summary || '',
    currentRole: professional.currentRole || '',

    topSkills: Array.isArray(skills.topSkills) ? skills.topSkills : [],
    certifications: Array.isArray(skills.certifications)
      ? skills.certifications
      : [],
    yearsExperience: normalizeNumber(yearsTotal),
    yearsManagementExperience: normalizeNumber(
      typeof years === 'object' ? years?.management ?? 0 : 0
    ),
    yearsTechnicalExperience: normalizeNumber(
      typeof years === 'object' ? years?.technical ?? 0 : 0
    ),

    degree: education.highestDegree || profile.degree || '',
    major: education.fieldOfStudy || profile.major || '',
    university: education.university || profile.university || '',
    gradYear: education.graduationYear || profile.gradYear || '',

    cvText: cvText || '',
    source: profile.metadata?.source || 'manual',
    onboardingComplete:
      profile.metadata?.onboardingComplete !== undefined
        ? profile.metadata.onboardingComplete
        : true,
  };
}

/**
 * Upload local profile to database
 * Call this after profile updates
 */
export async function syncProfileToDatabase() {
  try {
    const config = await getConfig();
    const [profile, rrState, storageData] = await Promise.all([
      getUserProfile(),
      getRRIntegrationState(),
      chrome.storage.local.get([
        'employmentHistory',
        'customAnswers',
        'userCV',
      ]),
    ]);
    const token = await getAuthToken();
    const effectiveToken = rrState?.authToken || token;

    if (!profile) {
      console.log('[ProfileSync] No profile to sync');
      return { success: false, error: 'No profile found' };
    }

    if (!effectiveToken) {
      console.log('[ProfileSync] No auth token, skipping sync');
      return { success: false, error: 'Not authenticated' };
    }

    const employmentHistory = storageData.employmentHistory;
    let customAnswers = storageData.customAnswers;
    const cvText = storageData.userCV || '';

    const rrBase = resolveRrApiBase(config);
    if (rrBase && rrState?.sessionId) {
      try {
        const rrResult = await syncProfileToReverseRecruiting({
          config,
          token: effectiveToken,
          profile,
          cvText,
          rrState,
        });
        if (rrResult) {
          await chrome.storage.local.set({
            lastProfileSync: Date.now(),
            profileSyncStatus: 'success',
          });
          return {
            success: true,
            data: rrResult,
            target: 'reverse-recruiting',
          };
        }
      } catch (rrError) {
        console.error(
          '[ProfileSync] Reverse Recruiting sync failed, falling back:',
          rrError
        );
      }
    }

    if (!token) {
      console.log('[ProfileSync] No legacy auth token, skipping Supabase sync');
      return { success: false, error: 'Not authenticated' };
    }

    if (
      customAnswers &&
      !Array.isArray(customAnswers) &&
      typeof customAnswers === 'object'
    ) {
      customAnswers = Object.entries(customAnswers)
        .filter(
          ([question, answer]) =>
            typeof question === 'string' && typeof answer === 'string'
        )
        .map(([question, answer]) => ({
          question,
          question_text: question,
          answer,
          answer_text: answer,
        }));
    }

    const payloadProfile = buildProfilePayload(profile, cvText);
    const base =
      resolveRrApiBase(config) || (config.apiBaseUrl || '').replace(/\/$/, '');
    if (!base) throw new Error('Legacy API base URL not configured');

    console.log('[ProfileSync] Syncing profile to legacy backend...');

    const response = await fetch(`${base}/v1/profile/sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        profile: payloadProfile,
        employment: employmentHistory || [],
        customAnswers: customAnswers || [],
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || 'Sync failed');
    }

    const result = await response.json();

    await chrome.storage.local.set({
      lastProfileSync: Date.now(),
      profileSyncStatus: 'success',
    });

    console.log('[ProfileSync] ✅ Profile synced to database successfully');
    return { success: true, data: result, target: 'legacy' };
  } catch (error) {
    console.error('[ProfileSync] Error syncing to database:', error);

    await chrome.storage.local.set({
      profileSyncStatus: 'error',
      profileSyncError: error.message,
    });

    return { success: false, error: error.message };
  }
}

/**
 * Download profile from database to local storage
 * Call this on login or when local profile is missing
 */
export async function syncProfileFromDatabase() {
  try {
    const token = await getAuthToken();
    if (!token) {
      console.log('[ProfileSync] No auth token, skipping sync');
      return { success: false, error: 'Not authenticated' };
    }

    const config = await getConfig();

    console.log('[ProfileSync] Fetching profile from database...');

    const base =
      resolveRrApiBase(config) || (config.apiBaseUrl || '').replace(/\/$/, '');

    const response = await fetch(`${base}/v1/profile/sync`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(error || 'Fetch failed');
    }

    const { profile, employment, customAnswers, synced_at } =
      await response.json();

    if (!profile) {
      console.log('[ProfileSync] No profile found in database');
      return { success: false, error: 'No profile in database' };
    }

    // Convert database format to local storage format
    const localProfile = {
      essential: {
        fullName: profile.full_name || '',
        email: profile.email || '',
        phone: profile.phone || '',
        location: profile.location || '',
        linkedIn: profile.linkedin_url || '',
        portfolio: profile.portfolio_url || '',
        github: profile.github_url || '',
        workAuthorization: profile.work_authorization || '',
        securityClearance: profile.security_clearance || '',
      },
      preferences: {
        jobTypes: profile.job_types || [],
        preferredIndustries: profile.preferred_industries || [],
        expectedSalaryMin: profile.expected_salary_min || '',
        expectedSalaryMax: profile.expected_salary_max || '',
        willingToRelocate: profile.willing_to_relocate || '',
      },
      skills: {
        topSkills: profile.top_skills || [],
        certifications: profile.certifications || [],
        yearsExperience: {
          total: profile.years_total_experience || 0,
          management: profile.years_management_experience || 0,
          technical: profile.years_technical_experience || 0,
        },
        education: {
          highestDegree: profile.highest_degree || '',
          fieldOfStudy: profile.field_of_study || '',
          university: profile.university || '',
          graduationYear: profile.graduation_year || '',
        },
      },
      commonAnswers: {
        referralSource: profile.referral_source || '',
        availableForInterview: profile.interview_availability || '',
        noticeRequired: profile.notice_required || '',
      },
      professional: {
        summary: profile.professional_summary || '',
        currentRole: profile.current_job_title || '',
        yearsInCurrentRole: 0,
      },
      metadata: {
        createdAt: new Date(profile.created_at).getTime(),
        lastUpdated: new Date(profile.updated_at).getTime(),
        completeness: profile.completeness_score || 0,
        source: profile.profile_source || 'manual',
        onboardingComplete: profile.onboarding_completed || false,
      },
    };

    // Save to local storage
    await saveUserProfile(localProfile);

    // Save employment history
    if (employment && employment.length > 0) {
      await chrome.storage.local.set({ employmentHistory: employment });
    }

    // Save custom answers
    if (customAnswers && customAnswers.length > 0) {
      await chrome.storage.local.set({ customAnswers: customAnswers });
    }

    // Update sync metadata
    await chrome.storage.local.set({
      lastProfileSync: Date.now(),
      profileSyncStatus: 'success',
      profileSyncDirection: 'from_database',
    });

    console.log('[ProfileSync] ✅ Profile synced from database successfully');
    return { success: true, profile: localProfile, employment, customAnswers };
  } catch (error) {
    console.error('[ProfileSync] Error syncing from database:', error);

    await chrome.storage.local.set({
      profileSyncStatus: 'error',
      profileSyncError: error.message,
    });

    return { success: false, error: error.message };
  }
}

/**
 * Bi-directional sync: merge local and remote profiles
 * Uses "last updated" timestamp to determine which is newer
 */
export async function bidirectionalSync() {
  try {
    const localProfile = await getUserProfile();
    const { profile: remoteProfile } = await syncProfileFromDatabase();

    if (!localProfile && !remoteProfile) {
      console.log('[ProfileSync] No profile found locally or remotely');
      return { success: true, message: 'No profile to sync' };
    }

    // If only one exists, use it
    if (!localProfile && remoteProfile) {
      console.log('[ProfileSync] Using remote profile');
      return { success: true, source: 'remote' };
    }

    if (localProfile && !remoteProfile) {
      console.log('[ProfileSync] Uploading local profile');
      return await syncProfileToDatabase();
    }

    // Both exist: compare timestamps
    const localTimestamp = localProfile.metadata?.lastUpdated || 0;
    const remoteTimestamp = new Date(remoteProfile.updated_at).getTime();

    if (remoteTimestamp > localTimestamp) {
      console.log('[ProfileSync] Remote is newer, using remote profile');
      return {
        success: true,
        source: 'remote',
        message: 'Used remote profile',
      };
    } else {
      console.log('[ProfileSync] Local is newer, uploading to database');
      return await syncProfileToDatabase();
    }
  } catch (error) {
    console.error('[ProfileSync] Bidirectional sync error:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Auto-sync: Run periodically in the background
 * Call this from background.js or service worker
 */
export async function startAutoSync() {
  // Sync immediately
  await bidirectionalSync();

  // Then sync every 5 minutes if there are changes
  setInterval(async () => {
    const { lastProfileSync } = await chrome.storage.local.get(
      'lastProfileSync'
    );
    const profile = await getUserProfile();

    if (!profile) return;

    const profileUpdated = profile.metadata?.lastUpdated || 0;
    const lastSync = lastProfileSync || 0;

    // If profile was updated since last sync, sync now
    if (profileUpdated > lastSync) {
      console.log('[ProfileSync] Profile changed, syncing...');
      await syncProfileToDatabase();
    }
  }, 5 * 60 * 1000); // 5 minutes
}

/**
 * Save a custom answer for reuse
 */
export async function saveCustomAnswer(question, answer, category = null) {
  try {
    const stored = await chrome.storage.local.get('customAnswers');
    let customAnswers = stored.customAnswers;

    const normalized = question.toLowerCase().replace(/[^\w\s]/g, '');

    if (Array.isArray(customAnswers)) {
      // Newer format: array of objects
      const existing = customAnswers.find(
        (a) => a.question_normalized === normalized
      );

      if (existing) {
        existing.answer_text = answer;
        existing.times_used = (existing.times_used || 0) + 1;
        existing.last_used_at = new Date().toISOString();
      } else {
        customAnswers.push({
          question_text: question,
          question_normalized: normalized,
          answer_text: answer,
          question_category: category,
          times_used: 1,
          last_used_at: new Date().toISOString(),
          created_at: new Date().toISOString(),
        });
      }
    } else {
      // Legacy format: simple { question: answer } map
      if (!customAnswers || typeof customAnswers !== 'object') {
        customAnswers = {};
      }
      customAnswers[question] = answer;
    }

    await chrome.storage.local.set({ customAnswers });

    // Sync to database in background
    syncProfileToDatabase().catch((e) =>
      console.error('[ProfileSync] Background sync failed:', e)
    );

    return { success: true };
  } catch (error) {
    console.error('[ProfileSync] Error saving custom answer:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Get cached answer for a question
 */
export async function getCachedAnswer(question) {
  try {
    const stored = await chrome.storage.local.get('customAnswers');
    const customAnswers = stored.customAnswers;

    const normalized = question.toLowerCase().replace(/[^\w\s]/g, '');

    if (Array.isArray(customAnswers)) {
      // Newer array format
      const match = customAnswers.find(
        (a) => a.question_normalized === normalized
      );

      if (match) {
        return {
          found: true,
          answer: match.answer_text,
          timesUsed: match.times_used || 0,
        };
      }
    } else if (customAnswers && typeof customAnswers === 'object') {
      // Legacy map format: exact question text as key
      const direct = customAnswers[question];
      if (typeof direct === 'string' && direct.trim()) {
        return { found: true, answer: direct, timesUsed: 0 };
      }
    }

    return { found: false, answer: null };
  } catch (error) {
    console.error('[ProfileSync] Error getting cached answer:', error);
    return { found: false, answer: null };
  }
}
