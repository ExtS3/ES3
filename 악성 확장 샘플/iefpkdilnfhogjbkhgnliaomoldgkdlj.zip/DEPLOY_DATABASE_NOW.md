# Deploy Database Schema to Supabase - Quick Guide

## ✅ You're Already in the Right Place!

I can see you have Supabase open with the `user_profiles` table visible (currently empty).

## 🚀 Step-by-Step Deployment

### Step 1: Open SQL Editor

1. In the Supabase dashboard (left sidebar), click **"SQL Editor"**
2. Click **"New query"** button

### Step 2: Copy the SQL Schema

1. Open this file in your IDE:

   ```
   /home/stationone/Desktop/up/ancilia/chromeextension2/vercel-backend/user_profiles.sql
   ```

2. **Copy ALL the content** (it's ~480 lines)

### Step 3: Paste and Run

1. Paste the entire SQL content into the Supabase SQL Editor
2. Click **"Run"** button (or press Ctrl+Enter / Cmd+Enter)
3. Wait for execution to complete (~5-10 seconds)

### Step 4: Verify Tables Were Created

After running, you should see in the left sidebar under "Tables":

- ✅ `user_profiles`
- ✅ `user_custom_answers` (for interview questions)
- ✅ `employment_history`
- ✅ `field_mappings`
- ✅ `profile_analytics`
- ✅ `trial_counters`
- ✅ `application_logs`

## Expected Output

You should see success messages like:

```
✓ CREATE EXTENSION
✓ CREATE TABLE public.user_profiles
✓ CREATE TABLE public.user_custom_answers
✓ CREATE TABLE public.employment_history
✓ CREATE TABLE public.field_mappings
✓ CREATE INDEX
✓ CREATE FUNCTION
✓ CREATE TRIGGER
✓ INSERT (seed data)
```

## What This Schema Does

### 1. `user_profiles` Table

Stores all user profile data:

- Personal info (name, email, phone, location)
- Professional details (role, experience, skills)
- Work preferences (salary, job types, relocation)
- Onboarding status

### 2. `user_custom_answers` Table

Stores interview question answers:

- Question text
- Answer text
- Usage tracking (times_used, last_used_at)
- For reuse across applications

### 3. `employment_history` Table

Tracks job history:

- Company, title, dates
- Responsibilities, achievements
- Linked to user profile

### 4. `field_mappings` Table

Maps form fields to profile fields:

- Learns common field patterns
- Speeds up auto-fill
- Tracks success rates

### 5. Helper Functions

- `calculate_profile_completeness()` - Returns completion %
- `get_or_create_profile()` - Auto-creates profile on first use
- Triggers for `updated_at` timestamps

## Troubleshooting

### ❌ Error: "relation already exists"

**Solution:** Tables already exist, you're good! Skip to verification.

### ❌ Error: "permission denied"

**Solution:** Make sure you're connected to the correct project and have admin access.

### ❌ Error: "syntax error"

**Solution:**

1. Make sure you copied the ENTIRE file
2. Don't modify any part of the SQL
3. Run it all at once, not line by line

## After Deployment

### Test the Schema

Run this query in SQL Editor to verify:

```sql
-- Check all tables exist
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
AND table_name IN (
  'user_profiles',
  'user_custom_answers',
  'employment_history',
  'field_mappings'
);
```

You should see 4 rows returned.

### Check RLS Policies

```sql
-- Verify Row Level Security is enabled
SELECT tablename, policyname
FROM pg_policies
WHERE schemaname = 'public';
```

You should see policies for each table.

## Next Steps

After deployment:

1. ✅ **Reload your Chrome extension** to test profile sync
2. ✅ **Sign up a new user** in the extension
3. ✅ **Fill out the profile** in onboarding
4. ✅ **Check Supabase Table Editor** - you should see data in `user_profiles`
5. ✅ **Answer interview questions** - data should appear in `user_custom_answers`

## Quick Verification Checklist

- [ ] Opened SQL Editor in Supabase
- [ ] Copied entire `user_profiles.sql` file
- [ ] Pasted and ran in SQL Editor
- [ ] Saw success messages (no errors)
- [ ] Verified tables appear in sidebar
- [ ] Tested with a new user signup
- [ ] Confirmed data appears in tables

## Files Reference

- **SQL Schema**: `/home/stationone/Desktop/up/ancilia/chromeextension2/vercel-backend/user_profiles.sql`
- **API Route**: `/home/stationone/Desktop/up/ancilia/chromeextension2/vercel-backend/app/api/v1/profile/sync/route.ts`
- **Client Sync**: `/home/stationone/Desktop/up/ancilia/chromeextension2/profile-sync.js`
- **Setup Flow**: `/home/stationone/Desktop/up/ancilia/chromeextension2/profile-setup.js`

## Common Issues

### Issue: 500 Error on Profile Fetch

**Cause:** Database tables don't exist yet
**Solution:** Deploy this SQL schema!

### Issue: Profile Data Not Saving

**Cause:** RLS policies blocking writes
**Solution:** Check user is authenticated (has valid token)

### Issue: Interview Answers Not Appearing

**Cause:** `user_custom_answers` table missing
**Solution:** This schema creates it!

---

## 🎉 Once Deployed

Your application will have:

- ✅ Cross-device profile sync
- ✅ Persistent interview answers
- ✅ Employment history tracking
- ✅ Smart field mapping learning
- ✅ Profile analytics
- ✅ Trial usage tracking

All data will be secure with Row Level Security (RLS) - users can only see their own data!
