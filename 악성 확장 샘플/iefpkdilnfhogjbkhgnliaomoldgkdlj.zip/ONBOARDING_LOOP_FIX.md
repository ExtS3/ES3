# Onboarding Redirect Loop Fix

## Problem

After completing onboarding, users were stuck in an infinite redirect loop:

1. User completes onboarding → Redirects to sidepanel
2. Sidepanel checks onboarding status → Finds it incomplete
3. Redirects back to onboarding → Loop continues

## Root Cause

The onboarding completion wasn't being properly saved or checked:

- Local storage flag was set but not checked first
- Backend sync might fail silently
- No delay to ensure storage write completed
- Insufficient logging to debug the issue

## Solution

### 1. **Profile Setup (`profile-setup.js`)**

**Added:**

- Better error logging for backend sync
- Explicit success tracking
- 500ms delay after setting local storage flag
- More detailed console logs
- Mark onboarding complete regardless of backend sync status

```javascript
// Sync to database with onboarding_completed flag
let syncSuccess = false;
try {
  // ... sync logic ...

  console.log('[ProfileSetup] Syncing profile to database...');
  const syncRes = await fetch(`${base}/v1/profile/sync`, {
    method: 'POST',
    // ...
  });

  if (syncRes.ok) {
    const syncData = await syncRes.json();
    console.log('[ProfileSetup] Profile synced to database:', syncData);
    syncSuccess = true;
  } else {
    const errorText = await syncRes.text();
    console.error(
      '[ProfileSetup] Database sync failed:',
      syncRes.status,
      errorText
    );
  }
} catch (e) {
  console.error('[ProfileSetup] Sync error:', e);
}

// Mark onboarding as complete locally regardless of sync status
await chrome.storage.local.set({ onboardingComplete: true });

// Add a small delay to ensure storage is written
await new Promise((resolve) => setTimeout(resolve, 500));

console.log(
  '[ProfileSetup] Onboarding marked complete, redirecting to sidepanel'
);
```

### 2. **Sidepanel (`sidepanel.js`)**

**Added:**

- Check local storage FIRST before backend
- Detailed logging at each step
- Fallback to local storage if backend check fails

```javascript
async function checkOnboardingStatus() {
  try {
    // First check local storage
    const { onboardingComplete } = await chrome.storage.local.get(
      'onboardingComplete'
    );
    if (onboardingComplete === true) {
      console.log('[Sidepanel] Onboarding marked complete in local storage');
      return true;
    }

    // Then check backend
    const base = (CONFIG?.apiBaseUrl || '').replace(/\/$/, '');
    if (!base) {
      console.log('[Sidepanel] No API base URL, checking local storage only');
      return false;
    }

    // ... backend check with detailed logging ...

    console.log('[Sidepanel] Profile data:', {
      onboarding_completed: profile?.onboarding_completed,
      has_name: !!profile?.full_name,
      has_email: !!profile?.email,
      has_cv: !!profile?.cv_text,
      has_skills: !!profile?.top_skills?.length,
    });
  } catch (err) {
    console.error('[Sidepanel] Error checking onboarding status:', err);
    // Check local storage as fallback
    const { onboardingComplete } = await chrome.storage.local.get(
      'onboardingComplete'
    );
    return onboardingComplete === true;
  }
}
```

## How It Works Now

### Flow 1: Successful Completion

1. User completes onboarding
2. Profile saved to local storage ✅
3. Profile synced to backend ✅
4. `onboardingComplete` flag set to `true` in local storage
5. 500ms delay to ensure write completes
6. Redirect to sidepanel
7. Sidepanel checks local storage → Finds `onboardingComplete: true`
8. ✅ Shows main interface (no redirect loop)

### Flow 2: Backend Sync Fails

1. User completes onboarding
2. Profile saved to local storage ✅
3. Backend sync fails ❌ (network error, server down, etc.)
4. `onboardingComplete` flag still set to `true` in local storage
5. Redirect to sidepanel
6. Sidepanel checks local storage → Finds `onboardingComplete: true`
7. ✅ Shows main interface (no redirect loop)

### Flow 3: First-Time User

1. User logs in for first time
2. Sidepanel checks local storage → No `onboardingComplete` flag
3. Sidepanel checks backend → No profile data
4. Redirects to onboarding
5. User completes onboarding
6. Follows Flow 1 or Flow 2

## Debugging

### Check Console Logs

**In Profile Setup:**

```
[ProfileSetup] Profile saved successfully
[ProfileSetup] Syncing profile to database...
[ProfileSetup] Profile synced to database with onboarding completed: {...}
[ProfileSetup] Onboarding marked complete, redirecting to sidepanel
```

**In Sidepanel:**

```
[Sidepanel] DOMContentLoaded - Extension starting up
[Sidepanel] Onboarding marked complete in local storage
[Sidepanel] User is authenticated and has completed onboarding, show main plugin interface
```

### Check Local Storage

Open DevTools → Application → Storage → Local Storage:

```javascript
{
  "onboardingComplete": true,
  "userProfile": { ... },
  "userCV": "..."
}
```

### Check Backend

```bash
# Check if profile was synced
curl -H "Authorization: Bearer YOUR_TOKEN" \
  https://your-backend.com/v1/profile/sync

# Response should include:
{
  "profile": {
    "onboarding_completed": true,
    ...
  }
}
```

## Benefits

1. **No More Loops** ✅

   - Local storage check prevents infinite redirects
   - Works even if backend is down

2. **Better Reliability** ✅

   - Doesn't depend solely on backend
   - Fallback mechanisms at every step

3. **Better Debugging** ✅

   - Detailed console logs
   - Can trace exact failure point

4. **Faster** ✅
   - Local storage check is instant
   - No need to wait for backend on every load

## Testing

### Test Case 1: Normal Completion

1. Complete onboarding
2. Check console for success logs
3. Should redirect to sidepanel
4. Should NOT redirect back to onboarding
5. ✅ Pass

### Test Case 2: Backend Down

1. Disconnect internet
2. Complete onboarding
3. Backend sync will fail
4. Should still redirect to sidepanel
5. Should NOT redirect back to onboarding
6. ✅ Pass

### Test Case 3: Refresh After Completion

1. Complete onboarding
2. Refresh the sidepanel
3. Should check local storage first
4. Should NOT redirect to onboarding
5. ✅ Pass

### Test Case 4: New User

1. Sign up with new account
2. Should redirect to onboarding
3. Complete onboarding
4. Should redirect to sidepanel
5. Should NOT loop back
6. ✅ Pass

## Rollback Plan

If issues persist, you can temporarily disable onboarding check:

```javascript
// In sidepanel.js, comment out the onboarding check:
// const hasCompletedOnboarding = await checkOnboardingStatus();
// if (!hasCompletedOnboarding) {
//   console.log('[Sidepanel] User needs onboarding - redirecting');
//   window.location.href = 'profile-setup.html';
//   return;
// }

// Force show main interface:
const hasCompletedOnboarding = true; // Always true
```

## Future Improvements

1. **Add Loading State**

   - Show spinner while checking onboarding status
   - Prevent flash of wrong screen

2. **Sync Retry Logic**

   - Retry backend sync if it fails
   - Queue sync for later if offline

3. **Better Error Messages**
   - Show user-friendly message if sync fails
   - Option to retry sync manually
