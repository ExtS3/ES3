# Build Fix - Missing Supabase Dependency

## ❌ Error:

```
Module not found: Can't resolve '@supabase/supabase-js'
```

## ✅ Fix:

Added `@supabase/supabase-js` to `vercel-backend/package.json`

## Changes Made:

**File:** `vercel-backend/package.json`

```json
"dependencies": {
  "@supabase/supabase-js": "^2.39.3",  // ✅ ADDED
  "next": "14.2.7",
  "react": "18.2.0",
  "react-dom": "18.2.0"
}
```

## Why This Happened:

The new API endpoint `/api/v1/profile/sync/route.ts` uses:

```typescript
import { createClient } from '@supabase/supabase-js';
```

But the package wasn't installed in the backend's dependencies.

## ✅ Fixed!

Push this change to trigger a new build. The deployment should now succeed.

```bash
git add vercel-backend/package.json
git commit -m "Add @supabase/supabase-js dependency"
git push
```

Vercel will auto-deploy and the build will succeed! 🚀






