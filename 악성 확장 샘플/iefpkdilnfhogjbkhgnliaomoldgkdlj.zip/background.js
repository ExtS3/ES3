// Background Service Worker for Job Form Filler Assistant
//
// Ensure side panel is enabled on install and update
chrome.runtime.onInstalled.addListener(async (details) => {
  try {
    await chrome.sidePanel.setOptions({
      path: 'sidepanel.html',
      enabled: true,
    });

    // On first install, do not open any tabs. The side panel will show
    // the built-in auth overlay (signup/login) when opened.
    // Optionally, try to open the side panel on the active window.
    if (details.reason === 'install') {
      try {
        const [tab] = await chrome.tabs.query({
          active: true,
          lastFocusedWindow: true,
        });
        if (tab && tab.windowId != null) {
          await chrome.sidePanel.open({ windowId: tab.windowId });
        }
      } catch (_) {}
    }
  } catch (error) {
    console.error('Failed to set side panel options:', error);
  }
});

// Allow clicking the extension action to open the side panel
chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.sidePanel.open({ windowId: tab.windowId });
  } catch (error) {
    console.error('Failed to open side panel:', error);
  }
});

function normalizeLabel(str) {
  return String(str || '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/[^a-z0-9 ]+/g, '')
    .trim();
}

function detectFormFieldNames(formText) {
  const lines = String(formText || '').split(/\n+/);
  const names = [];
  for (const line of lines) {
    if (
      /\bFIELD:\b/i.test(line) ||
      /\blabel=/i.test(line) ||
      /name=/.test(line)
    ) {
      const labelMatch = line.match(/label=([^\n]*)/i);
      const nameMatch = line.match(/name=([^\s]+)/i);
      const label = labelMatch ? labelMatch[1].trim() : '';
      const name = nameMatch ? nameMatch[1].trim() : '';
      const candidate = label || name;
      if (!candidate) continue;
      const norm = normalizeLabel(candidate);
      if (norm && !names.includes(norm)) names.push(norm);
    }
  }
  // If nothing detected, add some common defaults to try filling
  if (names.length === 0) {
    names.push(
      'fullname',
      'firstname',
      'lastname',
      'email',
      'phone',
      'linkedin',
      'github',
      'portfolio',
      'website',
      'address',
      'city',
      'state',
      'country',
      'postalcode'
    );
  }
  return names;
}

function isEmail(value) {
  const v = String(value || '').trim();
  return /^(?:mailto:)?[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(
    v.replace(/^https?:\/\//i, '')
  );
}

function cleanEmail(value) {
  const v = String(value || '')
    .trim()
    .replace(/^https?:\/\//i, '')
    .replace(/^mailto:/i, '');
  // If it contains spaces or pipes around, just return trimmed
  return v;
}

function isDomainLike(value) {
  const v = String(value || '').trim();
  if (!v || /@/.test(v)) return false; // do not treat emails as domain-like
  return /^(?:https?:\/\/)?(?:www\.)?[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?:\/[\w./%-]*)?$/.test(
    v
  );
}

function normalizeAbsoluteUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  try {
    if (/^https?:\/\//i.test(raw)) {
      const u = new URL(raw);
      u.protocol = 'https:';
      u.search = '';
      u.hash = '';
      return u.toString().replace(/\/?$/, '');
    }
    if (/^www\./i.test(raw) || isDomainLike(raw)) {
      return ('https://' + raw).replace(/\/?$/, '');
    }
    return raw;
  } catch (_) {
    return raw;
  }
}

function normalizeLinkedInUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  try {
    if (/^https?:\/\//i.test(raw)) {
      const u = new URL(raw);
      if (u.hostname.toLowerCase().includes('linkedin.com')) {
        u.protocol = 'https:';
        u.hostname = 'www.linkedin.com';
        u.search = '';
        u.hash = '';
        return u.toString().replace(/\/?$/, '');
      }
      return normalizeAbsoluteUrl(raw);
    }
    if (/^(?:www\.)?linkedin\.com/i.test(raw)) {
      return ('https://' + raw).replace(/\/?$/, '');
    }
    const rel = raw.match(/\/?in\/[A-Za-z0-9_.-]+/i);
    if (rel) {
      const path = rel[0].startsWith('/') ? rel[0] : '/' + rel[0];
      return 'https://www.linkedin.com' + path;
    }
    return normalizeAbsoluteUrl(raw);
  } catch (_) {
    return raw;
  }
}

function normalizeGithubUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  try {
    if (/^https?:\/\//i.test(raw)) {
      const u = new URL(raw);
      if (u.hostname.toLowerCase().includes('github.com')) {
        u.protocol = 'https:';
        u.hostname = 'github.com';
        u.search = '';
        u.hash = '';
        return u.toString().replace(/\/?$/, '');
      }
      return normalizeAbsoluteUrl(raw);
    }
    if (/^(?:www\.)?github\.com/i.test(raw)) {
      return ('https://' + raw).replace(/\/?$/, '');
    }
    return normalizeAbsoluteUrl(raw);
  } catch (_) {
    return raw;
  }
}

// Performance helpers: config loader, hashing, caching, truncation, timeout
const __CONFIG = { apiBaseUrl: null, loaded: false };
async function getConfig() {
  if (__CONFIG.loaded) return __CONFIG;
  try {
    const res = await fetch(chrome.runtime.getURL('config.json'));
    const json = await res.json();
    __CONFIG.apiBaseUrl = String(json?.apiBaseUrl || '').replace(/\/+$/, '');
  } catch (_) {}
  __CONFIG.loaded = true;
  return __CONFIG;
}

function fnv1a(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
  }
  return (h >>> 0).toString(16);
}

function makeCacheKey(kind, obj) {
  return `v1:${kind}:${fnv1a(JSON.stringify(obj || {}))}`;
}

async function getCached(key) {
  try {
    const data = await chrome.storage.local.get(key);
    return data?.[key];
  } catch (_) {
    return undefined;
  }
}

async function setCached(key, value) {
  try {
    await chrome.storage.local.set({ [key]: value });
  } catch (_) {}
}

function trimInput(text, maxLen) {
  const MAX = typeof maxLen === 'number' ? maxLen : 8000;
  try {
    const cleaned = stripPlaceholders(String(text || ''));
    return cleaned.length > MAX ? cleaned.slice(0, MAX) : cleaned;
  } catch (_) {
    const t = String(text || '');
    return t.length > MAX ? t.slice(0, MAX) : t;
  }
}

function buildCondensedFormText(formText, maxFields) {
  const limit = typeof maxFields === 'number' ? maxFields : 50;
  const fields = detectFormFieldNames(formText).slice(0, limit);
  return fields.map((f) => `FIELD: ${f}`).join('\n');
}

function withTimeout(promise, ms) {
  let timer;
  return Promise.race([
    promise.finally(() => clearTimeout(timer)),
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('timeout')), ms);
    }),
  ]);
}

function annotateResult(result, provider, model, startedAtMs) {
  try {
    const seconds = Math.max(
      0,
      (Date.now() - (startedAtMs || Date.now())) / 1000
    );
    const secondsStr = seconds.toFixed(1).replace(/\.0$/, '.0');
    const modelLine = `Model: ${String(provider || 'unknown')} ${String(
      model || ''
    )}`.trim();
    const timeLine = `⏱️ Took ${secondsStr}s`;
    const existing = String(result && result.notes ? result.notes : '').trim();
    const combinedLine = `${modelLine} • ${timeLine}`;
    result.notes = existing ? `${existing}\n${combinedLine}` : combinedLine;
  } catch (_) {}
  return result;
}

async function readSuperFastConfig() {
  const cfg = await getConfig();
  const block = cfg && cfg.apiBaseUrl !== undefined ? cfg : { apiBaseUrl: '' };
  try {
    // Re-read raw file to access superFast keys
    const res = await fetch(chrome.runtime.getURL('config.json'));
    const json = await res.json();
    const sf = json?.superFast || {};
    return {
      enabled: !!sf.enabled,
      preferredProvider:
        String(sf.preferredProvider || '').toLowerCase() || 'openai',
      openaiKey: String(sf.openaiKey || ''),
      openaiModel: String(sf.openaiModel || 'gpt-5-mini'),
      geminiKey: String(sf.geminiKey || ''),
      geminiModel: String(sf.geminiModel || 'gemini-1.5-flash'),
      grokKey: String(sf.grokKey || ''),
      grokModel: String(sf.grokModel || 'grok-4-1-fast-non-reasoning'),
      claudeKey: String(sf.claudeKey || ''),
      claudeModel: String(sf.claudeModel || 'claude-3-5-haiku-latest'),
    };
  } catch (_) {
    return { enabled: false };
  }
}

async function callGeminiJSON({ apiKey, model, system, user }) {
  // Minimal Gemini generateContent with JSON bias using safety defaults
  const url =
    'https://generativelanguage.googleapis.com/v1beta/models/' +
    (model || 'gemini-1.5-flash') +
    ':generateContent?key=' +
    encodeURIComponent(apiKey);
  const body = {
    contents: [
      {
        role: 'user',
        parts: [{ text: (system ? system + '\n\n' : '') + user }],
      },
    ],
    generationConfig: {
      temperature: 0.2,
      responseMimeType: 'application/json',
    },
  };
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error('Gemini API error ' + res.status + ': ' + t);
  }
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
  return text;
}

async function callClaudeJSON({ apiKey, model, system, user }) {
  console.log('[Background] Calling Claude API with model:', model);
  const url = 'https://api.anthropic.com/v1/messages';
  const body = {
    model: model || 'claude-3-5-haiku-latest',
    temperature: 0.2,
    max_tokens: 800,
    system,
    messages: [
      {
        role: 'user',
        content: user,
      },
    ],
    metadata: { source: 'jobapai-extension' },
  };
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const t = await res.text();
    console.error('[Background] Claude API error:', res.status, t);
    throw new Error('Claude API error ' + res.status + ': ' + t);
  }
  const data = await res.json();
  // Claude messages API returns content array with text segments
  const text = (data?.content && data.content[0]?.text) || '';
  console.log(
    '[Background] Claude API response received, length:',
    text.length
  );
  return text || '{}';
}

// Try multiple Claude models until one succeeds (helps when some models are not enabled)
async function callClaudeWithFallback({
  apiKey,
  preferredModel,
  system,
  user,
}) {
  const candidateModels = Array.from(
    new Set([
      preferredModel || 'claude-3-5-haiku-latest',
      'claude-3-5-haiku-20241022',
      'claude-3-haiku-20240307',
      'claude-3-haiku-20240229',
      'claude-3-5-sonnet-latest',
      'claude-3-5-sonnet-20241022',
      'claude-3-5-sonnet-20240620',
      'claude-3-sonnet-20240229',
      'claude-3-opus-20240229',
      'claude-2.1',
      'claude-2.0',
      'claude-instant-1.2',
    ])
  );

  let lastErr = null;
  for (const m of candidateModels) {
    try {
      const text = await callClaudeJSON({ apiKey, model: m, system, user });
      return { text, modelUsed: m };
    } catch (e) {
      lastErr = e;
      console.warn(
        '[Background] Claude model failed, trying next:',
        m,
        e?.message || e
      );
    }
  }
  throw lastErr || new Error('All Claude models failed');
}

async function callGrokJSON({ apiKey, model, system, user }) {
  console.log('[Background] Calling Grok API with model:', model);
  const url = 'https://api.x.ai/v1/chat/completions';
  const body = {
    model: model || 'grok-2',
    temperature: 0.2,
    response_format: { type: 'json_object' },
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
  };
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const t = await res.text();
    console.error('[Background] Grok API error:', res.status, t);
    throw new Error('Grok API error ' + res.status + ': ' + t);
  }
  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content || '{}';
  console.log(
    '[Background] Grok API response received, length:',
    content.length
  );
  return content;
}

function extractFromCv(cvText) {
  const text = String(cvText || '');
  const lines = text
    .split(/\n+/)
    .map((l) => l.trim())
    .filter(Boolean);
  const top = lines[0] || '';
  const email =
    (text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i) || [])[0] || '';
  const phone = (text.match(/\+?\d[\d\s().-]{7,}\d/) || [])[0] || '';
  // Try absolute LinkedIn first
  let linkedin =
    (text.match(
      /https?:\/\/(?:[\w.-]+\.)?linkedin\.com\/[A-Za-z0-9\/_\-.]+/i
    ) || [])[0] || '';
  // Then try relative or domain-only forms
  if (!linkedin) {
    const rel =
      (text.match(/(?:^|\s)(?:www\.)?linkedin\.com\/[A-Za-z0-9\/_\-.]+/i) ||
        [])[0] || '';
    const justIn =
      (text.match(/(?:^|\s)\/?in\/[A-Za-z0-9_.-]+/i) || [])[0] || '';
    linkedin = (rel || justIn).trim();
  }
  let github =
    (text.match(/https?:\/\/(?:www\.)?github\.com\/[A-Za-z0-9\/_\-.]+/i) ||
      [])[0] || '';
  if (!github) {
    const ghRel =
      (text.match(/(?:^|\s)(?:www\.)?github\.com\/[A-Za-z0-9\/_\-.]+/i) ||
        [])[0] || '';
    github = ghRel.trim();
  }
  const urlCandidates = Array.from(
    text.matchAll(/https?:\/\/[A-Za-z0-9._~:\/?#\[\]@!$&'()*+,;=%-]+/g)
  ).map((m) => m[0]);
  let website = urlCandidates.find((u) => u !== linkedin && u !== github) || '';

  // Name heuristics
  let fullName = '';
  const nameLine = lines.find((l) => /\b[name]\b/i.test(l)) || top;
  if (nameLine && !/^[A-Za-z]+@[A-Za-z.]+$/.test(nameLine)) {
    const cleaned = nameLine.replace(/^(name\s*[:\-]\s*)/i, '').trim();
    if (cleaned.split(' ').length >= 2) fullName = cleaned;
  }
  if (!fullName && email) {
    const prefix = email
      .split('@')[0]
      .replace(/[._\-]+/g, ' ')
      .trim();
    if (prefix.split(' ').length >= 2) fullName = prefix;
  }
  fullName = fullName.replace(/\s+/g, ' ').trim();
  let firstName = '',
    lastName = '';
  if (fullName) {
    const parts = fullName.split(' ');
    firstName = parts[0] || '';
    lastName = parts.length > 1 ? parts[parts.length - 1] : '';
  }

  // Address-like lines
  const addressLine = lines.find((l) => /\baddress\b/i.test(l)) || '';

  return {
    fullName,
    firstName,
    lastName,
    email,
    phone,
    linkedin: normalizeLinkedInUrl(linkedin),
    github: normalizeGithubUrl(github),
    website: normalizeAbsoluteUrl(website),
    address: addressLine,
  };
}

function valueForField(fieldNameNorm, profile) {
  const s = fieldNameNorm;
  if (/(^| )fullname( |$)|(^| )name( |$)/.test(s))
    return (
      profile.fullName || `${profile.firstName} ${profile.lastName}`.trim()
    );
  if (
    s.includes('firstname') ||
    s.includes('givenname') ||
    s.includes('forename')
  )
    return profile.firstName;
  if (
    s.includes('lastname') ||
    s.includes('surname') ||
    s.includes('familyname')
  )
    return profile.lastName;
  if (s.includes('email')) return profile.email;
  if (s.includes('phone') || s.includes('mobile') || s.includes('cell'))
    return profile.phone;
  if (s.includes('linkedin')) return profile.linkedin;
  if (s.includes('github')) return profile.github;
  if (s.includes('portfolio') || s.includes('website') || s.includes('url'))
    return profile.website || profile.linkedin || profile.github;
  if (s.includes('address') || s.includes('street')) return profile.address;
  if (s.includes('country')) return '';
  if (s.includes('city') || s.includes('town')) return '';
  if (s.includes('state') || s.includes('province') || s.includes('region'))
    return '';
  if (s.includes('postal') || s.includes('zip')) return '';
  return '';
}

function localAnalyze(cvText, jobDescriptionText, formText) {
  const fieldsDetected = detectFormFieldNames(formText);
  const profile = extractFromCv(cvText);
  const fields = [];
  for (const f of fieldsDetected) {
    const val = valueForField(f, profile);
    fields.push({ name: f, value: val, reasoning: 'Local fallback mapping' });
  }
  return {
    fields,
    notes:
      'Local fallback used due to AI API error or quota limits. Edit any fields before filling.',
  };
}

function stripPlaceholders(text) {
  try {
    let t = String(text || '');
    // Remove common placeholder tokens
    t = t.replace(
      /\b(TBD|Lorem ipsum|\[?ADD [^\]]+\]?|\[?INSERT [^\]]+\]?|<[^>]*placeholder[^>]*>)\b/gi,
      ''
    );
    t = t.replace(/\(\s*\)/g, '');
    // Remove code fences
    t = t.replace(/^```[\s\S]*?\n|```$/g, '');
    // Remove markdown headings and emphasis to keep plain text
    t = t.replace(/^\s*#{1,6}\s*/gm, '');
    t = t.replace(/\*\*(.*?)\*\*/g, '$1');
    t = t.replace(/__(.*?)__/g, '$1');
    t = t.replace(/`([^`]+)`/g, '$1');
    // Convert single-asterisk or underscore italics to plain
    t = t.replace(/(^|\W)\*(.*?)\*(?=\W|$)/g, '$1$2');
    t = t.replace(/(^|\W)_(.*?)_(?=\W|$)/g, '$1$2');
    // Trim bullet-only lines
    t = t.replace(/^\s*[-•*]\s*$/gm, '');
    return t.trim();
  } catch (_) {
    return String(text || '');
  }
}

function normalizeHeaderLinks(text) {
  try {
    const lines = String(text || '').split(/\n/);
    if (lines.length === 0) return text;
    const header = lines[0];
    const parts = header.split('|').map((p) => p.trim());
    let changed = false;
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      // Emails: keep plain, strip any https:// or mailto:
      if (/@/.test(p) || isEmail(p)) {
        const cleaned = cleanEmail(p);
        if (cleaned !== p) {
          parts[i] = cleaned;
          changed = true;
        }
        continue;
      }
      if (/linkedin/i.test(p) || /^\/?in\//i.test(p)) {
        const norm = normalizeLinkedInUrl(p);
        if (norm && norm !== p) {
          parts[i] = norm;
          changed = true;
        }
        continue;
      }
      if (/github/i.test(p)) {
        const norm = normalizeGithubUrl(p);
        if (norm && norm !== p) {
          parts[i] = norm;
          changed = true;
        }
        continue;
      }
      if (isDomainLike(p) || /^www\./i.test(p) || /^https?:\/\//i.test(p)) {
        const norm = normalizeAbsoluteUrl(p);
        if (norm && norm !== p) {
          parts[i] = norm;
          changed = true;
        }
      }
    }
    if (changed) {
      lines[0] = parts.join(' | ');
      return lines.join('\n');
    }
    return text;
  } catch (_) {
    return text;
  }
}

function buildResumeFallback(cvText, jobDescriptionText) {
  const profile = extractFromCv(cvText);
  const parts = [];
  if (profile.fullName) parts.push(profile.fullName);
  const contacts = [
    profile.email,
    profile.phone,
    profile.linkedin || profile.github || profile.website,
  ]
    .filter(Boolean)
    .join(' | ');
  if (contacts) parts.push(contacts);
  parts.push('');
  parts.push('Summary');
  parts.push(
    'I bring relevant experience and a track record of delivering results. Please replace this section with your own achievements and metrics.'
  );
  parts.push('');
  parts.push('Skills');
  parts.push('List your most relevant tools, languages, and domains.');
  parts.push('');
  parts.push('Experience');
  parts.push('Company – Title (Dates)');
  parts.push(
    'Impact-driven bullet describing the problem, your action, and the measurable result.'
  );
  parts.push('');
  parts.push('Education');
  parts.push('Institution – Degree');
  return parts.join('\n');
}

function buildCoverFallback(cvText, jobDescriptionText) {
  const profile = extractFromCv(cvText);
  const header = [
    profile.fullName,
    profile.email,
    profile.phone,
    profile.linkedin || profile.github || profile.website,
  ]
    .filter(Boolean)
    .join(' | ');
  return (
    (header ? header + '\n\n' : '') +
    `Dear Hiring Manager,\n\n` +
    `I'm excited to apply for this role. My background aligns with your needs, and I focus on delivering measurable outcomes. ` +
    `Please personalize this letter with concrete examples from your experience.\n\n` +
    `Sincerely,\n${profile.fullName || ''}`
  );
}

async function callOpenAIText({ apiKey, model, system, user }) {
  const body = {
    model: model || 'gpt-5-mini',
    temperature: 0.3,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
  };
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const t = await res.text();
    const err = new Error(`OpenAI API error ${res.status}: ${t}`);
    err.status = res.status;
    throw err;
  }
  const data = await res.json();
  return stripPlaceholders(data?.choices?.[0]?.message?.content || '');
}

// Message handler for analysis requests
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log(
    '[Background] Received message:',
    message?.type,
    message?.payload?.modelId
  );
  if (message && message.type === 'RR_EXTENSION_OPEN_PANEL') {
    (async () => {
      let panelTarget = null;
      try {
        console.log('[Background] RR_EXTENSION_OPEN_PANEL message', {
          reason: message.reason,
          tabId: message.tabId,
          senderTabId: sender?.tab?.id,
          senderWindowId: sender?.tab?.windowId,
        });
        if (typeof message.tabId === 'number') {
          panelTarget = { tabId: message.tabId };
        } else if (sender?.tab?.id != null) {
          panelTarget = { tabId: sender.tab.id };
        } else if (sender?.tab?.windowId != null) {
          panelTarget = { windowId: sender.tab.windowId };
        } else {
          const [activeTab] = await chrome.tabs.query({
            active: true,
            lastFocusedWindow: true,
          });
          if (activeTab?.id != null) {
            panelTarget = { tabId: activeTab.id };
          } else if (activeTab?.windowId != null) {
            panelTarget = { windowId: activeTab.windowId };
          }
        }
        if (!panelTarget) {
          throw new Error('No active tab available to open side panel');
        }
        try {
          await chrome.sidePanel.setOptions({
            path: 'sidepanel.html',
            enabled: true,
          });
        } catch (_) {}
        console.log(
          '[Background] Opening side panel with target:',
          panelTarget
        );
        await chrome.sidePanel.open(panelTarget);
        console.log('[Background] Side panel opened successfully');
        if (
          panelTarget?.tabId != null &&
          chrome?.tabs?.sendMessage &&
          typeof chrome.tabs.sendMessage === 'function'
        ) {
          try {
            await chrome.tabs.sendMessage(panelTarget.tabId, {
              type: 'RR_EXTENSION_OPEN_PANEL_SUCCESS',
            });
          } catch (_) {}
        }
        try {
          await chrome.storage.local.remove('rrGesturePrompt');
        } catch (_) {}
        sendResponse({ ok: true });
      } catch (error) {
        const needsGesture =
          typeof error?.message === 'string' &&
          /user gesture/i.test(error.message);
        if (needsGesture) {
          console.log(
            '[Background] Side panel requires user gesture, will prompt user'
          );
        } else {
          console.warn('[Background] Failed to auto-open side panel:', error);
        }
        if (needsGesture && chrome?.tabs?.sendMessage) {
          try {
            const targetTabId =
              panelTarget?.tabId ||
              (typeof message.tabId === 'number' ? message.tabId : null) ||
              sender?.tab?.id ||
              null;
            if (targetTabId) {
              await chrome.tabs.sendMessage(targetTabId, {
                type: 'RR_EXTENSION_OPEN_PANEL_FAILED',
                reason: 'user_gesture_required',
                jobId: message.jobId || '',
                jobTitle:
                  message.metadata?.jobTitle ||
                  message.metadata?.job_title ||
                  '',
                externalJobUrl:
                  message.externalJobUrl ||
                  message.metadata?.external_job_url ||
                  '',
                metadata: message.metadata || {},
              });
            }
          } catch (notifyError) {
            console.warn(
              '[Background] Failed to notify tab about side panel gesture requirement:',
              notifyError
            );
          }
        }
        sendResponse({
          ok: false,
          error: String(error && error.message ? error.message : error),
        });
      }
    })();
    return true;
  }
  if (message && message.type === 'analyzeForm') {
    // Super Fast mode has been removed - all requests should go through optimized-api.js to the backend
    // This message handler is kept for backwards compatibility but returns an error
    sendResponse({
      ok: false,
      error:
        'This feature has been moved to the backend. Please ensure the extension is using optimized-api.js.',
    });
    return true;
  }

  // New: generate tailored resume
  if (message && message.type === 'generateResume') {
    (async () => {
      try {
        const { cvText, jobDescriptionText } = message.payload || {};
        if (!cvText || !jobDescriptionText) {
          sendResponse({
            ok: false,
            error: 'Please provide CV and job description.',
          });
          return;
        }
        const { openaiApiKey, openaiModel } = await chrome.storage.sync.get([
          'openaiApiKey',
          'openaiModel',
        ]);
        if (!openaiApiKey) {
          sendResponse({
            ok: false,
            error: 'Resume generation is unavailable. Please try again later.',
          });
          return;
        }
        const trimmedCv = trimInput(cvText, 7000);
        const trimmedJd = trimInput(jobDescriptionText, 7000);

        const modelToUse =
          typeof openaiModel === 'string' && openaiModel.trim().length > 0
            ? openaiModel.trim()
            : 'gpt-5-mini';

        const system =
          "You are an expert resume writer. Write like a real human, in a natural voice. Absolutely no placeholders, brackets, or template filler. Do not invent facts; use only the candidate's information. Optimize for ATS without sounding robotic. CRITICAL: NEVER use letter spacing for emphasis (like 'S t r a t e g i c' is WRONG). Write all words normally without spaces between letters. No markdown, no bold, no italic - plain text only.";
        const user = `Candidate CV/Assets\n\n${cvText}\n\nJob Description\n\n${jobDescriptionText}\n\nInstructions: Return only the final resume text. Start with a single header line: Full Name | Email | Phone | Location | Links — include only fields present in the materials and omit any that are missing (do not fabricate). Emails must be plain (no http/https). Any link (LinkedIn, GitHub, website, portfolio) must be an absolute https URL. Then write clear sections (Summary, Skills, Experience, Education, Projects). Use specific tools and measurable outcomes. No markdown or code fences.\n\nAssume you are the applicant and you have to fill that form; please try to answer every question.`;

        const cacheKey = makeCacheKey('genResume', {
          cv: trimmedCv,
          jd: trimmedJd,
          model: modelToUse,
        });
        const cached = await getCached(cacheKey);
        if (cached) {
          sendResponse({ ok: true, text: cached, cached: true });
          return;
        }

        let text = '';
        try {
          const cfg = await getConfig();
          if (cfg.apiBaseUrl) {
            const pBackend = fetch(`${cfg.apiBaseUrl}/v1/generate/resume`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'x-openai-key': openaiApiKey,
              },
              body: JSON.stringify({
                cvText: trimmedCv,
                jobDescriptionText: trimmedJd,
                modelId: modelToUse,
              }),
            }).then(async (r) => {
              if (!r.ok) throw new Error(`Backend ${r.status}`);
              const data = await r.json();
              if (data?.text) return data.text;
              throw new Error('Bad backend shape');
            });
            text = await withTimeout(pBackend, 6000);
          }
        } catch (_) {}

        if (!text) {
          try {
            const p = callOpenAIText({
              apiKey: openaiApiKey,
              model: modelToUse,
              system,
              user,
            });
            text = await withTimeout(p, 8000);
          } catch (e) {
            text = buildResumeFallback(trimmedCv, trimmedJd);
          }
        }
        text = normalizeHeaderLinks(stripPlaceholders(text));
        await setCached(cacheKey, text);
        sendResponse({ ok: true, text });
      } catch (error) {
        sendResponse({
          ok: false,
          error: String(error && error.message ? error.message : error),
        });
      }
    })();
    return true;
  }

  // New: generate tailored cover letter
  if (message && message.type === 'generateCoverLetter') {
    (async () => {
      try {
        const { cvText, jobDescriptionText } = message.payload || {};
        if (!cvText || !jobDescriptionText) {
          sendResponse({
            ok: false,
            error: 'Please provide CV and job description.',
          });
          return;
        }
        const { openaiApiKey, openaiModel } = await chrome.storage.sync.get([
          'openaiApiKey',
          'openaiModel',
        ]);
        if (!openaiApiKey) {
          sendResponse({
            ok: false,
            error:
              'Cover letter generation is unavailable. Please try again later.',
          });
          return;
        }
        const trimmedCv = trimInput(cvText, 7000);
        const trimmedJd = trimInput(jobDescriptionText, 7000);

        const modelToUse =
          typeof openaiModel === 'string' && openaiModel.trim().length > 0
            ? openaiModel.trim()
            : 'gpt-5-mini';

        const system =
          "You are a professional cover letter writer. Write like a real human. Absolutely no placeholders or templated lines. Do not fabricate details; tie claims to the candidate's experience. Keep it specific, confident, and concise. CRITICAL: NEVER use letter spacing for emphasis (like 'S t r a t e g i c' is WRONG). Write all words normally without spaces between letters. No markdown, no bold, no italic - plain text only.";
        const user = `Candidate CV/Assets\n\n${cvText}\n\nJob Description\n\n${jobDescriptionText}\n\nInstructions: Return only the final cover letter text. You may begin with a header line (Full Name | Email | Phone | Location | Links). Emails must be plain (no http/https). Any link must be an absolute https URL. Use a short opening that references the role, 2–3 tight paragraphs linking experience to requirements, and a polite close with availability. No markdown or code fences.\n\nAssume you are the applicant and you have to fill that form; please try to answer every question.`;

        const cacheKey = makeCacheKey('genCover', {
          cv: trimmedCv,
          jd: trimmedJd,
          model: modelToUse,
        });
        const cached = await getCached(cacheKey);
        if (cached) {
          sendResponse({ ok: true, text: cached, cached: true });
          return;
        }

        let text = '';
        try {
          const cfg = await getConfig();
          if (cfg.apiBaseUrl) {
            const pBackend = fetch(`${cfg.apiBaseUrl}/v1/generate/cover`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'x-openai-key': openaiApiKey,
              },
              body: JSON.stringify({
                cvText: trimmedCv,
                jobDescriptionText: trimmedJd,
                modelId: modelToUse,
              }),
            }).then(async (r) => {
              if (!r.ok) throw new Error(`Backend ${r.status}`);
              const data = await r.json();
              if (data?.text) return data.text;
              throw new Error('Bad backend shape');
            });
            text = await withTimeout(pBackend, 6000);
          }
        } catch (_) {}

        if (!text) {
          try {
            const p = callOpenAIText({
              apiKey: openaiApiKey,
              model: modelToUse,
              system,
              user,
            });
            text = await withTimeout(p, 8000);
          } catch (e) {
            text = buildCoverFallback(trimmedCv, trimmedJd);
          }
        }
        text = normalizeHeaderLinks(stripPlaceholders(text));
        await setCached(cacheKey, text);
        sendResponse({ ok: true, text });
      } catch (error) {
        sendResponse({
          ok: false,
          error: String(error && error.message ? error.message : error),
        });
      }
    })();
    return true;
  }
});
