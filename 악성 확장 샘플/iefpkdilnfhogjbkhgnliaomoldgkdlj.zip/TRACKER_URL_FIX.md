# Tracker URL Fix

## Problem

After completing onboarding, the redirect went to:

```
❌ https://jobapai-323731579339.us-south1.run.app/api/tracker
   (404 - Page not found)
```

But the tracker page is at:

```
✅ https://jobapai-323731579339.us-south1.run.app/tracker
```

## Root Cause

The `apiBaseUrl` in `config.json` includes `/api`:

```json
{
  "apiBaseUrl": "https://jobapai-323731579339.us-south1.run.app/api"
}
```

When we appended `/tracker`, it became `/api/tracker` instead of just `/tracker`.

## Solution

Strip the `/api` suffix before appending `/tracker`:

```javascript
let base = (cfg?.apiBaseUrl || '').replace(/\/$/, '');

// Remove /api suffix if present (tracker is at root, not under /api)
if (base.endsWith('/api')) {
  base = base.slice(0, -4);
}

const trackerUrl = `${base}/tracker`;
// Result: https://jobapai-323731579339.us-south1.run.app/tracker ✅
```

## How It Works

### Before:

```
apiBaseUrl: "https://jobapai-323731579339.us-south1.run.app/api"
                                                                ↓
trackerUrl: "https://jobapai-323731579339.us-south1.run.app/api/tracker"
                                                                ❌ 404
```

### After:

```
apiBaseUrl: "https://jobapai-323731579339.us-south1.run.app/api"
                                                                ↓
Remove /api: "https://jobapai-323731579339.us-south1.run.app"
                                                                ↓
trackerUrl: "https://jobapai-323731579339.us-south1.run.app/tracker"
                                                                ✅ Works!
```

## Console Logs

### Before (404):

```
[ProfileSetup] Opening tracker: https://jobapai-323731579339.us-south1.run.app/api/tracker
❌ 404 - Page not found
```

### After (Success):

```
[ProfileSetup] Opening tracker: https://jobapai-323731579339.us-south1.run.app/tracker
✅ Tracker page opens
```

## Testing

1. Complete onboarding (≥30% profile)
2. Click "Finish Setup"
3. Should see in console:
   ```
   [ProfileSetup] Opening tracker: https://jobapai-323731579339.us-south1.run.app/tracker
   ```
4. Tracker page opens in new tab ✅
5. Profile setup window closes ✅

## URL Structure

Your app has two different URL patterns:

### API Endpoints (under `/api`)

```
https://jobapai-323731579339.us-south1.run.app/api/v1/auth/login
https://jobapai-323731579339.us-south1.run.app/api/v1/profile/sync
https://jobapai-323731579339.us-south1.run.app/api/v1/generate/resume
```

### Web Pages (at root)

```
https://jobapai-323731579339.us-south1.run.app/tracker
https://jobapai-323731579339.us-south1.run.app/login
https://jobapai-323731579339.us-south1.run.app/signup
```

The fix ensures we use the correct base URL for each type.

## Alternative Solution

If you want to avoid this issue in the future, you could add a separate config value:

```json
{
  "apiBaseUrl": "https://jobapai-323731579339.us-south1.run.app/api",
  "webBaseUrl": "https://jobapai-323731579339.us-south1.run.app"
}
```

Then use:

```javascript
const trackerUrl = `${cfg.webBaseUrl}/tracker`;
```

But the current solution works fine and doesn't require config changes.
