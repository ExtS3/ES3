# Tracker Page Redirect After Onboarding

## Summary

Updated the onboarding completion flow to properly redirect users to the tracker page when they complete profile setup with ≥30% completeness.

## Changes Made

### Before (Complex Logic)

```javascript
// Check if tracker.html exists, fallback to opening tracker URL
try {
  const trackerUrl = chrome.runtime.getURL('tracker.html');
  const response = await fetch(trackerUrl);
  if (response.ok && !skipped && isComplete) {
    window.location.href = 'tracker.html';
  } else {
    // Tracker.html doesn't exist, open tracker page in new tab
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await resp.json();
    const base = (cfg?.apiBaseUrl || '').replace(/\/$/, '');
    if (base && !skipped && isComplete) {
      chrome.tabs.create({ url: `${base}/tracker` });
    }
    window.location.href = 'sidepanel.html';
  }
} catch (e) {
  window.location.href = 'sidepanel.html';
}
```

**Issues:**

- ❌ Complex nested logic
- ❌ Checks for local `tracker.html` file (doesn't exist)
- ❌ Opens tracker in new tab but also redirects to sidepanel
- ❌ Confusing flow

### After (Simplified)

```javascript
// Redirect to tracker page if complete (>= 30%), otherwise sidepanel
if (!skipped && isComplete) {
  console.log('[ProfileSetup] Redirecting to tracker page...');
  try {
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await resp.json();
    const base = (cfg?.apiBaseUrl || '').replace(/\/$/, '');

    if (base) {
      const trackerUrl = `${base}/tracker`;
      console.log('[ProfileSetup] Opening tracker:', trackerUrl);

      // Open tracker in new tab
      await chrome.tabs.create({ url: trackerUrl });

      // Close the profile setup window after a short delay
      setTimeout(() => {
        window.close();
      }, 500);
    } else {
      console.warn(
        '[ProfileSetup] No API base URL configured, redirecting to sidepanel'
      );
      window.location.href = 'sidepanel.html';
    }
  } catch (e) {
    console.error('[ProfileSetup] Error opening tracker:', e);
    window.location.href = 'sidepanel.html';
  }
} else {
  // Not complete or skipped - go to sidepanel
  console.log('[ProfileSetup] Redirecting to sidepanel...');
  window.location.href = 'sidepanel.html';
}
```

**Benefits:**

- ✅ Simple, clear logic
- ✅ Opens tracker in new tab
- ✅ Closes profile setup window
- ✅ Better logging
- ✅ Proper error handling

## How It Works

### Scenario 1: Onboarding Complete (≥30%)

```
1. User fills out profile (50% completeness)
   → Console: "[ProfileSetup] Profile completeness: 50% (9/18 fields)"

2. User clicks "Finish Setup"
   → Profile saved locally
   → CV text saved (10,292 characters)
   → Onboarding marked complete

3. Redirect logic triggered
   → Console: "[ProfileSetup] Redirecting to tracker page..."
   → Console: "[ProfileSetup] Opening tracker: https://your-backend.com/tracker"

4. Opens tracker in new tab
   → Tracker page opens: https://your-backend.com/tracker

5. Closes profile setup window after 500ms
   → Profile setup window closes automatically
```

### Scenario 2: Onboarding Incomplete (<30%)

```
1. User fills out minimal profile (28% completeness)
   → Console: "[ProfileSetup] Profile completeness: 28% (5/18 fields)"

2. User clicks "Finish Setup"
   → Profile saved locally
   → Onboarding marked incomplete

3. Redirect logic triggered
   → Console: "[ProfileSetup] Redirecting to sidepanel..."

4. Redirects to sidepanel
   → Sidepanel checks onboarding status
   → Redirects back to onboarding (needs ≥30%)
```

### Scenario 3: User Skips Onboarding

```
1. User clicks "Skip for now"
   → Console: "[ProfileSetup] Redirecting to sidepanel..."

2. Redirects to sidepanel
   → Onboarding marked incomplete
   → Will be prompted again on next login
```

## Configuration

The tracker URL is read from `config.json`:

```json
{
  "apiBaseUrl": "https://your-backend.com"
}
```

**Tracker URL:** `https://your-backend.com/tracker`

## Console Logs

### Success Flow:

```
[ProfileSetup] Profile completeness: 50% (9/18 fields)
[ProfileSetup] Profile saved successfully (50% complete, onboarding: complete)
[ProfileSetup] Onboarding complete (50%), redirecting to tracker
[ProfileSetup] Redirecting to tracker page...
[ProfileSetup] Opening tracker: https://your-backend.com/tracker
```

### Incomplete Flow:

```
[ProfileSetup] Profile completeness: 28% (5/18 fields)
[ProfileSetup] Profile saved successfully (28% complete, onboarding: incomplete)
[ProfileSetup] Onboarding incomplete (28%), redirecting to sidepanel
[ProfileSetup] Redirecting to sidepanel...
```

### Error Flow (No API URL):

```
[ProfileSetup] No API base URL configured, redirecting to sidepanel
```

## Testing

### Test Case 1: Complete Onboarding (≥30%)

1. Fill out at least 6 fields (name, email, phone, location, LinkedIn, CV)
2. Click "Finish Setup"
3. Should see: `[ProfileSetup] Opening tracker: https://...`
4. Tracker opens in new tab ✅
5. Profile setup window closes ✅

### Test Case 2: Incomplete Onboarding (<30%)

1. Fill out only 5 fields
2. Click "Finish Setup"
3. Should see: `[ProfileSetup] Redirecting to sidepanel...`
4. Redirects to sidepanel ✅
5. Sidepanel redirects back to onboarding ✅

### Test Case 3: Skip Onboarding

1. Click "Skip for now"
2. Should see: `[ProfileSetup] Redirecting to sidepanel...`
3. Redirects to sidepanel ✅

### Test Case 4: No API URL Configured

1. Remove `apiBaseUrl` from config.json
2. Complete onboarding
3. Should see: `[ProfileSetup] No API base URL configured, redirecting to sidepanel`
4. Redirects to sidepanel (fallback) ✅

## Benefits

### 1. **Clear User Flow** ✅

- Complete onboarding → See tracker immediately
- Incomplete onboarding → Prompted to complete
- Skip onboarding → Can complete later

### 2. **Better UX** ✅

- Opens tracker in new tab (doesn't lose context)
- Closes profile setup automatically
- No confusing redirects

### 3. **Proper Logging** ✅

- Clear console messages at each step
- Easy to debug issues
- Shows exact tracker URL

### 4. **Error Handling** ✅

- Falls back to sidepanel if tracker fails
- Handles missing config gracefully
- Doesn't break if API is down

## Tracker Page Requirements

The backend tracker page should:

1. **Check Authentication**

   - Verify user is logged in
   - Redirect to login if not authenticated

2. **Show Application Tracker**

   - List of job applications
   - Application status
   - Notes and follow-ups

3. **Allow New Applications**
   - Button to start new application
   - Quick apply from tracker

## Future Improvements

1. **Smart Redirect**

   - Remember last page user was on
   - Redirect to that page instead of always tracker

2. **Onboarding Progress Bar**

   - Show "You're 50% complete!"
   - Encourage completing remaining fields

3. **Tracker Preview**

   - Show preview of tracker in profile setup
   - "See where your applications will be tracked"

4. **Deep Linking**
   - Redirect to specific tracker section
   - E.g., `/tracker?view=applications&filter=pending`
