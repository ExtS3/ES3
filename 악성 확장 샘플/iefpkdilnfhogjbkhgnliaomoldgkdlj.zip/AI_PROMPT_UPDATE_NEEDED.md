# AI Prompt Update Required

## Issue

The AI needs to return dropdown answers that match the actual dropdown option text exactly.

## Current Behavior

AI returns generic answers like:

- "No"
- "Male"
- "I am not a protected veteran"

## Required Behavior

AI should return the EXACT text from dropdown options:

- "No, I don't have a disability and have not had one in the past"
- "Male" (if that's the exact option)
- "I am not a protected veteran" (exact match)

## Implementation Location

Update the AI prompt in: `/home/stationone/Desktop/up/ancilia/rrextension/vercel-backend/lib/openai.ts`

## Prompt Addition Needed

Add this instruction to the AI prompt:

```
IMPORTANT FOR DROPDOWN FIELDS:
- When you see a dropdown/select field in the form HTML, extract ALL available options
- Return the answer using the EXACT text from one of the dropdown options
- Do NOT abbreviate or paraphrase dropdown options
- Match the exact casing and punctuation from the dropdown

Examples:
- If dropdown has "No, I don't have a disability", return exactly that
- If dropdown has "Male", return "Male" not "male" or "M"
- If dropdown has "I am not a protected veteran", return exactly that

This ensures the extension can directly match and select the correct option without fuzzy matching.
```

## Frontend Changes Made

The content.js now uses a simple algorithm:

1. Open dropdown
2. Get ALL available options
3. Use findBestOption() algorithm to match
4. Select the best match

This works best when AI returns exact dropdown option text.
