# Privacy Policy

JobAPAI processes text that you paste into the side panel (CV, job description, and application form text) to generate suggestions. The extension:

- Stores your OpenAI API key locally in Chrome Sync storage on your device.
- Sends the pasted text and your key directly to OpenAI for analysis.
- Does not collect, sell, or share your data with third parties beyond the OpenAI API call.
- Does not run analytics or tracking.

You can remove your key at any time from the Options page. Uninstalling the extension removes local data.

If you have questions, contact the developer.
