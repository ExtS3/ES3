# Complete CV Storage: Local + Supabase

## Summary

CV is saved in **two places** for redundancy and accessibility:

1. **Local Storage** (`chrome.storage.local`) - Fast access, offline support
2. **Supabase Database** - Permanent storage, cross-device sync

## Storage Flow

```
User Uploads CV
      ↓
┌─────────────────────────────────────────┐
│  Extract CV Text                        │
│  cvText = "John Doe\nSoftware Engineer" │
└─────────────────────────────────────────┘
      ↓
      ├─────────────────────┬──────────────────────┐
      ↓                     ↓                      ↓
┌──────────────┐   ┌──────────────┐   ┌──────────────────┐
│ Local        │   │ Profile Sync │   │ Supabase         │
│ Storage      │   │ to Backend   │   │ Database         │
│              │   │              │   │                  │
│ userCV: "..."│   │ POST /api/   │   │ user_profiles    │
│              │   │ v1/profile/  │   │ ├─ user_id       │
│ ✅ Instant   │   │ sync         │   │ ├─ full_name     │
│ ✅ Offline   │   │              │   │ ├─ email         │
│              │   │ payload: {   │   │ └─ cv_text: "..." │
│              │   │   cvText     │   │                  │
│              │   │ }            │   │ ✅ Permanent     │
│              │   │              │   │ ✅ Cross-device  │
└──────────────┘   └──────────────┘   └──────────────────┘
```

## Implementation Details

### 1. Profile Setup (Onboarding)

**File:** `profile-setup.js`

#### Save to Local Storage (Line 393-400)

```javascript
// Persist CV for reuse and backend sync later
try {
  console.log(`[ProfileSetup] Saving CV text (${cvText.length} characters)`);
  await chrome.storage.local.set({ userCV: cvText });
  console.log('[ProfileSetup] CV text saved successfully');
} catch (error) {
  console.error('[ProfileSetup] Error saving CV text:', error);
}
```

#### Sync to Supabase (Line 753-779)

```javascript
const payload = {
  profile: {
    full_name: data.fullName,
    email: data.email,
    // ... other fields ...
    cvText: cvText || '', // ✅ CV text sent to backend
    source: data.source || 'manual',
    onboardingComplete: isComplete,
    completenessScore: completeness,
  },
  customAnswers: [ ... ]
};

const syncRes = await fetch(`${base}/v1/profile/sync`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  },
  credentials: 'include',
  body: JSON.stringify(payload),
});
```

### 2. Profile Page

**File:** `profile.js`

#### Load from Local Storage (Line 82)

```javascript
// Store raw CV for re-upload preview/use
if (p.cv_text) {
  await chrome.storage.local.set({ userCV: p.cv_text });
}
```

#### Save to Supabase (Line 197-236)

```javascript
const { userCV } = await chrome.storage.local.get('userCV');

const payload = {
  profile: {
    full_name: profile.essential.fullName,
    email: profile.essential.email,
    // ... other fields ...
    cvText: userCV || '', // ✅ CV text sent to backend
    source: 'manual',
    onboardingComplete: true,
  },
  customAnswers: Object.entries(interviewAnswers).map(([question, answer]) => ({
    question,
    answer,
  })),
};

await fetch(`${base}/api/v1/profile/sync`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  },
  credentials: 'include',
  body: JSON.stringify(payload),
});
```

### 3. Backend API

**File:** `vercel-backend/app/api/v1/profile/sync/route.ts`

#### Save to Database (Line 231-234)

```typescript
const profileData = {
  user_id: user.id,
  full_name: profile.full_name || null,
  email: profile.email || null,
  // ... other fields ...
  cv_text: profile.cvText || profile.cv_text || null, // ✅ Saved to DB
  profile_source: profile.source || 'manual',
  completeness_score: completenessScore,
  onboarding_completed:
    profile.onboardingComplete !== undefined
      ? profile.onboardingComplete
      : true,
};

const { error: profileError } = await supabase
  .from('user_profiles')
  .upsert(profileData, { onConflict: 'user_id' });
```

#### Retrieve from Database (Line 68-72)

```typescript
// Fetch user profile
const { data: profile, error: profileError } = await supabase
  .from('user_profiles')
  .select('*')
  .eq('user_id', user.id)
  .single();

// Returns profile with cv_text field
```

## Database Schema

### Table: `user_profiles`

```sql
CREATE TABLE user_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,

  -- Basic Info
  full_name TEXT,
  email TEXT,
  phone TEXT,
  location TEXT,

  -- CV Text (IMPORTANT!)
  cv_text TEXT, -- ✅ Stores full CV text

  -- Other fields...
  linkedin_url TEXT,
  portfolio_url TEXT,
  github_url TEXT,
  work_authorization TEXT,
  security_clearance TEXT,
  professional_summary TEXT,
  current_job_title TEXT,
  years_total_experience INTEGER,

  -- Metadata
  profile_source TEXT DEFAULT 'manual',
  completeness_score INTEGER DEFAULT 0,
  onboarding_completed BOOLEAN DEFAULT false,
  onboarding_completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),

  UNIQUE(user_id)
);
```

## Data Flow Examples

### Example 1: First Upload (Onboarding)

```
1. User uploads CV.pdf
   → Extract text: "John Doe\nSoftware Engineer\n..."
   → cvText = "John Doe\nSoftware Engineer\n..." (10,292 chars)

2. Save to Local Storage
   → chrome.storage.local.set({ userCV: cvText })
   → Console: "[ProfileSetup] Saving CV text (10292 characters)"
   → Console: "[ProfileSetup] CV text saved successfully"
   → ✅ Saved locally

3. Sync to Supabase
   → POST /api/v1/profile/sync
   → payload.profile.cvText = cvText
   → Console: "[ProfileSetup] Syncing profile to database..."
   → Backend: INSERT INTO user_profiles (cv_text) VALUES (cvText)
   → Console: "[ProfileSetup] Profile synced to database"
   → ✅ Saved to Supabase

4. Result
   → Local: chrome.storage.local.userCV = "John Doe\n..." ✅
   → Database: user_profiles.cv_text = "John Doe\n..." ✅
```

### Example 2: Update from Profile Page

```
1. User edits profile
   → Loads existing CV from local storage
   → { userCV } = await chrome.storage.local.get('userCV')

2. User clicks "Save Profile"
   → Collects all profile data
   → Includes CV text from storage

3. Sync to Supabase
   → POST /api/v1/profile/sync
   → payload.profile.cvText = userCV
   → Backend: UPDATE user_profiles SET cv_text = userCV WHERE user_id = ...
   → ✅ Updated in Supabase

4. Result
   → Local: Still has CV ✅
   → Database: Updated with latest CV ✅
```

### Example 3: Load on New Device

```
1. User logs in on new device
   → No local storage yet

2. Sidepanel loads
   → Calls GET /api/v1/profile/sync
   → Backend: SELECT * FROM user_profiles WHERE user_id = ...
   → Returns profile with cv_text

3. Profile loads
   → Saves cv_text to local storage
   → chrome.storage.local.set({ userCV: profile.cv_text })
   → ✅ Now available locally

4. Result
   → Local: CV loaded from database ✅
   → Database: CV already there ✅
```

## Benefits of Dual Storage

### Local Storage (`chrome.storage.local`)

**Pros:**

- ✅ **Instant access** - No network delay
- ✅ **Offline support** - Works without internet
- ✅ **Fast loading** - Immediate availability
- ✅ **Reduced API calls** - Less bandwidth usage

**Cons:**

- ❌ **Device-specific** - Not synced across devices
- ❌ **Can be cleared** - User can clear extension data
- ❌ **Limited to 10MB** - Chrome storage quota

### Supabase Database

**Pros:**

- ✅ **Permanent storage** - Never lost
- ✅ **Cross-device sync** - Available everywhere
- ✅ **Backup** - Safe from local data loss
- ✅ **Unlimited size** - No storage limits

**Cons:**

- ❌ **Network required** - Needs internet
- ❌ **Slower access** - API call latency
- ❌ **API costs** - Database queries cost money

### Best of Both Worlds ✅

By using **both**, we get:

- Fast local access for immediate use
- Permanent cloud backup for safety
- Cross-device sync when needed
- Offline support when no internet

## Console Logs

### Successful Save (Both):

```
[ProfileSetup] Saving CV text (10292 characters)
[ProfileSetup] CV text saved successfully
[ProfileSetup] Syncing profile to database...
[ProfileSetup] Profile synced to database with onboarding completed
✅ CV saved locally and to Supabase
```

### Local Save Only (Network Error):

```
[ProfileSetup] Saving CV text (10292 characters)
[ProfileSetup] CV text saved successfully
[ProfileSetup] Syncing profile to database...
[ProfileSetup] Database sync failed: 500 {"error":"..."}
⚠️ CV saved locally, will retry sync later
```

### Load from Database:

```
[Profile] Loading profile from backend...
[Profile] Profile loaded successfully
[Profile] Saving CV to local storage (10292 characters)
✅ CV loaded from Supabase and cached locally
```

## Verification

### Check Local Storage:

```javascript
// Open DevTools Console
chrome.storage.local.get(['userCV'], (result) => {
  console.log('Local CV:', result.userCV ? 'Yes' : 'No');
  console.log('Local CV length:', result.userCV?.length);
  console.log('Local CV preview:', result.userCV?.substring(0, 100));
});
```

Expected output:

```
Local CV: Yes
Local CV length: 10292
Local CV preview: John Doe
Software Engineer
john.doe@email.com | (555) 123-4567

PROFESSIONAL SUMMARY
Experienced...
```

### Check Supabase Database:

```sql
-- Run in Supabase SQL Editor
SELECT
  user_id,
  full_name,
  email,
  LENGTH(cv_text) as cv_length,
  SUBSTRING(cv_text, 1, 100) as cv_preview,
  onboarding_completed,
  completeness_score,
  updated_at
FROM user_profiles
WHERE user_id = 'your-user-id';
```

Expected output:

```
user_id: abc-123-def-456
full_name: John Doe
email: john.doe@email.com
cv_length: 10292
cv_preview: John Doe
Software Engineer
john.doe@email.com | (555) 123-4567

PROFESSIONAL SUMMARY
Experienced...
onboarding_completed: true
completeness_score: 50
updated_at: 2025-01-15 10:30:00
```

## Error Handling

### Scenario 1: Local Save Fails

```javascript
try {
  await chrome.storage.local.set({ userCV: cvText });
} catch (error) {
  console.error('[ProfileSetup] Error saving CV text:', error);
  // Still continues to sync to Supabase
}
```

**Result:** CV saved to Supabase, can be loaded later ✅

### Scenario 2: Supabase Sync Fails

```javascript
try {
  await fetch(`${base}/v1/profile/sync`, { ... });
} catch (e) {
  console.error('[ProfileSetup] Sync error:', e);
  // CV already saved locally
}
```

**Result:** CV saved locally, will retry sync on next save ✅

### Scenario 3: Both Fail

```javascript
// Local save fails
// Supabase sync fails
// User sees error message
alert('Error saving profile. Please try again.');
```

**Result:** User prompted to retry ⚠️

## Future Improvements

1. **Retry Logic**

   - Auto-retry Supabase sync if it fails
   - Queue failed syncs for later
   - Background sync when online

2. **Conflict Resolution**

   - Detect if local and remote CV differ
   - Ask user which to keep
   - Merge changes intelligently

3. **Version History**

   - Keep last 5 CV versions in Supabase
   - Allow rollback to previous version
   - Show diff between versions

4. **Compression**

   - Compress CV text before storing
   - Save storage space
   - Faster uploads/downloads

5. **Encryption**
   - Encrypt CV text in database
   - Decrypt only when needed
   - Enhanced privacy

## Summary

✅ **CV is saved in TWO places:**

1. **Local Storage** - Fast, offline, instant access
2. **Supabase Database** - Permanent, cross-device, backed up

✅ **Automatic Sync:**

- Upload on profile page → Saved locally + Supabase
- Upload during onboarding → Saved locally + Supabase
- Edit profile → Updated locally + Supabase

✅ **Redundancy:**

- If local is lost → Load from Supabase
- If Supabase fails → Still have local copy
- Best of both worlds!

The CV storage system is **robust, reliable, and redundant**! 🎉
