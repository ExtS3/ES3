# Force GPT-5 Mini for Resume & Cover Letter Generation ✅

## Problem

Resume and cover letter were using whatever model the user selected in the dropdown (Grok, Claude, Gemini, etc.) instead of **always using GPT-5 Mini**.

## Root Cause

The backend functions `generateResumeText()` and `generateCoverText()` were respecting the `modelId` parameter passed from the frontend, which came from the user's dropdown selection.

**Before (Lines 158-179 and 222-241):**

```typescript
export async function generateResumeText(..., modelId?: string) {
  const ui = String(modelId || 'gpt-5-mini').trim().toLowerCase();

  if (ui.startsWith('gemini-')) {
    return geminiText(...);  // Used Gemini if selected
  }
  if (ui.startsWith('claude-')) {
    return claudeText(...);  // Used Claude if selected
  }
  if (ui.startsWith('grok-')) {
    return grokText(...);    // Used Grok if selected ❌
  }

  return callOpenAIText(..., preferredModel: 'gpt-5-mini');
}
```

**Problem:** If user selected "Grok" or "Claude" from dropdown, it would use that model instead of GPT-5 Mini!

## Solution Applied

Modified both functions to **ignore the `modelId` parameter** and **always use GPT-5 Mini**.

### 1. Updated `generateResumeText()`

**File:** `vercel-backend/lib/openai.ts` (Lines 152-170)

**After:**

```typescript
export async function generateResumeText(
  apiKey: string,
  cvText: string,
  jobDescriptionText: string,
  modelId?: string // ← Parameter still accepted but IGNORED
) {
  // ALWAYS use GPT-5 Mini for resume generation (ignore modelId parameter)
  console.log('[OpenAI] Generating resume with GPT-5 Mini (forced)');

  const system = '...resume writer prompt...';
  const user = '...resume template...';

  // Force GPT-5 Mini - ignore any other model selection
  return callOpenAIText({ apiKey, system, user, preferredModel: 'gpt-5-mini' });
}
```

**Key Changes:**

- ✅ Removed all `if (ui.startsWith(...))` checks
- ✅ Directly call `callOpenAIText` with `preferredModel: 'gpt-5-mini'`
- ✅ Added console.log for debugging
- ✅ Comment explaining forced behavior

### 2. Updated `generateCoverText()`

**File:** `vercel-backend/lib/openai.ts` (Lines 172-217)

**After:**

```typescript
export async function generateCoverText(
  apiKey: string,
  cvText: string,
  jobDescriptionText: string,
  modelId?: string // ← Parameter still accepted but IGNORED
) {
  // ALWAYS use GPT-5 Mini for cover letter generation (ignore modelId parameter)
  console.log('[OpenAI] Generating cover letter with GPT-5 Mini (forced)');

  const system = '...cover letter writer prompt...';
  const user = '...cover letter template...';

  // Force GPT-5 Mini - ignore any other model selection
  return callOpenAIText({ apiKey, system, user, preferredModel: 'gpt-5-mini' });
}
```

**Key Changes:**

- ✅ Removed all model routing logic (`gemini`, `claude`, `grok` checks)
- ✅ Directly call `callOpenAIText` with `preferredModel: 'gpt-5-mini'`
- ✅ Added console.log for debugging
- ✅ Comment explaining forced behavior

## Behavior Now

### Before Fix:

```
User selects "Grok" from dropdown
  ↓
Click "Generate Resume"
  ↓
Backend receives modelId = "grok-2"
  ↓
generateResumeText() uses Grok ❌
  ↓
Resume generated with Grok
```

### After Fix:

```
User selects ANY MODEL from dropdown
  ↓
Click "Generate Resume" or "Generate Cover Letter"
  ↓
Backend receives modelId = "grok-2" (or any model)
  ↓
generateResumeText() IGNORES modelId ✅
  ↓
ALWAYS uses GPT-5 Mini ✅
  ↓
Console: "[OpenAI] Generating resume with GPT-5 Mini (forced)"
```

## Why This Approach?

**Option 1 (Rejected):** Remove model dropdown for documents

- ❌ Would require frontend changes
- ❌ Might confuse users (dropdown disappears)

**Option 2 (Chosen):** Backend forces GPT-5 Mini

- ✅ No frontend changes needed
- ✅ Works immediately
- ✅ User can still select any model for form autofill
- ✅ Documents always use GPT-5 Mini regardless of selection

## What Still Uses Selected Model?

The model dropdown **still controls** these operations:

- ✅ Form Analysis (`analyzeForm`) - Uses selected model
- ✅ Job Description Scanning - Uses selected model
- ✅ Resume Extraction - Uses selected model

**Only forced to GPT-5 Mini:**

- ✅ Resume Generation (`generateResumeText`)
- ✅ Cover Letter Generation (`generateCoverText`)

## Testing

### Test 1: Resume Generation

```
1. Open extension sidepanel
2. Select "Grok" from AI model dropdown
3. Fill CV and Job Description
4. Click "Generate Resume"
5. Check backend logs: "[OpenAI] Generating resume with GPT-5 Mini (forced)"
6. Verify: Resume generated successfully
```

### Test 2: Cover Letter Generation

```
1. Open extension sidepanel
2. Select "Claude" from AI model dropdown
3. Fill CV and Job Description
4. Click "Generate Cover Letter"
5. Check backend logs: "[OpenAI] Generating cover letter with GPT-5 Mini (forced)"
6. Verify: Cover letter generated successfully
```

### Test 3: Form Autofill (Should Use Selected Model)

```
1. Select "Gemini" from dropdown
2. Scan job form
3. Check logs: Should use Gemini (NOT forced to GPT-5 Mini)
4. Verify: Form analysis uses Gemini as expected
```

## Console Logs

### Backend (Vercel Logs)

**Resume Generation:**

```
[OpenAI] Generating resume with GPT-5 Mini (forced)
[OpenAI] Calling OpenAI API with model: gpt-5-mini
```

**Cover Letter Generation:**

```
[OpenAI] Generating cover letter with GPT-5 Mini (forced)
[OpenAI] Calling OpenAI API with model: gpt-5-mini
```

## Benefits

### ✅ **Quality Control**

- Resume and cover letter always use best model (GPT-5 Mini)
- Consistent quality across all generations
- No risk of poor quality from experimental models

### ✅ **Cost Control**

- GPT-5 Mini is cost-effective
- Prevents expensive model usage for documents
- Predictable pricing

### ✅ **User Experience**

- No confusion about which model to select
- Works regardless of dropdown selection
- Professional output guaranteed

## Important Note

The `modelId` parameter is **still accepted** by both functions for backward compatibility, but it's **silently ignored**. This ensures:

- ✅ No breaking changes to API contracts
- ✅ Frontend doesn't need updates
- ✅ Other code calling these functions still works

## Files Modified

1. ✅ **`vercel-backend/lib/openai.ts`** (Lines 152-217)

   - `generateResumeText()` - Force GPT-5 Mini
   - `generateCoverText()` - Force GPT-5 Mini
   - Removed model routing logic
   - Added logging for debugging

2. ✅ **`FORCE_GPT5_MINI_FOR_DOCUMENTS.md`** - This documentation

## Deployment

After deploying this change to Vercel:

1. ✅ Resume generation will always use GPT-5 Mini
2. ✅ Cover letter generation will always use GPT-5 Mini
3. ✅ Form autofill will continue using selected model
4. ✅ No frontend changes required
5. ✅ Works immediately for all users

## Summary

✅ **Problem:** Resume/cover letter using Grok or other models instead of GPT-5 Mini  
✅ **Fix:** Backend now ignores modelId and always uses GPT-5 Mini  
✅ **Impact:** High-quality, consistent resume and cover letters  
✅ **Breaking Changes:** None (backward compatible)

**Status: FIXED** 🎉

Both resume and cover letter generation now **always use GPT-5 Mini** regardless of the user's model selection in the dropdown!





