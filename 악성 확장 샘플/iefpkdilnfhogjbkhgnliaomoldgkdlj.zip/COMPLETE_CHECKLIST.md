# ✅ Complete Migration & Integration Checklist

## 📋 Overview

This checklist guides you through:

1. **Supabase → Google Cloud Migration** (~2-3 hours)
2. **Reverse Recruiting Integration** (~1-2 hours)

---

## Part 1: Google Cloud Migration

### Phase 1: Infrastructure Setup (30 min)

- [ ] **1.1 Enable Google Cloud APIs**

  ```bash
  gcloud config set project YOUR_PROJECT_ID
  gcloud services enable sqladmin.googleapis.com identitytoolkit.googleapis.com storage.googleapis.com secretmanager.googleapis.com
  ```

- [ ] **1.2 Create Cloud SQL Instance**

  ```bash
  gcloud sql instances create jobapai-db \
    --database-version=POSTGRES_15 \
    --tier=db-f1-micro \
    --region=us-south1 \
    --root-password=$(openssl rand -base64 32)

  gcloud sql databases create jobapai --instance=jobapai-db

  APP_PASSWORD=$(openssl rand -base64 32)
  gcloud sql users create jobapai-app --instance=jobapai-db --password=$APP_PASSWORD
  ```

- [ ] **1.3 Create Cloud Storage Bucket**

  ```bash
  gsutil mb -l us-south1 gs://jobapai-user-files
  gsutil cors set cors.json gs://jobapai-user-files
  ```

  _(See GCP_SETUP_COMMANDS.md for cors.json)_

- [ ] **1.4 Store Database Password in Secrets**
  ```bash
  echo -n "$APP_PASSWORD" | gcloud secrets create db-password --data-file=-
  ```

---

### Phase 2: Database Schema Migration (15 min)

- [ ] **2.1 Install Cloud SQL Proxy**

  ```bash
  curl -o cloud-sql-proxy https://storage.googleapis.com/cloud-sql-connectors/cloud-sql-proxy/v2.8.0/cloud-sql-proxy.linux.amd64
  chmod +x cloud-sql-proxy
  sudo mv cloud-sql-proxy /usr/local/bin/
  ```

- [ ] **2.2 Start Proxy & Connect**

  ```bash
  # Get connection name
  CONNECTION_NAME=$(gcloud sql instances describe jobapai-db --format="value(connectionName)")

  # Start proxy (keep running)
  cloud-sql-proxy $CONNECTION_NAME &

  # Connect
  psql "host=127.0.0.1 port=5432 dbname=jobapai user=jobapai-app password=$APP_PASSWORD"
  ```

- [ ] **2.3 Run Schema Files**

  ```sql
  \i vercel-backend/user_profiles.sql
  \i vercel-backend/tracker.sql
  \i vercel-backend/supabase.sql
  \i vercel-backend/verify_supabase_setup.sql
  ```

- [ ] **2.4 Verify Tables Created**
  ```sql
  SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';
  -- Should see: user_profiles, custom_answers, employment_history, field_mappings, trial_counters, application_logs
  ```

---

### Phase 3: Firebase Auth Setup (20 min)

- [ ] **3.1 Enable Identity Platform**

  - Go to https://console.cloud.google.com/customer-identity
  - Click "Enable"
  - Or via CLI: `gcloud identity toolkit-config update --enable-email-password`

- [ ] **3.2 Configure Auth Providers**

  - Go to https://console.firebase.google.com → Authentication → Sign-in method
  - Enable **Email/Password**
  - Enable **Google** (optional)

- [ ] **3.3 Add Authorized Domains**

  - In Firebase Console → Authentication → Settings → Authorized domains
  - Add:
    - `localhost`
    - `127.0.0.1`
    - Your Cloud Run domain (e.g., `jobapai-*.run.app`)

- [ ] **3.4 Get Firebase Config**
  ```bash
  npm install -g firebase-tools
  firebase login
  firebase apps:create web jobapai-extension --project=YOUR_PROJECT
  firebase apps:sdkconfig web --project=YOUR_PROJECT
  ```
- [ ] **3.5 Update `firebase-auth.js`**
  - Copy Firebase config from previous step
  - Replace placeholder values in `firebase-auth.js` lines 8-14

---

### Phase 4: Backend Code Update (30 min)

- [ ] **4.1 Update Dependencies**

  ```bash
  cd vercel-backend
  npm install
  # Verify package.json has: firebase-admin, pg, @google-cloud/storage
  ```

- [ ] **4.2 Update Connection String in db.ts**

  - Edit `vercel-backend/lib/db.ts` line 11
  - Replace `YOUR_PROJECT` with your actual project ID
  - Format: `/cloudsql/YOUR_PROJECT:us-south1:jobapai-db`

- [ ] **4.3 Grant IAM Permissions**

  ```bash
  SERVICE_ACCOUNT=$(gcloud run services describe jobapai --region=us-south1 --format="value(spec.template.spec.serviceAccountName)")

  # Cloud SQL access
  gcloud projects add-iam-policy-binding YOUR_PROJECT \
    --member="serviceAccount:$SERVICE_ACCOUNT" \
    --role="roles/cloudsql.client"

  # Secret access
  gcloud secrets add-iam-policy-binding db-password \
    --member="serviceAccount:$SERVICE_ACCOUNT" \
    --role="roles/secretmanager.secretAccessor"

  # Storage access
  gsutil iam ch serviceAccount:$SERVICE_ACCOUNT:objectAdmin gs://jobapai-user-files
  ```

- [ ] **4.4 Build Backend**
  ```bash
  npm run build
  # Should complete without errors
  ```

---

### Phase 5: Deploy to Cloud Run (20 min)

- [ ] **5.1 Update Environment Variables**

  ```bash
  CONNECTION_NAME=$(gcloud sql instances describe jobapai-db --format="value(connectionName)")

  gcloud run services update jobapai \
    --region=us-south1 \
    --add-cloudsql-instances=$CONNECTION_NAME \
    --set-env-vars="DB_HOST=/cloudsql/$CONNECTION_NAME" \
    --set-env-vars="DB_USER=jobapai-app" \
    --set-env-vars="DB_NAME=jobapai" \
    --set-env-vars="DB_PORT=5432" \
    --set-env-vars="GOOGLE_CLOUD_PROJECT=YOUR_PROJECT" \
    --set-env-vars="STORAGE_BUCKET=jobapai-user-files" \
    --update-secrets=DB_PASSWORD=db-password:latest
  ```

- [ ] **5.2 Deploy Backend**

  ```bash
  cd vercel-backend
  gcloud run deploy jobapai \
    --source . \
    --region=us-south1 \
    --platform=managed \
    --allow-unauthenticated \
    --add-cloudsql-instances=$CONNECTION_NAME
  ```

- [ ] **5.3 Test Health Endpoint**
  ```bash
  CLOUD_RUN_URL=$(gcloud run services describe jobapai --region=us-south1 --format="value(status.url)")
  curl $CLOUD_RUN_URL/api/health
  # Should return 200 OK
  ```

---

### Phase 6: Frontend Update (30 min)

- [ ] **6.1 Update HTML Files**
      Replace Supabase script tags with Firebase in:

  - `signup.html`
  - `login.html`
  - `profile-setup.html`
  - `profile.html`

  **Remove:**

  ```html
  <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
  <script src="supabase-global.js"></script>
  ```

  **Add:**

  ```html
  <script type="module" src="firebase-auth.js"></script>
  ```

- [ ] **6.2 Update Auth Calls**

  **In `signup.js`:**

  ```javascript
  // OLD
  import { supabase } from './supabase-global.js';
  const { data, error } = await supabase.auth.signUp({ email, password });

  // NEW
  import { signUpWithEmail } from './firebase-auth.js';
  const { user, session, error } = await signUpWithEmail(email, password);
  ```

  **In `login.js`:**

  ```javascript
  // OLD
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  // NEW
  import { signInWithEmail } from './firebase-auth.js';
  const { user, session, error } = await signInWithEmail(email, password);
  ```

  **In `profile-sync.js` and `profile-setup.js`:**

  ```javascript
  // OLD
  const { supabaseSession } = await chrome.storage.sync.get([
    'supabaseSession',
  ]);
  const token = supabaseSession?.access_token;

  // NEW
  const { firebaseSession } = await chrome.storage.sync.get([
    'firebaseSession',
  ]);
  const token = firebaseSession?.access_token;
  ```

- [ ] **6.3 Delete Old Supabase File**

  ```bash
  rm supabase-global.js
  ```

- [ ] **6.4 Update config.json**
  - Ensure `apiBaseUrl` points to your Cloud Run URL
  - Remove any Supabase-specific config

---

### Phase 7: Testing (30 min)

- [ ] **7.1 Test Signup**

  - Load extension in Chrome
  - Go to signup page
  - Create new account
  - Check Firebase Console → Authentication → Users (should see new user)

- [ ] **7.2 Test Login**

  - Log out
  - Log back in with same credentials
  - Should redirect to tracker/sidepanel

- [ ] **7.3 Test Profile Sync**

  - Complete onboarding flow
  - Fill out profile fields
  - Check Cloud SQL:
    ```sql
    SELECT * FROM user_profiles WHERE email = 'your-test-email@example.com';
    ```

- [ ] **7.4 Test Custom Answers**

  - Fill interview questions on profile page
  - Save
  - Check database:
    ```sql
    SELECT * FROM custom_answers WHERE user_id = 'your-user-id';
    ```

- [ ] **7.5 Test CV Upload**

  - Upload CV on profile page
  - Verify `cv_text` saved in database
  - Check Cloud Storage bucket for any uploaded files

- [ ] **7.6 Test Job Application**
  - Go to a job site (e.g., LinkedIn, Greenhouse)
  - Click extension icon
  - Scan form
  - Generate resume
  - Verify resume downloads correctly

---

## Part 2: Reverse Recruiting Integration

### Phase 8: Extension Listener Setup (20 min)

- [ ] **8.1 Add External Message Listener**

  In `background.js`, add:

  ```javascript
  // Listen for messages from Reverse Recruiting platform
  chrome.runtime.onMessageExternal.addListener(
    async (request, sender, sendResponse) => {
      if (request.type === 'REVERSE_RECRUITING_APPLY') {
        console.log(
          '[Background] Received job application request from Reverse Recruiting'
        );

        // Store auth token
        await chrome.storage.sync.set({
          firebaseSession: {
            access_token: request.token,
          },
        });

        // Store job and profile data
        await chrome.storage.local.set({
          reverseRecruitingJob: request.job,
          userProfile: request.userProfile,
          applicationSettings: request.settings,
          applicationSource: 'reverse-recruiting',
        });

        // Open extension
        await chrome.tabs.create({
          url: chrome.runtime.getURL(
            'sidepanel.html?source=reverse-recruiting'
          ),
        });

        // Send initial status update
        if (request.settings.callback_url) {
          await sendStatusUpdate(request.settings.callback_url, request.token, {
            job_id: request.job.job_id,
            status: 'started',
            timestamp: new Date().toISOString(),
            metadata: {
              extension_version: chrome.runtime.getManifest().version,
              models_used: {
                analysis: 'grok-4-fast-non-reasoning',
                resume: 'gpt-5-mini',
                cover_letter: 'gpt-5-mini',
              },
              duration_ms: { total: 0 },
              user_interactions: {
                manual_edits: 0,
                regenerations: 0,
                field_overrides: 0,
              },
            },
          });
        }

        sendResponse({ success: true });
      }
    }
  );

  async function sendStatusUpdate(callbackUrl, token, update) {
    if (!callbackUrl) return;

    try {
      const res = await fetch(callbackUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(update),
      });

      if (!res.ok) {
        console.error('[Background] Status update failed:', await res.text());
      } else {
        console.log('[Background] Status update sent:', update.status);
      }
    } catch (error) {
      console.error('[Background] Status update error:', error);
    }
  }
  ```

- [ ] **8.2 Update manifest.json for External Messaging**

  Add `externally_connectable` section:

  ```json
  {
    "externally_connectable": {
      "matches": [
        "https://your-reverse-recruiting-domain.com/*",
        "http://localhost:*"
      ]
    }
  }
  ```

- [ ] **8.3 Add Status Update Helpers**

  Create `vercel-backend/lib/status-updates.ts`:

  ```typescript
  export async function sendApplicationStatus(
    callbackUrl: string,
    token: string,
    status: string,
    data: any
  ) {
    // Implementation for sending status updates
  }
  ```

---

### Phase 9: Reverse Recruiting Team Coordination (15 min)

- [ ] **9.1 Share Integration Document**

  - Send `REVERSE_RECRUITING_INTEGRATION.md` to their team
  - Clarify payload structure and API contract

- [ ] **9.2 Exchange Technical Details**

  - [ ] Get their API base URL for callback
  - [ ] Get their domain for `externally_connectable`
  - [ ] Decide on message passing method (`chrome.runtime.sendMessage` recommended)
  - [ ] Confirm auth flow (shared Firebase or separate tokens)

- [ ] **9.3 Set Up Test Environment**
  - [ ] Create test job posting
  - [ ] Generate test payload
  - [ ] Test message passing
  - [ ] Verify callback works

---

### Phase 10: Integration Testing (20 min)

- [ ] **10.1 Test Message Reception**

  ```javascript
  // From Reverse Recruiting console
  chrome.runtime.sendMessage(
    'YOUR_EXTENSION_ID',
    {
      type: 'REVERSE_RECRUITING_APPLY',
      token: 'test-token',
      userProfile: {
        /* test data */
      },
      job: {
        /* test job */
      },
      settings: {
        /* test settings */
      },
    },
    (response) => console.log('Response:', response)
  );
  ```

- [ ] **10.2 Verify Data Storage**

  - Check `chrome.storage.local` for job data
  - Check `chrome.storage.sync` for token

- [ ] **10.3 Test Status Callbacks**

  - Set up mock webhook server
  - Verify status updates are received
  - Check payload structure matches spec

- [ ] **10.4 End-to-End Test**
  - Click "Apply" on Reverse Recruiting platform
  - Extension opens with pre-filled data
  - Generate resume/cover letter
  - Submit application
  - Verify status updates in Reverse Recruiting dashboard

---

## 🎉 Migration Complete!

### Post-Migration Checklist

- [ ] Monitor Cloud Run logs for errors
- [ ] Check Cloud SQL connection count
- [ ] Verify storage bucket has correct permissions
- [ ] Set up billing alerts
- [ ] Document any environment-specific config
- [ ] Update team documentation

### Cost Monitoring

```bash
# Set up budget alert
gcloud billing budgets create \
  --billing-account=YOUR_BILLING_ACCOUNT \
  --display-name="JobAp AI Budget" \
  --budget-amount=30USD \
  --threshold-rule=percent=50 \
  --threshold-rule=percent=90
```

---

## 📚 Reference Documents

1. **MIGRATION_TO_GCP.md** - Detailed migration guide
2. **GCP_SETUP_COMMANDS.md** - All terminal commands
3. **REVERSE_RECRUITING_INTEGRATION.md** - Integration spec
4. **MIGRATION_SUMMARY.md** - High-level overview

---

## 🆘 Troubleshooting

### Database Connection Issues

```bash
# Check Cloud SQL instance is running
gcloud sql instances describe jobapai-db

# Test proxy connection
cloud-sql-proxy YOUR_CONNECTION_NAME &
psql "host=127.0.0.1 port=5432 dbname=jobapai user=jobapai-app"
```

### Auth Issues

```bash
# Verify Firebase config
firebase projects:list
firebase apps:list --project=YOUR_PROJECT

# Check authorized domains
# Go to Firebase Console → Authentication → Settings
```

### Storage Issues

```bash
# Check bucket exists
gsutil ls gs://jobapai-user-files

# Verify CORS
gsutil cors get gs://jobapai-user-files

# Test upload
echo "test" > test.txt
gsutil cp test.txt gs://jobapai-user-files/
```

---

**Questions? Check the reference docs or contact the dev team!**

