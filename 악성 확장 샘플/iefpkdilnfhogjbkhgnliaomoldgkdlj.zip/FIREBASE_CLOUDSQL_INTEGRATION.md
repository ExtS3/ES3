# Firebase Auth ↔ Cloud SQL Integration

## ✅ **YES! They Are Connected**

Here's how the complete flow works:

---

## 🔄 **Google Sign-In → Cloud SQL Flow**

### **Step 1: User Signs In**

```
User clicks "Continue with Google"
  ↓
Chrome Identity API opens Google account picker
  ↓
User selects account and grants permissions
  ↓
Firebase Auth creates/authenticates user
  ↓
Extension receives Firebase ID Token
```

### **Step 2: Profile Creation/Sync**

```
Extension stores Firebase session locally
  ↓
Extension calls: window.JobApAIProfile.syncOnLogin()
  ↓
Makes API request to: /api/v1/profile/sync
  ↓
Backend verifies Firebase ID token
  ↓
Backend creates/updates user_profiles in Cloud SQL
```

### **Step 3: Data Stored in Cloud SQL**

```sql
-- user_profiles table
INSERT INTO user_profiles (
  user_id,          -- Firebase UID (e.g., "abc123xyz")
  email,            -- From Google account
  full_name,        -- From Google profile (if available)
  created_at,       -- Timestamp
  updated_at        -- Timestamp
) VALUES (
  'firebase_uid_here',
  'user@gmail.com',
  'John Doe',
  NOW(),
  NOW()
);
```

---

## 📊 **What Gets Saved to Cloud SQL**

### **On First Google Sign-In:**

**Automatic (from Google account):**

- ✅ `user_id` (Firebase UID)
- ✅ `email` (Google email)
- ✅ `full_name` (Google display name, if available)
- ✅ `created_at` (timestamp)

**Set to defaults:**

- `completeness_score` = 0
- `onboarding_completed` = false
- All other fields = NULL

### **After User Completes Onboarding:**

User fills out profile-setup.html:

- CV upload → `cv_text`
- Contact info → `phone`, `location`, `linkedin_url`, etc.
- Work experience → `employment_history` table
- Interview questions → `custom_answers` table

---

## 🔍 **Backend Verification Flow**

### **File: `vercel-backend/app/api/v1/profile/sync/route.ts`**

```typescript
// 1. Extract Firebase token from request
const authHeader = req.headers.get('authorization');
const token = authHeader.substring(7); // "Bearer <token>"

// 2. Verify token with Firebase Admin SDK
const { user, error } = await verifyIdToken(token);
// Returns: { id: "firebase_uid", email: "user@gmail.com" }

// 3. Query/Insert into Cloud SQL
await query(
  'SELECT * FROM user_profiles WHERE user_id = $1',
  [user.id] // Firebase UID
);

// 4. Create profile if doesn't exist
await query(
  'INSERT INTO user_profiles (user_id, email, ...) VALUES ($1, $2, ...)',
  [user.id, user.email, ...]
);
```

---

## 🧪 **How to Verify It's Working**

### **Method 1: Check Cloud SQL Database**

```bash
# Connect to Cloud SQL
psql "host=127.0.0.1 port=5433 user=jobapai-app dbname=jobapai"

# Check if user was created
SELECT user_id, email, full_name, created_at
FROM user_profiles
ORDER BY created_at DESC
LIMIT 5;
```

### **Method 2: Check Backend Logs**

1. Go to [Cloud Run Logs](https://console.cloud.google.com/run/detail/us-east1/jobapai/logs?project=jobapai)
2. Sign in with Google in your extension
3. Look for logs like:
   ```
   [DB] Query executed { duration: '25ms', rows: 1, command: 'INSERT' }
   [ProfileSync] Profile synced successfully
   ```

### **Method 3: Check Browser Console**

1. Open extension sidepanel
2. Sign in with Google
3. Open DevTools (F12)
4. Look for:
   ```
   [Google OAuth] Profile synced from database
   ```

---

## 📋 **Complete Data Flow**

```
┌─────────────────┐
│  User clicks    │
│ "Sign in with   │
│     Google"     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Chrome Identity │
│  API + Firebase │
│      Auth       │
└────────┬────────┘
         │ Returns Firebase ID Token
         ▼
┌─────────────────┐
│   Extension     │
│  Stores Token   │
│  in Chrome      │
│    Storage      │
└────────┬────────┘
         │ Sends token to backend
         ▼
┌─────────────────┐
│ Backend API:    │
│ /v1/profile/    │
│      sync       │
└────────┬────────┘
         │ Verifies token with Firebase Admin
         ▼
┌─────────────────┐
│ Firebase Admin  │
│   SDK Verifies  │
│      Token      │
└────────┬────────┘
         │ Returns { id: "uid", email: "user@gmail.com" }
         ▼
┌─────────────────┐
│   Cloud SQL     │
│  PostgreSQL     │
│   Database      │
└─────────────────┘
  Stores:
  - user_id (Firebase UID)
  - email
  - full_name
  - profile data
  - employment history
  - custom answers
```

---

## ✅ **Yes, They're Connected!**

### **Firebase Auth provides:**

- User authentication
- ID tokens for API requests
- User email & display name

### **Cloud SQL stores:**

- User profiles
- Employment history
- Interview answers
- Application logs
- All persistent data

### **The Bridge:**

- Backend verifies Firebase tokens
- Backend uses Firebase UID as `user_id` in database
- All API requests require valid Firebase token

---

## 🎯 **Test the Complete Flow**

1. Sign in with Google
2. Complete profile setup
3. Check Cloud SQL:
   ```sql
   SELECT * FROM user_profiles WHERE email = 'your@email.com';
   ```
4. You should see your data! ✅

---

## 🔒 **Security Flow**

```
Extension → Backend: "Bearer <firebase_token>"
             ↓
Backend → Firebase Admin: "Verify this token"
             ↓
Firebase Admin → Backend: "Valid! User ID: abc123"
             ↓
Backend → Cloud SQL: "SELECT WHERE user_id = 'abc123'"
             ↓
Backend → Extension: "Here's your profile data"
```

**Every API request is authenticated with Firebase token!** 🔐

---

**So YES**, Firebase Auth and Cloud SQL are fully integrated. When you sign in with Google, a user record is created in Cloud SQL with your Firebase UID as the primary identifier! 🎉

