# Figma Design Implementation - Onboarding Page

## Design Specifications (Node 9-8851)

This document details the exact Figma design specifications implemented for the onboarding/signup page.

### 📐 Container Dimensions

**Extension Sign Up Frame**

- Width: `420px`
- Height: `696px` (auto-adjusts based on content)
- Background: `#FFFFFF`
- Border: `1px solid #E8E8E8`
- Border Radius: `12px`
- Box Shadow: `0px 4px 6px -2px rgba(16, 24, 40, 0.03), 0px 12px 16px -4px rgba(16, 24, 40, 0.08)`

**Inner Container**

- Width: `388px` (420px - 32px horizontal padding)
- Padding: `32px 0px` (vertical only)
- Gap: `32px` (between major sections)
- Alignment: Centered

**Form Content Container**

- Width: `338px`
- Gap: `16px` (between form sections)
- Alignment: Centered within 388px container

---

## 🎨 Color Palette

### Brand Colors

- **Primary**: `#007D70` (buttons, focus states)
- **Hover**: `#006b61` (button hover)
- **Light**: `#E9FFF8` (checkbox selected bg)
- **Accent**: `#92FDCF` (logo accent)

### Text Colors

- **Primary**: `#282828` (headings, labels, input text)
- **Secondary**: `#727272` (placeholders, help text)
- **Muted**: `#868686` (helper text)
- **Divider Text**: `#1C1C1C` ("or" text)

### Borders

- **Default**: `#E8E8E8` (outer border, divider lines)
- **Strong**: `#DDDDDD` (input borders, button borders)
- **Focus**: `#007D70` (input focus)

---

## 📏 Typography

### Font Family

- **All Text**: `Montserrat`

### Logo Section

- **Logo Image**: `32px` height
- **Logo Text**:
  - Size: `19.63px`
  - Weight: `400`
  - Line Height: `1.22`
  - Color: `#282828`

### Body Text

- **Body-3/Regular** (inputs, toggle text):

  - Size: `14px`
  - Weight: `400`
  - Line Height: `1.43` (20px)

- **Body-3/Medium** (buttons):

  - Size: `14px`
  - Weight: `500`
  - Line Height: `1.43` (20px)

- **Body-4/Regular** (helper text, terms):
  - Size: `12px`
  - Weight: `400`
  - Line Height: `1.33` (16px)

---

## 📦 Component Specifications

### Header Section

- **Total Width**: `388px`
- **Container Gap**: `16px` (between logo and auth toggle)
- **Logo Container Gap**: `8px` (between logo image and text)
- **Margin Bottom**: `32px`

**Auth Toggle Text**

- Text: "Already have an account? Log in"
- Font Size: `14px`
- Color: `#727272`
- Text Align: Center

---

### Google Sign-In Button

- **Width**: `338px`
- **Height**: `44px`
- **Padding**: `8px 16px`
- **Gap**: `16px` (icon to text)
- **Border**: `1px solid #DDDDDD`
- **Border Radius**: `10px`
- **Background**: `#FFFFFF`
- **Margin Bottom**: `16px`

**Google Icon**

- Size: `18px × 18px`
- Border Radius: `99px`

---

### Divider ("or")

- **Width**: `338px`
- **Height**: `20px`
- **Gap**: `8px` (between lines and text)
- **Margin**: `16px 0`

**Lines**

- Height: `1px`
- Color: `#E8E8E8`
- Flex: `1` (equal width)

**Text**

- Content: "or"
- Font Size: `14px`
- Color: `#1C1C1C`

---

### Form Structure

**Form Container** (`auth-form`)

- Width: `338px`
- Gap: `24px` (between major sections)

**Major Sections**:

1. **Fields Group** (`form-fields-group`)
   - Gap: `16px` (between individual fields)
2. **Checkbox** (`checkbox-container`)
   - No additional spacing
3. **Submit Container** (`submit-container`)
   - Gap: `8px` (button to terms text)

---

### Input Fields

**Field Container** (`form-field`)

- Width: `338px`
- Gap: `8px` (between input and helper/error text)

**Input Style** (`form-input`)

- Width: `100%`
- Height: `44px`
- Padding: `12px 16px`
- Border: `1px solid #DDDDDD`
- Border Radius: `10px`
- Background: `#FFFFFF`
- Font Size: `14px`
- Color: `#282828`
- Placeholder Color: `#727272`

**Focus State**

- Border Color: `#007D70`
- Background: `#FFFFFF`

**Password Field**

- Password Input: `padding-right: 48px` (space for toggle icon)
- Toggle Icon: `20px × 20px`, positioned `16px` from right

---

### Helper & Error Text

**Helper Text** (`field-helper`)

- Font Size: `12px`
- Color: `#868686`
- Line Height: `1.33`
- Text: "Use 8+ characters with mixed case and numbers."

**Error Text** (`field-error`)

- Font Size: `12px`
- Color: `#F83446`
- Line Height: `1.33`

---

### Checkbox

**Checkbox Container**

- Display: Flex, row
- Gap: `8px`
- Align Items: Center

**Checkbox Custom** (`checkbox-custom`)

- Size: `20px × 20px`
- Border: `1px solid #DDDDDD`
- Border Radius: `6px`
- Background: `#FFFFFF`

**Checked State**

- Background: `#E9FFF8`
- Border Color: `#007D70`
- Checkmark: 14px × 14px icon

**Label Text**

- Font Size: `12px`
- Color: `#282828`
- Text: "Send me updates and offers (optional)"

---

### Submit Button

**Button** (`submit-btn`)

- Width: `338px`
- Height: `44px`
- Padding: `8px 16px`
- Gap: `8px` (icon to text, if any)
- Background: `#007D70`
- Border: None
- Border Radius: `10px`
- Font Size: `14px`
- Font Weight: `500`
- Color: `#FFFFFF`

**Button Text**

- Content: "Continue with email"
- Line Height: `1.43`

**Hover State**

- Background: `#006b61`
- Box Shadow: `0 2px 8px rgba(0, 125, 112, 0.25)`

**Active State**

- Transform: `scale(0.98)`

**Disabled State**

- Opacity: `0.6`
- Cursor: `not-allowed`

---

### Terms Text

**Terms Container** (`terms-text`)

- Width: `338px`
- Font Size: `12px`
- Font Weight: `400`
- Color: `#727272`
- Text Align: Center
- Line Height: `1.33`

**Text Content**

- "By signing up, you agree to the Terms and Conditions and Privacy Policy"

**Links**

- Color: `#727272`
- Text Decoration: None
- Hover: Underline

---

## 🔄 Layout Hierarchy

```
.onboarding-container (420px, padding 32px 16px)
├── .onboarding-header (388px, gap 16px, mb 32px)
│   ├── .logo-container (gap 8px)
│   │   ├── .logo-image (32px height)
│   │   └── .logo-text (19.63px)
│   └── .auth-toggle (14px)
│
├── .google-btn (338px, mb 16px)
│
├── .divider (338px, margin 16px 0)
│
└── .auth-form (338px, gap 24px)
    ├── .form-fields-group (gap 16px)
    │   ├── .form-field (gap 8px) [Name]
    │   ├── .form-field (gap 8px) [Email]
    │   ├── .form-field (gap 8px) [Password]
    │   └── .forgot-password (optional)
    │
    ├── .checkbox-container (gap 8px)
    │
    └── .submit-container (gap 8px)
        ├── .submit-btn
        └── .terms-text
```

---

## ✨ Spacing Summary

| Element                      | Spacing         | Value            |
| ---------------------------- | --------------- | ---------------- |
| Container vertical padding   | `padding`       | `32px 0`         |
| Container horizontal padding | `padding`       | `16px` each side |
| Header to form               | `margin-bottom` | `32px`           |
| Header internal              | `gap`           | `16px`           |
| Logo container               | `gap`           | `8px`            |
| Google button                | `margin-bottom` | `16px`           |
| Divider                      | `margin`        | `16px 0`         |
| Form major sections          | `gap`           | `24px`           |
| Form fields group            | `gap`           | `16px`           |
| Individual field             | `gap`           | `8px`            |
| Submit container             | `gap`           | `8px`            |
| Checkbox                     | `gap`           | `8px`            |

---

## 📱 Responsive Behavior

**Mobile (< 480px)**

- Container padding reduced to: `24px 16px`
- All widths adjust proportionally
- Max-widths ensure content doesn't overflow

---

## 🎯 Design Tokens (CSS Variables)

```css
:root {
  /* Brand Colors */
  --brand-primary: #007d70;
  --brand-hover: #006b61;
  --brand-light: #e9fff8;
  --brand-border: #92fdcf;

  /* Text Colors */
  --text-primary: #282828;
  --text-secondary: #727272;
  --text-muted: #868686;

  /* Background & Borders */
  --bg-white: #ffffff;
  --bg-soft: #f3f3f3;
  --border-default: #e8e8e8;
  --border-strong: #dddddd;
  --border-focus: #007d70;

  /* Shadow */
  --shadow-sm: 0px 4px 6px -2px rgba(16, 24, 40, 0.03), 0px 12px 16px -4px rgba(16, 24, 40, 0.08);
}
```

---

## 🔍 Implementation Notes

1. **Exact Measurements**: All measurements match Figma specs precisely
2. **Font Family**: Montserrat loaded from Google Fonts
3. **Responsive**: Design adapts gracefully on smaller screens
4. **Accessibility**: Focus states, ARIA labels, proper semantic HTML
5. **Animations**: Smooth transitions (0.2s ease) on hover/active states
6. **Loading States**: Spinner animations for async actions

---

## 📂 Files

- **HTML**: `onboarding.html`
- **CSS**: `onboarding.css`
- **JavaScript**: `onboarding.js`
- **Assets**: `icons/logo.png`

---

**Design Source**: [Figma - JobApAI Design 2025](https://www.figma.com/design/UXb3Fa3pxhkqRJsoXLz2Nz/JobApAI---Design---2025?node-id=9-8851)

**Last Updated**: October 15, 2025


