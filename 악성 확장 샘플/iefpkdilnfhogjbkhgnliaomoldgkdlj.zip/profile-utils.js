/**
 * User Profile Management Utilities for JobApAI
 * Handles profile storage, extraction, and pre-filling
 */

/**
 * Profile schema definition
 */
export const PROFILE_SCHEMA = {
  version: '1.0',

  essential: {
    fullName: '',
    email: '',
    phone: '',
    location: '', // City, State ZIP
    linkedIn: '',
    portfolio: '',
    workAuthorization: '', // "US Citizen", "Need H1B", "Have Work Permit", etc.
    securityClearance: '', // "None", "Secret", "Top Secret", etc.
  },

  preferences: {
    jobTypes: [], // ["Full-Time", "Remote", "Hybrid"]
    preferredIndustries: [],
    expectedSalaryMin: '',
    expectedSalaryMax: '',
    availableStartDate: '',
    willingToRelocate: '',
    overtimeWillingness: '',
    travelWillingness: '',
    remoteSetup: '',
    timezone: '',
  },

  skills: {
    topSkills: [], // Max 10
    certifications: [],
    yearsExperience: {
      total: 0,
      management: 0,
      technical: 0,
    },
    education: {
      highestDegree: '',
      fieldOfStudy: '',
      university: '',
      graduationYear: '',
    },
  },

  commonAnswers: {
    referralSource: '',
    availableForInterview: '',
    noticeRequired: '',
    diversityStatement: '',
    whyThisCompany: '', // Template that can be customized
    strength: '',
    weakness: '',
  },

  professional: {
    summary: '', // 2-3 sentence professional summary
    currentRole: '',
    yearsInCurrentRole: 0,
  },

  metadata: {
    createdAt: 0,
    lastUpdated: 0,
    completeness: 0, // Percentage (0-100)
    source: '', // "manual" or "ai-extracted"
  },
};

/**
 * Get user profile from storage
 */
export async function getUserProfile() {
  try {
    const result = await chrome.storage.local.get('userProfile');
    return result.userProfile || null;
  } catch (e) {
    console.error('[Profile] Error getting profile:', e);
    return null;
  }
}

/**
 * Save user profile to storage
 */
export async function saveUserProfile(profileData) {
  try {
    const profile = {
      ...profileData,
      metadata: {
        ...profileData.metadata,
        lastUpdated: Date.now(),
        completeness: calculateCompleteness(profileData),
      },
    };

    await chrome.storage.local.set({ userProfile: profile });
    console.log(
      '[Profile] Saved successfully. Completeness:',
      profile.metadata.completeness + '%'
    );
    return true;
  } catch (e) {
    console.error('[Profile] Error saving profile:', e);
    return false;
  }
}

/**
 * Update specific section of profile
 */
export async function updateProfileSection(section, data) {
  try {
    const profile = await getUserProfile();
    if (!profile) {
      console.error('[Profile] No existing profile found');
      return false;
    }

    profile[section] = {
      ...profile[section],
      ...data,
    };

    return await saveUserProfile(profile);
  } catch (e) {
    console.error('[Profile] Error updating section:', e);
    return false;
  }
}

/**
 * Calculate profile completeness percentage
 */
function calculateCompleteness(profile) {
  const weights = {
    essential: 40, // Most important
    skills: 25,
    preferences: 15,
    professional: 15,
    commonAnswers: 5,
  };

  let totalScore = 0;

  // Essential fields
  const essentialFields = [
    'fullName',
    'email',
    'phone',
    'location',
    'workAuthorization',
  ];
  const essentialComplete = essentialFields.filter(
    (f) => profile.essential?.[f]
  ).length;
  totalScore +=
    (essentialComplete / essentialFields.length) * weights.essential;

  // Skills
  const hasSkills = profile.skills?.topSkills?.length > 0;
  const hasEducation = profile.skills?.education?.highestDegree;
  const hasExperience = profile.skills?.yearsExperience?.total > 0;
  const skillsScore = (hasSkills + hasEducation + hasExperience) / 3;
  totalScore += skillsScore * weights.skills;

  // Preferences
  const prefFields = ['jobTypes', 'expectedSalaryMin', 'willingToRelocate'];
  const prefComplete = prefFields.filter((f) => {
    const val = profile.preferences?.[f];
    return Array.isArray(val) ? val.length > 0 : !!val;
  }).length;
  totalScore += (prefComplete / prefFields.length) * weights.preferences;

  // Professional
  const hasSummary = profile.professional?.summary?.length > 20;
  const hasCurrentRole = profile.professional?.currentRole;
  const profScore = (hasSummary + hasCurrentRole) / 2;
  totalScore += profScore * weights.professional;

  // Common answers
  const hasCommonAnswers =
    Object.values(profile.commonAnswers || {}).filter((v) => v).length > 0;
  totalScore += hasCommonAnswers * weights.commonAnswers;

  return Math.round(totalScore);
}

/**
 * Extract profile from CV text using AI
 */
export async function extractProfileFromCV(cvText, apiBaseUrl, modelId) {
  try {
    const system = `You are a profile extraction assistant. Extract key information from the CV and return ONLY valid JSON.`;

    const user = `Extract ALL available profile information from this CV:

${cvText}

Return ONLY this JSON structure (use exact field names, extract ALL fields that are present):
{
  "fullName": "exact full name from CV",
  "email": "email address",
  "phone": "phone number with country code if present",
  "location": "City, State ZIP or City, State or just City",
  "linkedIn": "full LinkedIn URL if present (e.g., https://linkedin.com/in/username)",
  "portfolio": "portfolio website URL if present",
  "github": "GitHub profile URL if present (e.g., https://github.com/username)",
  "topSkills": ["skill1", "skill2", "skill3", "skill4", "skill5", "skill6", "skill7", "skill8"],
  "yearsExperience": 0,
  "currentRole": "most recent job title",
  "highestDegree": "degree name (e.g., Bachelor of Science, Master of Arts, Ph.D.)",
  "fieldOfStudy": "major/field of study (e.g., Computer Science, Business Administration)",
  "university": "university name",
  "graduationYear": "YYYY",
  "professionalSummary": "2-3 sentence summary of experience, expertise, and career highlights",
  "certifications": ["cert1", "cert2", "cert3"]
}

EXTRACTION RULES:
1. Extract ALL fields that are present in the CV
2. For missing fields, use empty string "" or empty array [] or 0
3. For LinkedIn/GitHub/Portfolio: Extract full URLs if present
4. For skills: Extract 5-10 most relevant technical and professional skills
5. For yearsExperience: Calculate from work history or stated experience
6. For location: Include as much detail as available (City, State, ZIP)
7. For currentRole: Use the most recent job title from work experience
8. For professionalSummary: Create a concise summary if not explicitly stated

CRITICAL: Return ONLY the JSON object, no markdown code blocks, no explanation, no additional text.`;

    const headers = {
      'Content-Type': 'application/json',
    };

    // Add API keys from chrome.storage
    try {
      const storage = await chrome.storage.sync.get([
        'openaiApiKey',
        'geminiApiKey',
        'claudeApiKey',
      ]);
      if (storage.openaiApiKey) headers['x-openai-key'] = storage.openaiApiKey;
      if (storage.geminiApiKey) headers['x-gemini-key'] = storage.geminiApiKey;
      if (storage.claudeApiKey) headers['x-claude-key'] = storage.claudeApiKey;
    } catch (e) {
      console.error('[Profile] Error getting API keys:', e);
    }

    const response = await fetch(`${apiBaseUrl}/v1/extract-profile`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ cvText, modelId }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.warn(
        `[Profile] AI extraction failed (${response.status}): ${errorText}, using basic extraction`
      );
      // Fallback to basic extraction
      return extractProfileBasic(cvText);
    }

    const data = await response.json();
    console.log('[Profile] AI extraction successful');
    return data.profile || data.result || data;
  } catch (e) {
    console.error('[Profile] Extraction error:', e);

    // Fallback: Basic extraction using regex
    console.log('[Profile] Using basic regex extraction as fallback');
    return extractProfileBasic(cvText);
  }
}

/**
 * Basic profile extraction (fallback when AI fails)
 */
function extractProfileBasic(cvText) {
  const lines = cvText
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l);

  const profile = {
    fullName: '',
    email: '',
    phone: '',
    location: '',
    linkedIn: '',
    portfolio: '',
    github: '',
    topSkills: [],
    yearsExperience: 0,
    currentRole: '',
    highestDegree: '',
    fieldOfStudy: '',
    university: '',
    graduationYear: '',
    professionalSummary: '',
    certifications: [],
  };

  // Extract email
  const emailMatch = cvText.match(
    /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/
  );
  if (emailMatch) profile.email = emailMatch[0];

  // Extract phone
  const phoneMatch = cvText.match(
    /(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/
  );
  if (phoneMatch) profile.phone = phoneMatch[0];

  // Extract LinkedIn
  const linkedInMatch = cvText.match(/linkedin\.com\/in\/[a-zA-Z0-9-]+/i);
  if (linkedInMatch) profile.linkedIn = 'https://' + linkedInMatch[0];

  // Extract GitHub
  const githubMatch = cvText.match(/github\.com\/[a-zA-Z0-9-]+/i);
  if (githubMatch) profile.github = 'https://' + githubMatch[0];

  // Extract Portfolio (look for personal website URLs)
  const portfolioMatch = cvText.match(
    /(?:portfolio|website):\s*(https?:\/\/[^\s]+)/i
  );
  if (portfolioMatch) profile.portfolio = portfolioMatch[1];

  // Extract name (usually first line, before email/phone)
  if (lines.length > 0) {
    // Skip lines that are just contact info
    for (let i = 0; i < Math.min(5, lines.length); i++) {
      const line = lines[i];
      if (
        !line.includes('@') &&
        !line.match(/\d{3}[-.\s]\d{3}[-.\s]\d{4}/) &&
        line.length > 3
      ) {
        profile.fullName = line.replace(/[,;].*$/, '').trim();
        break;
      }
    }
  }

  // Extract location (look for City, State ZIP pattern)
  const locationMatch = cvText.match(/([A-Z][a-z]+,?\s+[A-Z]{2}(?:\s+\d{5})?)/);
  if (locationMatch) profile.location = locationMatch[0];

  // Extract skills (look for SKILLS section)
  const skillsSection = cvText.match(/SKILLS[\s\S]{0,500}/i);
  if (skillsSection) {
    const bullets = skillsSection[0].match(/[•\-\*]\s*([^\n]+)/g);
    if (bullets) {
      profile.topSkills = bullets
        .map((b) => b.replace(/[•\-\*]\s*/, '').trim())
        .slice(0, 10);
    }
  }

  // Extract current role (look for most recent job title in EXPERIENCE section)
  const experienceSection = cvText.match(
    /(?:EXPERIENCE|WORK HISTORY|EMPLOYMENT)[\s\S]{0,300}/i
  );
  if (experienceSection) {
    // Look for job title patterns (usually after company name or first line)
    const titleMatch = experienceSection[0].match(
      /\n([A-Z][a-zA-Z\s&]+(?:Engineer|Developer|Manager|Analyst|Designer|Consultant|Director|Lead|Specialist|Coordinator))/
    );
    if (titleMatch) profile.currentRole = titleMatch[1].trim();
  }

  // Extract education info (look for EDUCATION section)
  const educationSection = cvText.match(/(?:EDUCATION)[\s\S]{0,400}/i);
  if (educationSection) {
    const eduText = educationSection[0];

    // Extract degree
    const degreeMatch = eduText.match(
      /(Bachelor|Master|Ph\.?D\.?|Associate|B\.?S\.?|M\.?S\.?|M\.?B\.?A\.?|B\.?A\.?)[\s\w]*(?:of|in)?\s*([A-Z][a-zA-Z\s]+)/i
    );
    if (degreeMatch) {
      profile.highestDegree = degreeMatch[0].trim();
      // Extract field of study
      const fieldMatch = degreeMatch[2];
      if (fieldMatch) profile.fieldOfStudy = fieldMatch.trim();
    }

    // Extract university
    const uniMatch = eduText.match(
      /(?:University|College|Institute|School)\s+(?:of\s+)?([A-Z][a-zA-Z\s]+)/i
    );
    if (uniMatch) profile.university = uniMatch[0].trim();

    // Extract graduation year
    const gradYearMatch = eduText.match(
      /(?:Graduated|Graduation|Class of)?\s*['"]?(\d{4})['"]?/i
    );
    if (gradYearMatch) profile.graduationYear = gradYearMatch[1];
  }

  // Estimate years of experience from work history dates
  const yearMatches = cvText.match(/\d{4}/g);
  if (yearMatches && yearMatches.length >= 2) {
    const years = yearMatches
      .map((y) => parseInt(y))
      .filter((y) => y >= 1990 && y <= new Date().getFullYear())
      .sort();
    if (years.length >= 2) {
      const currentYear = new Date().getFullYear();
      profile.yearsExperience = Math.min(currentYear - years[0], 50); // Cap at 50 years
    }
  }

  // Extract certifications (look for CERTIFICATIONS section)
  const certsSection = cvText.match(
    /(?:CERTIFICATIONS?|CERTIFICATES?)[\s\S]{0,300}/i
  );
  if (certsSection) {
    const bullets = certsSection[0].match(/[•\-\*]\s*([^\n]+)/g);
    if (bullets) {
      profile.certifications = bullets
        .map((b) => b.replace(/[•\-\*]\s*/, '').trim())
        .slice(0, 5);
    }
  }

  // Create professional summary from first few lines if not in a specific section
  const summarySection = cvText.match(
    /(?:SUMMARY|PROFILE|OBJECTIVE)[\s\S]{0,300}/i
  );
  if (summarySection) {
    const summaryText = summarySection[0]
      .replace(/(?:SUMMARY|PROFILE|OBJECTIVE)/i, '')
      .trim()
      .split('\n')
      .filter((l) => l.trim().length > 20)
      .slice(0, 3)
      .join(' ');
    if (summaryText) profile.professionalSummary = summaryText;
  }

  console.log('[Profile] Basic extraction completed:', {
    hasName: !!profile.fullName,
    hasEmail: !!profile.email,
    hasPhone: !!profile.phone,
    hasLocation: !!profile.location,
    hasLinkedIn: !!profile.linkedIn,
    hasGitHub: !!profile.github,
    hasPortfolio: !!profile.portfolio,
    skillsCount: profile.topSkills.length,
    hasCurrentRole: !!profile.currentRole,
    hasDegree: !!profile.highestDegree,
    hasUniversity: !!profile.university,
    yearsExp: profile.yearsExperience,
  });

  return profile;
}

/**
 * Pre-fill form fields from user profile
 */
export function prePopulateFromProfile(formText, userProfile) {
  if (!userProfile || !formText) return [];

  const preFilled = [];
  const formLower = formText.toLowerCase();

  // Name fields
  if (formLower.includes('name') && userProfile.essential?.fullName) {
    // Try to detect first/last name separately
    if (formLower.includes('first name') || formLower.includes('firstname')) {
      const firstName = userProfile.essential.fullName.split(' ')[0];
      preFilled.push({ name: 'First Name', value: firstName });
    }
    if (formLower.includes('last name') || formLower.includes('lastname')) {
      const parts = userProfile.essential.fullName.split(' ');
      const lastName = parts[parts.length - 1];
      preFilled.push({ name: 'Last Name', value: lastName });
    }
    if (
      formLower.includes('full name') ||
      (formLower.includes('name') &&
        !formLower.includes('first') &&
        !formLower.includes('last'))
    ) {
      preFilled.push({
        name: 'Full Name',
        value: userProfile.essential.fullName,
      });
    }
  }

  // Email
  if (formLower.includes('email') && userProfile.essential?.email) {
    preFilled.push({ name: 'Email', value: userProfile.essential.email });
  }

  // Phone
  if (
    (formLower.includes('phone') || formLower.includes('mobile')) &&
    userProfile.essential?.phone
  ) {
    preFilled.push({ name: 'Phone', value: userProfile.essential.phone });
  }

  // Location/Address
  if (userProfile.essential?.location) {
    if (formLower.includes('city')) {
      const city = userProfile.essential.location.split(',')[0].trim();
      preFilled.push({ name: 'City', value: city });
    }
    if (formLower.includes('state')) {
      const stateMatch = userProfile.essential.location.match(/,\s*([A-Z]{2})/);
      if (stateMatch) {
        preFilled.push({ name: 'State', value: stateMatch[1] });
      }
    }
    if (formLower.includes('zip') || formLower.includes('postal')) {
      const zipMatch = userProfile.essential.location.match(/\d{5}/);
      if (zipMatch) {
        preFilled.push({ name: 'ZIP Code', value: zipMatch[0] });
      }
    }
    if (formLower.includes('location') || formLower.includes('address')) {
      preFilled.push({
        name: 'Location',
        value: userProfile.essential.location,
      });
    }
  }

  // LinkedIn
  if (
    (formLower.includes('linkedin') || formLower.includes('profile')) &&
    userProfile.essential?.linkedIn
  ) {
    preFilled.push({ name: 'LinkedIn', value: userProfile.essential.linkedIn });
  }

  // Portfolio/Website
  if (
    (formLower.includes('portfolio') || formLower.includes('website')) &&
    userProfile.essential?.portfolio
  ) {
    preFilled.push({
      name: 'Portfolio',
      value: userProfile.essential.portfolio,
    });
  }

  // Work Authorization
  if (
    (formLower.includes('work authorization') ||
      formLower.includes('visa') ||
      formLower.includes('eligibility')) &&
    userProfile.essential?.workAuthorization
  ) {
    preFilled.push({
      name: 'Work Authorization',
      value: userProfile.essential.workAuthorization,
    });
  }

  // Security Clearance
  if (
    (formLower.includes('security clearance') ||
      formLower.includes('clearance')) &&
    userProfile.essential?.securityClearance
  ) {
    preFilled.push({
      name: 'Security Clearance',
      value: userProfile.essential.securityClearance,
    });
  }

  // Start Date
  if (
    (formLower.includes('start date') || formLower.includes('available')) &&
    userProfile.preferences?.availableStartDate
  ) {
    preFilled.push({
      name: 'Start Date',
      value: userProfile.preferences.availableStartDate,
    });
  }

  // Salary
  if (formLower.includes('salary') || formLower.includes('compensation')) {
    if (
      userProfile.preferences?.expectedSalaryMin &&
      userProfile.preferences?.expectedSalaryMax
    ) {
      const salaryRange = `$${userProfile.preferences.expectedSalaryMin} - $${userProfile.preferences.expectedSalaryMax}`;
      preFilled.push({ name: 'Expected Salary', value: salaryRange });
    }
  }

  // Relocation
  if (
    (formLower.includes('relocat') || formLower.includes('willing to move')) &&
    userProfile.preferences?.willingToRelocate
  ) {
    preFilled.push({
      name: 'Willing to Relocate',
      value: userProfile.preferences.willingToRelocate,
    });
  }

  // Notice Period
  if (
    (formLower.includes('notice') || formLower.includes('availability')) &&
    userProfile.commonAnswers?.noticeRequired
  ) {
    preFilled.push({
      name: 'Notice Required',
      value: userProfile.commonAnswers.noticeRequired,
    });
  }

  // Referral Source
  if (
    (formLower.includes('how did you hear') ||
      formLower.includes('referral')) &&
    userProfile.commonAnswers?.referralSource
  ) {
    preFilled.push({
      name: 'Referral Source',
      value: userProfile.commonAnswers.referralSource,
    });
  }

  return preFilled;
}

/**
 * Build profile context for AI prompts
 */
export function buildProfileContext(userProfile) {
  if (!userProfile) return '';

  let context = 'Candidate Profile Summary:\n';

  if (userProfile.essential) {
    if (userProfile.essential.fullName) {
      context += `Name: ${userProfile.essential.fullName}\n`;
    }
    if (userProfile.essential.workAuthorization) {
      context += `Work Authorization: ${userProfile.essential.workAuthorization}\n`;
    }
    if (userProfile.essential.securityClearance) {
      context += `Security Clearance: ${userProfile.essential.securityClearance}\n`;
    }
  }

  if (userProfile.professional?.summary) {
    context += `\nProfessional Summary:\n${userProfile.professional.summary}\n`;
  }

  if (userProfile.skills) {
    if (userProfile.skills.topSkills?.length > 0) {
      context += `\nTop Skills: ${userProfile.skills.topSkills.join(', ')}\n`;
    }
    if (userProfile.skills.yearsExperience?.total) {
      context += `Total Experience: ${userProfile.skills.yearsExperience.total} years\n`;
    }
    if (userProfile.skills.education?.highestDegree) {
      context += `Education: ${userProfile.skills.education.highestDegree}`;
      if (userProfile.skills.education.university) {
        context += ` from ${userProfile.skills.education.university}`;
      }
      context += '\n';
    }
  }

  if (userProfile.preferences) {
    if (userProfile.preferences.jobTypes?.length > 0) {
      context += `\nJob Type Preferences: ${userProfile.preferences.jobTypes.join(
        ', '
      )}\n`;
    }
    if (userProfile.preferences.expectedSalaryMin) {
      context += `Expected Salary: $${
        userProfile.preferences.expectedSalaryMin
      } - $${userProfile.preferences.expectedSalaryMax || 'negotiable'}\n`;
    }
  }

  return context;
}

/**
 * Check if profile exists and is complete enough
 */
export async function isProfileComplete(minCompleteness = 40) {
  const profile = await getUserProfile();
  if (!profile) return false;

  const completeness = profile.metadata?.completeness || 0;
  return completeness >= minCompleteness;
}

/**
 * Create initial profile from onboarding data
 */
export function createInitialProfile(onboardingData) {
  return {
    version: PROFILE_SCHEMA.version,
    essential: {
      fullName: onboardingData.fullName || '',
      email: onboardingData.email || '',
      phone: onboardingData.phone || '',
      location: onboardingData.location || '',
      linkedIn: onboardingData.linkedIn || '',
      portfolio: onboardingData.portfolio || '',
      workAuthorization: onboardingData.workAuthorization || '',
      securityClearance: onboardingData.securityClearance || 'None',
    },
    preferences: {
      jobTypes: onboardingData.jobTypes || [],
      preferredIndustries: onboardingData.industries || [],
      expectedSalaryMin: onboardingData.salaryMin || '',
      expectedSalaryMax: onboardingData.salaryMax || '',
      availableStartDate: onboardingData.startDate || '',
      willingToRelocate: onboardingData.relocate || '',
      overtimeWillingness: '',
      travelWillingness: '',
      remoteSetup: '',
      timezone: '',
    },
    skills: {
      topSkills: onboardingData.skills || [],
      certifications: onboardingData.certifications || [],
      yearsExperience: {
        total: onboardingData.yearsExperience || 0,
        management: 0,
        technical: 0,
      },
      education: {
        highestDegree: onboardingData.degree || '',
        fieldOfStudy: onboardingData.major || '',
        university: onboardingData.university || '',
        graduationYear: onboardingData.gradYear || '',
      },
    },
    commonAnswers: {
      referralSource: onboardingData.referralSource || '',
      availableForInterview: '',
      noticeRequired: onboardingData.notice || '',
      diversityStatement: '',
      whyThisCompany: '',
      strength: '',
      weakness: '',
    },
    professional: {
      summary: onboardingData.summary || '',
      currentRole: onboardingData.currentRole || '',
      yearsInCurrentRole: 0,
    },
    metadata: {
      createdAt: Date.now(),
      lastUpdated: Date.now(),
      completeness: 0,
      source: onboardingData.source || 'manual',
    },
  };
}
