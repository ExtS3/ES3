# Troubleshooting Google Sign-In

## Error: "Cannot read properties of undefined (reading 'error')"

This error means the background script isn't responding properly. Here's how to fix it:

### Step 1: Check Background Script Logs

1. Go to `chrome://extensions/`
2. Find **JobApAI** extension
3. Click **"Service worker"** link (or **"background page"** in older Chrome)
4. Look for console logs starting with `[Firebase Background]`

### Expected Logs:

```
[Background] Firebase Auth loaded
[Firebase Background] Starting initialization...
[Firebase Background] firebase-app-compat loaded
[Firebase Background] firebase-auth-compat loaded
[Firebase Background] Firebase SDK loaded successfully
[Firebase Background] Initialized
```

### If You See Errors:

#### Error: "Failed to load firebase-app-compat" or "Failed to load firebase-auth-compat"

**Cause**: Service worker can't load Firebase from CDN (network issue or CSP)

**Fix**: The extension needs internet connection to load Firebase. Make sure:

- You have internet connection
- No firewall blocking `gstatic.com`
- Try reloading the extension

#### Error: "Firebase SDK failed to load!"

**Cause**: `importScripts()` failed completely

**Fix**: Reload the extension:

1. Go to `chrome://extensions/`
2. Click **"Reload"** button
3. Try again

---

## Step 2: Reload Extension

**Always reload after changing files!**

1. Go to `chrome://extensions/`
2. Find **JobApAI**
3. Click **"Reload"** (⟳ icon)
4. Close and reopen the sidepanel
5. Try Google Sign-In again

---

## Step 3: Check manifest.json

Make sure you have `"identity"` permission:

```json
{
  "permissions": [
    "storage",
    "sidePanel",
    "tabs",
    "webNavigation",
    "identity"  ← Must be present!
  ]
}
```

---

## Step 4: Add OAuth2 Configuration

Google Sign-In requires OAuth2 config in `manifest.json`:

```json
{
  "oauth2": {
    "client_id": "YOUR_CLIENT_ID.apps.googleusercontent.com",
    "scopes": [
      "https://www.googleapis.com/auth/userinfo.email",
      "https://www.googleapis.com/auth/userinfo.profile"
    ]
  }
}
```

**How to get Client ID**:

1. Go to [Google Cloud Console - Credentials](https://console.cloud.google.com/apis/credentials?project=323731579339)
2. Create **OAuth client ID** → **Chrome extension**
3. Copy the Client ID

---

## Step 5: Enable Google Sign-In in Firebase

1. Go to [Firebase Console - Authentication](https://console.firebase.google.com/project/jobapai/authentication/providers)
2. Click **"Google"**
3. Toggle **"Enable"**
4. Save

---

## Common Errors:

### "No response from background script"

- **Fix**: Reload extension, check background script logs

### "Firebase not initialized"

- **Fix**: Firebase SDK failed to load. Check internet connection, reload extension

### "OAuth2 client ID missing"

- **Fix**: Add `oauth2` section to `manifest.json`

### "Authorization required"

- **Fix**: User needs to grant Google account access. Try again and click "Allow"

---

## Testing Checklist:

- [ ] Extension reloaded after changes
- [ ] Background script logs show Firebase loaded
- [ ] `manifest.json` has `"identity"` permission
- [ ] `manifest.json` has `"oauth2"` config with valid Client ID
- [ ] Google Sign-In enabled in Firebase Console
- [ ] Internet connection active
- [ ] Clicked "Continue with Google" button
- [ ] Selected Google account in popup
- [ ] Granted permissions

---

## Still Not Working?

Check these logs in order:

1. **Background Script Console** (`chrome://extensions/` → Service worker)

   - Look for `[Firebase Background]` logs
   - Check for errors

2. **Sidepanel Console** (F12 while sidepanel is open)

   - Look for `[Google Sign-In]` logs
   - Check the response object

3. **Network Tab** (F12 → Network)
   - Check if Firebase scripts load from `gstatic.com`
   - Status should be `200 OK`

---

## Quick Fix Checklist:

1. ✅ Reload extension
2. ✅ Check background script logs
3. ✅ Verify `identity` permission in manifest
4. ✅ Add `oauth2` config to manifest
5. ✅ Enable Google provider in Firebase Console
6. ✅ Try again!

