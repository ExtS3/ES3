## API Catalog

Base URL: see `config.json` `apiBaseUrl` (e.g., `https://<your-domain>/api`)

### Generate

- POST `/v1/generate/resume`

  - Body: `{ cvText: string, jobDescriptionText: string, modelId?: string }`
  - Headers: `x-openai-key` or `x-gemini-key` or `x-claude-key` (optional BYOK)
  - Response: `{ text: string }` or `{ error }`

- POST `/v1/generate/cover`
  - Body: `{ cvText: string, jobDescriptionText: string, modelId?: string }`
  - Headers: BYOK headers as above
  - Response: `{ text: string }` or `{ error }`

### Analyze

- POST `/v1/analyze-form`
  - Body: `{ cvText: string, jobDescriptionText: string, formText: string, modelId?: string }`
  - Headers: BYOK headers supported
  - Response: `{ fields: {name,value,reasoning}[], notes: string }` or `{ error }`

### Usage

- GET `/v1/usage`
  - Response: usage summary for current actor (depends on auth/trial config)

### Key Validation

- POST `/v1/key/validate`
  - Body: `{ provider: 'openai'|'gemini'|'claude', apiKey: string }`
  - Response: `{ ok: boolean }` or `{ error }`

### Applications Tracker

- POST `/v1/apps/log`

  - Auth: Supabase session cookie (via extension or web app)
  - Body: `{ job_url?, job_title?, company_name?, date_applied?, resume_generated?, cover_letter_generated?, notes? }`
  - Response: `{ ok: true, row }` or `{ error }`

- PATCH `/v1/apps/log`
  - Auth: Supabase session cookie
  - Body: `{ id: string, company_name?, job_title? }`
  - Response: `{ ok: true, row }` or `{ error }`

### Auth

- POST `/v1/auth/signup`
- POST `/v1/auth/login`
- POST `/v1/auth/logout`
- GET `/v1/auth/me`
- POST `/v1/auth/forgot-password`
- POST `/v1/auth/reset-password`
- GET `/v1/auth/google/start`
- GET `/v1/auth/google/session`

Notes:

- CORS is handled by the backend to permit requests from the extension and configured origins.
- BYOK headers are optional; if absent, server uses configured shared keys where available.





