# Sign Up & Sign In Pages - Quick Reference

## ✅ **IMPLEMENTED - Separate Pages**

You now have **two separate authentication pages** that match the Figma design exactly!

---

## 📄 Pages Created

### 1. **Sign Up Page** (`signup.html`)

**What it includes:**

- ✅ "Already have an account? **Log in**" (links to login.html)
- ✅ **Continue with Google** button
- ✅ **or** divider
- ✅ **Enter your full name** field
- ✅ **Enter your email** field
- ✅ **Enter your password** field with 👁 eye icon
- ✅ Helper text: "Use 8+ characters with mixed case and numbers."
- ✅ Checkbox: "Send me updates and offers (optional)"
- ✅ **Continue with email** button
- ✅ Terms and conditions text

### 2. **Log In Page** (`login.html`)

**What it includes:**

- ✅ "Don't have an account? **Sign up for free**" (links to signup.html)
- ✅ **Log in with Google** button
- ✅ **or** divider
- ✅ **Enter your email** field (NO name field)
- ✅ **Enter your password** field with 👁 eye icon
- ✅ **Forgot Password?** link (NO helper text)
- ✅ **Log in** button (NO checkbox)
- ✅ Terms and conditions text

---

## 🔄 How They Work

### **Navigation:**

```
signup.html ←→ login.html
     ↓              ↓
  Success      Success
     ↓              ↓
 Side Panel   Side Panel
```

### **On Extension Install:**

```
Chrome Extension Install → Opens signup.html automatically
```

### **Links:**

- **Sign Up Page**: Click "Log in" → Goes to login.html
- **Log In Page**: Click "Sign up for free" → Goes to signup.html

---

## 📂 Files

| File             | Purpose                        |
| ---------------- | ------------------------------ |
| `signup.html`    | Sign up page structure         |
| `signup.js`      | Sign up logic & validation     |
| `login.html`     | Log in page structure          |
| `login.js`       | Log in logic & forgot password |
| `onboarding.css` | Shared styles for both pages   |
| `background.js`  | Opens signup.html on install   |
| `manifest.json`  | Includes all files             |

---

## 🎨 Design

Both pages use the same:

- ✅ Centered floating white card (420px)
- ✅ Soft green background (#EAF6ED)
- ✅ Figma-exact spacing and colors
- ✅ Modern, clean UI

---

## 🧪 Test It

### **Sign Up:**

1. Install/reload extension
2. Signup page opens automatically
3. Fill out form and submit
4. Or click "Log in" to switch pages

### **Log In:**

1. Navigate to login page
2. Enter credentials
3. Click "Forgot Password?" if needed
4. Or click "Sign up for free" to switch

---

## 🎉 Complete!

**All TODOs finished:**

- ✅ Created separate `signup.html`
- ✅ Created separate `login.html`
- ✅ Created `signup.js` with signup logic
- ✅ Created `login.js` with login logic
- ✅ Updated `background.js` to open signup page
- ✅ Updated `manifest.json` with new files
- ✅ Shared CSS works for both pages
- ✅ No linter errors

---

**Ready to use! 🚀**


