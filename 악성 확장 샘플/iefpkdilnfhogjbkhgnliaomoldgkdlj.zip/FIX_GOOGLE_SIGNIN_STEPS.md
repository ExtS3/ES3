# Fix Google Sign-In - Complete Steps

## ✅ **Step 1: Download Firebase SDK**

Run these commands in a **fresh terminal** (not in Cursor):

```bash
# Navigate to extension directory
cd /home/stationone/Desktop/up/ancilia/chromeextension2

# Create vendor directory
mkdir -p vendor/firebase

# Download Firebase App SDK (compat version for service workers)
curl -o vendor/firebase/firebase-app-compat.js \
  https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js

# Download Firebase Auth SDK (compat version)
curl -o vendor/firebase/firebase-auth-compat.js \
  https://www.gstatic.com/firebasejs/10.7.1/firebase-auth-compat.js

# Verify files downloaded successfully
ls -lh vendor/firebase/
```

**Expected output:**

```
-rw-r--r-- 1 user user 250K ... firebase-app-compat.js
-rw-r--r-- 1 user user 180K ... firebase-auth-compat.js
```

---

## ✅ **Step 2: Files Already Updated**

I've already updated `firebase-auth-bg.js` to load from local files:

- ✅ Changed from CDN URLs to `vendor/firebase/` paths
- ✅ Added better error messages

---

## ✅ **Step 3: Reload Extension**

1. Go to `chrome://extensions/`
2. Find **JobApAI**
3. Click **"Reload"** button (⟳ icon)
4. Wait for reload to complete

---

## ✅ **Step 4: Check Background Console**

1. Stay on `chrome://extensions/`
2. Click **"Service worker"** link (under JobApAI)
3. Check console logs

**Expected logs:**

```
[Background] Firebase Auth loaded
[Firebase Background] Starting initialization...
[Firebase Background] firebase-app-compat loaded
[Firebase Background] firebase-auth-compat loaded
[Firebase Background] Firebase SDK loaded successfully
[Firebase Background] Initialized
```

**If you see "Failed to load":**

- Files might not have downloaded correctly
- Check that `vendor/firebase/` directory exists
- Re-run the curl commands

---

## ✅ **Step 5: Test Google Sign-In**

1. Open your extension sidepanel
2. Click **"Continue with Google"**
3. Select your Google account
4. Grant permissions
5. You should be signed in! ✅

---

## 🔍 **Troubleshooting**

### Error: "Failed to load firebase-app-compat"

**Fix:**

```bash
# Check if files exist
ls -la /home/stationone/Desktop/up/ancilia/chromeextension2/vendor/firebase/

# If missing, re-download
cd /home/stationone/Desktop/up/ancilia/chromeextension2
curl -o vendor/firebase/firebase-app-compat.js \
  https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js
curl -o vendor/firebase/firebase-auth-compat.js \
  https://www.gstatic.com/firebasejs/10.7.1/firebase-auth-compat.js
```

### Error: "Firebase SDK failed to load"

**Fix:** Reload the extension completely:

1. `chrome://extensions/`
2. Click "Remove" on JobApAI
3. Click "Load unpacked"
4. Select `/home/stationone/Desktop/up/ancilia/chromeextension2`

---

## 📋 **Checklist**

- [ ] Run curl commands to download Firebase SDK
- [ ] Verify files exist in `vendor/firebase/`
- [ ] Reload extension in Chrome
- [ ] Check background console for success logs
- [ ] Test "Continue with Google" button
- [ ] Sign in successfully

---

## 🎉 **After Success**

Once Google Sign-In works:

1. Test profile sync
2. Test job application features
3. Verify data saves to Cloud SQL
4. Check Cloud Storage for uploaded files

---

**Run the curl commands now and let me know when done!** 🚀

