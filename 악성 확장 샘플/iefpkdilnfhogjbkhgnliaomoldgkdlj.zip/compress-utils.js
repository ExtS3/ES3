/**
 * Input compression/reduction utilities for JobApAI
 * Reduces token count while preserving essential information
 */

/**
 * Compress CV text - NO COMPRESSION, KEEP FULL TEXT
 * User wants complete CV details for accurate answers
 */
export function compressCV(cvText, maxChars = 4000) {
  // DO NOT COMPRESS - Return full CV
  // User needs complete work history, skills, and achievements
  return cvText || '';
}

/**
 * Extract key requirements from JD
 * Returns: title, requirements, must-haves, nice-to-haves, location, visa
 */
export function compressJD(jdText, maxChars = 3000) {
  if (!jdText || jdText.length <= maxChars) return jdText;

  const lines = jdText
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l);

  const compressed = [];
  let charCount = 0;
  let inRequirements = false;
  let inNiceToHave = false;
  let requirementCount = 0;
  const maxRequirements = 10;

  for (const line of lines) {
    // Always keep first few lines (usually job title, company, location)
    if (compressed.length < 3) {
      compressed.push(line);
      charCount += line.length + 1;
      continue;
    }

    // Detect requirement sections
    const lowerLine = line.toLowerCase();

    if (
      /^(requirements?|qualifications?|must.?haves?|responsibilities)/i.test(
        line
      )
    ) {
      inRequirements = true;
      inNiceToHave = false;
      requirementCount = 0;
      compressed.push(line);
      charCount += line.length + 1;
      continue;
    }

    if (/^(nice.?to.?have|preferred|bonus|plus)/i.test(line)) {
      inNiceToHave = true;
      inRequirements = false;
      requirementCount = 0;
      compressed.push(line);
      charCount += line.length + 1;
      continue;
    }

    // Keep important keywords
    const hasImportantKeyword =
      lowerLine.includes('years') ||
      lowerLine.includes('experience') ||
      lowerLine.includes('degree') ||
      lowerLine.includes('bachelor') ||
      lowerLine.includes('master') ||
      lowerLine.includes('certification') ||
      lowerLine.includes('clearance') ||
      lowerLine.includes('visa') ||
      lowerLine.includes('remote') ||
      lowerLine.includes('location') ||
      lowerLine.includes('salary') ||
      lowerLine.includes('$');

    // Keep bullets in requirement sections
    const isBullet = /^[-•*]\s/.test(line);
    if (isBullet && (inRequirements || inNiceToHave)) {
      requirementCount++;
      if (requirementCount <= maxRequirements) {
        compressed.push(line);
        charCount += line.length + 1;
      }
      continue;
    }

    // Keep important lines
    if (hasImportantKeyword) {
      compressed.push(line);
      charCount += line.length + 1;
    }

    // Stop if we hit the limit
    if (charCount >= maxChars) {
      break;
    }
  }

  // Add summary note
  const result = compressed.join('\n');
  if (result.length < jdText.length * 0.8) {
    return `[Compressed JD - Key Requirements Only]\n${result}`;
  }
  return result;
}

/**
 * Compress form text - NO COMPRESSION, KEEP FULL TEXT
 * User wants complete form data with all questions and labels
 */
export function compressForm(formText, maxChars = 2000) {
  // DO NOT COMPRESS - Return full text
  // User needs complete questions for accurate AI responses
  return formText || '';
}

/**
 * Normalize text - remove excessive whitespace, control characters
 */
export function normalizeText(text) {
  if (!text) return '';

  return text
    .replace(/[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]/g, '') // Remove control chars except \n, \r, \t
    .replace(/\r\n/g, '\n') // Normalize line endings
    .replace(/\r/g, '\n')
    .replace(/\t/g, '  ') // Replace tabs with spaces
    .replace(/ +/g, ' ') // Collapse multiple spaces
    .replace(/\n{3,}/g, '\n\n') // Collapse multiple newlines
    .trim();
}

/**
 * Generate a quick summary of CV for caching
 * Extracts: name, skills, years of experience, current/recent role
 */
export function generateCVSummary(cvText) {
  const lines = cvText
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l);

  const summary = {
    name: '',
    contact: '',
    skills: [],
    experience: [],
    education: [],
  };

  let inSkills = false;
  let inExperience = false;
  let inEducation = false;
  let currentJob = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lowerLine = line.toLowerCase();

    // Extract name (usually first non-empty line)
    if (i === 0 && !summary.name) {
      summary.name = line.replace(/[,;].*$/, '').trim();
      continue;
    }

    // Extract contact info (email, phone)
    if (i < 5 && (line.includes('@') || line.includes('|'))) {
      summary.contact = line;
      continue;
    }

    // Detect sections
    if (/^(SKILLS|EXPERTISE|COMPETENCIES|TECHNICAL)/i.test(line)) {
      inSkills = true;
      inExperience = false;
      inEducation = false;
      continue;
    }

    if (/^(EXPERIENCE|EMPLOYMENT)/i.test(line)) {
      inSkills = false;
      inExperience = true;
      inEducation = false;
      continue;
    }

    if (/^EDUCATION/i.test(line)) {
      inSkills = false;
      inExperience = false;
      inEducation = true;
      continue;
    }

    // Extract skills
    if (inSkills) {
      const isBullet = /^[-•*]\s/.test(line);
      if (isBullet) {
        const skill = line.replace(/^[-•*]\s*/, '').trim();
        if (skill && summary.skills.length < 12) {
          summary.skills.push(skill);
        }
      }
    }

    // Extract experience (company + title only, first 3 jobs)
    if (inExperience && summary.experience.length < 3) {
      // Company/Date line
      if (
        /\d{4}/.test(line) &&
        !line.startsWith('-') &&
        !line.startsWith('•')
      ) {
        if (currentJob) {
          summary.experience.push(currentJob);
        }
        currentJob = { company: line.split(/\d{4}/)[0].trim(), title: '' };
        continue;
      }

      // Title line (usually follows company)
      if (
        currentJob &&
        !currentJob.title &&
        line.length < 80 &&
        !line.startsWith('-') &&
        !line.startsWith('•')
      ) {
        currentJob.title = line;
      }
    }

    // Extract education (first 2 entries)
    if (inEducation && summary.education.length < 2) {
      if (line.length > 10 && !line.startsWith('-') && !line.startsWith('•')) {
        summary.education.push(line);
      }
    }
  }

  // Add last job if exists
  if (
    currentJob &&
    !summary.experience.find((e) => e.company === currentJob.company)
  ) {
    summary.experience.push(currentJob);
  }

  return summary;
}

/**
 * Create a compact representation for caching
 */
export function createCompactCV(cvText) {
  const summary = generateCVSummary(cvText);
  const compressed = compressCV(cvText);

  return {
    summary,
    compressed,
    hash: null, // Will be set by cache-utils
  };
}
