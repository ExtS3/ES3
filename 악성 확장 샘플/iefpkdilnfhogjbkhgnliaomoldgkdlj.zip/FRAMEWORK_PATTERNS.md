# Framework Detection Patterns - Quick Reference

## How to Add Support for a New Framework

If you encounter a form that's not being detected, follow these steps:

### 1. Identify the Framework

Open browser DevTools and inspect the form elements. Look for:

- Class name patterns (e.g., `mui-`, `ant-`, `chakra-`)
- Data attributes (e.g., `data-testid`, `data-component`)
- Custom element tags (e.g., `<mat-form-field>`)
- Framework-specific IDs or names

### 2. Add Detection Pattern

#### In `collectFields()` function:

```javascript
// YourFramework fields
const yourFrameworkFields = Array.from(
  scope.querySelectorAll
    ? scope.querySelectorAll(
        '.your-framework-input, .your-framework-select, ' +
          '[class*="your-framework"], [data-your-framework]'
      )
    : []
);
for (const el of yourFrameworkFields) {
  if (isHidden(el)) continue;
  const input = el.querySelector('input, textarea, select') || el;
  const label = resolveLabelForElement(scope, el);
  const id = input.getAttribute('id') || input.getAttribute('name') || '';
  const type = input.getAttribute('type') || input.tagName.toLowerCase();
  lines.push(
    `FIELD: type=${type} id=${id} label=${label} framework=your-framework`
  );
}
```

#### In `applyFieldsToRoot()` function:

```javascript
// YourFramework
candidates.push(
  ...root.querySelectorAll(
    '.your-framework-input, .your-framework-select, ' +
      '[class*="your-framework"], [data-your-framework]'
  )
);
```

### 3. Test the Detection

1. Reload the extension
2. Navigate to a form using the framework
3. Click "Scan Application Form"
4. Check console logs for detected fields
5. Verify fields are filled correctly

## Common Framework Patterns

### React-Based Frameworks

#### React Select

```javascript
// Detection
'[class*="select-shell"], [class*="select__container"]';

// Filling
async function setReactSelect(container, value) {
  // Click to open
  // Wait for options
  // Click matching option
}
```

#### Material-UI (MUI)

```javascript
// Detection
'.MuiTextField-root, .MuiSelect-root, .MuiAutocomplete-root';

// Label
el.querySelector('.MuiFormLabel-root')?.textContent;

// Input
el.querySelector('input, textarea, [role="combobox"]');
```

#### Chakra UI

```javascript
// Detection
'[class*="chakra-input"], [class*="chakra-select"]';

// Label
el.closest('.chakra-form-control')?.querySelector('label')?.textContent;

// Input
el.querySelector('input, textarea, select');
```

#### Ant Design

```javascript
// Detection
'.ant-input, .ant-select, .ant-picker, .ant-form-item';

// Label
el.closest('.ant-form-item')?.querySelector('.ant-form-item-label')
  ?.textContent;

// Input
el.querySelector('input, textarea, .ant-select-selector');
```

### Vue-Based Frameworks

#### Vuetify

```javascript
// Detection
'.v-text-field, .v-select, .v-autocomplete';

// Label
el.querySelector('.v-label')?.textContent;

// Input
el.querySelector('input, textarea, select');
```

#### Element UI

```javascript
// Detection
'.el-input, .el-select, .el-date-picker';

// Label
el.closest('.el-form-item')?.querySelector('.el-form-item__label')?.textContent;

// Input
el.querySelector('input, textarea, .el-input__inner');
```

### Angular-Based Frameworks

#### Angular Material

```javascript
// Detection
'mat-form-field, mat-input, mat-select';

// Label
el.querySelector('mat-label')?.textContent;

// Input
el.querySelector('input, textarea, mat-select');
```

### Job Application Platforms

#### LinkedIn

```javascript
// Detection
'[data-test-text-entity-list-form-component]';
'[data-test-single-typeahead-entity]';
'[data-test-form-element]';

// Label
el.querySelector('[data-test-form-element-label]')?.textContent ||
  el.closest('[data-test-form-element]')?.querySelector('label')?.textContent;
```

#### Greenhouse

```javascript
// Detection
'[class*="field--"], [data-provides="field"]';

// Label
el.querySelector('label')?.textContent || el.getAttribute('data-field-label');

// Uses React Select heavily
```

#### Lever

```javascript
// Detection
'[class*="application-field"], [data-qa*="field"]';

// Label
el.querySelector('.application-label')?.textContent;
```

#### Workday

```javascript
// Detection
'[data-automation-id*="input"], [data-automation-id*="select"]';

// Label
el.getAttribute('aria-label') ||
  el.closest('[data-automation-id]')?.querySelector('label')?.textContent;
```

### Form Builders

#### Google Forms

```javascript
// Detection
'[data-params*="question"]';
'[class*="freebirdFormviewerComponentsQuestion"]';

// Label
el.querySelector('[class*="freebirdFormviewerComponentsQuestionBaseTitle"]')
  ?.textContent;

// Input
el.querySelector('input, textarea, select');
```

#### Typeform

```javascript
// Detection
'[data-qa="question"]';
'[data-qa*="input"]';

// Label
el.querySelector('[data-qa="question-title"]')?.textContent;

// Input
el.querySelector('input, textarea, select, [contenteditable]');
```

#### JotForm

```javascript
// Detection
'.form-line, [class*="form-input"]';

// Label
el.querySelector('.form-label')?.textContent;

// Input
el.querySelector('input, textarea, select');
```

### CMS Platforms

#### WordPress - Gravity Forms

```javascript
// Detection
'.gfield';

// Label
el.querySelector('.gfield_label')?.textContent;

// Input
el.querySelector('input, textarea, select');
```

#### WordPress - WPForms

```javascript
// Detection
'.wpforms-field';

// Label
el.querySelector('.wpforms-field-label')?.textContent;

// Input
el.querySelector('input, textarea, select');
```

#### WordPress - Contact Form 7

```javascript
// Detection
'.wpcf7-form-control-wrap';

// Label
el.previousElementSibling?.textContent || // Label often before wrapper
  el.closest('label')?.textContent;

// Input
el.querySelector('input, textarea, select');
```

#### Wix

```javascript
// Detection
'[data-testid*="input"], [data-testid*="field"]';

// Label
el.getAttribute('aria-label') ||
  el.closest('[data-testid*="field"]')?.querySelector('label')?.textContent;
```

## Custom Component Patterns

### Contenteditable Fields

```javascript
// Detection
'[contenteditable="true"], [role="textbox"]';

// Filling
el.textContent = value;
el.innerHTML = value;
el.dispatchEvent(new Event('input', { bubbles: true }));
```

### Shadow DOM Elements

```javascript
// Detection
function* enumerateRoots(root) {
  yield root;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
  let node;
  while ((node = walker.nextNode())) {
    if (node.shadowRoot) {
      yield node.shadowRoot;
    }
  }
}
```

### Iframe Forms

```javascript
// Detection
const iframes = root.querySelectorAll('iframe');
for (const iframe of iframes) {
  try {
    const doc = iframe.contentDocument;
    if (doc) yield doc;
  } catch (_) {
    // Cross-origin iframe, can't access
  }
}
```

### Custom Dropdowns (Non-Select)

```javascript
// Detection
'[role="combobox"], [aria-haspopup="listbox"]'

// Filling
1. Click to open: el.click()
2. Wait for options: await waitForElement('[role="option"]')
3. Find match: findBestOption(options, value)
4. Click option: option.click()
```

## Event Dispatching

Different frameworks require different events:

### Standard HTML

```javascript
el.value = value;
el.dispatchEvent(new Event('input', { bubbles: true }));
el.dispatchEvent(new Event('change', { bubbles: true }));
el.dispatchEvent(new Event('blur', { bubbles: true }));
```

### React

```javascript
// React uses synthetic events
const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
  window.HTMLInputElement.prototype,
  'value'
).set;
nativeInputValueSetter.call(el, value);
el.dispatchEvent(new Event('input', { bubbles: true }));
```

### Vue

```javascript
// Vue watches for input events
el.value = value;
el.dispatchEvent(new Event('input', { bubbles: true }));
el.dispatchEvent(new Event('change', { bubbles: true }));
```

### Angular

```javascript
// Angular uses zone.js
el.value = value;
el.dispatchEvent(new Event('input', { bubbles: true }));
el.dispatchEvent(new Event('change', { bubbles: true }));
el.dispatchEvent(new Event('blur', { bubbles: true }));
```

## Debugging Tips

### 1. Check Field Detection

```javascript
// In browser console
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  chrome.tabs.sendMessage(tabs[0].id, { type: 'collectFields' }, (response) => {
    console.log(response);
  });
});
```

### 2. Inspect Element Structure

```javascript
// Right-click element → Inspect
// Look for:
- Class names
- Data attributes
- ARIA roles
- Parent containers
- Label associations
```

### 3. Test Label Resolution

```javascript
// In content script context
const el = document.querySelector('input'); // Your target element
const label = resolveLabelForElement(document, el);
console.log('Resolved label:', label);
```

### 4. Test Value Setting

```javascript
// In content script context
const el = document.querySelector('input');
await setValue(el, 'Test Value');
console.log('Value set:', el.value);
```

## Performance Optimization

### Selector Specificity

```javascript
// ❌ Too broad (slow)
'[class*="input"]';

// ✅ More specific (fast)
'.your-framework-input, [data-your-framework-input]';
```

### Caching

```javascript
// ❌ Query multiple times
const inputs = root.querySelectorAll('input');
const textareas = root.querySelectorAll('textarea');

// ✅ Query once
const fields = root.querySelectorAll('input, textarea, select');
```

### Early Returns

```javascript
// ✅ Skip hidden elements early
if (isHidden(el)) continue;

// ✅ Skip non-matching elements early
if (!el.matches('.your-selector')) continue;
```

## Conclusion

With these patterns, you can add support for ANY framework or platform. The key is:

1. **Identify** the unique selectors
2. **Add** detection patterns
3. **Test** thoroughly
4. **Document** for future reference

The extension is designed to be **infinitely extensible** - no form is too complex!



























