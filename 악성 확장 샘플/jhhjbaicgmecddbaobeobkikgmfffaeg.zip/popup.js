document.addEventListener('DOMContentLoaded', function() {
  // Handle privacy policy link
  document.getElementById('privacy-link').addEventListener('click', function(e) {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://chatgptforchrome.com/privacy.html' });
  });
  
  // Handle terms of service link
  document.getElementById('terms-link').addEventListener('click', function(e) {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://chatgptforchrome.com/terms.html' });
  });
  
  // Optional: Add some interactive features
  // Show a random tip when clicking on the Pro Tips section
  const tips = [
    'Ask follow-up questions for deeper insights',
    'Try: "gpt explain like I\'m 5: [topic]"',
    'Perfect for coding help and debugging',
    'Get summaries of complex topics instantly',
    'Ask for step-by-step instructions',
    'Request examples to better understand concepts',
    'Use it for creative writing and brainstorming'
  ];
  
  const tipSection = document.querySelector('.tip');
  if (tipSection) {
    tipSection.style.cursor = 'pointer';
    tipSection.addEventListener('click', function() {
      const randomTip = tips[Math.floor(Math.random() * tips.length)];
      const tipContent = tipSection.querySelector('div:last-child');
      if (tipContent) {
        tipContent.innerHTML = `• ${randomTip}<br>• Click for more tips!`;
        
        // Add a subtle animation
        tipSection.style.transform = 'scale(1.02)';
        setTimeout(() => {
          tipSection.style.transform = 'scale(1)';
        }, 200);
      }
    });
  }
  
  // Subtle logo animation on hover (scale only, no rotation for image)
  const logo = document.querySelector('.logo img');
  if (logo) {
    logo.style.transition = 'transform 0.3s ease';
    logo.addEventListener('mouseenter', function() {
      logo.style.transform = 'scale(1.1)';
    });
    logo.addEventListener('mouseleave', function() {
      logo.style.transform = 'scale(1)';
    });
  }
});