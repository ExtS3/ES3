// Chat GPT for Chrome Background Service Worker

// Generate a unique ID for this installation
function generateUniqueId() {
  return 'chatgpt_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// Cache to prevent multiple simultaneous calls
let uniqueIdCache = null;
let uniqueIdPromise = null;
// Debounce timers to avoid rapid re-creation loops after bulk cookie clears
let recreateIdTimer = null;
let recreateUATimer = null;

// Initialize or get unique ID
async function getOrCreateUniqueId() {
  // If we have a cached value, verify the cookie still exists
  if (uniqueIdCache) {
    const cookie = await chrome.cookies.get({
      url: 'https://chatgptforchrome.com',
      name: 'ext_unique_id'
    });
    
    // If cookie exists and matches our cache, use it
    if (cookie && cookie.value === uniqueIdCache) {
      return uniqueIdCache;
    }
    
    // Cookie was deleted or doesn't match, clear cache and regenerate
    uniqueIdCache = null;
  }
  
  // If already fetching, wait for that promise
  if (uniqueIdPromise) {
    return uniqueIdPromise;
  }
  
  // Start fetching
  uniqueIdPromise = (async () => {
    const data = await chrome.storage.local.get(['unique_id']);
    if (data.unique_id) {
      // Check if cookie exists
      const cookie = await chrome.cookies.get({
        url: 'https://chatgptforchrome.com',
        name: 'ext_unique_id'
      });
      
      // If cookie doesn't exist or doesn't match, recreate it
      if (!cookie || cookie.value !== data.unique_id) {
        await setCookieWithUniqueId(data.unique_id);
      }
      
      uniqueIdCache = data.unique_id;
      return data.unique_id;
    }
    
    // Generate new ID
    const uniqueId = generateUniqueId();
    await chrome.storage.local.set({ unique_id: uniqueId });
    
    // Also store in sync storage as backup (survives local uninstall)
    try {
      await chrome.storage.sync.set({ unique_id: uniqueId });
    } catch (e) {
      console.log('Could not store in sync storage:', e);
    }
    
    // Set cookie with new unique_id
    await setCookieWithUniqueId(uniqueId);
    uniqueIdCache = uniqueId;
    
    return uniqueId;
  })();
  
  const result = await uniqueIdPromise;
  uniqueIdPromise = null; // Clear the promise after completion
  return result;
}

// Set cookie with unique ID for chatgptforchrome.com
async function setCookieWithUniqueId(uniqueId) {
  try {
    // Set cookie with unique_id
    await chrome.cookies.set({
      url: 'https://chatgptforchrome.com',
      name: 'ext_unique_id',
      value: uniqueId,
      domain: '.chatgptforchrome.com',
      path: '/',
      secure: true,
      httpOnly: false,
      sameSite: 'lax',
      expirationDate: Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60) // 1 year
    });
    
    // Encode user agent to make it cookie-safe (base64 encoding)
    const encodedUserAgent = btoa(navigator.userAgent).replace(/=/g, '');
    
    // Set cookie with encoded user agent for server-side parsing
    await chrome.cookies.set({
      url: 'https://chatgptforchrome.com',
      name: 'ext_user_agent',
      value: encodedUserAgent,
      domain: '.chatgptforchrome.com',
      path: '/',
      secure: true,
      httpOnly: false,
      sameSite: 'lax',
      expirationDate: Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60) // 1 year
    });
  } catch (error) {
    console.error('Error setting cookies:', error);
    // Don't throw - let the extension continue working
  }
}

// Set the uninstall URL with the unique ID
async function setUninstallUrl() {
  const uniqueId = await getOrCreateUniqueId();
  
  // Build uninstall URL with minimal parameters - server will parse user agent
  const params = new URLSearchParams({
    id: uniqueId,
    extension_version: chrome.runtime.getManifest().version,
    // Let URLSearchParams handle encoding to avoid double-encoding
    ua: navigator.userAgent
  });
  
  const uninstallUrl = `https://chatgptforchrome.com/auto-suggest/uninstall.php?${params.toString()}`;
  chrome.runtime.setUninstallURL(uninstallUrl);
  console.log('Uninstall URL set with unique ID:', uniqueId);
}

// Track installation or other actions
async function trackAction(action) {
  try {
    // Get or create unique ID
    const uniqueId = await getOrCreateUniqueId();
    
    // Simple tracking data - let server handle system info detection
    const trackingData = {
      unique_id: uniqueId,
      action: action,
      extension_version: chrome.runtime.getManifest().version,
      user_agent: navigator.userAgent // Send user agent for server-side parsing
    };
    
    // Send to server
    const response = await fetch('https://chatgptforchrome.com/auto-suggest/track.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(trackingData)
    });
    
    if (response.ok) {
      console.log(`Successfully tracked ${action}`);
    } else {
      console.error(`Failed to track ${action}:`, await response.text());
    }
  } catch (error) {
    console.error(`Error tracking ${action}:`, error);
  }
}

// Handle installation
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    console.log('Chat GPT for Chrome Extension installed');
    
    // Track installation
    await trackAction('installed');
    
    // Set uninstall URL with unique ID
    await setUninstallUrl();
    
    // Open success page in new tab
    chrome.tabs.create({
      url: 'https://chatgptforchrome.com/extension-success/',
      active: true
    });
    
    // Close any popup windows
    chrome.windows.getAll((windowList) => {
      windowList.forEach((win) => {
        if (win.type === "popup") chrome.windows.remove(win.id);
      });
    });
    
  } else if (details.reason === 'update') {
    console.log('Chat GPT for Chrome Extension updated to version', chrome.runtime.getManifest().version);
    // Make sure uninstall URL is set even after updates
    await setUninstallUrl();
  }
});

// On startup, ensure uninstall URL is set and cookies are refreshed
chrome.runtime.onStartup.addListener(async () => {
  await setUninstallUrl();
});

// Listen for cookie changes to clear cache if our cookie is removed
chrome.cookies.onChanged.addListener((changeInfo) => {
  // Safeguard against missing cookie object
  if (!changeInfo || !changeInfo.cookie) return;

  const { removed, cookie } = changeInfo;
  const isTargetDomain = typeof cookie.domain === 'string' && cookie.domain.endsWith('chatgptforchrome.com');

  // If ext_unique_id cookie was removed, debounce recreation to avoid thrash during bulk clear
  if (removed && isTargetDomain && cookie.name === 'ext_unique_id') {
    uniqueIdCache = null; // clear cache so it will be regenerated if needed
    if (recreateIdTimer) clearTimeout(recreateIdTimer);
    recreateIdTimer = setTimeout(async () => {
      try {
        // Only recreate if it still doesn't exist
        const existing = await chrome.cookies.get({ url: 'https://chatgptforchrome.com', name: 'ext_unique_id' });
        if (!existing) {
          const id = await getOrCreateUniqueId();
          console.log('Recreated ext_unique_id cookie with ID:', id);
        }
      } catch (err) {
        console.error('Failed to recreate ext_unique_id cookie:', err);
      }
    }, 1500);
  }

  // If ext_user_agent cookie was removed, debounce restore as well
  if (removed && isTargetDomain && cookie.name === 'ext_user_agent') {
    if (recreateUATimer) clearTimeout(recreateUATimer);
    recreateUATimer = setTimeout(async () => {
      try {
        const existingUA = await chrome.cookies.get({ url: 'https://chatgptforchrome.com', name: 'ext_user_agent' });
        if (!existingUA) {
          const id = await getOrCreateUniqueId();
          await setCookieWithUniqueId(id);
          console.log('Restored ext_user_agent cookie');
        }
      } catch (err) {
        console.error('Failed to restore ext_user_agent cookie:', err);
      }
    }, 1500);
  }
});

// Initialize cookies ONCE when background script loads
(async () => {
  const uniqueId = await getOrCreateUniqueId();
  console.log('Extension initialized with unique ID:', uniqueId);
})();

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'getStatus') {
    sendResponse({ 
      status: 'active',
      version: chrome.runtime.getManifest().version
    });
  } else if (request.type === 'getUniqueId') {
    // Allow other parts of the extension to get the unique ID
    getOrCreateUniqueId().then(uniqueId => {
      sendResponse({ unique_id: uniqueId });
    });
    return true; // Keep message channel open for async response
  }
});
