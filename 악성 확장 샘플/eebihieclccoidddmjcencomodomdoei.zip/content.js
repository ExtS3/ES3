// Gmail Enhanced - Content Script
class GmailEnhancer {
  constructor() {
    this.isInjected = false;
    this.observer = null;
    this.currentPreview = null;
    this.hideTimeout = null;
    this.init();
  }

  init() {
    // Wait for Gmail to load
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.startObserving());
    } else {
      this.startObserving();
    }
  }

  startObserving() {
    // Create observer to watch for Gmail UI changes
    this.observer = new MutationObserver((mutations) => {
      this.handleDOMChanges();
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Initial injection with multiple attempts
    setTimeout(() => this.handleDOMChanges(), 1000);
    setTimeout(() => this.handleDOMChanges(), 2000);
    setTimeout(() => this.handleDOMChanges(), 3000);
    
    // Also run periodically to catch dynamically created buttons
    setInterval(() => this.handleDOMChanges(), 5000);
  }

  handleDOMChanges() {
    this.injectCustomSearchBar();
    this.injectGenerateReplyButton();
    this.injectEmailActionButtons();
    this.injectSendConfirmation();
    this.injectEmailHoverPreviews();
  }

  injectCustomSearchBar() {
    const searchInput = document.querySelector('input[aria-label="Search mail"]') ||
                       document.querySelector('.gb_qe.aJh[type="text"]');
    
    if (searchInput && !document.querySelector('.supersonic-search-injected')) {
      
      // Find the search container to inject our icon
      const searchContainer = searchInput.closest('.gb_re') || 
                             searchInput.closest('.gsib_a') ||
                             searchInput.parentElement;
      
      if (searchContainer) {
        // Create Supersonic Search text button
        const supersonicIcon = document.createElement('div');
        supersonicIcon.className = 'supersonic-search-icon supersonic-search-injected';
        supersonicIcon.style.cssText = `
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          background: #f8f9fa;
          border: 1px solid #dadce0;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          z-index: 1000;
          padding: 2px 10px;
          font-size: 13px;
          font-weight: 300;
          color: #3c4043;
          white-space: nowrap;
          font-family: 'Google Sans',Roboto,RobotoDraft,Helvetica,Arial,sans-serif;
        `;
        
        supersonicIcon.textContent = 'Supersonic search';
        
        // Add hover effects
        supersonicIcon.addEventListener('mouseenter', () => {
          supersonicIcon.style.background = '#e8f0fe';
          supersonicIcon.style.borderColor = '#1a73e8';
          supersonicIcon.style.color = '#1a73e8';
        });
        
        supersonicIcon.addEventListener('mouseleave', () => {
          supersonicIcon.style.background = '#f8f9fa';
          supersonicIcon.style.borderColor = '#dadce0';
          supersonicIcon.style.color = '#3c4043';
        });
        
        // Add click handler to show spotlight popup
        supersonicIcon.addEventListener('click', () => {
          this.showSupersonicSearchPopup();
        });
        
        // Make the search container relative for absolute positioning
        searchContainer.style.position = 'relative';
        
        // Insert the icon
        searchContainer.appendChild(supersonicIcon);
      }
    }
  }

  async showSupersonicSearchPopup() {
    
    // Remove existing popup if any
    const existingPopup = document.querySelector('.supersonic-waitlist-popup');
    if (existingPopup) {
      existingPopup.remove();
    }
    
    // Create backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'supersonic-waitlist-popup';
    backdrop.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(12px);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      animation: fadeIn 0.3s ease-out;
    `;
    
    // Create popup container
    const popup = document.createElement('div');
    popup.style.cssText = `
      background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(30, 115, 230, 0.1) 100%);
      backdrop-filter: blur(25px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 20px;
      max-width: 500px;
      width: 90%;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25), 
                  0 0 0 1px rgba(255, 255, 255, 0.1) inset;
      animation: slideUp 0.4s ease-out;
      position: relative;
      padding: 40px 32px;
      text-align: center;
    `;
    
        popup.innerHTML = `
      <!-- Close button -->
      <button class="close-waitlist-btn" style="
        position: absolute;
        top: 20px;
        right: 20px;
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 50%;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: rgba(255, 255, 255, 0.9);
        font-size: 20px;
        transition: all 0.3s ease;
        font-weight: 300;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      ">×</button>

      <!-- Flight Registration Header -->
      <div style="
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(30px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 16px;
        padding: 20px;
        margin-bottom: 24px;
        text-align: center;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      ">
        <!-- Airline Logo -->
        <div style="
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: linear-gradient(135deg, #3B82F6 0%, #1E73E6 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          margin: 0 auto 16px;
          box-shadow: 0 8px 32px rgba(59, 130, 246, 0.4);
          border: 2px solid rgba(255, 255, 255, 0.3);
        ">✈️</div>
        
        <div style="
          font-size: 14px;
          font-weight: 800;
          color: rgba(255, 255, 255, 0.7);
          margin-bottom: 4px;
          font-family: 'Courier New', monospace;
          letter-spacing: 2px;
        ">SUPERSONIC AIRWAYS</div>
        
        <div style="
          font-size: 24px;
          font-weight: 700;
          color: white;
          margin-bottom: 8px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        ">Join the waitlist</div>
        
        <div style="
          font-size: 13px;
          font-weight: 800;
          color: rgba(255, 255, 255, 0.6);
          font-family: 'Courier New', monospace;
          letter-spacing: 1px;
        ">DESTINATION: PRODUCTIVITY</div>
      </div>

      <!-- Flight Information Panel -->
      <div style="
        background: rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(25px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 24px;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.1);
      ">
        <div style="
          font-size: 13px;
          font-weight: 600;
          color: rgba(255, 255, 255, 0.9);
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 8px;
        ">
          Onboard experience
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <div style="
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px;
            text-align: center;
          ">
            <div style="font-size: 11px; color: rgba(255, 255, 255, 0.8); font-weight: 500;">HYPERSONIC-FAST SEARCH</div>
          </div>
          <div style="
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px;
            text-align: center;
          ">
            <div style="font-size: 11px; color: rgba(255, 255, 255, 0.8); font-weight: 500;">AI INBOX PRIORITIZER</div>
          </div>
          <div style="
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px;
            text-align: center;
          ">
            <div style="font-size: 11px; color: rgba(255, 255, 255, 0.8); font-weight: 500;">AUTO DRAFTS</div>
          </div>
          <div style="
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px;
            text-align: center;
          ">
            <div style="font-size: 11px; color: rgba(255, 255, 255, 0.8); font-weight: 500;">SMART ACTIONS</div>
          </div>
        </div>
      </div>

      <!-- Passenger Information -->
      <div style="
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(30px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.1);
      ">
        <div style="
          font-size: 13px;
          font-weight: 600;
          color: rgba(255, 255, 255, 0.9);
          margin-bottom: 12px;
          font-family: 'Courier New', monospace;
          letter-spacing: 1px;
        ">PASSENGER INFORMATION</div>
        
        <input type="email" placeholder="EMAIL ADDRESS" style="
          width: 100%;
          border: 2px solid rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 16px;
          font-size: 14px;
          outline: none;
          transition: all 0.3s ease;
          box-sizing: border-box;
          background: rgba(255, 255, 255, 0.08);
          backdrop-filter: blur(20px);
          color: white;
          font-weight: 500;
          font-family: 'Courier New', monospace;
          letter-spacing: 1px;
          text-transform: uppercase;
        " class="waitlist-email-input">
      </div>

      <!-- Board Flight button -->
      <button class="join-waitlist-btn" style="
        width: 100%;
        background: linear-gradient(135deg, #3B82F6 0%, #1E73E6 100%);
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 12px;
        padding: 18px 24px;
        font-size: 16px;
        font-weight: 700;
        color: white;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 8px 32px rgba(59, 130, 246, 0.4);
        font-family: 'Courier New', monospace;
        letter-spacing: 2px;
        margin-bottom: 16px;
        backdrop-filter: blur(20px);
        position: relative;
        overflow: hidden;
      ">
        <span style="position: relative; z-index: 2;">RESERVE SEAT</span>
        <div style="
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
          transition: left 0.5s ease;
        " class="shine-effect"></div>
      </button>

      <!-- Flight Terms -->
      <p style="
        font-size: 11px;
        color: rgba(255, 255, 255, 0.6);
        margin: 0;
        line-height: 1.4;
        font-family: 'Courier New', monospace;
        text-align: center;
        letter-spacing: 0.5px;
        font-weight: 800;
      ">EARLY ACCESS BOARDING PASS WILL BE ISSUED UPON TAKEOFF</p>
    `;
    
    // Add animations with CSS
    const style = document.createElement('style');
    style.textContent = `
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes slideUp {
        from { 
          opacity: 0;
          transform: translateY(30px) scale(0.96);
        }
        to { 
          opacity: 1;
          transform: translateY(0) scale(1);
        }
      }
                    .waitlist-email-input:focus {
         border-color: rgba(59, 130, 246, 1) !important;
         background: rgba(255, 255, 255, 0.15) !important;
         box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.3), 0 8px 32px rgba(59, 130, 246, 0.2) !important;
         transform: translateY(-2px);
       }
       .waitlist-email-input::placeholder {
         color: rgba(255, 255, 255, 0.5);
       }
       .join-waitlist-btn:hover {
         transform: translateY(-3px);
         box-shadow: 0 12px 40px rgba(59, 130, 246, 0.6) !important;
         border-color: rgba(255, 255, 255, 0.5) !important;
       }
       .join-waitlist-btn:hover .shine-effect {
         left: 100% !important;
       }
       .join-waitlist-btn:active {
         transform: translateY(-1px);
       }
       .close-waitlist-btn:hover {
         background: rgba(255, 255, 255, 0.25) !important;
         transform: scale(1.1) rotate(90deg);
         box-shadow: 0 12px 40px rgba(0, 0, 0, 0.2) !important;
       }
       @keyframes flight-pulse {
         0%, 100% { box-shadow: 0 8px 32px rgba(59, 130, 246, 0.4); }
         50% { box-shadow: 0 8px 32px rgba(59, 130, 246, 0.8); }
       }
       .flight-logo {
         animation: flight-pulse 3s ease-in-out infinite;
       }
    `;
    document.head.appendChild(style);
    
    backdrop.appendChild(popup);
    document.body.appendChild(backdrop);
    
    // Add event listeners
    const emailInput = popup.querySelector('.waitlist-email-input');
    const joinBtn = popup.querySelector('.join-waitlist-btn');
    const closeBtn = popup.querySelector('.close-waitlist-btn');
    
    // Focus email input
    setTimeout(() => emailInput.focus(), 100);
    
    // Handle join waitlist
    const handleJoinWaitlist = () => {
      const email = emailInput.value.trim();
      if (email && this.isValidEmail(email)) {
        this.submitToWaitlist(email, joinBtn, popup);
      } else {
        this.showInputError(emailInput);
      }
    };
    
    joinBtn.addEventListener('click', handleJoinWaitlist);
    
    emailInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleJoinWaitlist();
      }
    });
    
    // Close handlers
    closeBtn.addEventListener('click', () => {
      backdrop.remove();
      style.remove();
    });
    
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        backdrop.remove();
        style.remove();
      }
    });
    
    document.addEventListener('keydown', function escapeHandler(e) {
      if (e.key === 'Escape') {
        backdrop.remove();
        style.remove();
        document.removeEventListener('keydown', escapeHandler);
      }
    });
  }

  showReplyGeneratorPopup() {
    console.log('✨ Opening Reply Generator');
    
    // Remove existing popup if any
    const existingPopup = document.querySelector('.reply-generator-popup');
    if (existingPopup) {
      existingPopup.remove();
    }

    // Create backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'reply-generator-popup';
    backdrop.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(12px);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      animation: fadeIn 0.2s ease-out;
    `;
    
    // Create popup container
    const popup = document.createElement('div');
    popup.style.cssText = `
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(25px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 16px;
      max-width: 600px;
      width: 90%;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25), 
                  0 0 0 1px rgba(255, 255, 255, 0.1) inset;
      animation: slideDown 0.3s ease-out;
      position: relative;
      padding: 24px;
      display: flex;
      flex-direction: column;
    `;
    
    popup.innerHTML = `
      <div class="generated-reply-container" style="
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        min-height: 300px;
        font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
      ">
        <div class="reply-placeholder" style="
          color: rgba(255, 255, 255, 0.7);
          font-size: 14px;
          text-align: center;
          padding: 40px 20px;
          line-height: 1.5;
        ">
          Select a tone below to generate your reply
        </div>
      </div>

      <div class="tone-buttons" style="display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin-bottom: 20px;">
        <button class="tone-btn" data-tone="professional" style="
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          color: rgba(255, 255, 255, 0.9);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 8px 16px;
          font-size: 12px;
          font-weight: 400;
          cursor: pointer;
          transition: all 0.2s;
          font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        ">Professional</button>
        <button class="tone-btn" data-tone="casual" style="
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          color: rgba(255, 255, 255, 0.9);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 8px 16px;
          font-size: 12px;
          font-weight: 400;
          cursor: pointer;
          transition: all 0.2s;
          font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        ">Casual</button>
        <button class="tone-btn" data-tone="brief" style="
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          color: rgba(255, 255, 255, 0.9);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 8px 16px;
          font-size: 12px;
          font-weight: 400;
          cursor: pointer;
          transition: all 0.2s;
          font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        ">Very Brief</button>
        <button class="tone-btn" data-tone="agree" style="
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          color: rgba(255, 255, 255, 0.9);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 8px 16px;
          font-size: 12px;
          font-weight: 400;
          cursor: pointer;
          transition: all 0.2s;
          font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        ">Agree</button>
        <button class="tone-btn" data-tone="decline" style="
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          color: rgba(255, 255, 255, 0.9);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 8px 16px;
          font-size: 12px;
          font-weight: 400;
          cursor: pointer;
          transition: all 0.2s;
          font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        ">Decline</button>
      </div>

      <div style="display: flex; gap: 8px;">
        <input type="text" class="feedback-input" placeholder="Provide feedback to adjust the reply..." style="
          flex: 1;
          border: 1px solid rgba(255, 255, 255, 0.3);
          border-radius: 8px;
          padding: 12px 16px;
          font-size: 13px;
          outline: none;
          transition: all 0.2s;
          box-sizing: border-box;
          background: rgba(255, 255, 255, 0.2);
          backdrop-filter: blur(10px);
          color: white;
          font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        ">
        <button class="send-feedback-btn" style="
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          color: rgba(255, 255, 255, 0.9);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 12px 16px;
          font-size: 13px;
          cursor: pointer;
          transition: all 0.2s;
          font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
        ">Send</button>
      </div>

      <button class="close-popup-btn" style="
        position: absolute;
        top: 16px;
        right: 16px;
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 50%;
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: rgba(255, 255, 255, 0.8);
        font-size: 16px;
        transition: all 0.2s;
      ">×</button>
    `;
    
    // Add styles for the popup
    const style = document.createElement('style');
    style.textContent = `
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes slideDown {
        from { 
          opacity: 0;
          transform: translateY(-20px) scale(0.98);
        }
        to { 
          opacity: 1;
          transform: translateY(0) scale(1);
        }
      }
      .tone-btn:hover {
        background: rgba(255, 255, 255, 0.25) !important;
        border-color: #1a73e8 !important;
        transform: translateY(-1px);
      }
      .feedback-input:focus {
        border-color: #1a73e8 !important;
        background: rgba(255, 255, 255, 0.25) !important;
        box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2) !important;
      }
      .feedback-input::placeholder {
        color: rgba(255, 255, 255, 0.7);
      }
      .send-feedback-btn:hover {
        background: rgba(255, 255, 255, 0.25) !important;
        border-color: #1a73e8 !important;
        transform: translateY(-1px);
      }
      .close-popup-btn:hover {
        background: rgba(255, 255, 255, 0.2) !important;
        transform: scale(1.1);
      }
      .chat-input:focus {
        border-color: #1a73e8 !important;
        background: rgba(255, 255, 255, 0.15) !important;
        box-shadow: 0 0 0 3px rgba(249, 104, 141, 0.2) !important;
      }
      .chat-input::placeholder {
        color: rgba(255, 255, 255, 0.6);
      }
      .chat-messages::-webkit-scrollbar {
        width: 4px;
      }
      .chat-messages::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 2px;
      }
      .chat-messages::-webkit-scrollbar-thumb {
        background: rgba(249, 104, 141, 0.5);
        border-radius: 2px;
      }
      .generated-reply-container::-webkit-scrollbar {
        width: 4px;
      }
      .generated-reply-container::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 2px;
      }
      .generated-reply-container::-webkit-scrollbar-thumb {
        background: rgba(249, 104, 141, 0.5);
        border-radius: 2px;
      }
    `;
    document.head.appendChild(style);
    
    backdrop.appendChild(popup);
    document.body.appendChild(backdrop);
    
    // Add event listeners
    this.addReplyGeneratorEventListeners(popup, backdrop, style);
    
    // Focus on the first tone button
    setTimeout(() => {
      const firstToneBtn = popup.querySelector('.tone-btn');
      if (firstToneBtn) firstToneBtn.focus();
    }, 100);
  }

  showInlineSummary(actionContainer) {
    console.log('✨ Showing inline email summary');
    
    // Remove existing summary if any
    const existingSummary = document.querySelector('.inline-email-summary');
    if (existingSummary) {
      existingSummary.remove();
    }

    // Create summary container
    const summaryContainer = document.createElement('div');
    summaryContainer.className = 'inline-email-summary';
    summaryContainer.style.cssText = `
      max-width: 600px;
      margin: 12px 0;
      padding: 16px;
      background: #f8f9fa;
      border: 1px solid #dadce0;
      border-radius: 8px;
      font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
      animation: slideIn 0.3s ease-out;
    `;
    
    summaryContainer.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 14px; font-weight: 500; color: #3c4043;">Email summary</span>
          <span style="font-size: 12px; font-weight: 500; color: #5f6368; background: #e8f0fe; padding: 1px 6px; border-radius: 4px;">TL;DR</span>
        </div>
        <button class="close-summary-btn" style="
          display: none;
          background: none;
          border: none;
          color: #5f6368;
          cursor: pointer;
          font-size: 16px;
          padding: 4px;
          border-radius: 4px;
          transition: all 0.1s ease;
        ">×</button>
      </div>
      <div class="summary-content" style="
        color: #3c4043;
        font-size: 13px;
        line-height: 1.5;
        min-height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="color: #5f6368; display: flex; align-items: center; gap: 8px;">
          <div style="width: 16px; height: 16px; border: 2px solid #1a73e8; border-top: 2px solid transparent; border-radius: 50%; animation: spin 1s linear infinite;"></div>
          Generating summary...
        </div>
      </div>
    `;

    // Add CSS for animations
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideIn {
        from { 
          opacity: 0;
          transform: translateY(-10px);
        }
        to { 
          opacity: 1;
          transform: translateY(0);
        }
      }
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      .close-summary-btn:hover {
        background: #f1f3f4 !important;
        color: #3c4043 !important;
      }
    `;
    document.head.appendChild(style);
    
    // Insert summary after the action container
    actionContainer.parentNode.insertBefore(summaryContainer, actionContainer.nextSibling);
    
    // Add close button event listener
    const closeBtn = summaryContainer.querySelector('.close-summary-btn');
    closeBtn.addEventListener('click', () => {
      summaryContainer.remove();
      style.remove();
    });
    
    // Generate summary immediately
    this.generateInlineSummary(summaryContainer.querySelector('.summary-content'));
  }

  async generateInlineSummary(summaryContent) {
    try {
      // Extract full thread content
      const threadContent = await this.extractFullThreadWithExpansion();
      
      if (!threadContent || !threadContent.rawContent) {
        throw new Error('Could not extract email content');
      }

      // Make API request via background script
      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
          action: 'generateSummary',
          data: {
            email_content: threadContent.rawContent,
            summary_type: 'tldr'
          }
        }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response.success) {
            resolve(response.data);
          } else {
            reject(new Error(response.error));
          }
        });
      });

      // Update the content with the generated summary
      summaryContent.innerHTML = `
        <div style="color: #3c4043; text-align: left; font-size: 13px; font-weight: 300;">
          ${response.content || response.summary || 'Summary generated successfully'}
        </div>
      `;

    } catch (error) {
      console.error('❌ Error generating summary:', error);
      
      // Show error
      summaryContent.innerHTML = `
        <div style="color: #ea4335; text-align: center;">
          ⚠️ Could not generate summary: ${error.message}
        </div>
      `;
    }
  }

  handleSupersonicSearch(query) {
    console.log('🔍 Supersonic Search:', query);
    this.showNotification('🚀 Supersonic Search feature coming soon!');
  }

  handleSupersonicAction(action, query) {
    console.log(`⚡ Supersonic Action: ${action}`, query);
    if (action === 'ai-search') {
      this.showNotification('🧠 AI Search feature coming soon!');
    } else if (action === 'smart-filter') {
      this.showNotification('🎯 Smart Filter feature coming soon!');
    }
  }

  handleUrgentEmailClick(threadId) {
    console.log('⚡ Urgent email clicked:', threadId);
    this.showNotification('⚡ Opening urgent email thread coming soon!');
  }

  // Helper methods for waitlist functionality
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  showInputError(input) {
    // Add error styling
    input.style.borderColor = '#FF6B6B';
    input.style.boxShadow = '0 0 0 3px rgba(255, 107, 107, 0.2)';
    
    // Remove error styling after 3 seconds
    setTimeout(() => {
      input.style.borderColor = 'rgba(255, 255, 255, 0.3)';
      input.style.boxShadow = 'none';
    }, 3000);
    
    // Shake animation
    input.style.animation = 'shake 0.5s ease-in-out';
    setTimeout(() => {
      input.style.animation = '';
    }, 500);
    
    // Add shake animation to styles if not already added
    if (!document.querySelector('#shake-animation')) {
      const shakeStyle = document.createElement('style');
      shakeStyle.id = 'shake-animation';
      shakeStyle.textContent = `
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
      `;
      document.head.appendChild(shakeStyle);
    }
  }

  async submitToWaitlist(email, button, popup) {
    // Update button to loading state
    const originalText = button.textContent;
    button.textContent = 'Joining...';
    button.disabled = true;
    button.style.opacity = '0.7';
    button.style.cursor = 'not-allowed';
    
    try {
      // In a real implementation, you'd send this to your backend
      // For now, we'll simulate an API call
      await this.sleep(1500);
      
      // Show success state
      this.showWaitlistSuccess(popup, email);
      
    } catch (error) {
      console.error('Error joining waitlist:', error);
      
      // Reset button on error
      button.textContent = originalText;
      button.disabled = false;
      button.style.opacity = '1';
      button.style.cursor = 'pointer';
      
      this.showNotification('❌ Something went wrong. Please try again.');
    }
  }

  showWaitlistSuccess(popup, email) {
    const flightNumber = 'SS' + Math.floor(Math.random() * 9000 + 1000);
    const seatNumber = Math.floor(Math.random() * 30 + 1) + String.fromCharCode(65 + Math.floor(Math.random() * 6));
    const boardingTime = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    
    popup.innerHTML = `
      <!-- Boarding Pass Container -->
      <div style="
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(40px);
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 20px;
        padding: 0;
        margin: 0;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        position: relative;
        overflow: hidden;
        width: 100%;
        max-width: 450px;
      ">
        <!-- Boarding Pass Header -->
        <div style="
          background: linear-gradient(135deg, #3B82F6 0%, #1E73E6 100%);
          padding: 20px;
          text-align: center;
          position: relative;
        ">
          <div style="
            font-size: 12px;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 8px;
            font-family: 'Courier New', monospace;
            letter-spacing: 3px;
          ">SUPERSONIC AIRWAYS</div>
          
          <div style="
            font-size: 24px;
            font-weight: 700;
            color: white;
            margin-bottom: 4px;
          ">BOARDING PASS</div>
          
          <div style="
            font-size: 11px;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.8);
            font-family: 'Courier New', monospace;
            letter-spacing: 1px;
          ">EARLY ACCESS RESERVED</div>
          
          <!-- Animated Plane -->
          <div style="
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 20px;
            animation: fly 2s ease-in-out infinite;
          ">✈️</div>
        </div>

        <!-- Boarding Pass Body -->
        <div style="
          background: rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(30px);
          padding: 24px;
          color: #1a1a1a;
        ">
          <!-- Flight Information Grid -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px;">
            <div>
              <div style="font-size: 10px; font-weight: 600; color: #666; margin-bottom: 4px; font-family: 'Courier New', monospace; letter-spacing: 1px;">PASSENGER</div>
              <div style="font-size: 14px; font-weight: 700; color: #1a1a1a; font-family: 'Courier New', monospace;">${email.split('@')[0].toUpperCase()}</div>
            </div>
            <div>
              <div style="font-size: 10px; font-weight: 600; color: #666; margin-bottom: 4px; font-family: 'Courier New', monospace; letter-spacing: 1px;">FLIGHT</div>
              <div style="font-size: 14px; font-weight: 700; color: #1a1a1a; font-family: 'Courier New', monospace;">${flightNumber}</div>
            </div>
            <div>
              <div style="font-size: 10px; font-weight: 600; color: #666; margin-bottom: 4px; font-family: 'Courier New', monospace; letter-spacing: 1px;">FROM</div>
              <div style="font-size: 14px; font-weight: 700; color: #1a1a1a; font-family: 'Courier New', monospace;">CURRENT</div>
            </div>
            <div>
              <div style="font-size: 10px; font-weight: 600; color: #666; margin-bottom: 4px; font-family: 'Courier New', monospace; letter-spacing: 1px;">TO</div>
              <div style="font-size: 14px; font-weight: 700; color: #1a1a1a; font-family: 'Courier New', monospace;">PRODUCTIVITY</div>
            </div>
            <div>
              <div style="font-size: 10px; font-weight: 600; color: #666; margin-bottom: 4px; font-family: 'Courier New', monospace; letter-spacing: 1px;">SEAT</div>
              <div style="font-size: 14px; font-weight: 700; color: #3B82F6; font-family: 'Courier New', monospace;">${seatNumber}</div>
            </div>
            <div>
              <div style="font-size: 10px; font-weight: 600; color: #666; margin-bottom: 4px; font-family: 'Courier New', monospace; letter-spacing: 1px;">BOARDING</div>
              <div style="font-size: 14px; font-weight: 700; color: #3B82F6; font-family: 'Courier New', monospace;">${boardingTime}</div>
            </div>
          </div>

          <!-- Boarding Status -->
          <div style="
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(52, 211, 153, 0.1) 100%);
            border: 2px solid rgba(16, 185, 129, 0.3);
            border-radius: 12px;
            padding: 16px;
            text-align: center;
            margin-bottom: 20px;
            position: relative;
            overflow: hidden;
          ">
            <div style="
              font-size: 16px;
              font-weight: 700;
              color: #10B981;
              margin-bottom: 4px;
            ">SEAT RESERVED</div>
            <div style="
              font-size: 12px;
              font-weight: 600;
              color: #059669;
              font-family: 'Courier New', monospace;
            ">You'll receive boarding instructions via email</div>
          </div>

          <!-- Social & Close Actions -->
          <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 16px;">
            <button class="share-btn" data-platform="twitter" style="
              background: #1DA1F2;
              border: none;
              border-radius: 8px;
              padding: 8px 16px;
              color: white;
              font-size: 12px;
              cursor: pointer;
              transition: all 0.3s ease;
              font-family: 'Courier New', monospace;
              font-weight: 600;
            ">SHARE FLIGHT</button>
            <button class="close-success-btn" style="
              background: rgba(59, 130, 246, 0.1);
              border: 2px solid rgba(59, 130, 246, 0.3);
              border-radius: 8px;
              padding: 8px 16px;
              color: #3B82F6;
              font-size: 12px;
              cursor: pointer;
              transition: all 0.3s ease;
              font-family: 'Courier New', monospace;
              font-weight: 600;
            ">CLOSE</button>
          </div>

          <!-- Barcode/QR Code Effect -->
          <div style="
            height: 60px;
            background: repeating-linear-gradient(
              90deg,
              #1a1a1a 0px,
              #1a1a1a 2px,
              transparent 2px,
              transparent 4px,
              #1a1a1a 4px,
              #1a1a1a 6px,
              transparent 6px,
              transparent 10px,
              #1a1a1a 10px,
              #1a1a1a 11px,
              transparent 11px,
              transparent 13px
            );
            opacity: 0.6;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
          ">
            <div style="
              background: rgba(255, 255, 255, 0.9);
              padding: 4px 12px;
              border-radius: 4px;
              font-family: 'Courier New', monospace;
              font-size: 16px;
              font-weight: 800;
              color: #1a1a1a;
              letter-spacing: 2px;
            ">${flightNumber}-${seatNumber}</div>
          </div>
        </div>

        <!-- Perforated Edge Effect -->
        <div style="
          position: absolute;
          left: 0;
          right: 0;
          height: 2px;
          background: repeating-linear-gradient(
            90deg,
            transparent 0px,
            transparent 8px,
            rgba(255, 255, 255, 0.3) 8px,
            rgba(255, 255, 255, 0.3) 12px
          );
          top: 100px;
        "></div>
      </div>
    `;

    // Add success animation
    const successStyle = document.createElement('style');
    successStyle.textContent = `
      @keyframes fly {
        0%, 100% { transform: translateX(0) translateY(0); }
        25% { transform: translateX(-3px) translateY(-2px); }
        50% { transform: translateX(0) translateY(-1px); }
        75% { transform: translateX(3px) translateY(-2px); }
      }
      @keyframes boardingPass {
        0% { transform: translateY(20px) rotateX(30deg); opacity: 0; }
        100% { transform: translateY(0) rotateX(0deg); opacity: 1; }
      }
      .boarding-pass-container {
        animation: boardingPass 0.8s ease-out;
      }
      .share-btn:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 20px rgba(29, 161, 242, 0.4) !important;
      }
      .close-success-btn:hover {
        background: rgba(59, 130, 246, 0.2) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3) !important;
      }
    `;
    document.head.appendChild(successStyle);

    // Add event listeners for new elements
    const closeBtn = popup.querySelector('.close-success-btn');
    const shareButtons = popup.querySelectorAll('.share-btn');

    closeBtn.addEventListener('click', () => {
      const backdrop = popup.closest('.supersonic-waitlist-popup');
      if (backdrop) backdrop.remove();
      successStyle.remove();
    });

    shareButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const platform = btn.dataset.platform;
        this.handleSocialShare(platform);
      });
    });

    // Auto-close after 10 seconds
    // setTimeout(() => {
    //   const backdrop = popup.closest('.supersonic-waitlist-popup');
    //   if (backdrop) backdrop.remove();
    //   successStyle.remove();
    // }, 10000);
  }

  handleSocialShare(platform) {
    const text = "I just joined the waitlist for Supersonic - the future of email productivity! 🚀";
    const url = "https://gosupersonic.email"; // Replace with your actual URL
    
    let shareUrl = '';
    
    if (platform === 'twitter') {
      shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
    } else if (platform === 'linkedin') {
      shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank', 'width=600,height=400');
      this.showNotification('Thanks for sharing! 🙌');
    }
  }

  async fetchUrgentEmails() {
    try {
      // TODO: Replace with your actual API endpoint
      const response = await fetch(CONFIG.ENDPOINTS.URGENT_EMAILS, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          // TODO: Add your auth token here
          // 'Authorization': `Bearer ${your_token}`
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data.urgent_emails || [];
    } catch (error) {
      console.error('Failed to fetch urgent emails:', error);
      // Return mock data for now
      return UrgentEmailsComponent.getMockData();
    }
  }

  injectSendConfirmation() {
    // Find all send buttons that haven't been processed - expanded selectors
    const sendButtons = document.querySelectorAll(`
      [data-tooltip="Send ‪(Ctrl+Enter)‬"], 
      [data-tooltip="Send"], 
      [aria-label="Send"], 
      [data-tooltip^="Send"],
      [role="button"][aria-label*="Send"],
      .T-I.J-J5-Ji.aoO.v7.T-I-atl.L3,
      .T-I.J-J5-Ji.aoO.T-I-atl.L3,
      div[tabindex="0"][role="button"][aria-label*="Send"]
    `.replace(/\s+/g, ' ').trim());
    
    console.log('Supersonic: Found', sendButtons.length, 'send buttons');
    
    sendButtons.forEach(button => {
      if (!button.dataset.supersonicSendConfirmation) {
        button.dataset.supersonicSendConfirmation = 'true';
        
        // Add our confirmation handler for click events
        const clickHandler = async (e) => {
          console.log('Supersonic: Send button clicked!');
          
          // Always prevent default first to stop Gmail from sending
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          
          // Check if the user has disabled this feature
          const isFeatureEnabled = await this.isEmailConfirmationEnabled();
          
          if (!isFeatureEnabled) {
            console.log('Supersonic: Feature disabled, proceeding with send');
            // Feature is disabled, manually trigger send by removing our listener temporarily
            button.removeEventListener('click', clickHandler, true);
            
            // Trigger the original click
            setTimeout(() => {
              button.click();
              // Re-add our listener
              setTimeout(() => {
                button.addEventListener('click', clickHandler, true);
              }, 100);
            }, 10);
            return;
          }
          
          // Feature is enabled, show popup
          console.log('Supersonic: Showing send confirmation popup');
          this.showSendConfirmationPopup(button);
        };
        
        // Store the click handler on the button for later reference
        button._supersonicClickHandler = clickHandler;
        
        // Add click listener with capture phase to intercept before Gmail
        button.addEventListener('click', clickHandler, true);
      }
    });

    

    // Add keyboard listener for Cmd+Enter / Ctrl+Enter
    if (!document.body.dataset.supersonicKeyboardListener) {
      document.body.dataset.supersonicKeyboardListener = 'true';
      
      // Store reference to this for use in event listener
      const self = this;
      
      document.addEventListener('keydown', async (e) => {
        // Check for Cmd+Enter (Mac) or Ctrl+Enter (Windows/Linux)
        if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
          console.log('Supersonic: Keyboard shortcut detected', e.metaKey, e.ctrlKey, e.key);
          
          // Check if we should bypass confirmation
          if (window.supersonicBypassConfirmation) {
            console.log('Supersonic: Bypassing confirmation');
            return; // Let the normal keyboard shortcut proceed
          }
          
          // Check if we're in a compose area first
          const keyboardActiveElement = document.activeElement;
          console.log('Supersonic: Active element:', keyboardActiveElement);
          
          // Enhanced selectors for Gmail compose areas
          const keyboardComposeArea = keyboardActiveElement.closest('[role="textbox"]') || 
                             keyboardActiveElement.closest('.Am.Al.editable') || 
                             keyboardActiveElement.closest('[contenteditable="true"]') ||
                             keyboardActiveElement.closest('.editable') ||
                             keyboardActiveElement.closest('[aria-label*="Message Body"]') ||
                             keyboardActiveElement.closest('.Ar.Au') ||
                             keyboardActiveElement.closest('[data-tooltip*="Message body"]');
          
          console.log('Supersonic: Compose area found:', keyboardComposeArea);
          
          if (!keyboardComposeArea) {
            console.log('Supersonic: Not in compose area');
            return; // Not in compose area, let normal behavior proceed
          }
          
          // Always prevent default first to stop Gmail from sending
          e.preventDefault();
          e.stopPropagation();
          
          // Check if the user has disabled this feature
          const isFeatureEnabled = await self.isEmailConfirmationEnabled();
          if (!isFeatureEnabled) {
            console.log('Supersonic: Feature disabled by user');
            // Feature is disabled, manually trigger keyboard shortcut
            window.supersonicBypassConfirmation = true;
            setTimeout(() => {
              // Simulate the original keyboard shortcut
              const keyEvent = new KeyboardEvent('keydown', {
                key: 'Enter',
                code: 'Enter',
                keyCode: 13,
                which: 13,
                metaKey: e.metaKey,
                ctrlKey: e.ctrlKey,
                bubbles: true,
                cancelable: true
              });
              
                             keyboardActiveElement.dispatchEvent(keyEvent);
              
              setTimeout(() => {
                window.supersonicBypassConfirmation = false;
              }, 1000);
            }, 10);
            return;
          }
          
          // Find the associated send button and show popup
          const composeContainer = keyboardComposeArea.closest('.M9') || 
                                 keyboardComposeArea.closest('.Ar') || 
                                 keyboardComposeArea.closest('[role="dialog"]') ||
                                 keyboardComposeArea.closest('.nH') ||
                                 keyboardComposeArea.closest('form') ||
                                 keyboardComposeArea.closest('.J-J5-Ji') ||
                                 keyboardComposeArea.closest('.J-M.J-JN-I') ||
                                 keyboardComposeArea.closest('.AD') ||
                                 keyboardComposeArea.closest('.J-M') ||
                                 keyboardComposeArea.closest('.J-J5-Ji.J-JN-I') ||
                                 keyboardComposeArea.closest('.Ar.Au') ||
                                 keyboardComposeArea.closest('[role="dialog"]') ||
                                 document.querySelector('.nH.if'); // Last resort - compose window
          
          console.log('Supersonic: Compose container found:', composeContainer);
          
          if (composeContainer) {
            // Enhanced send button search
            const sendButton = composeContainer.querySelector('[data-tooltip="Send ‪(Ctrl+Enter)‬"]') ||
                             composeContainer.querySelector('[data-tooltip="Send"]') ||
                             composeContainer.querySelector('[aria-label="Send"]') ||
                             composeContainer.querySelector('[data-tooltip^="Send"]') ||
                             composeContainer.querySelector('.T-I.J-J5-Ji.aoO.v7.T-I-atl.L3') ||
                             composeContainer.querySelector('.T-I.J-J5-Ji.aoO.T-I-atl.L3') ||
                             composeContainer.querySelector('[role="button"][aria-label*="Send"]') ||
                             composeContainer.querySelector('div[tabindex="0"][role="button"][aria-label*="Send"]');
            
            console.log('Supersonic: Send button found:', sendButton);
            
            if (sendButton) {
              console.log('Supersonic: Showing confirmation popup');
              self.showSendConfirmationPopup(sendButton, true);
            } else {
              console.log('Supersonic: No send button found');
            }
          } else {
            console.log('Supersonic: No compose container found');
          }
        }
      }, true);
    }
  }

  showSendConfirmationPopup(sendButton, wasKeyboardShortcut = false) {
    // Remove existing popup if any
    const existingPopup = document.querySelector('.supersonic-send-confirmation-popup');
    if (existingPopup) {
      existingPopup.remove();
    }
    
    // Create backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'supersonic-send-confirmation-popup';
    backdrop.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(12px);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      animation: fadeIn 0.3s ease-out;
    `;
    
    // Create popup container
    const popup = document.createElement('div');
    popup.style.cssText = `
      background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(30, 115, 230, 0.1) 100%);
      backdrop-filter: blur(25px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 20px;
      max-width: 450px;
      width: 90%;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25), 
                  0 0 0 1px rgba(255, 255, 255, 0.1) inset;
      animation: slideUp 0.4s ease-out;
      position: relative;
      padding: 40px 32px;
      text-align: center;
    `;
    
    popup.innerHTML = `
      <!-- Close button -->
      <button class="close-send-confirmation-btn" style="
        position: absolute;
        top: 20px;
        right: 20px;
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 50%;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: rgba(255, 255, 255, 0.9);
        font-size: 20px;
        transition: all 0.3s ease;
        font-weight: 300;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      ">×</button>

      <!-- Send Confirmation Header -->
      <div style="
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(30px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 16px;
        padding: 20px;
        margin-bottom: 24px;
        text-align: center;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      ">
        <h2 style="
          font-size: 22px;
          font-weight: 700;
          color: rgba(255, 255, 255, 0.95);
          margin: 0 0 8px 0;
          font-family: 'Google Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        ">Send Confirmation</h2>
        
        <p style="
          font-size: 14px;
          color: rgba(255, 255, 255, 0.7);
          margin: 0;
          font-family: 'Google Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        ">Are you sure you want to send this email?</p>
      </div>

      <!-- Action Buttons -->
      <div style="
        display: flex;
        gap: 12px;
        justify-content: center;
        margin-top: 24px;
      ">
        <button class="cancel-send-btn" style="
          background: rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(20px);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 12px;
          padding: 12px 24px;
          color: rgba(255, 255, 255, 0.9);
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.3s ease;
          font-family: 'Google Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        ">Cancel</button>
        
        <button class="confirm-send-btn" style="
          background: linear-gradient(135deg, #3B82F6 0%, #1E73E6 100%);
          border: none;
          border-radius: 12px;
          padding: 12px 24px;
          color: white;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.3s ease;
          font-family: 'Google Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          box-shadow: 0 4px 16px rgba(59, 130, 246, 0.4);
        ">Send Email</button>
      </div>
      
      <!-- Disable Feature Button -->
      <div style="
        text-align: center;
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
      ">
        <button class="disable-feature-btn" style="
          background: none;
          border: none;
          color: rgba(255, 255, 255, 0.6);
          font-size: 12px;
          font-weight: 400;
          cursor: pointer;
          transition: all 0.3s ease;
          font-family: 'Google Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          text-decoration: underline;
          text-underline-offset: 2px;
          padding: 4px 8px;
        ">Disable this feature</button>
      </div>
    `;
    
    backdrop.appendChild(popup);
    
    // Add event listeners
    const closeBtn = popup.querySelector('.close-send-confirmation-btn');
    const cancelBtn = popup.querySelector('.cancel-send-btn');
    const confirmBtn = popup.querySelector('.confirm-send-btn');
    const disableBtn = popup.querySelector('.disable-feature-btn');
    
    const closePopup = () => {
      backdrop.remove();
    };
    
    const sendEmail = () => {
      backdrop.remove();
      
      // Find and temporarily remove our click listener
      const clickHandler = sendButton._supersonicClickHandler;
      if (clickHandler) {
        sendButton.removeEventListener('click', clickHandler, true);
      }
      
      // If this was triggered by a keyboard shortcut, simulate Cmd+Enter
      if (wasKeyboardShortcut) {
        setTimeout(() => {
          // Find the compose area and focus it
          const composeArea = sendButton.closest('.M9') || sendButton.closest('.Ar') || sendButton.closest('[role="dialog"]');
          const textArea = composeArea?.querySelector('[role="textbox"], [contenteditable="true"]');
          
          if (textArea) {
            textArea.focus();
            
            // Simulate Cmd+Enter / Ctrl+Enter
            const keyEvent = new KeyboardEvent('keydown', {
              key: 'Enter',
              code: 'Enter',
              keyCode: 13,
              which: 13,
              metaKey: navigator.platform.includes('Mac'), // Use metaKey for Mac
              ctrlKey: !navigator.platform.includes('Mac'), // Use ctrlKey for Windows/Linux
              bubbles: true,
              cancelable: true
            });
            
            textArea.dispatchEvent(keyEvent);
          } else {
            // Fallback to button click
            sendButton.click();
          }
          
          // Re-add our listener after a delay
          setTimeout(() => {
            if (clickHandler) {
              sendButton.addEventListener('click', clickHandler, true);
            }
          }, 1000);
        }, 100);
      } else {
        // Trigger the send button click without our handler
        setTimeout(() => {
          sendButton.click();
          
          // Re-add our listener after a delay
          setTimeout(() => {
            if (clickHandler) {
              sendButton.addEventListener('click', clickHandler, true);
            }
          }, 1000);
        }, 100);
      }
    };
    
    const disableFeature = async () => {
      try {
        // Get the user's token from storage
        const token = await this.getStoredToken();
        
        if (!token) {
          this.showNotification('Please set your extension token first');
          return;
        }
        
        // Call the API to disable email confirmation
        const response = await fetch(CONFIG.ENDPOINTS.USER_SETTINGS, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Token ${token}`
          },
          body: JSON.stringify({
            email_confirmation: false
          })
        });
        
        if (response.ok) {
          // Store the setting locally for immediate use
          localStorage.setItem('supersonic_email_confirmation', 'false');
          
          // Close the popup
          closePopup();
          
          // Show success notification
          this.showNotification('Send confirmation disabled');
          
          // Proceed with sending the email
          const clickHandler = sendButton._supersonicClickHandler;
          if (clickHandler) {
            sendButton.removeEventListener('click', clickHandler, true);
          }
          
          setTimeout(() => {
            sendButton.click();
            
            setTimeout(() => {
              if (clickHandler) {
                sendButton.addEventListener('click', clickHandler, true);
              }
            }, 1000);
          }, 10);
        } else {
          const errorData = await response.json();
          this.showNotification(`Error: ${errorData.error || 'Failed to disable feature'}`);
        }
      } catch (error) {
        console.error('Error disabling feature:', error);
        
        // Check if it's a blocked request (ad blocker)
        if (error.message.includes('Failed to fetch') || error.toString().includes('ERR_BLOCKED_BY_CLIENT')) {
          // Fallback: disable locally and proceed with sending
          localStorage.setItem('supersonic_email_confirmation', 'false');
          
          // Close the popup
          closePopup();
          
          // Show informative notification
          this.showNotification('Feature disabled locally (backend blocked by ad blocker)');
          
          // Proceed with sending the email
          const clickHandler = sendButton._supersonicClickHandler;
          if (clickHandler) {
            sendButton.removeEventListener('click', clickHandler, true);
          }
          
          setTimeout(() => {
            sendButton.click();
            
            setTimeout(() => {
              if (clickHandler) {
                sendButton.addEventListener('click', clickHandler, true);
              }
            }, 1000);
          }, 10);
        } else {
          this.showNotification('Error disabling feature');
        }
      }
    };
    
    // Button event listeners
    closeBtn.addEventListener('click', closePopup);
    cancelBtn.addEventListener('click', closePopup);
    confirmBtn.addEventListener('click', sendEmail);
    disableBtn.addEventListener('click', disableFeature);
    
    // Close on backdrop click
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        closePopup();
      }
    });
    
    // Close on Escape key
    document.addEventListener('keydown', function escapeHandler(e) {
      if (e.key === 'Escape') {
        closePopup();
        document.removeEventListener('keydown', escapeHandler);
      }
    });
    
    // Add hover effects
    cancelBtn.addEventListener('mouseenter', () => {
      cancelBtn.style.background = 'rgba(255, 255, 255, 0.2)';
      cancelBtn.style.transform = 'translateY(-2px)';
      cancelBtn.style.boxShadow = '0 6px 20px rgba(0, 0, 0, 0.15)';
    });
    
    cancelBtn.addEventListener('mouseleave', () => {
      cancelBtn.style.background = 'rgba(255, 255, 255, 0.1)';
      cancelBtn.style.transform = 'translateY(0)';
      cancelBtn.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.1)';
    });
    
    confirmBtn.addEventListener('mouseenter', () => {
      confirmBtn.style.background = 'linear-gradient(135deg, #2563EB 0%, #1D4ED8 100%)';
      confirmBtn.style.transform = 'translateY(-2px)';
      confirmBtn.style.boxShadow = '0 6px 20px rgba(59, 130, 246, 0.6)';
    });
    
    confirmBtn.addEventListener('mouseleave', () => {
      confirmBtn.style.background = 'linear-gradient(135deg, #3B82F6 0%, #1E73E6 100%)';
      confirmBtn.style.transform = 'translateY(0)';
      confirmBtn.style.boxShadow = '0 4px 16px rgba(59, 130, 246, 0.4)';
    });
    
    disableBtn.addEventListener('mouseenter', () => {
      disableBtn.style.color = 'rgba(255, 255, 255, 0.8)';
      disableBtn.style.background = 'rgba(255, 255, 255, 0.05)';
      disableBtn.style.borderRadius = '6px';
    });
    
    disableBtn.addEventListener('mouseleave', () => {
      disableBtn.style.color = 'rgba(255, 255, 255, 0.6)';
      disableBtn.style.background = 'none';
      disableBtn.style.borderRadius = '0';
    });
    
    document.body.appendChild(backdrop);
  }

  async getStoredToken() {
    // Try to get from chrome.storage if available
    if (typeof chrome !== 'undefined' && chrome.storage) {
      try {
        // Try multiple possible key names
        const possibleKeys = ['supersonicToken', 'extensionToken', 'token', 'supersonic_token'];
        const result = await chrome.storage.local.get(possibleKeys);
        
        console.log('Supersonic: Chrome storage contents:', result);
        
        // Check all possible keys
        for (const key of possibleKeys) {
          if (result[key]) {
            console.log(`Supersonic: Found token under key: ${key}`);
            return result[key];
          }
        }
        
        // If no token found, get all storage contents for debugging
        const allStorage = await chrome.storage.local.get(null);
        console.log('Supersonic: All chrome storage contents:', allStorage);
        
      } catch (error) {
        console.error('Error getting token from chrome.storage:', error);
      }
    }
    
    // Fallback to localStorage with multiple possible keys
    const localStorageKeys = ['supersonic_token', 'supersonicToken', 'extensionToken', 'token'];
    for (const key of localStorageKeys) {
      const token = localStorage.getItem(key);
      if (token) {
        console.log(`Supersonic: Found token in localStorage under key: ${key}`);
        return token;
      }
    }
    
    console.log('Supersonic: No token found in any storage location');
    return null;
  }

  async isEmailConfirmationEnabled() {
    // Check local storage first for immediate response
    const localSetting = localStorage.getItem('supersonic_email_confirmation');
    console.log('Supersonic: Local email confirmation setting:', localSetting);
    
    if (localSetting === 'false') {
      console.log('Supersonic: Email confirmation disabled locally');
      return false;
    }
    
    // If not explicitly disabled locally, check with the backend
    try {
      const token = await this.getStoredToken();
      console.log('Supersonic: Got token for settings check:', token ? 'Yes' : 'No');
      
      if (!token) {
        console.log('Supersonic: No token, assuming feature is enabled');
        // If no token, assume feature is enabled (default)
        return true;
      }
      
      const response = await fetch(CONFIG.ENDPOINTS.USER_SETTINGS, {
        method: 'GET',
        headers: {
          'Authorization': `Token ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        const isEnabled = data.email_confirmation !== false;
        console.log('Supersonic: Backend email confirmation setting:', data.email_confirmation, 'isEnabled:', isEnabled);
        
        // Update local storage for faster future checks
        localStorage.setItem('supersonic_email_confirmation', isEnabled.toString());
        
        return isEnabled;
      } else {
        console.error('Error fetching user settings:', response.status);
        // If API call fails, assume feature is enabled
        return true;
      }
    } catch (error) {
      console.error('Error checking email confirmation setting:', error);
      
      // If it's a blocked request (ad blocker), rely on local storage
      if (error.message.includes('Failed to fetch') || error.toString().includes('ERR_BLOCKED_BY_CLIENT')) {
        console.log('Supersonic: Backend blocked by ad blocker, using local setting');
        // Return current local setting (default to enabled if not set)
        return localStorage.getItem('supersonic_email_confirmation') !== 'false';
      }
      
      // For other errors, assume feature is enabled
      return true;
    }
  }

  injectEmailHoverPreviews() {
    // Find email rows in the inbox
    const emailRows = document.querySelectorAll('tr[role="row"]');
    
    emailRows.forEach(row => {
      // Skip if already processed
      if (row.dataset.supersonicHoverProcessed) return;
      
      // Mark as processed
      row.dataset.supersonicHoverProcessed = 'true';
      
      let hoverTimeout;
      
      // Mouse enter handler
      const handleMouseEnter = (e) => {
        // Clear any existing timeouts
        clearTimeout(hoverTimeout);
        this.cancelHideTimeout();
        
        // Set a delay before showing preview (prevents accidental triggers)
        hoverTimeout = setTimeout(() => {
          this.showEmailPreview(row, e);
        }, 800); // 800ms delay
      };
      
      // Mouse leave handler
      const handleMouseLeave = () => {
        clearTimeout(hoverTimeout);
        
        // Add delay before hiding to allow mouse movement to popup
        this.scheduleHideTimeout();
      };
      
      // Add event listeners
      row.addEventListener('mouseenter', handleMouseEnter);
      row.addEventListener('mouseleave', handleMouseLeave);
      
      // Store cleanup function
      row._supersonicCleanup = () => {
        row.removeEventListener('mouseenter', handleMouseEnter);
        row.removeEventListener('mouseleave', handleMouseLeave);
        clearTimeout(hoverTimeout);
      };
    });

    // Add global event listeners to hide preview on scroll or click
    if (!document.body.dataset.supersonicPreviewListeners) {
      document.body.dataset.supersonicPreviewListeners = 'true';
      
      // Hide on scroll
      document.addEventListener('scroll', () => {
        this.hideEmailPreview();
      }, true);
      
      // Hide on click outside (but not on send buttons)
      document.addEventListener('click', (e) => {
        if (this.currentPreview && !this.currentPreview.contains(e.target)) {
          // Don't hide if clicking on send buttons - let send confirmation handle it
          const isSendButton = e.target.getAttribute('data-tooltip')?.includes('Send') ||
                              e.target.getAttribute('aria-label')?.includes('Send') ||
                              e.target.textContent?.trim() === 'Send' ||
                              e.target.classList.contains('T-I-atl') && e.target.textContent?.includes('Send');
          
          if (!isSendButton) {
            this.hideEmailPreview();
          }
        }
      }, true);
      
      // Hide on Escape key
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          this.hideEmailPreview();
        }
      });
    }
  }

  showEmailPreview(emailRow, mouseEvent) {
    // Hide any existing preview
    this.hideEmailPreview();
    
    // Extract email data from the row
    const emailData = this.extractEmailRowData(emailRow);
    
    if (!emailData) return;
    
    // Create preview popup
    const preview = document.createElement('div');
    preview.className = 'supersonic-email-preview';
    preview.style.cssText = `
      position: fixed;
      background: white;
      border: 1px solid #e0e0e0;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12);
      max-width: 400px;
      min-width: 300px;
      max-height: 500px;
      z-index: 10000;
      padding: 16px;
      font-family: 'Google Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      overflow: hidden;
      animation: fadeInScale 0.2s ease-out;
    `;
    
    // Position near the cursor
    const x = Math.min(mouseEvent.clientX + 20, window.innerWidth - 420);
    const y = Math.min(mouseEvent.clientY - 20, window.innerHeight - 520);
    preview.style.left = `${x}px`;
    preview.style.top = `${y}px`;
    
    // Preview content
    preview.innerHTML = `
      <div style="display: flex; align-items: center; margin-bottom: 12px;">
        <div style="
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: linear-gradient(135deg, #4285f4 0%, #34a853 50%, #fbbc05 75%, #ea4335 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-weight: 600;
          font-size: 14px;
          margin-right: 12px;
        ">${this.getInitials(emailData.sender)}</div>
        <div style="flex: 1; min-width: 0;">
          <div style="
            font-weight: 600;
            font-size: 14px;
            color: #202124;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          ">${this.escapeHtml(emailData.sender)}</div>
          <div style="
            font-size: 12px;
            color: #5f6368;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          ">${this.escapeHtml(emailData.timestamp)}</div>
        </div>
        ${emailData.isUnread ? '<div style="width: 8px; height: 8px; background: #1a73e8; border-radius: 50%; margin-left: 8px;"></div>' : ''}
      </div>
      
      <div style="
        font-weight: 600;
        font-size: 14px;
        color: #202124;
        margin-bottom: 8px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      ">${this.escapeHtml(emailData.subject)}</div>
      
      <div style="
        font-size: 13px;
        color: #5f6368;
        line-height: 1.4;
        max-height: 120px;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 6;
        -webkit-box-orient: vertical;
      ">${this.escapeHtml(emailData.snippet)}</div>
      
      ${emailData.hasAttachments ? `
        <div style="
          margin-top: 12px;
          padding-top: 12px;
          border-top: 1px solid #e8eaed;
          display: flex;
          align-items: center;
          font-size: 12px;
          color: #5f6368;
        ">
          <svg style="width: 16px; height: 16px; margin-right: 6px;" viewBox="0 0 24 24" fill="currentColor">
            <path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/>
          </svg>
          Has attachments
        </div>
      ` : ''}
      
      <div style="
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid #e8eaed;
        display: flex;
        gap: 8px;
      ">
        <button class="preview-reply-btn" style="
          background: #1a73e8;
          color: white;
          border: none;
          border-radius: 6px;
          padding: 6px 12px;
          font-size: 12px;
          font-weight: 500;
          cursor: pointer;
          transition: background 0.2s;
        ">Reply</button>
        <button class="preview-archive-btn" style="
          background: #f8f9fa;
          color: #5f6368;
          border: 1px solid #e8eaed;
          border-radius: 6px;
          padding: 6px 12px;
          font-size: 12px;
          font-weight: 500;
          cursor: pointer;
          transition: background 0.2s;
        ">Archive</button>
        <button class="preview-open-btn" style="
          background: #f8f9fa;
          color: #5f6368;
          border: 1px solid #e8eaed;
          border-radius: 6px;
          padding: 6px 12px;
          font-size: 12px;
          font-weight: 500;
          cursor: pointer;
          transition: background 0.2s;
        ">Open</button>
      </div>
    `;
    
    // Add hover effects to buttons
    const replyBtn = preview.querySelector('.preview-reply-btn');
    const archiveBtn = preview.querySelector('.preview-archive-btn');
    const openBtn = preview.querySelector('.preview-open-btn');
    
    replyBtn.addEventListener('mouseenter', () => replyBtn.style.background = '#1557b2');
    replyBtn.addEventListener('mouseleave', () => replyBtn.style.background = '#1a73e8');
    
    archiveBtn.addEventListener('mouseenter', () => archiveBtn.style.background = '#f1f3f4');
    archiveBtn.addEventListener('mouseleave', () => archiveBtn.style.background = '#f8f9fa');
    
    openBtn.addEventListener('mouseenter', () => openBtn.style.background = '#f1f3f4');
    openBtn.addEventListener('mouseleave', () => openBtn.style.background = '#f8f9fa');
    
    // Add button click handlers
    replyBtn.addEventListener('click', () => {
      this.hideEmailPreview();
      this.openEmailForReply(emailRow);
    });
    
    archiveBtn.addEventListener('click', () => {
      this.hideEmailPreview();
      this.archiveEmail(emailRow);
    });
    
    openBtn.addEventListener('click', () => {
      this.hideEmailPreview();
      this.openEmail(emailRow);
    });
    
    // Add CSS animation if not already added
    if (!document.getElementById('supersonic-preview-styles')) {
      const style = document.createElement('style');
      style.id = 'supersonic-preview-styles';
      style.textContent = `
        @keyframes fadeInScale {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
      `;
      document.head.appendChild(style);
    }
    
    // Add hover handlers to keep preview visible when mouse is over it
    preview.addEventListener('mouseenter', () => {
      // Cancel any pending hide timeout when mouse enters the preview
      this.cancelHideTimeout();
    });
    
    preview.addEventListener('mouseleave', () => {
      // Hide preview when mouse leaves the popup (with small delay)
      this.scheduleHideTimeout();
    });
    
    // Store reference and add to DOM
    this.currentPreview = preview;
    document.body.appendChild(preview);
  }

  hideEmailPreview() {
    if (this.currentPreview) {
      this.currentPreview.remove();
      this.currentPreview = null;
    }
    // Clear any pending hide timeout
    this.cancelHideTimeout();
  }

  scheduleHideTimeout() {
    // Clear any existing hide timeout
    this.cancelHideTimeout();
    
    // Schedule new hide timeout
    this.hideTimeout = setTimeout(() => {
      this.hideEmailPreview();
    }, 300); // 300ms grace period
  }

  cancelHideTimeout() {
    if (this.hideTimeout) {
      clearTimeout(this.hideTimeout);
      this.hideTimeout = null;
    }
  }

  extractEmailRowData(emailRow) {
    try {
      // Gmail inbox row selectors
      const senderElement = emailRow.querySelector('span[email]') || 
                           emailRow.querySelector('.go span[title]') ||
                           emailRow.querySelector('.yW span[title]');
      
      const subjectElement = emailRow.querySelector('.bog') ||
                            emailRow.querySelector('span[id^="thread-"]:not([email])');
      
      const snippetElement = emailRow.querySelector('.y2');
      
      const timestampElement = emailRow.querySelector('.xY span[title]') ||
                              emailRow.querySelector('.xY span');
      
      const unreadIndicator = emailRow.querySelector('.pk');
      
      const attachmentIndicator = emailRow.querySelector('.yf') ||
                                 emailRow.querySelector('[aria-label*="attachment"]');
      
      return {
        sender: senderElement?.textContent?.trim() || senderElement?.title || 'Unknown Sender',
        subject: subjectElement?.textContent?.trim() || 'No Subject',
        snippet: snippetElement?.textContent?.trim() || 'No preview available',
        timestamp: timestampElement?.title || timestampElement?.textContent?.trim() || '',
        isUnread: !!unreadIndicator,
        hasAttachments: !!attachmentIndicator
      };
    } catch (error) {
      console.error('Error extracting email row data:', error);
      return null;
    }
  }

  getInitials(name) {
    if (!name) return '?';
    return name.split(' ')
      .map(word => word.charAt(0))
      .join('')
      .substring(0, 2)
      .toUpperCase();
  }

  escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  openEmailForReply(emailRow) {
    // Click the email row to open it, then trigger reply
    emailRow.click();
    setTimeout(() => {
      // Look for reply button and click it
      const replyBtn = document.querySelector('[data-tooltip="Reply"]') ||
                      document.querySelector('[aria-label="Reply"]');
      if (replyBtn) {
        replyBtn.click();
      }
    }, 1000);
  }

  archiveEmail(emailRow) {
    // Look for archive button in the row or use Gmail keyboard shortcut
    const archiveBtn = emailRow.querySelector('[data-tooltip="Archive"]') ||
                      emailRow.querySelector('[aria-label="Archive"]');
    
    if (archiveBtn) {
      archiveBtn.click();
    } else {
      // Fallback: select the email and use keyboard shortcut
      emailRow.click();
      setTimeout(() => {
        // Simulate 'e' key for archive
        const event = new KeyboardEvent('keydown', {
          key: 'e',
          code: 'KeyE',
          which: 69,
          keyCode: 69,
          bubbles: true
        });
        document.dispatchEvent(event);
      }, 100);
    }
  }

  openEmail(emailRow) {
    // Simply click the email row to open it
    emailRow.click();
  }

  injectGenerateReplyButton() {
    // Look for compose/reply areas
    const composeAreas = document.querySelectorAll('[role="textbox"][aria-label*="Message Body"]');
    
    composeAreas.forEach(composeArea => {
      if (!composeArea.parentElement.querySelector('.generate-reply-injected')) {
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'generate-reply-container generate-reply-injected';
        buttonContainer.innerHTML = `
          <button class="generate-reply-btn">
            Generate Reply
          </button>
          <button class="enhance-reply-btn">
            <span class="btn-icon">🚀</span>
            Enhance Text
          </button>
        `;
        buttonContainer.style.cssText = `
          display: none;
        `;

        // Insert button above the compose area
        composeArea.parentElement.insertBefore(buttonContainer, composeArea);

        // Add event listeners
        this.addReplyEventListeners(buttonContainer);
      }
    });

    // Also look for Gmail compose toolbar (bottom toolbar with Send button)
    this.injectGenerateReplyIntoToolbar();
  }

  injectGenerateReplyIntoToolbar() {
    // Look for Gmail compose toolbar (table with class "IZ")
    const composeToolbars = document.querySelectorAll('table.IZ[role="group"]');
    
    composeToolbars.forEach(toolbar => {
      // Check if we already injected into this toolbar
      if (toolbar.querySelector('.supersonic-generate-reply-injected')) {
        return;
      }

      // Find the Send button cell (first cell with class "gU Up")
      const sendButtonCell = toolbar.querySelector('td.gU.Up');
      
      if (sendButtonCell) {
        // Find the Send button container - try different structures
        const sendButtonContainer = sendButtonCell.querySelector('.J-J5-Ji.btA');
        
        if (sendButtonContainer) {
          // Check if there's a .dC container (newer Gmail structure)
          const dcContainer = sendButtonContainer.querySelector('.dC');
          const insertionTarget = dcContainer || sendButtonContainer;
          
          // Create generate reply button with prominent styling
          const generateReplyBtn = document.createElement('div');
          generateReplyBtn.className = 'T-I J-J5-Ji T-I-atl L3 supersonic-generate-reply-injected';
          generateReplyBtn.setAttribute('data-tooltip', 'Generate Reply with AI');
          generateReplyBtn.setAttribute('aria-label', 'Generate Reply with AI');
          generateReplyBtn.setAttribute('tabindex', '1');
          generateReplyBtn.setAttribute('role', 'button');
          generateReplyBtn.style.cssText = `
            user-select: none;
            cursor: pointer;
            background: #f8f9fa;
            color: #3c4043;
            border: 1px solid #dadce0;
            border-radius: 8px;
            padding: 8px 14px;
            margin-right: 12px;
            font-size: 13px;
            font-weight: 300;
            font-family: 'Google Sans',Roboto,RobotoDraft,Helvetica,Arial,sans-serif;
            transition: all 0.1s ease;
            display: flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
            height: 32px;
            outline: none;
            flex-shrink: 0;
          `;
          
          generateReplyBtn.innerHTML = `
            <span>Generate</span>
          `;

          // Add hover effects
          generateReplyBtn.addEventListener('mouseenter', () => {
            generateReplyBtn.style.background = '#e8f0fe';
            generateReplyBtn.style.borderColor = '#1a73e8';
            generateReplyBtn.style.color = '#1a73e8';
          });

          generateReplyBtn.addEventListener('mouseleave', () => {
            generateReplyBtn.style.background = '#f8f9fa';
            generateReplyBtn.style.borderColor = '#dadce0';
            generateReplyBtn.style.color = '#3c4043';
          });

          // Add click handler
          generateReplyBtn.addEventListener('click', () => {
            this.handleGenerateReply();
          });

          // Insert the button as a sibling to the send button container, not inside it
          // This prevents it from being part of the send button's hover group
          sendButtonContainer.insertBefore(generateReplyBtn, insertionTarget);
          
          console.log('✅ Generate Reply button injected as separate element before Send button container');
        }
      }
    });
  }

  injectEmailActionButtons() {
    const containers = document.querySelectorAll('.ha');
    
    containers.forEach((container, index) => {
      const threadContainer = container.closest('[data-legacy-thread-id]') || container.closest('[role="main"]') || container;
      if (threadContainer.querySelector('.email-summary-injected')) {
        return;
      }
      
      const targetDiv = container.querySelector('.dJ');
      if (targetDiv) {
        console.log('✅ Found .dJ target, injecting TL;DR summary');
        this.createAndInjectSummary(targetDiv);
      } else {
        console.log('❌ No .dJ found, trying to append to .ha');
        this.createAndInjectSummary(container);
      }
    });
  }

  createAndInjectSummary(targetElement) {
    // Double check we're not already injected here
    if (targetElement.querySelector('.email-summary-injected')) {
      console.log('⚠️ Summary already exists here, skipping');
      return;
    }
    
    // Create a placeholder container to mark injection
    const placeholderContainer = document.createElement('div');
    placeholderContainer.className = 'email-summary-injected';
    placeholderContainer.style.display = 'none';
    targetElement.appendChild(placeholderContainer);
    
    console.log('✅ TL;DR summary placeholder injected');
    
    // Automatically show TL;DR summary
    setTimeout(() => {
      this.showInlineSummary(placeholderContainer);
    }, 500); // Small delay to ensure DOM is ready
  }

  addSearchEventListeners(container) {
    const searchInput = container.querySelector('.custom-search-input');
    const aiSearchBtn = container.querySelector('.custom-search-ai');
    const smartFilterBtn = container.querySelector('.custom-search-filter');

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        this.handleAISearch(searchInput.value);
      }
    });

    aiSearchBtn.addEventListener('click', () => {
      this.handleAISearch(searchInput.value);
    });

    smartFilterBtn.addEventListener('click', () => {
      this.handleSmartFilter(searchInput.value);
    });
  }

  addReplyEventListeners(container) {
    const generateBtn = container.querySelector('.generate-reply-btn');
    const enhanceBtn = container.querySelector('.enhance-reply-btn');

    generateBtn.addEventListener('click', () => this.handleGenerateReply());
    enhanceBtn.addEventListener('click', () => this.handleEnhanceText());
  }

  addEmailActionEventListeners(container) {
    const researchBtn = container.querySelector('.research-btn');
    const calendarBtn = container.querySelector('.calendar-btn');
    const summaryBtn = container.querySelector('.summary-btn');
    const actionBtn = container.querySelector('.action-btn');

    researchBtn.addEventListener('click', () => this.handleResearchContact());
    calendarBtn.addEventListener('click', () => this.handleCheckAvailability());
    summaryBtn.addEventListener('click', () => this.handleSummarizeEmail());
    actionBtn.addEventListener('click', () => this.handleQuickActions());
  }

  addReplyGeneratorEventListeners(popup, backdrop, style) {
    const toneButtons = popup.querySelectorAll('.tone-btn');
    const closeBtn = popup.querySelector('.close-popup-btn');
    const replyContainer = popup.querySelector('.generated-reply-container');
    const feedbackInput = popup.querySelector('.feedback-input');
    const sendFeedbackBtn = popup.querySelector('.send-feedback-btn');

    let currentReply = '';
    let currentTone = 'professional';
    let chatHistory = [];
    let feedbackMessages = [];

    // Tone button handlers - generate immediately on click
    toneButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        currentTone = btn.dataset.tone;
        this.generateReplyWithAPI(currentTone, chatHistory, feedbackMessages, replyContainer);
      });
    });

    // Feedback handlers - regenerate with feedback
    const sendFeedback = () => {
      const feedback = feedbackInput.value.trim();
      if (feedback) {
        // Add feedback to chat history
        const feedbackMessage = {
          role: 'user',
          content: feedback,
          timestamp: new Date().toISOString(),
          type: 'feedback'
        };
        
        chatHistory.push(feedbackMessage);
        feedbackMessages.push(feedbackMessage);
        
        // Show feedback in UI (optional visual feedback)
        this.showFeedbackMessage(replyContainer, feedback);
        
        feedbackInput.value = '';
        // Regenerate with the last used tone and updated chat history
        this.generateReplyWithAPI(currentTone, chatHistory, feedbackMessages, replyContainer);
      }
    };

    feedbackInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        sendFeedback();
      }
    });

    sendFeedbackBtn.addEventListener('click', sendFeedback);

    // Close handlers
    closeBtn.addEventListener('click', () => {
      backdrop.remove();
      style.remove();
    });

    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        backdrop.remove();
        style.remove();
      }
    });

    document.addEventListener('keydown', function escapeHandler(e) {
      if (e.key === 'Escape') {
        backdrop.remove();
        style.remove();
        document.removeEventListener('keydown', escapeHandler);
      }
    });

    // Store current reply and chat history for access in other handlers
    this.currentReplyContent = {
      get reply() { return currentReply; },
      set reply(value) { currentReply = value; },
      get chatHistory() { return chatHistory; },
      set chatHistory(value) { chatHistory = value; }
    };
  }

  // Event handlers (placeholder implementations)
  handleAISearch(query) {
    console.log('AI Search triggered:', query);
    this.showNotification('🔍 AI Search feature coming soon!');
  }

  handleSmartFilter(query) {
    console.log('Smart Filter triggered:', query);
    this.showNotification('🎯 Smart Filter feature coming soon!');
  }

  async handleGenerateReply() {
    console.log('Generate Reply triggered - showing UI first');
    
    // Always show the generator UI first
    this.showReplyGeneratorPopup();
  }

  handleEnhanceText() {
    console.log('Enhance Text triggered');
    
    // Extract full thread content with expansion
    this.extractFullThreadWithExpansion().then(threadContent => {
      console.log('📧 Full thread content for enhancement:', threadContent);
    });
    
    this.showNotification('🚀 Text enhancement feature coming soon!');
  }

  handleResearchContact() {
    console.log('Research Contact triggered');
    
    // Extract full thread content with expansion
    this.extractFullThreadWithExpansion().then(threadContent => {
      console.log('👤 Full thread for contact research:', threadContent);
    });
    
    this.showNotification('🔍 Contact research feature coming soon!');
  }

  handleCheckAvailability() {
    console.log('Check Availability triggered');
    
    // Extract full thread content with expansion
    this.extractFullThreadWithExpansion().then(threadContent => {
      console.log('📅 Full thread for calendar analysis:', threadContent);
    });
    
    this.showNotification('📅 Calendar availability check coming soon!');
  }

  handleSummarizeEmail() {
    console.log('Summarize Email triggered');
    
    // Extract full thread content with expansion
    this.extractFullThreadWithExpansion().then(threadContent => {
      console.log('📝 Full thread content for summarization:', threadContent);
    });
    
    this.showNotification('📝 Email summarization feature coming soon!');
  }

  handleQuickActions() {
    console.log('Quick Actions triggered');
    
    // Extract full thread content with expansion
    this.extractFullThreadWithExpansion().then(threadContent => {
      console.log('⚡ Full thread for quick actions:', threadContent);
    });
    
    this.showNotification('⚡ Quick actions feature coming soon!');
  }

  // Enhanced async method for full thread extraction with expansion
    async extractFullThreadWithExpansion() {
    try {
      await this.expandCollapsedMessageGroups();
      await this.sleep(200);
      
      const lastEmailElement = this.findLastEmailElement();
      if (!lastEmailElement) return null;
      
      const completeThreadData = await this.extractCompleteThreadFromLastEmail(lastEmailElement);
      
      if (completeThreadData && completeThreadData.rawContent) {
        console.log(completeThreadData.rawContent);
        return completeThreadData;
      }
      
      return null;
      
    } catch (error) {
      return null;
    }
  }

  findLastEmailElement() {
    try {
      const selectors = [
        '.h7[role="listitem"][aria-expanded="true"]',
        '.h7[role="listitem"]:last-child',
        '[data-message-id]:last-of-type',
        '.adn.ads:last-of-type'
      ];
      
      for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          return elements[elements.length - 1];
        }
      }
      
      return null;
    } catch (error) {
      return null;
    }
  }

  async extractCompleteThreadFromLastEmail(lastEmailElement) {
    try {
      await this.clickAndExpandEmail(lastEmailElement, 'last');
      await this.sleep(200);
      
      const rawThreadContent = this.extractRawThreadContent(lastEmailElement);
      
      return {
        rawContent: rawThreadContent
      };
      
    } catch (error) {
      return null;
    }
  }

  extractRawThreadContent(lastEmailElement) {
    try {
      const emailBodyElement = lastEmailElement.querySelector('.ii.gt, .a3s.aiL, [id*=":"]');
      
      if (!emailBodyElement) {
        return 'No content found';
      }
      
      const rawContent = emailBodyElement.textContent || emailBodyElement.innerText || '';
      
      return rawContent.trim();
      
    } catch (error) {
      return 'Error extracting content';
    }
  }



  async expandCollapsedMessageGroups() {
    try {
      const olderMessageButtons = document.querySelectorAll('.adx[aria-expanded="false"][role="button"]');
      
      for (const button of olderMessageButtons) {
        try {
          button.click();
          const clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
          });
          button.dispatchEvent(clickEvent);
          await this.sleep(100);
        } catch (error) {}
      }
      
      const collapsedContainers = document.querySelectorAll('.kQ.bg[role="listitem"], .kv[aria-expanded="false"]');
      
      for (const container of collapsedContainers) {
        try {
          container.click();
          const clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
          });
          container.dispatchEvent(clickEvent);
          await this.sleep(50);
        } catch (error) {}
      }
      
      const expandableElements = document.querySelectorAll('[aria-expanded="false"][role="button"]');
      
      for (const element of expandableElements) {
        try {
          const label = element.getAttribute('aria-label') || element.textContent;
          if (label && (label.includes('older') || label.includes('message') || label.includes('collapsed'))) {
            element.click();
            await this.sleep(50);
          }
        } catch (error) {}
      }
      
      await this.sleep(200);
      
    } catch (error) {}
  }

  async clickAndExpandEmail(emailElement, emailIndex) {
    try {
      const clickTargets = this.findEmailClickTargets(emailElement);
      
      for (const target of clickTargets) {
        try {
          if (this.isElementClickable(target)) {
            target.click();
            
            const clickEvent = new MouseEvent('click', {
              view: window,
              bubbles: true,
              cancelable: true
            });
            target.dispatchEvent(clickEvent);
            
            await this.sleep(100);
            
            const hasExpandedContent = this.checkIfEmailExpanded(emailElement);
            if (hasExpandedContent) {
              return true;
            }
          }
        } catch (error) {}
      }
      
      return false;
      
    } catch (error) {
      return false;
    }
  }

  findEmailClickTargets(emailElement) {
    const targets = [];
    
    const clickSelectors = [
      '.kQ',
      '.kR',
      '.qu',
      '.go',
      '.atn',
      '.ii.gt',
      '[role="button"]',
      '.Bn'
    ];
    
    clickSelectors.forEach(selector => {
      const elements = emailElement.querySelectorAll(selector);
      elements.forEach(el => targets.push(el));
    });
    
    if (targets.length === 0) {
      targets.push(emailElement);
    }
    
    let parent = emailElement.parentElement;
    let depth = 0;
    while (parent && depth < 3) {
      if (parent.classList.contains('kQ') || 
          parent.classList.contains('qu') ||
          parent.classList.contains('atn')) {
        targets.push(parent);
      }
      parent = parent.parentElement;
      depth++;
    }
    
    return targets;
  }

  isElementClickable(element) {
    try {
      // Check if element is visible and can be clicked
      const rect = element.getBoundingClientRect();
      const isVisible = rect.width > 0 && rect.height > 0 && 
                       rect.top >= 0 && rect.left >= 0;
      
      const isDisplayed = element.style.display !== 'none' && 
                         element.style.visibility !== 'hidden';
      
      const isInteractive = element.onclick || 
                           element.getAttribute('role') === 'button' ||
                           element.style.cursor === 'pointer' ||
                           element.classList.contains('kQ') ||
                           element.classList.contains('qu');
      
      return isVisible && isDisplayed && (isInteractive || true); // Allow clicking on any visible element
    } catch (error) {
      return false;
    }
  }

  checkIfEmailExpanded(emailElement) {
    try {
      // Check if the email now has expanded content
      const expandedContentSelectors = [
        '.a3s.aiL',
        '.ii.gt .a3s',
        'div[dir="ltr"]'
      ];
      
      for (const selector of expandedContentSelectors) {
        const content = emailElement.querySelector(selector);
        if (content && content.textContent.trim().length > 50) {
          return true;
        }
      }
      
      // Also check if collapsed indicators are gone
      const collapsedIndicators = emailElement.querySelectorAll('.kQ, .Zt, .aZo');
      return collapsedIndicators.length === 0;
      
    } catch (error) {
      return false;
    }
  }

  async extractEmailDataAfterClick(emailElement, emailIndex) {
    try {
      // Wait a bit more for content to fully load
      await this.sleep(500);
      
      // Now extract comprehensive email data
      const emailData = {
        index: emailIndex,
        subject: this.extractSubject(emailElement),
        sender: this.extractSenderFromElement(emailElement),
        senderEmail: this.extractSenderEmailFromElement(emailElement),
        recipients: this.extractRecipientsFromElement(emailElement),
        timestamp: this.extractTimestampFromElement(emailElement),
        body: this.extractEmailBodyFromElement(emailElement),
        messageId: this.extractMessageId(emailElement),
        isFullyExpanded: this.checkIfEmailExpanded(emailElement),
        extractionMethod: 'post-click'
      };
      
      return emailData;
      
    } catch (error) {
      console.error(`❌ Error extracting email data after click for email ${emailIndex}:`, error);
      return null;
    }
  }

  extractBasicEmailData(emailElement, emailIndex) {
    try {
      return {
        index: emailIndex,
        subject: this.extractSubject(emailElement),
        sender: this.extractSenderFromElement(emailElement),
        senderEmail: this.extractSenderEmailFromElement(emailElement),
        recipients: [],
        timestamp: this.extractTimestampFromElement(emailElement),
        body: this.extractEmailBodyFromElement(emailElement) || '[Content not accessible]',
        messageId: this.extractMessageId(emailElement),
        isFullyExpanded: false,
        extractionMethod: 'fallback'
      };
    } catch (error) {
      console.error(`❌ Error extracting basic email data for email ${emailIndex}:`, error);
      return null;
    }
  }

  // Enhanced extraction methods that work on specific email elements
  extractSenderFromElement(emailElement) {
    try {
      const senderSelectors = [
        '.go .gb',
        '.go .g2', 
        '.gD',
        '.qu .go .gb',
        '.bA4 .go .gb',
        '[email]'
      ];
      
      for (const selector of senderSelectors) {
        const element = emailElement.querySelector(selector);
        if (element && element.textContent.trim()) {
          return element.textContent.trim();
        }
      }
      
      return 'Unknown sender';
    } catch (error) {
      return 'Unknown sender';
    }
  }

  extractSenderEmailFromElement(emailElement) {
    try {
      const emailSelectors = [
        '[email]',
        '.go .gb[email]',
        '.gD[email]',
        '.qu .go .gb[email]'
      ];
      
      for (const selector of emailSelectors) {
        const element = emailElement.querySelector(selector);
        if (element && element.getAttribute('email')) {
          return element.getAttribute('email');
        }
      }
      
      return 'Unknown email';
    } catch (error) {
      return 'Unknown email';
    }
  }

  extractRecipientsFromElement(emailElement) {
    try {
      const recipients = [];
      const recipientElements = emailElement.querySelectorAll('.g2, [email]');
      
      recipientElements.forEach(element => {
        const email = element.getAttribute('email');
        const name = element.textContent.trim();
        if (email || name) {
          recipients.push({ name, email });
        }
      });
      
      return recipients;
    } catch (error) {
      return [];
    }
  }

  extractTimestampFromElement(emailElement) {
    try {
      const timestampSelectors = [
        '.g3',
        '[title*=":"]',
        '.qu .g3',
        '.bA4 .g3'
      ];
      
      for (const selector of timestampSelectors) {
        const element = emailElement.querySelector(selector);
        if (element) {
          return element.getAttribute('title') || element.textContent.trim();
        }
      }
      
      return 'Unknown timestamp';
    } catch (error) {
      return 'Unknown timestamp';
    }
  }

  extractEmailBodyFromElement(emailElement) {
    try {
      // Try to get the most complete email content after clicking
      const bodySelectors = [
        '.a3s.aiL',
        '.ii.gt .a3s',
        '.adn.ads .a3s',
        'div[dir="ltr"]',
        '.gs .a3s',
        '.ii.gt'
      ];
      
      for (const selector of bodySelectors) {
        const element = emailElement.querySelector(selector);
        if (element && element.textContent.trim()) {
          let bodyText = element.textContent.trim();
          
          // Clean up the text content
          bodyText = bodyText.replace(/^\s*On.*wrote:\s*/gm, '');
          bodyText = bodyText.replace(/^\s*From:.*$/gm, '');
          bodyText = bodyText.replace(/^\s*Sent:.*$/gm, '');
          bodyText = bodyText.replace(/^\s*To:.*$/gm, '');
          bodyText = bodyText.replace(/^\s*Subject:.*$/gm, '');
          
          if (bodyText.length > 10) {
            return bodyText.trim();
          }
        }
      }
      
      // Fallback: try to get any text content
      if (emailElement.textContent && emailElement.textContent.trim().length > 20) {
        return `[EXTRACTED] ${emailElement.textContent.trim().substring(0, 500)}...`;
      }
      
      return 'No email body found';
    } catch (error) {
      return 'Error extracting email body';
    }
  }

  extractThreadId(emailElement) {
    try {
      // Try to get real Gmail thread ID from various sources
      
      // Method 1: Look for data-legacy-thread-id attribute
      const threadElement = document.querySelector('[data-legacy-thread-id]');
      if (threadElement) {
        const threadId = threadElement.getAttribute('data-legacy-thread-id');
        console.log(`📧 Found real Gmail thread ID: ${threadId}`);
        return threadId;
      }
      
      // Method 2: Try to extract from URL hash
      const url = window.location.href;
      const threadMatch = url.match(/#([^\/]+)\/([a-zA-Z0-9_-]+)/);
      if (threadMatch && threadMatch[2]) {
        console.log(`📧 Found thread ID from URL: ${threadMatch[2]}`);
        return threadMatch[2];
      }
      
      // Method 3: Look for thread ID in other attributes
      const threadIdAttributes = [
        '[data-thread-id]',
        '[data-tid]',
        '[thread-id]'
      ];
      
      for (const selector of threadIdAttributes) {
        const element = document.querySelector(selector);
        if (element) {
          const threadId = element.getAttribute(selector.slice(1, -1));
          if (threadId) {
            console.log(`📧 Found thread ID from attribute: ${threadId}`);
            return threadId;
          }
        }
      }
      
      // No real thread ID found
      console.log(`⚠️ No real thread ID found, returning null`);
      return null;
      
    } catch (error) {
      console.error('Error extracting thread ID:', error);
      return null;
    }
  }

  extractMessageId(emailElement) {
    try {
      // Try to get real Gmail message ID
      
      // Method 1: data-message-id attribute (most reliable)
      if (emailElement && emailElement.getAttribute('data-message-id')) {
        const messageId = emailElement.getAttribute('data-message-id');
        console.log(`📧 Found real Gmail message ID: ${messageId}`);
        return messageId;
      }
      
      // Method 2: Look for other message ID attributes
      const messageIdAttributes = [
        'data-mid',
        'data-msg-id', 
        'message-id',
        'mid'
      ];
      
      if (emailElement) {
        for (const attr of messageIdAttributes) {
          const messageId = emailElement.getAttribute(attr);
          if (messageId) {
            console.log(`📧 Found message ID from attribute ${attr}: ${messageId}`);
            return messageId;
          }
        }
      }
      
      // Method 3: Look in child elements
      if (emailElement) {
        const childWithMessageId = emailElement.querySelector('[data-message-id], [data-mid], [message-id]');
        if (childWithMessageId) {
          const messageId = childWithMessageId.getAttribute('data-message-id') ||
                           childWithMessageId.getAttribute('data-mid') ||
                           childWithMessageId.getAttribute('message-id');
          if (messageId) {
            console.log(`📧 Found message ID from child element: ${messageId}`);
            return messageId;
          }
        }
      }
      
      // No real message ID found
      console.log(`⚠️ No real message ID found, returning null`);
      return null;
      
    } catch (error) {
      console.error('Error extracting message ID:', error);
      return null;
    }
  }

  // New helper methods for improved thread analysis
  extractThreadSubject() {
    try {
      const subjectElement = document.querySelector('[data-legacy-thread-id] h2, .hP');
      return subjectElement ? subjectElement.textContent.trim() : 'Unknown subject';
    } catch (error) {
      console.error('Error extracting thread subject:', error);
      return 'Error extracting thread subject';
    }
  }

  isEmailExpanded(emailElement) {
    try {
      // Check if email is expanded (visible content vs collapsed)
      const isHidden = emailElement.style.display === 'none' || 
                      emailElement.closest('[style*="display: none"]');
      const hasVisibleContent = emailElement.querySelector('.a3s.aiL, .ii.gt');
      
      return !isHidden && hasVisibleContent;
    } catch (error) {
      return false;
    }
  }

  isEmailCollapsed(emailElement) {
    try {
      // Check if email is in collapsed state
      const hasCollapsedClass = emailElement.classList.contains('kQ') ||
                               emailElement.classList.contains('Zt') ||
                               emailElement.closest('.kQ') ||
                               emailElement.closest('.Zt');
      
      const hasCollapsedIndicator = emailElement.textContent.includes('...') ||
                                   emailElement.querySelector('.aZo') ||
                                   emailElement.querySelector('.aZq');
      
      const isMinimized = emailElement.style.height === '0px' ||
                         emailElement.style.overflow === 'hidden';
      
      const hasExpandButton = emailElement.querySelector('[aria-expanded="false"]') ||
                             emailElement.querySelector('.Bn');
      
      return hasCollapsedClass || hasCollapsedIndicator || isMinimized || hasExpandButton;
    } catch (error) {
      return false;
    }
  }

  extractAllParticipants(threadEmails) {
    try {
      const participants = new Set();
      
      threadEmails.forEach(email => {
        if (email.senderEmail && email.senderEmail !== 'Unknown email') {
          participants.add(JSON.stringify({
            name: email.sender,
            email: email.senderEmail
          }));
        }
        
        email.recipients.forEach(recipient => {
          if (recipient.email) {
            participants.add(JSON.stringify(recipient));
          }
        });
      });
      
      return Array.from(participants).map(p => JSON.parse(p));
    } catch (error) {
      console.error('Error extracting participants:', error);
      return [];
    }
  }

  async generateReplyWithAPI(tone, chatHistory, feedbackMessages, replyContainer) {
    // Show loading state
    replyContainer.innerHTML = `
      <div style="color: rgba(255, 255, 255, 0.7); text-align: center; padding: 40px 20px;">
        <div style="margin-bottom: 15px;">Generating ${tone} reply${feedbackMessages.length > 0 ? ' with feedback' : ''}...</div>
        <div style="width: 100%; height: 2px; background: rgba(255, 255, 255, 0.1); border-radius: 1px; overflow: hidden;">
          <div style="width: 0%; height: 100%; background: linear-gradient(135deg, #1a73e8 0%,rgb(11, 52, 106) 100%); animation: loading 2s ease-in-out;" class="loading-bar"></div>
        </div>
      </div>
    `;

    // Add loading animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes loading {
        0% { width: 0%; }
        50% { width: 100%; }
        100% { width: 0%; }
      }
    `;
    document.head.appendChild(style);

    try {
      // Extract only the last email content
      const lastEmailContent = await this.extractLastEmailContent();
      
      if (!lastEmailContent) {
        throw new Error('Could not extract email content');
      }

      // Make API request via background script with chat history and feedback
      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
          action: 'generateReply',
          data: {
            email_content: lastEmailContent,
            tone: tone,
            context: 'Reply to the last email in this thread',
            chat_history: chatHistory,
            feedback_messages: feedbackMessages
          }
        }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response.success) {
            resolve(response.data);
          } else {
            reject(new Error(response.error));
          }
        });
      });

      // Update chat history if provided in response
      if (response.chat_history) {
        this.currentReplyContent.chatHistory = response.chat_history;
      }

      // Update the container with the generated reply
      const formattedReplyForDisplay = response.generated_reply.replace(/\n/g, '<br>');
      
      // Show feedback history if any
      let feedbackHistoryHTML = '';
      if (feedbackMessages.length > 0) {
        feedbackHistoryHTML = `
          <div style="margin-bottom: 12px; padding: 8px; background: rgba(255, 255, 255, 0.1); border-radius: 6px; border-left: 3px solid #8B5CF6;">
            <div style="font-size: 11px; color: rgba(255, 255, 255, 0.7); margin-bottom: 4px;">Applied feedback:</div>
            <div style="font-size: 12px; color: rgba(255, 255, 255, 0.9);">${feedbackMessages[feedbackMessages.length - 1].content}</div>
          </div>
        `;
      }
      
      replyContainer.innerHTML = `
        ${feedbackHistoryHTML}
        <div style="color: rgba(255, 255, 255, 0.95); font-size: 14px; line-height: 1.6; text-align: left;">${formattedReplyForDisplay}</div>
        <div style="margin-top: 16px; display: flex; gap: 8px; justify-content: flex-end;">
          <button class="copy-reply-btn" style="
            display: none;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            color: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
            font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
          ">Copy</button>
          <button class="use-reply-btn" style="
            background: #1a73e8;
            backdrop-filter: blur(10px);
            color: white;
            border: 1px solid rgba(59, 130, 246, 0.5);
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
            font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
          ">Use Reply</button>
        </div>
      `;

      // Add button event listeners
      const copyBtn = replyContainer.querySelector('.copy-reply-btn');
      const useBtn = replyContainer.querySelector('.use-reply-btn');

      copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(response.generated_reply);
        copyBtn.textContent = 'Copied!';
        setTimeout(() => copyBtn.textContent = 'Copy', 2000);
      });

      useBtn.addEventListener('click', () => {
        this.insertGeneratedReply(response.generated_reply);
        // Find and close the popup
        const popup = document.querySelector('.reply-generator-popup');
        if (popup) popup.remove();
      });

      // Store current reply for access in other handlers
      this.currentReplyContent.reply = response.generated_reply;

    } catch (error) {
      console.error('❌ Error generating reply:', error);
      
      // Show error and fallback to mock reply
      replyContainer.innerHTML = `
        <div style="color: rgba(255, 255, 255, 0.7); text-align: center; padding: 40px 20px;">
          <div style="margin-bottom: 15px;">⚠️ API Error - Using fallback</div>
        </div>
      `;
      
      // Fallback to mock reply after a short delay
      setTimeout(() => {
        this.generateMockReply(tone, chatHistory, replyContainer, null, null);
      }, 1000);
    }

    // Clean up loading animation
    setTimeout(() => style.remove(), 3000);
  }

  showFeedbackMessage(replyContainer, feedback) {
    // Temporarily show feedback being processed
    const feedbackIndicator = document.createElement('div');
    feedbackIndicator.style.cssText = `
      position: absolute;
      top: 10px;
      right: 10px;
      background: rgba(59, 130, 246, 0.8);
      color: white;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      z-index: 1001;
      animation: fadeInOut 2s ease-in-out;
    `;
    feedbackIndicator.textContent = 'Processing feedback...';
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes fadeInOut {
        0% { opacity: 0; transform: translateY(-10px); }
        20% { opacity: 1; transform: translateY(0); }
        80% { opacity: 1; transform: translateY(0); }
        100% { opacity: 0; transform: translateY(-10px); }
      }
    `;
    document.head.appendChild(style);
    
    replyContainer.style.position = 'relative';
    replyContainer.appendChild(feedbackIndicator);
    
    // Remove after animation
    setTimeout(() => {
      feedbackIndicator.remove();
      style.remove();
    }, 2000);
  }

  async extractLastEmailContent() {
    try {
      // Find the last email element in the thread
      const lastEmailElement = this.findLastEmailElement();
      if (!lastEmailElement) {
        return null;
      }

      // Expand it if needed
      await this.clickAndExpandEmail(lastEmailElement, 'last');
      await this.sleep(200);

      // Extract just the email body text (no subject, no headers)
      const emailBodyElement = lastEmailElement.querySelector('.ii.gt, .a3s.aiL, [id*=":"]');
      
      if (!emailBodyElement) {
        return 'No email content found';
      }

      let emailText = emailBodyElement.textContent || emailBodyElement.innerText || '';
      
      // Clean up the text - remove email signatures, quoted text, etc.
      emailText = this.cleanEmailText(emailText);
      
      return emailText.trim();
      
    } catch (error) {
      console.error('Error extracting last email:', error);
      return null;
    }
  }

  cleanEmailText(text) {
    // Remove common email artifacts
    return text
      // Remove "On [date] [person] wrote:" lines
      .replace(/^On .+ wrote:\s*$/gm, '')
      // Remove email headers
      .replace(/^(From|To|Sent|Subject|Date):\s*.+$/gm, '')
      // Remove excessive whitespace
      .replace(/\n\s*\n\s*\n/g, '\n\n')
      // Remove leading/trailing whitespace
      .trim();
  }

  generateMockReply(tone, chatHistory, replyContainer, copyBtn, useBtn) {
    // Clear the container
    replyContainer.innerHTML = `
      <div style="color: rgba(255, 255, 255, 0.7); text-align: center; padding: 40px 20px;">
        <div style="margin-bottom: 15px;">Generating ${tone} reply...</div>
        <div style="width: 100%; height: 2px; background: rgba(255, 255, 255, 0.1); border-radius: 1px; overflow: hidden;">
          <div style="width: 0%; height: 100%; background: linear-gradient(135deg, #1a73e8 0%,rgb(11, 52, 106) 100%); animation: loading 2s ease-in-out;" class="loading-bar"></div>
        </div>
      </div>
    `;

    // Add loading animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes loading {
        from { width: 0%; }
        to { width: 100%; }
      }
    `;
    document.head.appendChild(style);

    // Simulate API call delay
    setTimeout(() => {
      const reply = this.getMockReplyByTone(tone, chatHistory);
      this.currentReplyContent.reply = reply;
      
      replyContainer.innerHTML = `
        <div style="color: rgba(255, 255, 255, 0.95); font-size: 14px; line-height: 1.6; white-space: pre-wrap; text-align: left;">${reply}</div>
        <div style="margin-top: 16px; display: flex; gap: 8px; justify-content: flex-end;">
          <button class="copy-reply-btn" style="
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            color: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
            font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
          ">Copy</button>
          <button class="use-reply-btn" style="
            background: rgba(59, 130, 246, 0.8);
            backdrop-filter: blur(10px);
            color: white;
            border: 1px solid rgba(59, 130, 246, 0.5);
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
            font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
          ">Use Reply</button>
        </div>
      `;

      // Add button event listeners for mock reply
      const copyBtn = replyContainer.querySelector('.copy-reply-btn');
      const useBtn = replyContainer.querySelector('.use-reply-btn');

      copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(reply);
        copyBtn.textContent = 'Copied!';
        setTimeout(() => copyBtn.textContent = 'Copy', 2000);
      });

      useBtn.addEventListener('click', () => {
        this.insertGeneratedReply(reply);
        // Find and close the popup
        const popup = document.querySelector('.reply-generator-popup');
        if (popup) popup.remove();
      });

      style.remove();
    }, 2000);
  }

  getMockReplyByTone(tone, chatHistory) {
    const hasNegativeFeedback = chatHistory.some(msg => 
      msg.role === 'user' && (
        msg.content.toLowerCase().includes('disagree') ||
        msg.content.toLowerCase().includes('don\'t agree') ||
        msg.content.toLowerCase().includes('rewrite') ||
        msg.content.toLowerCase().includes('wrong')
      )
    );

    const hasBriefFeedback = chatHistory.some(msg => 
      msg.role === 'user' && (
        msg.content.toLowerCase().includes('brief') ||
        msg.content.toLowerCase().includes('short') ||
        msg.content.toLowerCase().includes('concise')
      )
    );

    const replies = {
      professional: hasBriefFeedback 
        ? `Hi [Name],

Thank you for your email. I acknowledge your proposal and will review the details.

I'll provide feedback by [date] after proper consideration.

Best regards,
[Your Name]`
        : `Dear [Name],

Thank you for your email regarding [subject]. I have reviewed the information you provided and appreciate you taking the time to reach out.

I would like to schedule a meeting to discuss this matter in more detail. Please let me know your availability for the coming week, and I will coordinate accordingly.

Looking forward to our discussion.

Best regards,
[Your Name]`,

      casual: hasBriefFeedback
        ? `Hey [Name]!

Thanks for reaching out! I'll take a look and get back to you soon.

Talk soon!
[Your Name]`
        : `Hey [Name]!

Hope you're doing well! Thanks for your email - I really appreciate you thinking of me for this.

I'm definitely interested in learning more about what you have in mind. It sounds like it could be a great opportunity, and I'd love to dive deeper into the details.

Would you be free for a quick chat sometime this week? I'm pretty flexible with my schedule, so just let me know what works best for you!

Looking forward to hearing from you soon!

Best,
[Your Name]`,

      brief: `Hi [Name],

Thanks for your email. Will review and get back to you by [date].

Best,
[Your Name]`,

      agree: hasNegativeFeedback
        ? `Hi [Name],

Thank you for your email. After reviewing your proposal, I'm happy to move forward with this.

I agree with your approach and think this is the right direction. Please let me know the next steps and how I can help make this happen.

Looking forward to working together on this.

Best regards,
[Your Name]`
        : `Hi [Name],

Thank you for reaching out about this opportunity. I'm excited to let you know that I would love to be involved.

I agree with your proposal and think it's a great idea. The timing works well for me, and I believe we can achieve excellent results together.

Please send over any additional details or next steps, and I'll get started right away.

Looking forward to working with you!

Best regards,
[Your Name]`,

      decline: hasNegativeFeedback
        ? `Hi [Name],

Thank you for your email and for thinking of me for this opportunity.

After careful consideration, I won't be able to move forward with this proposal at this time. While I appreciate the offer, it doesn't align with my current priorities and commitments.

I hope you understand, and I wish you the best of luck with this project.

Best regards,
[Your Name]`
        : `Hi [Name],

Thank you for reaching out and for considering me for this opportunity. I really appreciate you thinking of me.

Unfortunately, I won't be able to participate in this project at this time due to my current commitments and scheduling constraints.

I hope you find the right person for this, and I wish you all the best with the project.

Thank you again for the consideration.

Best regards,
[Your Name]`
    };

    return replies[tone] || replies.professional;
  }

  addChatMessage(chatContainer, message, type) {
    // Remove placeholder if it exists
    const placeholder = chatContainer.querySelector('.chat-placeholder');
    if (placeholder) {
      placeholder.remove();
    }

    const messageDiv = document.createElement('div');
    messageDiv.style.cssText = `
      margin-bottom: 12px;
      padding: 8px 12px;
      border-radius: 12px;
      font-size: 12px;
      line-height: 1.4;
      word-wrap: break-word;
      font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
    `;

    if (type === 'user') {
      messageDiv.style.cssText += `
        background: rgba(249, 104, 141, 0.8);
        color: white;
        margin-left: 20px;
        text-align: right;
      `;
      messageDiv.textContent = message;
    } else if (type === 'system') {
      messageDiv.style.cssText += `
        background: rgba(255, 255, 255, 0.1);
        color: rgba(255, 255, 255, 0.8);
        text-align: center;
        font-style: italic;
      `;
      messageDiv.textContent = message;
    }

    chatContainer.appendChild(messageDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }

  insertReplyIntoCompose(reply) {
    // Try to find Gmail compose textbox
    const composeTextbox = document.querySelector('[role="textbox"][aria-label*="Message Body"]') ||
                          document.querySelector('.Am.Al.editable') ||
                          document.querySelector('[contenteditable="true"]');
    
    if (composeTextbox) {
      // Clear existing content and insert reply
      composeTextbox.innerHTML = reply.replace(/\n/g, '<br>');
      
      // Trigger input event to let Gmail know content changed
      const inputEvent = new Event('input', { bubbles: true });
      composeTextbox.dispatchEvent(inputEvent);
      
      this.showNotification('✅ Reply inserted into compose window!');
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(reply).then(() => {
        this.showNotification('📋 Reply copied to clipboard (compose window not found)');
      });
    }
  }

  insertGeneratedReply(generatedReply) {
    try {
      // Find the compose area in Gmail with multiple selectors
      const composeSelectors = [
        '[role="textbox"][aria-label*="Message Body"]',
        '.Am.Al.editable[contenteditable="true"]',
        '[contenteditable="true"][aria-label*="Message Body"]',
        '.editable[role="textbox"]',
        '[contenteditable="true"]'
      ];
      
      let composeArea = null;
      for (const selector of composeSelectors) {
        composeArea = document.querySelector(selector);
        if (composeArea) {
          console.log(`✅ Found compose area with selector: ${selector}`);
          break;
        }
      }
      
      if (composeArea) {
        // Convert line breaks to proper HTML and preserve formatting
        const formattedReply = generatedReply
          .replace(/\n\n/g, '</p><p>')  // Double line breaks become paragraph breaks
          .replace(/\n/g, '<br>')       // Single line breaks become <br>
          .replace(/^/, '<p>')          // Start with paragraph
          .replace(/$/, '</p>');        // End with paragraph
        
        // Insert the generated reply with proper formatting
        composeArea.innerHTML = formattedReply;
        
        // Focus the compose area and place cursor at the end
        composeArea.focus();
        
        // Place cursor at the end of the content
        const range = document.createRange();
        const selection = window.getSelection();
        range.selectNodeContents(composeArea);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
        
        // Trigger events to notify Gmail of the change
        const inputEvent = new Event('input', { bubbles: true });
        const changeEvent = new Event('change', { bubbles: true });
        const keyupEvent = new Event('keyup', { bubbles: true });
        
        composeArea.dispatchEvent(inputEvent);
        composeArea.dispatchEvent(changeEvent);
        composeArea.dispatchEvent(keyupEvent);
        
        console.log('✅ AI-generated reply inserted into compose area with proper formatting');
        this.showNotification('✅ AI reply generated and inserted!');
      } else {
        console.log('❌ Gmail compose area not found');
        this.showGeneratedReplyFallback(generatedReply);
      }
    } catch (error) {
      console.error('❌ Error inserting generated reply:', error);
      this.showGeneratedReplyFallback(generatedReply);
    }
  }

  showGeneratedReplyFallback(generatedReply) {
    // Copy to clipboard as fallback
    try {
      navigator.clipboard.writeText(generatedReply).then(() => {
        this.showNotification('📋 AI reply copied to clipboard!');
        console.log('✅ AI reply copied to clipboard as fallback');
      }).catch(() => {
        // Show in a popup if clipboard fails
        alert(`AI Generated Reply:\n\n${generatedReply}`);
      });
    } catch (error) {
      alert(`AI Generated Reply:\n\n${generatedReply}`);
    }
  }

  showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'gmail-enhanced-notification';
    notification.innerHTML = `
      <div class="notification-content">
        <span>${message}</span>
        <button class="notification-close">×</button>
      </div>
    `;

    document.body.appendChild(notification);

    // Auto-remove after 3 seconds
    setTimeout(() => {
      notification.remove();
    }, 3000);

    // Add close button listener
    notification.querySelector('.notification-close').addEventListener('click', () => {
      notification.remove();
    });
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Helper methods for email content extraction
  findCurrentEmailElement() {
    // Try different selectors for the currently open email
    const selectors = [
      '[data-message-id]:not([style*="display: none"])',
      '.ii.gt .a3s.aiL',
      '.adn.ads .ii.gt',
      '.h7'
    ];
    
    for (const selector of selectors) {
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        // Return the last/most recent email element
        return elements[elements.length - 1];
      }
    }
    
    return null;
  }

  findAllEmailElementsInThread() {
    // Enhanced email detection for click-based approach with better duplicate prevention
    const emailSelectors = [
      '[data-message-id]',    // Gmail's message containers (highest priority - most reliable)
      '.kv',                  // Email message containers  
      '.qu',                  // Email headers (often clickable to expand)
      '.atn',                 // Email thread containers
      '.ii.gt',               // Individual email content
      '.adn.ads'              // Message containers
    ];
    
    let allEmails = [];
    const processedElements = new Set(); // Track processed elements to prevent duplicates
    
    // Process selectors in priority order
    emailSelectors.forEach((selector, selectorIndex) => {
      const elements = document.querySelectorAll(selector);
      console.log(`🔍 Selector "${selector}" found ${elements.length} elements`);
      
      elements.forEach(element => {
        // Create unique identifier for this element
        const elementId = this.createElementIdentifier(element);
        
        // Skip if we've already processed this element or its parent/child
        if (processedElements.has(elementId) || this.isElementAlreadyProcessed(element, processedElements)) {
          return;
        }
        
        // Additional check to see if this looks like an email container
        if (this.looksLikeEmailContainer(element)) {
          allEmails.push(element);
          processedElements.add(elementId);
          
          // Also mark any nested elements as processed to avoid duplicates
          this.markNestedElementsAsProcessed(element, processedElements);
          
          console.log(`✅ Added email element from selector "${selector}":`, {
            tagName: element.tagName,
            classes: element.className,
            hasMessageId: !!element.getAttribute('data-message-id'),
            textLength: element.textContent?.trim().length || 0
          });
        }
      });
    });
    
    console.log(`🔍 Found ${allEmails.length} unique email elements after deduplication`);
    
    // Sort emails by their position in the DOM (chronological order)
    allEmails.sort((a, b) => {
      const aPos = Array.from(document.querySelectorAll('*')).indexOf(a);
      const bPos = Array.from(document.querySelectorAll('*')).indexOf(b);
      return aPos - bPos;
    });
    
    return allEmails;
  }

  createElementIdentifier(element) {
    // Create a unique identifier for an element based on multiple factors
    const messageId = element.getAttribute('data-message-id');
    if (messageId) {
      return `msg-${messageId}`;
    }
    
    // Fallback: use element position, classes, and content
    const rect = element.getBoundingClientRect();
    const position = `${Math.round(rect.top)}-${Math.round(rect.left)}`;
    
    // Handle className safely - it might be a string, DOMTokenList, or undefined
    let classes = '';
    try {
      if (element.className) {
        if (typeof element.className === 'string') {
          classes = element.className.split(' ').sort().join('-');
        } else if (element.className.toString) {
          // Handle DOMTokenList or other objects with toString
          classes = element.className.toString().split(' ').sort().join('-');
        }
      }
    } catch (error) {
      classes = 'no-classes';
    }
    
    const contentHash = element.textContent?.trim().substring(0, 50).replace(/\s+/g, '') || '';
    
    return `${element.tagName}-${position}-${classes}-${contentHash}`.substring(0, 100);
  }

  isElementAlreadyProcessed(element, processedElements) {
    // Check if this element or any of its parents/children are already processed
    let current = element;
    
    // Check parents (up to 3 levels)
    for (let i = 0; i < 3 && current; i++) {
      const parentId = this.createElementIdentifier(current);
      if (processedElements.has(parentId)) {
        console.log(`⚠️ Element already processed (found parent): ${parentId}`);
        return true;
      }
      current = current.parentElement;
    }
    
    // Check children (only immediate children)
    const children = element.querySelectorAll('*');
    for (const child of children) {
      const childId = this.createElementIdentifier(child);
      if (processedElements.has(childId)) {
        console.log(`⚠️ Element already processed (found child): ${childId}`);
        return true;
      }
    }
    
    return false;
  }

  markNestedElementsAsProcessed(element, processedElements) {
    // Mark common nested elements as processed to prevent them from being picked up again
    const nestedSelectors = ['.ii.gt', '.a3s', '.go', '.qu'];
    
    nestedSelectors.forEach(selector => {
      const nestedElements = element.querySelectorAll(selector);
      nestedElements.forEach(nested => {
        const nestedId = this.createElementIdentifier(nested);
        processedElements.add(nestedId);
      });
    });
  }

  looksLikeEmailContainer(element) {
    try {
      // Check if element has characteristics of an email container
      const hasEmailClasses = element.classList.contains('kv') ||
                             element.classList.contains('qu') ||
                             element.classList.contains('atn') ||
                             element.classList.contains('ii') ||
                             element.classList.contains('adn') ||
                             element.hasAttribute('data-message-id');
      
      const hasEmailContent = element.querySelector('.a3s') ||
                             element.querySelector('.ii') ||
                             element.querySelector('.go') || // sender info
                             element.querySelector('.g3'); // timestamp
      
      const hasTextContent = element.textContent && element.textContent.trim().length > 20;
      
      const isVisible = element.offsetHeight > 0 && element.offsetWidth > 0;
      
      return (hasEmailClasses || hasEmailContent || hasTextContent) && isVisible;
    } catch (error) {
      return false;
    }
  }

  extractSubject(emailElement) {
    try {
      // Look for subject in different possible locations
      const subjectSelectors = [
        '[data-legacy-thread-id] h2',
        '.hP',
        '.bog',
        'h2[data-legacy-thread-id]',
        '.bqe .hP',
        '.aYF'
      ];
      
      for (const selector of subjectSelectors) {
        const element = document.querySelector(selector);
        if (element && element.textContent.trim()) {
          return element.textContent.trim();
        }
      }
      
      return 'No subject found';
    } catch (error) {
      console.error('Error extracting subject:', error);
      return 'Error extracting subject';
    }
  }

  processCurrentThreadState() {
    try {
      const threadEmails = [];
      const emailElements = this.findAllEmailElementsInThread();
      
      console.log(`📊 Found ${emailElements.length} email elements in thread`);
      
      emailElements.forEach((emailElement, index) => {
        try {
          console.log(`📧 Processing email ${index + 1}/${emailElements.length}`);
          
          const emailData = {
            index: index + 1,
            subject: this.extractSubject(emailElement),
            sender: this.extractSenderFromElement(emailElement),
            senderEmail: this.extractSenderEmailFromElement(emailElement),
            recipients: this.extractRecipientsFromElement(emailElement),
            timestamp: this.extractTimestampFromElement(emailElement),
            body: this.extractEmailBodyFromElement(emailElement),
            messageId: this.extractMessageId(emailElement),
            isFullyExpanded: this.checkIfEmailExpanded(emailElement),
            extractionMethod: 'fallback-current-state'
          };
          
          console.log(`✅ Email ${index + 1} extracted:`, {
            sender: emailData.sender,
            subject: emailData.subject,
            bodyLength: emailData.body.length,
            isFullyExpanded: emailData.isFullyExpanded
          });
          
          threadEmails.push(emailData);
        } catch (error) {
          console.error(`❌ Error extracting email ${index + 1}:`, error);
        }
      });

      const threadData = {
        threadId: this.extractThreadId(),
        threadSubject: this.extractThreadSubject(),
        totalEmails: threadEmails.length,
        expandedEmails: threadEmails.filter(e => e.isFullyExpanded).length,
        participants: this.extractAllParticipants(threadEmails),
        emails: threadEmails,
        extractionMethod: 'current-state-fallback'
      };

      console.log('✅ Successfully extracted thread content:', {
        threadId: threadData.threadId,
        totalEmails: threadData.totalEmails,
        expandedEmails: threadData.expandedEmails,
        participants: threadData.participants.length
      });
      
      return threadData;
    } catch (error) {
      console.error('❌ Error processing thread state:', error);
      return null;
    }
  }
}

// Reusable EmailActionButtons Component
class EmailActionButtonsComponent {
  static render() {
    const buttons = this.getButtonsData();
    
    return `
      <div class="email-actions-wrapper" style="display: flex; flex-wrap: wrap; gap: 8px; justify-content: flex-start;">
        ${buttons.map(button => this.renderButton(button)).join('')}
      </div>
    `;
  }

  static getButtonsData() {
    return [
      {
        id: 'research-btn',
        className: 'research-btn',
        icon: '🔍',
        text: 'Research Contact'
      },
      {
        id: 'calendar-btn',
        className: 'calendar-btn',
        icon: '📅',
        text: 'Check Availability'
      },
      {
        id: 'summary-btn',
        className: 'summary-btn',
        icon: '📝',
        text: 'Summarize Email'
      },
      {
        id: 'action-btn',
        className: 'action-btn',
        icon: '⚡',
        text: 'Quick Actions'
      }
    ];
  }

  static renderButton(button) {
    return `
      <button class="email-action-btn ${button.className}" style="display: flex; align-items: center; gap: 6px; background: #f8f9fa; border: 1px solid #dadce0; border-radius: 6px; padding: 6px 12px; font-size: 12px; cursor: pointer; font-weight: 400; transition: all 0.2s; color: #3c4043; font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
        <span class="btn-icon">${button.icon}</span>
        ${button.text}
      </button>
    `;
  }

  static addHoverEffects(buttons) {
    buttons.forEach(btn => {
      btn.addEventListener('mouseenter', () => {
        btn.style.background = '#e8f0fe';
        btn.style.borderColor = '#1a73e8';
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.background = '#f8f9fa';
        btn.style.borderColor = '#dadce0';
      });
    });
  }
}

// Reusable UrgentEmails Component
class UrgentEmailsComponent {
  static render(emails) {
    if (!emails || emails.length === 0) {
      return this.renderEmptyState();
    }

    return emails.map((email, index) => {
      const initials = this.getInitials(email.sender_name);
      const gradientStyle = this.getAvatarGradient(index);
      const textColor = this.getAvatarTextColor(index);
      
      return `
        <div class="urgent-email-item" data-thread-id="${email.thread_id}" style="
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 12px;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s;
          margin-bottom: 8px;
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        ">
          <div style="
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: ${gradientStyle};
            display: flex;
            align-items: center;
            justify-content: center;
            color: ${textColor};
            font-weight: 600;
            font-size: 12px;
            flex-shrink: 0;
          ">${initials}</div>
          <div style="flex: 1; min-width: 0;">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 2px;">
              <div style="font-size: 14px; font-weight: 600; color: rgba(255, 255, 255, 0.95);">${this.escapeHtml(email.sender_name)}</div>
              <div style="font-size: 11px; color: #8B5CF6; font-weight: 500;">${this.escapeHtml(email.time_ago)}</div>
            </div>
            <div style="font-size: 13px; color: rgba(255, 255, 255, 0.9); font-weight: 500; margin-bottom: 2px;">${this.escapeHtml(email.subject)}</div>
            <div style="font-size: 12px; color: rgba(255, 255, 255, 0.75); line-height: 1.3;">${this.escapeHtml(email.preview)}</div>
          </div>
        </div>
      `;
    }).join('');
  }

  static renderEmptyState() {
    return `
      <div style="text-align: center; padding: 20px; color: rgba(255, 255, 255, 0.7);">
        <div style="font-size: 14px;">No urgent emails found</div>
        <div style="font-size: 12px; margin-top: 4px;">You're all caught up! 🎉</div>
      </div>
    `;
  }

  static getInitials(name) {
    return name.split(' ')
      .map(word => word.charAt(0).toUpperCase())
      .slice(0, 2)
      .join('');
  }

  static getAvatarGradient(index) {
    const gradients = [
      'linear-gradient(135deg, #F9688D 0%, #536859 100%)',
      'linear-gradient(135deg, #536859 0%, #F9688D 100%)',
      'linear-gradient(135deg, #F8D0D0 0%, #F9688D 100%)',
      'linear-gradient(135deg, #536859 0%, #F8D0D0 100%)'
    ];
    return gradients[index % gradients.length];
  }

  static getAvatarTextColor(index) {
    const colors = ['white', 'white', '#536859', 'white'];
    return colors[index % colors.length];
  }

  static escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  static getMockData() {
    return [
      {
        thread_id: 'thread-1',
        sender_name: 'Jennifer Martinez',
        sender_email: 'jennifer.martinez@company.com',
        subject: 'Urgent: Client presentation tomorrow',
        preview: 'Need your feedback on the slides ASAP. Meeting is at 9 AM...',
        time_ago: '2h ago',
        urgency_level: 'high'
      },
      {
        thread_id: 'thread-2',
        sender_name: 'David Kim',
        sender_email: 'david.kim@tech.com',
        subject: 'Server outage - need immediate response',
        preview: 'Production servers are down. Can you approve the emergency fix?',
        time_ago: '4h ago',
        urgency_level: 'critical'
      },
      {
        thread_id: 'thread-3',
        sender_name: 'Rachel Thompson',
        sender_email: 'rachel.thompson@finance.com',
        subject: 'Budget approval needed by EOD',
        preview: 'Hi! The Q4 budget needs your sign-off before 5 PM today...',
        time_ago: '6h ago',
        urgency_level: 'medium'
      },
      {
        thread_id: 'thread-4',
        sender_name: 'Marcus Johnson',
        sender_email: 'marcus.johnson@hr.com',
        subject: 'Interview candidate waiting for response',
        preview: 'The candidate from yesterday\'s interview is waiting for feedback...',
        time_ago: '1d ago',
        urgency_level: 'medium'
      }
    ];
  }
}

// Initialize when script loads
const gmailEnhancer = new GmailEnhancer(); 