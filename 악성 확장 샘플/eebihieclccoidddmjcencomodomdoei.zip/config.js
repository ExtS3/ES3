// Production Configuration for Supersonic Chrome Extension
const CONFIG = {
  // Environment
  ENVIRONMENT: 'production',
  
  // URLs based on environment
  get API_BASE_URL() {
    return 'https://api.gosupersonic.email';
  },
  
  get WEB_APP_URL() {
    return 'https://gosupersonic.email';
  },
  
  // API endpoints
  get ENDPOINTS() {
    return {
      GENERATE_REPLY: `${this.API_BASE_URL}/api/generate-reply/`,
      GENERATE_SUMMARY: `${this.API_BASE_URL}/api/generate-summary/`,
      VALIDATE_TOKEN: `${this.API_BASE_URL}/api/validate-token/`,
      USER_SETTINGS: `${this.API_BASE_URL}/api/user/settings/`,
      URGENT_EMAILS: `${this.API_BASE_URL}/api/urgent-emails/`,
      RESEARCH: `${this.API_BASE_URL}/api/research/`,
    };
  },
  
  // Web app pages
  get PAGES() {
    return {
      SETTINGS: `${this.WEB_APP_URL}/settings`,
      LANDING: `${this.WEB_APP_URL}`,
    };
  }
};

// Make CONFIG available globally
window.CONFIG = CONFIG; 