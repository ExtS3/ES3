#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Get the environment argument
const env = process.argv[2] || 'development';

if (!['development', 'production'].includes(env)) {
  console.error('Usage: node build.js [development|production]');
  console.error('Example: node build.js production');
  process.exit(1);
}

console.log(`Building for ${env} environment...`);

// Read the appropriate config file
const configFile = env === 'production' ? 'config.prod.js' : 'config.js';
const configPath = path.join(__dirname, configFile);

if (!fs.existsSync(configPath)) {
  console.error(`Config file not found: ${configPath}`);
  process.exit(1);
}

// Copy the config file to the main config.js
const targetPath = path.join(__dirname, 'config.js');
fs.copyFileSync(configPath, targetPath);

console.log(`✅ Copied ${configFile} to config.js`);

// Update manifest.json version if needed
const manifestPath = path.join(__dirname, 'manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

// Add environment suffix to version for production builds
if (env === 'production') {
  const version = manifest.version.split('-')[0]; // Remove any existing suffix
  manifest.version = version; // Production gets clean version
} else {
  const version = manifest.version.split('-')[0]; // Remove any existing suffix
  manifest.version = `${version}.5`;
}

fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));

console.log(`✅ Updated manifest.json version to ${manifest.version}`);
console.log(`✅ Extension built for ${env} environment!`);

if (env === 'production') {
  console.log('\n📦 Production build ready for Chrome Web Store!');
  console.log('💡 Remember to:');
  console.log('   - Test the extension thoroughly');
  console.log('   - Update the version number if needed');
  console.log('   - Create a ZIP file for upload');
} 