# Supersonic Chrome Extension

This is the Chrome extension for Supersonic AI that adds AI-powered email features to Gmail.

## ✨ Features

### 🔍 Enhanced Search Bar
- **Custom Search Interface**: Replaces Gmail's default search with an AI-powered search bar
- **Smart Filtering**: Advanced filtering capabilities for better email discovery
- **Intelligent Search**: Context-aware search suggestions (coming soon)

### ✨ Reply Generation
- **Auto-Reply Generation**: Generate contextual email replies with AI assistance
- **Text Enhancement**: Improve and polish your email content
- **Smart Compose**: Intelligent writing assistance for better communication

### ⚡ Quick Actions
- **Research Contact**: Get information about email senders and recipients
- **Calendar Integration**: Check availability and schedule meetings
- **Email Summarization**: Get quick summaries of long email threads
- **Smart Actions**: Context-aware action suggestions

## 🚀 Installation

### Method 1: Developer Mode (Recommended for now)

1. **Download the Extension**
   ```bash
   git clone <repository-url>
   cd gmail-enhanced
   ```

2. **Open Chrome Extensions**
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top-right corner)

3. **Load the Extension**
   - Click "Load unpacked"
   - Select the extension folder
   - The extension should now appear in your extensions list

4. **Pin the Extension**
   - Click the puzzle piece icon in Chrome toolbar
   - Find "Gmail Enhanced" and click the pin icon

### Method 2: Chrome Web Store
Coming soon! The extension will be available on the Chrome Web Store.

## 📖 Usage

### Getting Started
1. Navigate to [Gmail](https://mail.google.com)
2. Look for the enhanced search bar at the top of the page
3. When composing emails, you'll see "Generate Reply" and "Enhance Text" buttons
4. When viewing emails, scroll down to see the Quick Actions panel

### Search Features
- Use the enhanced search bar with AI-powered suggestions
- Click "AI Search" for intelligent search results
- Use "Smart Filter" for advanced filtering options

### Reply Generation
- Click "Generate Reply" when composing to auto-generate responses
- Use "Enhance Text" to improve your existing draft
- Features are currently in development - notifications will show when clicked

### Quick Actions
- **Research Contact**: Get background information on email contacts
- **Check Availability**: Integrate with calendar for scheduling
- **Summarize Email**: Get quick summaries of email content
- **Quick Actions**: Access contextual action suggestions

## ⚙️ Settings

Access settings by clicking the extension icon in your Chrome toolbar:

- **Enable Enhanced Search**: Toggle the custom search bar
- **Enable Reply Generation**: Control reply generation features
- **Enable Quick Actions**: Show/hide action buttons in emails

## 🔧 Development Status

| Feature | Status |
|---------|--------|
| Enhanced Search UI | ✅ Active |
| Reply Generation UI | ✅ Active |
| Quick Actions UI | ✅ Active |
| AI Search Backend | 🚧 Coming Soon |
| Reply Generation Backend | 🚧 Coming Soon |
| Contact Research | 🚧 Coming Soon |
| Calendar Integration | 🚧 Coming Soon |

## 🛠️ Technical Details

### Files Structure
```
gmail-enhanced/
├── manifest.json          # Extension configuration
├── content.js            # Main content script
├── styles.css            # Injection styles
├── popup.html            # Extension popup
├── popup.css             # Popup styles
├── popup.js              # Popup functionality
├── icons/                # Extension icons
└── README.md             # This file
```

### Permissions

- `storage`: Save user preferences
- `https://mail.google.com/*`: Gmail access

## 💡 Troubleshooting

### Extension Not Working?
1. Refresh Gmail page
2. Check if extension is enabled in `chrome://extensions/`
3. Try disabling and re-enabling the extension
4. Use the "Refresh Gmail" button in the extension popup

### Features Not Appearing?
1. Make sure you're on `mail.google.com`
2. Wait a few seconds for Gmail to fully load
3. Check extension settings - features might be disabled
4. Try refreshing the page

### Reporting Issues
1. Click the extension icon
2. Click "Report Issue" button
3. Issue template will be copied to clipboard
4. Share the template with support team

## 🤝 Contributing

This extension is currently in development. Backend features are placeholders that show notifications when clicked.

### Development Setup
1. Clone the repository
2. Make changes to the files
3. Reload the extension in `chrome://extensions/`
4. Test changes in Gmail

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

If you encounter any issues or have feature requests:
1. Use the "Report Issue" feature in the extension popup
2. Check the browser console for error messages
3. Ensure you're using the latest version of Chrome

## 🏗️ Building for Production

The extension uses a configuration system to switch between development and production environments.

### Development Build (Default)
```bash
# Uses localhost URLs
node build.js development
```

### Production Build
```bash
# Uses production URLs (api.supersonic.email, supersonic.email)
node build.js production
```

### Configuration Files

- `config.js` - Development configuration (localhost URLs)
- `config.prod.js` - Production configuration (production URLs)
- `build.js` - Build script to switch between environments

### Environment URLs

**Development:**
- API: `http://localhost:8000`
- Web App: `http://localhost:3000`

**Production:**
- API: `https://api.supersonic.email`
- Web App: `https://supersonic.email`

### Chrome Web Store Deployment

1. Run production build: `node build.js production`
2. Test the extension thoroughly
3. Create a ZIP file of the extension folder
4. Upload to Chrome Web Store

---

**Made with ❤️ for a better Gmail experience** 