// Configuration for background script
const CONFIG = {
  ENVIRONMENT: 'production', // 'development' or 'production'
  
  get API_BASE_URL() {
    return this.ENVIRONMENT === 'production' 
      ? 'https://api.gosupersonic.email' 
      : 'http://localhost:8000';
  },
  
  get ENDPOINTS() {
    return {
      GENERATE_REPLY: `${this.API_BASE_URL}/api/generate-reply/`,
      GENERATE_SUMMARY: `${this.API_BASE_URL}/api/generate-summary/`,
    };
  }
};

// Background script to handle API calls
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'generateReply') {
    generateReply(request.data)
      .then(response => sendResponse({ success: true, data: response }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    
    // Return true to indicate we'll respond asynchronously
    return true;
  } else if (request.action === 'generateSummary') {
    generateSummary(request.data)
      .then(response => sendResponse({ success: true, data: response }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    
    // Return true to indicate we'll respond asynchronously
    return true;
  }
});

async function generateReply(requestData) {
  try {
    console.log('🚀 Background script making API request...');
    
    // Get stored token
    const result = await chrome.storage.local.get(['extensionToken']);
    const token = result.extensionToken;
    
    if (!token) {
      throw new Error('No authentication token found. Please set up your token in the extension popup.');
    }
    
    const response = await fetch(CONFIG.ENDPOINTS.GENERATE_REPLY, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Token ${token}`,
      },
      body: JSON.stringify(requestData)
    });

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('Authentication failed. Please check your token in the extension popup.');
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ Background script: Reply generated successfully');
    return data;
    
  } catch (error) {
    console.error('❌ Background script: API request failed:', error);
    throw error;
  }
}

async function generateSummary(requestData) {
  try {
    console.log('🚀 Background script making summary API request...');
    
    // Get stored token
    const result = await chrome.storage.local.get(['extensionToken']);
    const token = result.extensionToken;
    
    if (!token) {
      throw new Error('No authentication token found. Please set up your token in the extension popup.');
    }
    
    const response = await fetch(CONFIG.ENDPOINTS.GENERATE_SUMMARY, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Token ${token}`,
      },
      body: JSON.stringify(requestData)
    });

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('Authentication failed. Please check your token in the extension popup.');
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ Background script: Summary generated successfully');
    return data;
    
  } catch (error) {
    console.error('❌ Background script: Summary API request failed:', error);
    throw error;
  }
} 