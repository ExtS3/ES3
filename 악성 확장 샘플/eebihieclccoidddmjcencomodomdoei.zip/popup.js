// Supersonic AI - Popup Script

// Configuration for popup
const CONFIG = {
  ENVIRONMENT: 'production', // 'development' or 'production'
  
  get API_BASE_URL() {
    return this.ENVIRONMENT === 'production' 
      ? 'https://api.gosupersonic.email' 
      : 'http://localhost:8000';
  },
  
  get ENDPOINTS() {
    return {
      VALIDATE_TOKEN: `${this.API_BASE_URL}/api/validate-token/`,
    };
  },
  
  get WEB_APP_URL() {
    return this.ENVIRONMENT === 'production'
      ? 'https://gosupersonic.email'
      : 'http://localhost:3000';
  },
  
  get PAGES() {
    return {
      SETTINGS: `${this.WEB_APP_URL}/settings`,
    };
  }
};

class PopupManager {
    constructor() {
        this.init();
    }

    init() {
        this.updateSettingsLink();
        this.checkAuthStatus();
        this.attachEventListeners();
    }
    
    updateSettingsLink() {
        const settingsLink = document.getElementById('settingsLink');
        if (settingsLink) {
            settingsLink.href = CONFIG.PAGES.SETTINGS;
        }
    }

    attachEventListeners() {
        // Authentication listeners
        document.getElementById('saveTokenBtn').addEventListener('click', () => {
            this.saveToken();
        });

        // Success section listeners
        document.getElementById('openGmailBtn').addEventListener('click', () => {
            this.openGmail();
        });

        document.getElementById('generateNewTokenBtn').addEventListener('click', () => {
            this.showTokenInput();
        });

        // Allow Enter key to save token
        document.getElementById('tokenInput').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.saveToken();
            }
        });
    }

    async checkAuthStatus() {
        const statusIndicator = document.getElementById('statusIndicator');
        const statusText = document.getElementById('statusText');
        const tokenInputSection = document.getElementById('tokenInputSection');
        const successSection = document.getElementById('successSection');

        try {
            // Get stored token
            const result = await chrome.storage.local.get(['extensionToken']);
            const token = result.extensionToken;

            if (!token) {
                // No token stored
                this.showDisconnectedState();
                return;
            }

            // Test token with backend
            statusText.textContent = 'Validating token...';
            
            const response = await fetch(CONFIG.ENDPOINTS.VALIDATE_TOKEN, {
                method: 'GET',
                headers: {
                    'Authorization': `Token ${token}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                // Token is valid
                this.showConnectedState(data.user_email);
            } else {
                // Token is invalid
                this.showDisconnectedState('Invalid or expired token');
            }
        } catch (error) {
            console.error('Error checking auth status:', error);
            this.showDisconnectedState('Connection error - check if backend is running');
        }
    }

    showDisconnectedState(message = 'Not authenticated') {
        const statusIndicator = document.getElementById('statusIndicator');
        const statusText = document.getElementById('statusText');
        const tokenInputSection = document.getElementById('tokenInputSection');
        const successSection = document.getElementById('successSection');

        statusIndicator.className = 'status-indicator disconnected';
        statusText.textContent = message;
        tokenInputSection.style.display = 'block';
        successSection.style.display = 'none';
    }

    showConnectedState(userEmail) {
        const statusIndicator = document.getElementById('statusIndicator');
        const statusText = document.getElementById('statusText');
        const tokenInputSection = document.getElementById('tokenInputSection');
        const successSection = document.getElementById('successSection');

        statusIndicator.className = 'status-indicator connected';
        statusText.textContent = `Connected as ${userEmail}`;
        tokenInputSection.style.display = 'none';
        successSection.style.display = 'block';
    }

    showTokenInput() {
        const tokenInputSection = document.getElementById('tokenInputSection');
        const successSection = document.getElementById('successSection');

        tokenInputSection.style.display = 'block';
        successSection.style.display = 'none';
        
        // Focus on the token input
        document.getElementById('tokenInput').focus();
    }

    async saveToken() {
        const tokenInput = document.getElementById('tokenInput');
        const saveBtn = document.getElementById('saveTokenBtn');
        const btnText = saveBtn.querySelector('.btn-text');
        const token = tokenInput.value.trim();

        if (!token) {
            this.showNotification('⚠️ Please enter a token', 'error');
            return;
        }

        // Update button state
        saveBtn.disabled = true;
        btnText.textContent = 'Validating...';

        try {
            // Test token with backend
            const response = await fetch(CONFIG.ENDPOINTS.VALIDATE_TOKEN, {
                method: 'GET',
                headers: {
                    'Authorization': `Token ${token}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                // Token is valid, save it
                await chrome.storage.local.set({ extensionToken: token });
                tokenInput.value = '';
                this.showConnectedState(data.user_email);
                this.showNotification('✅ Token saved successfully!', 'success');
            } else {
                const errorData = await response.json();
                this.showNotification(`❌ ${errorData.error || 'Invalid token'}`, 'error');
            }
        } catch (error) {
            console.error('Error saving token:', error);
            this.showNotification('❌ Connection error - check if backend is running', 'error');
        } finally {
            saveBtn.disabled = false;
            btnText.textContent = 'Save Token';
        }
    }

    openGmail() {
        chrome.tabs.create({ url: 'https://mail.google.com' }, () => {
            window.close();
        });
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Style the notification
        Object.assign(notification.style, {
            position: 'fixed',
            top: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            background: type === 'error' ? '#fee2e2' : type === 'success' ? '#dcfce7' : '#e0f2fe',
            color: type === 'error' ? '#dc2626' : type === 'success' ? '#16a34a' : '#0369a1',
            padding: '12px 20px',
            borderRadius: '8px',
            border: `1px solid ${type === 'error' ? '#fca5a5' : type === 'success' ? '#86efac' : '#7dd3fc'}`,
            fontSize: '13px',
            fontWeight: '500',
            zIndex: '10000',
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            animation: 'slideDown 0.3s ease-out'
        });

        // Add animation styles
        if (!document.getElementById('notification-styles')) {
            const style = document.createElement('style');
            style.id = 'notification-styles';
            style.textContent = `
                @keyframes slideDown {
                    from { opacity: 0; transform: translateX(-50%) translateY(-20px); }
                    to { opacity: 1; transform: translateX(-50%) translateY(0); }
                }
            `;
            document.head.appendChild(style);
        }

        // Add to document
        document.body.appendChild(notification);

        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideDown 0.3s ease-in reverse';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PopupManager();
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'popupAction') {
        console.log('Popup action received:', request.data);
        sendResponse({status: 'success'});
    }
}); 