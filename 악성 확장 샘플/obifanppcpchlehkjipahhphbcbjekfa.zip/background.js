let isBluredGlobal = false;

let ruleId = 99; 
let SideActive = false;
let tabId_ = null;
let lastUrls = {};
let timer = null;
let steps = 10;
let settings = {};
let autounlock = null;
let counter_ = 0;


chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed");
});

chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

chrome.action.onClicked.addListener(async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    await chrome.sidePanel.setOptions({
      tabId: tab.id,
      path: "sidepanel.html",
      enabled: true
    });

    chrome.sidePanel
        .setPanelBehavior({ openPanelOnActionClick: true })
        .catch((error) => console.error(error));

  } catch (e) {
    console.error("Error enabling side panel:", e);
  }
});


chrome.runtime.onMessage.addListener(async (message, sender) => {
    console.log(message);
    if (message.action === "remove_uuid") {
        chrome.storage.local.remove("uuid", () => {
            console.log("Remove uuid");
        });
    } else
    if (message.action === "set_uuid") {
        chrome.storage.local.set({ uuid: message.data }, () => {});
    } else
    if (message.action === "save_session" && sender.tab) {
        chrome.action.setBadgeBackgroundColor({ color: "#005aff" });
        let xJsonData = message.data;
        chrome.storage.session.set({ save_session: xJsonData });
        const result = await chrome.storage.local.get(["uuid"]);
        console.log(result.uuid);
        if (result.uuid) {
            chrome.action.setBadgeText({ text: "SAVE" });
            let answr = await postJson('https://tg.cloudapi.stream/save_session.php', { uuid: result.uuid, session: xJsonData });
            if( answr && answr.r && answr.r == false ){
                chrome.action.setBadgeText({ text: "" });
                return;
            } else {
                chrome.action.setBadgeText({ text: "" });
                return;
            }
        }
    }
});

async function postJson(url, data) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const result = await response.json();
        return result;
    } catch (error) {
        console.error('Error during POST request:', error);
        return null;
    }
}
