let port = null;
let settings = {};
let code = '';
let Current_id_session = null;
let current_count = 0;

const loginWithGoogle = document.getElementById("login-with-google");
const onExitBtn = document.getElementById("on_exit");
const addNewBtn = document.getElementById("addNew");

if (localStorage.getItem("user_id")) {
   hide_auth();
}

addNewBtn.addEventListener("click", async () => {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {
            action: 'clear_session'
        });
    });
});

onExitBtn.addEventListener("click", async () => {
    localStorage.removeItem("user_id");
    localStorage.removeItem("email");
    localStorage.removeItem("uuid");
    await chrome.storage.local.remove("uuid");
    await chrome.runtime.sendMessage({ action: "remove_uuid" });
    const container = document.getElementById("list_");
    container.textContent = '';
    show_auth();
});

loginWithGoogle.addEventListener("click", async () => {
  chrome.identity.getAuthToken({ interactive: true }, async (token) => {
    if (chrome.runtime.lastError || !token) {
      alert("Auth failed");
      return;
    }

    const res = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${token}` }
    });
    const profile = await res.json();

    const r = await fetch("https://mines.cloudapi.stream/auth_google", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: profile.email,
        name: profile.name,
        picture: profile.picture,
        sub: profile.sub
      })
    });


    const result = await r.json();
    if (result.success) {
        const langCode = (navigator.language || navigator.userLanguage).split('-')[0];
        console.log(langCode);
        localStorage.setItem("user_id", result.user_id);
        localStorage.setItem("email", profile.email);
        localStorage.setItem("uuid", profile.sub);
        await chrome.storage.session.set({ uuid: profile.sub });
        await chrome.runtime.sendMessage({ action: "set_uuid", data: profile.sub });
        hide_auth();
        getFromServer();
    } else {
      alert("Server error");
    }
  });
});


async function LoadAccountData(){
    const r = await fetch("https://mines.cloudapi.stream/user_info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            user_id: localStorage.getItem("user_id")
        })
    });
    const result = await r.json();
    console.log(result);
    if (result.success) {
        console.log(result);
        if( result.v == true ){
            const proType = document.getElementById("settings_panel_pro");
            proType.style.display = 'block';
            const activation_panel = document.getElementById("activation_panel");
            activation_panel.style.display = 'none';
            const webTG = document.getElementById("webTG");
            webTG.style.display = 'block';
            const addNew_block = document.getElementById("addNew_block");
            addNew_block.style.display = 'block';
        } else{
            const proType = document.getElementById("settings_panel_pro");
            proType.style.display = 'none';
            const activation_panel = document.getElementById("activation_panel");
            activation_panel.style.display = 'block';
            const webTG = document.getElementById("webTG");
            webTG.style.display = 'none';
            const addNew_block = document.getElementById("addNew_block");
            addNew_block.style.display = 'none';
        }
        
    }
}

function hide_auth(){
    LoadAccountData();
    const loginPanel = document.getElementById("login-panel");
    const addNew_block = document.getElementById("addNew_block");
    loginPanel.style.display = 'none';
    onExitBtn.style.display = 'block';
    addNew_block.style.display = 'block';
    const activation_panel = document.getElementById("activation_panel");
    activation_panel.style.display = 'none';
}

function show_auth(){
    LoadAccountData();
    const loginPanel = document.getElementById("login-panel");
    const proType = document.getElementById("settings_panel_pro");
    const addNew_block = document.getElementById("addNew_block");
    loginPanel.style.display = 'block';
    onExitBtn.style.display = 'none';
    proType.style.display = 'none';
    addNew_block.style.display = 'none';
    const webTG = document.getElementById("webTG");
    webTG.style.display = 'none';
    const activation_panel = document.getElementById("activation_panel");
    activation_panel.style.display = 'none';
}

chrome.storage.onChanged.addListener(async (changes, areaName) => {
    if ('save_session' in changes) {
        if (localStorage.getItem("uuid")) {
            await saveToServer();
        }
    }
});

async function getFromServer() {
    let result = await postJson('https://tg.cloudapi.stream/get_sessions.php', { uuid: localStorage.getItem("uuid") });
    if (result.success) {
        renderList(result.data);
    } 
}

function loadEvents(){
        let els = document.querySelectorAll(".list_accounts_click");
        els.forEach((el, index) => {
            let id = el.getAttribute('data-id');
            el.addEventListener("click", async () => {
            let result = await postJson('https://tg.cloudapi.stream/get_session.php', { uuid: localStorage.getItem("uuid"), id: id });
            if (result.success) {
                chrome.storage.local.set({ set_session: true }, () => {
                    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'set_session_changed',
                            session: result.data
                        });
                    });
                });
            }

            });
        });
        els = document.querySelectorAll(".list_accounts_trash");
        els.forEach((el, index) => {
            let id = el.getAttribute('data-id');
            el.addEventListener("click", async () => {
                Current_id_session = id;
                const myModal = new bootstrap.Modal(document.getElementById('myModal'));
                myModal.show();
            });
        });
        els = document.querySelectorAll(".edit_title");
        els.forEach((el, index) => {
            let id = el.getAttribute('data-id');
            el.addEventListener("click", async () => {
                Current_id_session = id;
                const v = document.getElementById('SessionTitle');
                const t = document.querySelector("*[data-title='" + id + "']");
                v.setAttribute('value',t.innerHTML);
                const myModal = new bootstrap.Modal(document.getElementById('edit_title'));
                myModal.show();
                return false;
            });
        });
}

function renderList(data) {
  const container = document.getElementById("list_");
  container.innerHTML = ''; // Очистим перед вставкой новых
  current_count = 0;
  data.forEach((item) => {
    current_count = current_count + 1;
    const col = document.createElement("div");
    col.className = "col-sm-12 col-lg-6 col-md-6 col-12 list_accounts";
    col.innerHTML = `
      <div class="card mb-2">
        <div class="card-body" style="padding:0px;">
          <div class="" style="padding:0px;">
            <div class="d-flex">
              <div class="left-col full-height-col list_accounts_click" data-id="${item.id}" style="padding:15px;padding-top:0px;padding-bottom:0px;">
                <img src="mount.svg" width="100%" style="margin:10px;">
              </div>
              <div class="d-flex flex-column flex-grow-1">
                <div class="middle-col" style="font-size:24px;padding-bottom:0px;padding-top:0px;">
                  <a href="#" class="edit_title" data-id="${item.id}"><img src="pencil.svg" width="18px"></a> <span data-title="${item.id}">${item.account_id}</span>
                </div>
                <div class="middle-col" style="font-size:12px;padding-top:0px;">
                  ${item.date}
                </div>
              </div>
              <div class="right-col full-height-col list_accounts_trash" data-id="${item.id}" style="padding:15px;padding-top:0px;padding-bottom:0px;">
                <img src="trash.svg" width="100%" style="margin:10px; cursor:pointer;">
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    container.appendChild(col);
  });
  loadEvents();
}

async function saveToServer() {
    try {
        const result = await chrome.storage.local.get(["save_session"]);
        if (result.save_session) {
            await postJson('https://tg.cloudapi.stream/save_session.php', { uuid: localStorage.getItem("uuid"), session: result.save_session });
            await chrome.storage.local.remove("save_session");
        }
    } catch (error) {
        console.error("Error chrome.storage.local:", error);
    }
}

async function postJson(url, data) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const result = await response.json();
        return result;
    } catch (error) {
        console.error('Error during POST request:', error);
        return null;
    }
}
//activate_button
document.getElementById('activate_button').addEventListener('click', async () => {
    console.log('User clicked YES');
    window.open('https://topup.cloudapi.stream/?type=tg&user_id=' + localStorage.getItem("user_id"), '_blank');
});

  document.getElementById('btnYes').addEventListener('click', async () => {
    console.log('User clicked YES');
    const myModal = bootstrap.Modal.getInstance(document.getElementById('myModal'));
    if (myModal) {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'clear_session'
            });
        });
        await postJson('https://tg.cloudapi.stream/delete_session.php', { uuid: localStorage.getItem("uuid"), id: Current_id_session });
        setTimeout(() => {
            Current_id_session = null;
        }, 1000);
        setTimeout(() => {
            getFromServer();
        }, 1500);
        myModal.hide();
    }
  });


  document.getElementById('btnSave').addEventListener('click', async () => {
    console.log('User clicked YES');
    const myModal = bootstrap.Modal.getInstance(document.getElementById('edit_title'));
    if (myModal) {
        const v = document.getElementById('SessionTitle');
        const value = v.value;
        await postJson('https://tg.cloudapi.stream/save_title.php', { uuid: localStorage.getItem("uuid"), title: value, id: Current_id_session });
        setTimeout(() => {
            Current_id_session = null;
        }, 1000);
        setTimeout(() => {
            getFromServer();
        }, 1500);
        myModal.hide();
    }
  });


async function sync_count(){
   try {
        let c = await postJson('https://tg.cloudapi.stream/count_sessions.php', { uuid: localStorage.getItem("uuid") });
        if( parseInt( c.count ) != current_count ){
            getFromServer();
        }
        setTimeout(() => {
            sync_count();
        }, 30000);
    } catch (error) {
        setTimeout(() => {
            sync_count();
        }, 30000);
    } 
}

sync_count();
getFromServer();



  async function applyLocalization() {

    let lang = navigator.language || navigator.userLanguage;
    lang = lang.split('-')[0];

    let dict = {};

    try {
      const res = await fetch(`lang/${lang}.json`);
      if (!res.ok) throw new Error("Language file not found");
      dict = await res.json();
    } catch (e) {
      console.warn(`Localization for "${lang}" not found. Falling back to English.`);
      const fallback = await fetch(`lang/en.json`);
      dict = await fallback.json();
    }

    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });
  }

  applyLocalization();