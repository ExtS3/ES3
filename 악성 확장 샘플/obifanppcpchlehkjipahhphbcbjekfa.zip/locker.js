let port = null;
let settings = {};
let code = '';

function init(){
    chrome.storage.local.get(["settings_locker", "blurred"], (result) => {
        //document.querySelector("#settings_panel_pro").style.display = 'none';
        let y_temp = {};
        try {
            y_temp = JSON.parse(result.settings_locker);
        } catch (error) {
            y_temp = {};
        }
        settings = y_temp;
        if( settings.is_pin == true ){

        } else {
            let els = document.querySelectorAll(".pin_panel");
            for( i = 0; i < els.length; i++ ) els[i].setAttribute('style','display:none!important;');
        }
    });
}

init();

async function unlockbtnFunc() { //pin_code
    let pin_code = document.querySelector("#pin_code").value;
    if( pin_code && pin_code.length > 0 ){
        if( pin_code == settings.pin ){
            chrome.storage.local.set({ blurred: false });
        } else {
            document.querySelector("#pin_error").setAttribute('style','display: block !important');
            setTimeout(() => {
                document.querySelector("#pin_error").setAttribute('style','display: none !important');
            }, 1500);
        }
    } else {
        document.querySelector("#pin_error").setAttribute('style','display: block !important');
        setTimeout(() => {
            document.querySelector("#pin_error").setAttribute('style','display: none !important');
        }, 1500);
    }
}

document.getElementById('unlock_btn').addEventListener('click', unlockbtnFunc);
