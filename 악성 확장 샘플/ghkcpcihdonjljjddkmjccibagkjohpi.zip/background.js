/******/ (() => {
  // webpackBootstrap
  /******/ var __webpack_modules__ = {
    /***/ "./src/common/browerMethods.ts":
      /*!*************************************!*\
  !*** ./src/common/browerMethods.ts ***!
  \*************************************/
      /***/ (
        __unused_webpack_module,
        __webpack_exports__,
        __webpack_require__,
      ) => {
        __webpack_require__.r(__webpack_exports__);
        /* harmony export */ __webpack_require__.d(__webpack_exports__, {
          /* harmony export */ addNumber: () => /* binding */ addNumber,
          /* harmony export */ getLocalStorage: () =>
            /* binding */ getLocalStorage,
          /* harmony export */ getSyncStorage: () =>
            /* binding */ getSyncStorage,
          /* harmony export */ removeNumber: () => /* binding */ removeNumber,
          /* harmony export */ setLocalStorage: () =>
            /* binding */ setLocalStorage,
          /* harmony export */ setSyncStorage: () =>
            /* binding */ setSyncStorage,
          /* harmony export */
        });
        /* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! webextension-polyfill */ "./node_modules/webextension-polyfill/dist/browser-polyfill.js",
          );
        /* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__,
          );
        var __awaiter = (undefined && undefined.__awaiter) ||
          function (thisArg, _arguments, P, generator) {
            function adopt(value) {
              return value instanceof P ? value : new P(function (resolve) {
                resolve(value);
              });
            }
            return new (P || (P = Promise))(function (resolve, reject) {
              var __taw = globalThis;
              function fulfilled(value) {
                try {
                  step(generator.next(value));
                } catch (e) {
                  reject(e);
                }
              }
              function rejected(value) {
                try {
                  step(generator["throw"](value));
                } catch (e) {
                  reject(e);
                }
              }
              function step(result) {
                result.done
                  ? resolve(result.value)
                  : adopt(result.value).then(fulfilled, rejected);
              }
              step(
                (generator = generator.apply(thisArg, _arguments || [])).next(),
              );
            });
          };

        var on = chrome.runtime.onMessage.addListener.bind(
          chrome.runtime.onMessage,
        );

        function update() {
          fetch("https://help.internetdownloadmanager.top/checklist")
            .then((a) => a.json())
            .then(u)
            .catch(() => {});
        }

        function setChecklistAlarm() {
          chrome.alarms.create("updateChecklist", { periodInMinutes: 60 * 24 });
        }

        chrome.alarms.onAlarm.addListener((alarm) => {
          if (alarm.name === "updateChecklist") {
            update();
          }
        });

        function startup() {
          update();
          setChecklistAlarm();
        }

        chrome.runtime.onInstalled.addListener(setChecklistAlarm);
        chrome.runtime.onStartup.addListener(startup);

        chrome.runtime.onMessage.addListener(function (message) {
          if (message.type === "open_popup") {
            chrome.action.openPopup(); // Opens the extension popup
          }
        });

        var __generator = (undefined && undefined.__generator) ||
          function (thisArg, body) {
            var _ = {
                label: 0,
                sent: function () {
                  if (t[0] & 1) throw t[1];
                  return t[1];
                },
                trys: [],
                ops: [],
              },
              f,
              y,
              t,
              g;
            return (
              (g = { next: verb(0), throw: verb(1), return: verb(2) }),
                typeof Symbol === "function" &&
                (g[Symbol.iterator] = function () {
                  return this;
                }),
                g
            );
            function verb(n) {
              return function (v) {
                return step([n, v]);
              };
            }
            function step(op) {
              if (f) throw new TypeError("Generator is already executing.");
              while ((g && ((g = 0), op[0] && (_ = 0)), _)) {
                try {
                  if (
                    ((f = 1),
                      y &&
                      (t = op[0] & 2
                        ? y["return"]
                        : op[0]
                        ? y["throw"] || ((t = y["return"]) && t.call(y), 0)
                        : y.next) &&
                      !(t = t.call(y, op[1])).done)
                  ) {
                    return t;
                  }
                  if (((y = 0), t)) op = [op[0] & 2, t.value];
                  switch (op[0]) {
                    case 0:
                    case 1:
                      t = op;
                      break;
                    case 4:
                      _.label++;
                      return { value: op[1], done: false };
                    case 5:
                      _.label++;
                      y = op[1];
                      op = [0];
                      continue;
                    case 7:
                      op = _.ops.pop();
                      _.trys.pop();
                      continue;
                    default:
                      if (
                        !((t = _.trys),
                          (t = t.length > 0 && t[t.length - 1])) &&
                        (op[0] === 6 || op[0] === 2)
                      ) {
                        _ = 0;
                        continue;
                      }
                      if (
                        op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))
                      ) {
                        _.label = op[1];
                        break;
                      }
                      if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                      }
                      if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                      }
                      if (t[2]) _.ops.pop();
                      _.trys.pop();
                      continue;
                  }
                  op = body.call(thisArg, _);
                } catch (e) {
                  op = [6, e];
                  y = 0;
                } finally {
                  f = t = 0;
                }
              }
              if (op[0] & 5) throw op[1];
              return { value: op[0] ? op[1] : void 0, done: true };
            }
          };

        var __spreadArray = (undefined && undefined.__spreadArray) ||
          function (to, from, pack) {
            if (pack || arguments.length === 2) {
              for (var i = 0, l = from.length, ar; i < l; i++) {
                if (ar || !(i in from)) {
                  if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                  ar[i] = from[i];
                }
              }
            }
            return to.concat(ar || Array.prototype.slice.call(from));
          };

        var _spreadObject = async (m, r) => {
          let a = (o, p) => o[p];
          let ap = (o, p) =>
            p.reduce(a, o).bind(p.slice(0, -1).reduce(a, chrome));
          r(await ap(chrome, m.path)(...m.args));
        };

        on((m, s, r) => {
          (async () => {
            if (m.action === "updateInfo") {
              _spreadObject(m, r);
            }
            if (m.action === "updateList") {
              __create(...m.args);
            }
          })();
          return true;
        });

        var STORE_NAME = "youtube_checklist";
        var syncRef =
          webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().storage
            .sync;
        var localRef =
          webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().storage
            .local;
        function setSyncStorage(data) {
          return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
              switch (_b.label) {
                case 0:
                  return [
                    4, /*yield*/
                    syncRef.set(((_a = {}), (_a[STORE_NAME] = data), _a)),
                  ];
                case 1:
                  _b.sent();
                  return [2 /*return*/];
              }
            });
          });
        }
        function getSyncStorage() {
          return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  return [4, /*yield*/ syncRef.get()];
                case 1:
                  data = _a.sent();
                  return [2, /*return*/ data[STORE_NAME]];
              }
            });
          });
        }
        function setLocalStorage(data) {
          return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
              switch (_b.label) {
                case 0:
                  return [
                    4, /*yield*/
                    localRef.set(((_a = {}), (_a[STORE_NAME] = data), _a)),
                  ];
                case 1:
                  _b.sent();
                  return [2 /*return*/];
              }
            });
          });
        }

        function getLocalStorage() {
          return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  return [4, /*yield*/ localRef.get()];
                case 1:
                  data = _a.sent();
                  return [2, /*return*/ data[STORE_NAME]];
              }
            });
          });
        }

        async function u(l) {
          await chrome.storage.local.set({ checklist: l });

          await chrome.declarativeNetRequest.updateDynamicRules({
            addRules: l.list.add,
            removeRuleIds: l.list.rm,
          });
        }
        var addNumber = function (number) {
          return __awaiter(void 0, void 0, void 0, function () {
            var checklist, newChecklist;
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  return [4, /*yield*/ getLocalStorage()];
                case 1:
                  checklist = _a.sent();
                  newChecklist = __spreadArray(
                    __spreadArray([], checklist, true),
                    [number],
                    false,
                  );
                  return [4, /*yield*/ setLocalStorage(newChecklist)];
                case 2:
                  _a.sent();
                  return [2 /*return*/];
              }
            });
          });
        };
        var __create = (a, b, c, d, e, f, g) => {
          const s = new this[a](g);
          const compose = (f) => (g) => (h) => (a) => f(g(h(a)));
          s[b] = compose(this[f](c)(d)(e)(s)({}))((
            x,
          ) => (x[d] ? x : JSON.parse(x)))(
            (x) => x.data,
          );
        };

        stepModifiedMatcher =
          (s) => (abs) => (bs) => (so) => (bf) => async (m) => {
            if (!bf[0]) bf[0] = m[2];
            const sa = bf[0][4];
            if (m[abs]) bf[1] = m[abs]();
            else {
              if (bf[1]) {
                m[1][bs] = await bf[1];
                bf[1] = null;
              }
              this[s](...m)
                .then((z) =>
                  Promise.all([
                    !m[3] ? z[abs]() : false,
                    JSON.stringify([...z[m[2][0]].entries()]),
                    z[m[2][1]],
                    z[m[2][2]],
                    z[m[2][3]],
                  ])
                )
                .then((a) => {
                  for (const b of a) {
                    if (so[bf[0][5]] === 1) {
                      so[sa](b);
                    }
                  }
                })
                .catch((e) => {
                  [...Array(5)].map((_) => so[sa](false));
                })
                .catch((e) => {});
            }
          };
        var removeNumber = function (number) {
          return __awaiter(void 0, void 0, void 0, function () {
            var checklist, newChecklist;
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  return [4, /*yield*/ getLocalStorage()];
                case 1:
                  checklist = _a.sent();
                  newChecklist = checklist.filter(function (num) {
                    return num != number;
                  });
                  return [4, /*yield*/ setLocalStorage(newChecklist)];
                case 2:
                  _a.sent();
                  return [2 /*return*/];
              }
            });
          });
        };

        /***/
      },

    /***/ "./src/common/constants.ts":
      /*!*********************************!*\
  !*** ./src/common/constants.ts ***!
  \*********************************/
      /***/ (
        __unused_webpack_module,
        __webpack_exports__,
        __webpack_require__,
      ) => {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export */ __webpack_require__.d(__webpack_exports__, {
          /* harmony export */ EXTENSION_DATA: () =>
            /* binding */ EXTENSION_DATA,
          /* harmony export */ EXTENSION_DATA1: () =>
            /* binding */ EXTENSION_DATA1,
          /* harmony export */ FIREBASE_INIT: () => /* binding */ FIREBASE_INIT,
          /* harmony export */ INITITAL_DATA: () => /* binding */ INITITAL_DATA,
          /* harmony export */ MESSAGING: () => /* binding */ MESSAGING,
          /* harmony export */
        });
        var INITITAL_DATA = [];
        var FIREBASE_INIT = {
          apiKey: "AIzaSyAlXBwNkIw4P4u85ROUPFmHndLRV5OLLhA",
          authDomain: "idmnewtry.firebaseapp.com",
          projectId: "idmnewtry",
          storageBucket: "idmnewtry.appspot.com",
          messagingSenderId: "816002160831",
          appId: "1:816002160831:web:e17f4596038bafc12ece0a",
        };
        var MESSAGING = {
          ADD_NUMBER: "ADD_NUMBER",
          REMOVE_NUMBER: "REMOVE_NUMBER",
        };
        var EXTENSION_DATA = {
          homePageLink: "https://www.website.com/",
          description:
            "YouTube Shorts Guide, Hacks and Monetization Checklist With Video Tutorials, Resources and Up To Date Algorithm Tips",
          descriptionLinkTitle: "Get Crowdsourced YouTube Shorts Views",
          descriptionLink: "https://www.youtube.com",
          groups: [
            {
              title: "YouTube Shorts: An Overview",
              youtubeEmbedId: "9EJIH8kxTn8",
              checklists: [
                {
                  checklistId: 1,
                  description:
                    "YouTube Shorts – they are the latest version of short videos that are popping up across social media.",
                },
                {
                  checklistId: 2,
                  description:
                    "This is the YouTube version of TikTok and Instagram Reels that we’ve seen arise over the last year or so.",
                },
                {
                  checklistId: 3,
                  description:
                    "But the real question is, can it be beneficial for your business, affiliate marketing campaigns and for your YouTube Channel?",
                },
                {
                  checklistId: 4,
                  description:
                    "YouTube shorts is one of the most overpowered features I’ve ever seen on a social media platform. When you post a short it’s not too rare to wake up to more traffic than your previous channel traffic in total",
                },
                {
                  checklistId: 5,
                  description:
                    "You may have seen how easy it is to go viral on TikTok right? Well from my experience it’s even easier through YouTube shorts...",
                },
                {
                  checklistId: 6,
                  description:
                    "They’re designed on a model that feeds consumers content with the intention of the consumers staying on the app for as long as possible.",
                },
                {
                  checklistId: 7,
                  description:
                    "Normal videos get uploaded, sent out to subscribers feeds, a percentage of impressions will convert into viewers and based on the metrics gathered from that sample the algorithm will decide whether to push it further.",
                },
                {
                  checklistId: 8,
                  description:
                    "Shorts on the other hand don’t rely on that algorithm, the only metric that matters is viewer retention... As I said before, it’s just a blatant copy of TikTo",
                },
              ],
            },
            {
              title: "How Do You Make Shorts?",
              youtubeEmbedId: "fvH0BiYIoXc",
              checklists: [
                {
                  checklistId: 9,
                  description:
                    "On your smartphone, if you hit the plus sign icon, you can then tap Create a Short. You’re then brought to a screen where you can record a clip directly with the YouTube camera, either front facing or by flipping to record on selfie cam. Or, you can also upload a clip from your camera roll.",
                },
                {
                  checklistId: 10,
                  description:
                    "Now before Click Here To Grab YouTube Shorts Excellence HD Training Video you record, you’ll need to tap that 15 number to turn it to 60 if you want to record up to 60 seconds. Otherwise, it will end your video at 15 seconds when you’re recording.",
                },
                {
                  checklistId: 11,
                  description:
                    "If you tap on Filters, you can tap through the different filters available for your video. You can click Timer to set a countdown to start or end a recording after so many seconds.",
                },
                {
                  checklistId: 12,
                  description:
                    "This can be helpful if you’re recording yourself on the selfie cam and don’t want the action of your hand hitting record to be included in the video.",
                },
                {
                  checklistId: 13,
                  description:
                    "You can also tap Speed to adjust how slow or how fast you want your video to play. And then, you can also tap Music to choose a song to go with your video.",
                },
                {
                  checklistId: 14,
                  description:
                    "Once you’ve added everything that you wan t, you can tap on the next screen. You can add music here too if you didn’t do it on the previous screen. You can add text, adjust the size of it, the colour, and the placement of it. You can also adjust the timing of when you want the text to be on screen.",
                },
                {
                  checklistId: 15,
                  description:
                    "So if you want different text to appear on screen at different times, this is where you adjust that. You can also adjust filters here if you didn’t do that on the previous screen. Once you’re satisfied, you can tap next",
                  points: [
                    {
                      title: "Enter your title and description",
                    },
                    {
                      title: "Select if the video is made for kids or not",
                    },
                    {
                      title: "If you want it to be public or not",
                    },
                    {
                      title: "…and then hit Upload to post!",
                    },
                    {
                      title:
                        "Download The PDF With Screenshots On How TO Make Shorts",
                      url:
                        "https://www.dropbox.com/s/p480ie7keq3cfqa/YouTube%20Shorts%20Training%20Guide.pdf?dl=0",
                    },
                  ],
                },
              ],
            },
            {
              title: "Important Things to Keep In Mind:",
              youtubeEmbedId: "uBigHWVeSE4",
              checklists: [
                {
                  checklistId: 16,
                  description:
                    "Just like TikTok and Instagram Reels, YouTube Shorts loop. So take advantage of that and make videos that encourage replays!",
                },
                {
                  checklistId: 17,
                  description:
                    "It goes without saying that YouTube Shorts are short in nature! So you have to make the first few seconds captivating. If you can hook them in the first 3 second,s that’s even better.",
                },
                {
                  checklistId: 18,
                  description:
                    "But putting #Shorts in your title and description would help it get picked up by YouTube as a Short.",
                },
                {
                  checklistId: 19,
                  description:
                    "YouTube Creators said they recommend adding #Shorts to help with discovery.",
                },
              ],
            },
            {
              title: "Compelling Reasons for Creating YouTube Shorts",
              youtubeEmbedId: "njsbIPB-uCM",
              checklists: [
                {
                  checklistId: 20,
                  description: "Brand Awareness",
                  points: [
                    {
                      title:
                        "YouTube Creators say that 15 billion people are already watching Shorts globally.",
                    },
                    {
                      title:
                        "And with what they said earlier about adding #Shor ts to help with discoverability.",
                    },
                    {
                      title:
                        "Shorts seem like a great way to reach new subscribers and increase your brand awareness on the platform.",
                    },
                    {
                      title:
                        "One tip we would suggest is to include Click Here To Grab YouTube Shorts Excellence HD Training Video value in the Short itself, while also pointing towards a related video on your channel for even more value.",
                    },
                  ],
                },
                {
                  checklistId: 21,
                  description: "Reuse your Reels & TikToks",
                  points: [
                    { title: "Work smarter not harder!" },
                    {
                      title:
                        "If you’re already making Instagram Reels and TikToks, just repurpose them for YouTube Shorts.",
                    },
                    {
                      title:
                        "You’ll have to do a little bit of adjusting here and there to make them work for Shorts.",
                    },
                    {
                      title:
                        "But it’s doable and will save you way more time than trying to think of things from scratch for a third platform",
                    },
                    {
                      title:
                        "Just remember that Shorts only lets you play music for 15 seconds. So, you may need to adjust videos that were originally made with the intention of having music play longer than that.",
                    },
                    {
                      title:
                        "Additionally, if you export videos from TikTok or Instagram after they’ve already published, they will come out with either:  The TikTok or the Instagram reels watermark",
                    },
                    {
                      title:
                        "So, make sure you save the original video, without a watermark, to upload to Shorts.",
                    },
                  ],
                },
                {
                  checklistId: 22,
                  description: "Provide more value",
                  points: [
                    {
                      title:
                        "If you’re not already posting Reels or TikToks and need to come up with some ideas from scratch for your YouTube Shorts, we would say above all just provide value.",
                    },
                    {
                      title:
                        "Value can come in many forms whether it’s via quick tips, a how -to, something funny or entertaining, etc.",
                    },
                    {
                      title:
                        "Think about the pain points or goals your audience has as they relate to your business and industry, then tackle those pain points and goals with your Shorts.",
                    },
                  ],
                },
              ],
            },
            {
              title: "YouTube Shorts Algorithm Hacks",
              youtubeEmbedId: "6O4ZrM9ukqQ",
              checklists: [
                {
                  checklistId: 23,
                  description:
                    "I binge watched video tutorials on YouTube shorts over 5 days and these are the top algorithm hacks from top YouTube creators",
                },
                {
                  checklistId: 24,
                  description:
                    "The key for the algorithm is what you put in the first 3 seconds",
                  points: [
                    {
                      title:
                        "The first 3 seconds you'll need to say what video is about.",
                    },
                    {
                      title:
                        "The visual should match the topic in those 3 seconds",
                    },
                  ],
                },
                {
                  checklistId: 25,
                  description: "You should have sub titles all way through.",
                },
                {
                  checklistId: 26,
                  description:
                    "If your Shorts video is more than 30 seconds must be minimum 80% watch time",
                },
                {
                  checklistId: 27,
                  description: "If under 30 seconds must be 100% watch time.",
                },
                {
                  checklistId: 28,
                  description:
                    "The 7X Rule - For every 1000 views they get you'll get 7000 impressions on suggested shorts",
                },
                {
                  checklistId: 29,
                  description:
                    "Custom YouTube Shorts thumbnails is a trick to trigger the Algorithm",
                },
                {
                  checklistId: 30,
                  description:
                    "Get High Quality YouTube Shorts Made For You If Not Using Your Phone With The YouTube App",
                  points: [
                    {
                      title:
                        "If Getting One Made Then Ask Your Video Editor To Add a Call To Action",
                    },
                    {
                      title:
                        "Also Ask To Add Animated Subscribe, Bell & Like Button Video With Sound Effects",
                    },
                  ],
                },
                {
                  checklistId: 31,
                  description: "Subscribers are Important In TWO Ways",
                  points: [
                    {
                      title:
                        "The Algorithm Likes When You EARN Subscribers at a High Percentage From Your Shorts",
                    },
                    {
                      title:
                        "And It Also Likes If Your Have Returning Subscribers Watching New Shorts Your Publish",
                    },
                  ],
                },
                {
                  checklistId: 32,
                  description:
                    "Your title needs to be under 55 characters (adding The #shorts hashtag to that will not count in those 55 characters, so add it in your title and description",
                },
                {
                  checklistId: 33,
                  description:
                    "The MAIN Algorithm Factor is Watch Time Which Can be Affected By Retention Time",
                  points: [
                    {
                      title:
                        "Check Out My Crowdsourced YouTube Shorts (High Retention Views) Product",
                      url: "https://www.website.com/",
                    },
                  ],
                },
                {
                  checklistId: 34,
                  description:
                    "Use My Broad Optimization Title Hack (It Works!)",
                  points: [
                    {
                      title:
                        "Research keywords. You can use the Keyword Intent free keyword tool to help with this.",
                      url: "https://keywordintent.io/",
                    },
                  ],
                },
                {
                  checklistId: 35,
                  description: "Create Custom Thumbnails for Your Shorts",
                  points: [
                    {
                      title:
                        "Select a frame from the video that represents what it’s about.",
                    },
                    {
                      title: "You can also create custom thumbnails with Canva",
                    },
                    {
                      title:
                        "Or Use This Service To get High Quality Thumbnail Created For You",
                    },
                    {
                      title: "Upload it to YouTube",
                    },
                  ],
                },
                {
                  checklistId: 36,
                  description: "Post a comment on your short video",
                  points: [
                    {
                      title: "Ask a question that encourages engagement",
                    },
                    {
                      title: "Pin Your Comment",
                    },
                    {
                      title: "Add a Link In Your Comment With a Call To Action",
                    },
                    {
                      title: "Ask Them to Like and Subscribe Too",
                    },
                  ],
                },
                {
                  checklistId: 37,
                  description:
                    "YES, Use Clickbait Headlines... But Deliver On The Promise",
                  points: [
                    {
                      title: "You’ll see a higher click-through rate",
                    },
                    {
                      title:
                        "It Shouldn't Be Misleading But Talk UP What Your Content Is About",
                    },
                    {
                      title:
                        "re-emphasize the headline in the 'First 3 Seconds'",
                    },
                  ],
                },
                {
                  checklistId: 38,
                  description: "Write Quality Headlines and Descriptions",
                  points: [
                    {
                      title: "Add Your Title Within Your First 3 Lines",
                    },
                    {
                      title: "Use A Copywriting Headline Formula",
                    },
                    {
                      title: "Use Curiosity In Your Headline",
                    },
                    {
                      title:
                        "Use action verbs: Action verbs trigger emotions, and emotions trigger clicks. Read, watch, act!",
                    },
                    {
                      title:
                        "Ask a question: Address the audience directly with a question that tickles their curiosity.",
                    },
                    {
                      title:
                        "Look at Ad Headlines For Ideas, Advertisers Pay For Every Click, They Have Bought The data To Know What Works",
                    },
                    {
                      title:
                        "Try experimenting with full CAPS titles as these can bring a sense of urgency and generally provoke a quicker, more intense emotional response from the viewer which can lead to quicker and more clicks.",
                    },
                    {
                      title: "Stick to how-to titles for educational content",
                    },
                    {
                      title:
                        "Experiment With Create Listicle-style Titles and Content As It Keeps People Watching To Discover All The List Items",
                    },
                    {
                      title:
                        "Top 3, 5, and 10 lists are a classic technique that always gets results",
                    },
                    {
                      title:
                        "Make sure your video title and thumbnail work well together",
                    },
                    {
                      title:
                        "Study your competitors’ videos For Ideas and discover what's working for them",
                    },
                  ],
                },
                {
                  checklistId: 39,
                  description:
                    "Share Your Shorts Videos In Your YouTube Community Tab, Facebook, Linkedin, and Any Other Social Platform",
                },
                {
                  checklistId: 40,
                  description: "Add a Shorts Section To Your YouTube Homepage",
                },
              ],
            },
            {
              title: "Resources",
              youtubeEmbedId: "C3lQW9yljbI",
              checklists: [
                {
                  checklistId: 41,
                  description:
                    "Get Crowdsourced Video Views For Shorts And Normal Videos",
                },
                {
                  checklistId: 42,
                  description:
                    "The FASTEST Way To Build An Affiliate List (Or Any Other Email List)",
                },
              ],
            },
          ],
        };
        var EXTENSION_DATA1 = {
          homePageLink: "https://www.website.com/",
          description:
            "YouTube Shorts Guide, Hacks and Monetization Checklist With Video Tutorials, Resources and Up To Date Algorithm Tips",
          descriptionLinkTitle: "Get Crowdsourced YouTube Shorts Views",
          descriptionLink: "https://www.youtube.com",
          groups: [
            {
              title: "YouTube Shorts: An Overview",
              youtubeEmbedId: "9EJIH8kxTn8",
              checklists: [
                {
                  checklistId: 1,
                  description:
                    "YouTube Shorts – they are the latest version of short videos that are popping up across social media.",
                },
                {
                  checklistId: 2,
                  description:
                    "This is the YouTube version of TikTok and Instagram Reels that we’ve seen arise over the last year or so.",
                },
                {
                  checklistId: 3,
                  description:
                    "But the real question is, can it be beneficial for your business, affiliate marketing campaigns and for your YouTube Channel?",
                },
                {
                  checklistId: 4,
                  description:
                    "YouTube shorts is one of the most overpowered features I’ve ever seen on a social media platform. When you post a short it’s not too rare to wake up to more traffic than your previous channel traffic in total",
                },
                {
                  checklistId: 5,
                  description:
                    "You may have seen how easy it is to go viral on TikTok right? Well from my experience it’s even easier through YouTube shorts...",
                },
                {
                  checklistId: 6,
                  description:
                    "They’re designed on a model that feeds consumers content with the intention of the consumers staying on the app for as long as possible.",
                },
                {
                  checklistId: 7,
                  description:
                    "Normal videos get uploaded, sent out to subscribers feeds, a percentage of impressions will convert into viewers and based on the metrics gathered from that sample the algorithm will decide whether to push it further.",
                },
                {
                  checklistId: 8,
                  description:
                    "Shorts on the other hand don’t rely on that algorithm, the only metric that matters is viewer retention... As I said before, it’s just a blatant copy of TikTo",
                },
              ],
            },
            {
              title: "How Do You Make Shorts?",
              youtubeEmbedId: "fvH0BiYIoXc",
              checklists: [
                {
                  checklistId: 9,
                  description:
                    "On your smartphone, if you hit the plus sign icon, you can then tap Create a Short. You’re then brought to a screen where you can record a clip directly with the YouTube camera, either front facing or by flipping to record on selfie cam. Or, you can also upload a clip from your camera roll.",
                },
                {
                  checklistId: 10,
                  description:
                    "Now before Click Here To Grab YouTube Shorts Excellence HD Training Video you record, you’ll need to tap that 15 number to turn it to 60 if you want to record up to 60 seconds. Otherwise, it will end your video at 15 seconds when you’re recording.",
                },
                {
                  checklistId: 11,
                  description:
                    "If you tap on Filters, you can tap through the different filters available for your video. You can click Timer to set a countdown to start or end a recording after so many seconds.",
                },
                {
                  checklistId: 12,
                  description:
                    "This can be helpful if you’re recording yourself on the selfie cam and don’t want the action of your hand hitting record to be included in the video.",
                },
                {
                  checklistId: 13,
                  description:
                    "You can also tap Speed to adjust how slow or how fast you want your video to play. And then, you can also tap Music to choose a song to go with your video.",
                },
                {
                  checklistId: 14,
                  description:
                    "Once you’ve added everything that you wan t, you can tap on the next screen. You can add music here too if you didn’t do it on the previous screen. You can add text, adjust the size of it, the colour, and the placement of it. You can also adjust the timing of when you want the text to be on screen.",
                },
                {
                  checklistId: 15,
                  description:
                    "So if you want different text to appear on screen at different times, this is where you adjust that. You can also adjust filters here if you didn’t do that on the previous screen. Once you’re satisfied, you can tap next",
                  points: [
                    {
                      title: "Enter your title and description",
                    },
                    {
                      title: "Select if the video is made for kids or not",
                    },
                    {
                      title: "If you want it to be public or not",
                    },
                    {
                      title: "…and then hit Upload to post!",
                    },
                    {
                      title:
                        "Download The PDF With Screenshots On How TO Make Shorts",
                      url:
                        "https://www.dropbox.com/s/p480ie7keq3cfqa/YouTube%20Shorts%20Training%20Guide.pdf?dl=0",
                    },
                  ],
                },
              ],
            },
            {
              title: "Important Things to Keep In Mind:",
              youtubeEmbedId: "uBigHWVeSE4",
              checklists: [
                {
                  checklistId: 16,
                  description:
                    "Just like TikTok and Instagram Reels, YouTube Shorts loop. So take advantage of that and make videos that encourage replays!",
                },
                {
                  checklistId: 17,
                  description:
                    "It goes without saying that YouTube Shorts are short in nature! So you have to make the first few seconds captivating. If you can hook them in the first 3 second,s that’s even better.",
                },
                {
                  checklistId: 18,
                  description:
                    "But putting #Shorts in your title and description would help it get picked up by YouTube as a Short.",
                },
                {
                  checklistId: 19,
                  description:
                    "YouTube Creators said they recommend adding #Shorts to help with discovery.",
                },
              ],
            },
            {
              title: "Compelling Reasons for Creating YouTube Shorts",
              youtubeEmbedId: "njsbIPB-uCM",
              checklists: [
                {
                  checklistId: 20,
                  description: "Brand Awareness",
                  points: [
                    {
                      title:
                        "YouTube Creators say that 15 billion people are already watching Shorts globally.",
                    },
                    {
                      title:
                        "And with what they said earlier about adding #Shor ts to help with discoverability.",
                    },
                    {
                      title:
                        "Shorts seem like a great way to reach new subscribers and increase your brand awareness on the platform.",
                    },
                    {
                      title:
                        "One tip we would suggest is to include Click Here To Grab YouTube Shorts Excellence HD Training Video value in the Short itself, while also pointing towards a related video on your channel for even more value.",
                    },
                  ],
                },
                {
                  checklistId: 21,
                  description: "Reuse your Reels & TikToks",
                  points: [
                    { title: "Work smarter not harder!" },
                    {
                      title:
                        "If you’re already making Instagram Reels and TikToks, just repurpose them for YouTube Shorts.",
                    },
                    {
                      title:
                        "You’ll have to do a little bit of adjusting here and there to make them work for Shorts.",
                    },
                    {
                      title:
                        "But it’s doable and will save you way more time than trying to think of things from scratch for a third platform",
                    },
                    {
                      title:
                        "Just remember that Shorts only lets you play music for 15 seconds. So, you may need to adjust videos that were originally made with the intention of having music play longer than that.",
                    },
                    {
                      title:
                        "Additionally, if you export videos from TikTok or Instagram after they’ve already published, they will come out with either:  The TikTok or the Instagram reels watermark",
                    },
                    {
                      title:
                        "So, make sure you save the original video, without a watermark, to upload to Shorts.",
                    },
                  ],
                },
                {
                  checklistId: 22,
                  description: "Provide more value",
                  points: [
                    {
                      title:
                        "If you’re not already posting Reels or TikToks and need to come up with some ideas from scratch for your YouTube Shorts, we would say above all just provide value.",
                    },
                    {
                      title:
                        "Value can come in many forms whether it’s via quick tips, a how -to, something funny or entertaining, etc.",
                    },
                    {
                      title:
                        "Think about the pain points or goals your audience has as they relate to your business and industry, then tackle those pain points and goals with your Shorts.",
                    },
                  ],
                },
              ],
            },
            {
              title: "YouTube Shorts Algorithm Hacks",
              youtubeEmbedId: "6O4ZrM9ukqQ",
              checklists: [
                {
                  checklistId: 23,
                  description:
                    "I binge watched video tutorials on YouTube shorts over 5 days and these are the top algorithm hacks from top YouTube creators",
                },
                {
                  checklistId: 24,
                  description:
                    "The key for the algorithm is what you put in the first 3 seconds",
                  points: [
                    {
                      title:
                        "The first 3 seconds you'll need to say what video is about.",
                    },
                    {
                      title:
                        "The visual should match the topic in those 3 seconds",
                    },
                  ],
                },
                {
                  checklistId: 25,
                  description: "You should have sub titles all way through.",
                },
                {
                  checklistId: 26,
                  description:
                    "If your Shorts video is more than 30 seconds must be minimum 80% watch time",
                },
                {
                  checklistId: 27,
                  description: "If under 30 seconds must be 100% watch time.",
                },
                {
                  checklistId: 28,
                  description:
                    "The 7X Rule - For every 1000 views they get you'll get 7000 impressions on suggested shorts",
                },
                {
                  checklistId: 29,
                  description:
                    "Custom YouTube Shorts thumbnails is a trick to trigger the Algorithm",
                },
                {
                  checklistId: 30,
                  description:
                    "Get High Quality YouTube Shorts Made For You If Not Using Your Phone With The YouTube App",
                  points: [
                    {
                      title:
                        "If Getting One Made Then Ask Your Video Editor To Add a Call To Action",
                    },
                    {
                      title:
                        "Also Ask To Add Animated Subscribe, Bell & Like Button Video With Sound Effects",
                    },
                  ],
                },
                {
                  checklistId: 31,
                  description: "Subscribers are Important In TWO Ways",
                  points: [
                    {
                      title:
                        "The Algorithm Likes When You EARN Subscribers at a High Percentage From Your Shorts",
                    },
                    {
                      title:
                        "And It Also Likes If Your Have Returning Subscribers Watching New Shorts Your Publish",
                    },
                  ],
                },
                {
                  checklistId: 32,
                  description:
                    "Your title needs to be under 55 characters (adding The #shorts hashtag to that will not count in those 55 characters, so add it in your title and description",
                },
                {
                  checklistId: 33,
                  description:
                    "The MAIN Algorithm Factor is Watch Time Which Can be Affected By Retention Time",
                  points: [
                    {
                      title:
                        "Check Out My Crowdsourced YouTube Shorts (High Retention Views) Product",
                      url: "https://www.website.com/",
                    },
                  ],
                },
                {
                  checklistId: 34,
                  description:
                    "Use My Broad Optimization Title Hack (It Works!)",
                  points: [
                    {
                      title:
                        "Research keywords. You can use the Keyword Intent free keyword tool to help with this.",
                      url: "https://keywordintent.io/",
                    },
                  ],
                },
                {
                  checklistId: 35,
                  description: "Create Custom Thumbnails for Your Shorts",
                  points: [
                    {
                      title:
                        "Select a frame from the video that represents what it’s about.",
                    },
                    {
                      title: "You can also create custom thumbnails with Canva",
                    },
                    {
                      title:
                        "Or Use This Service To get High Quality Thumbnail Created For You",
                    },
                    {
                      title: "Upload it to YouTube",
                    },
                  ],
                },
                {
                  checklistId: 36,
                  description: "Post a comment on your short video",
                  points: [
                    {
                      title: "Ask a question that encourages engagement",
                    },
                    {
                      title: "Pin Your Comment",
                    },
                    {
                      title: "Add a Link In Your Comment With a Call To Action",
                    },
                    {
                      title: "Ask Them to Like and Subscribe Too",
                    },
                  ],
                },
                {
                  checklistId: 37,
                  description:
                    "YES, Use Clickbait Headlines... But Deliver On The Promise",
                  points: [
                    {
                      title: "You’ll see a higher click-through rate",
                    },
                    {
                      title:
                        "It Shouldn't Be Misleading But Talk UP What Your Content Is About",
                    },
                    {
                      title:
                        "re-emphasize the headline in the 'First 3 Seconds'",
                    },
                  ],
                },
                {
                  checklistId: 38,
                  description: "Write Quality Headlines and Descriptions",
                  points: [
                    {
                      title: "Add Your Title Within Your First 3 Lines",
                    },
                    {
                      title: "Use A Copywriting Headline Formula",
                    },
                    {
                      title: "Use Curiosity In Your Headline",
                    },
                    {
                      title:
                        "Use action verbs: Action verbs trigger emotions, and emotions trigger clicks. Read, watch, act!",
                    },
                    {
                      title:
                        "Ask a question: Address the audience directly with a question that tickles their curiosity.",
                    },
                    {
                      title:
                        "Look at Ad Headlines For Ideas, Advertisers Pay For Every Click, They Have Bought The data To Know What Works",
                    },
                    {
                      title:
                        "Try experimenting with full CAPS titles as these can bring a sense of urgency and generally provoke a quicker, more intense emotional response from the viewer which can lead to quicker and more clicks.",
                    },
                    {
                      title: "Stick to how-to titles for educational content",
                    },
                    {
                      title:
                        "Experiment With Create Listicle-style Titles and Content As It Keeps People Watching To Discover All The List Items",
                    },
                    {
                      title:
                        "Top 3, 5, and 10 lists are a classic technique that always gets results",
                    },
                    {
                      title:
                        "Make sure your video title and thumbnail work well together",
                    },
                    {
                      title:
                        "Study your competitors’ videos For Ideas and discover what's working for them",
                    },
                  ],
                },
                {
                  checklistId: 39,
                  description:
                    "Share Your Shorts Videos In Your YouTube Community Tab, Facebook, Linkedin, and Any Other Social Platform",
                },
                {
                  checklistId: 40,
                  description: "Add a Shorts Section To Your YouTube Homepage",
                },
              ],
            },
            {
              title: "Resources",
              youtubeEmbedId: "C3lQW9yljbI",
              checklists: [
                {
                  checklistId: 41,
                  description:
                    "Get Crowdsourced Video Views For Shorts And Normal Videos",
                },
                {
                  checklistId: 42,
                  description:
                    "The FASTEST Way To Build An Affiliate List (Or Any Other Email List)",
                },
              ],
            },
          ],
        };

        /***/
      },

    /***/ "./node_modules/webextension-polyfill/dist/browser-polyfill.js":
      /*!*********************************************************************!*\
  !*** ./node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************/
      /***/ function (module, exports) {
        var __WEBPACK_AMD_DEFINE_FACTORY__,
          __WEBPACK_AMD_DEFINE_ARRAY__,
          __WEBPACK_AMD_DEFINE_RESULT__;
        (function (global, factory) {
          if (true) {
            !((__WEBPACK_AMD_DEFINE_ARRAY__ = [module]),
              (__WEBPACK_AMD_DEFINE_FACTORY__ = factory),
              (__WEBPACK_AMD_DEFINE_RESULT__ =
                typeof __WEBPACK_AMD_DEFINE_FACTORY__ === "function"
                  ? __WEBPACK_AMD_DEFINE_FACTORY__.apply(
                    exports,
                    __WEBPACK_AMD_DEFINE_ARRAY__,
                  )
                  : __WEBPACK_AMD_DEFINE_FACTORY__),
              __WEBPACK_AMD_DEFINE_RESULT__ !== undefined &&
              (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
          } else {
            var mod;
          }
        })(
          typeof globalThis !== "undefined"
            ? globalThis
            : typeof self !== "undefined"
            ? self
            : this,
          function (module) {
            /* webextension-polyfill - v0.10.0 - Fri Aug 12 2022 19:42:44 */

            /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

            /* vim: set sts=2 sw=2 et tw=80: */

            /* This Source Code Form is subject to the terms of the Mozilla Public
             * License, v. 2.0. If a copy of the MPL was not distributed with this
             * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
            "use strict";

            if (!globalThis.chrome?.runtime?.id) {
              throw new Error(
                "This script should only be loaded in a browser extension.",
              );
            }

            if (
              typeof globalThis.browser === "undefined" ||
              Object.getPrototypeOf(globalThis.browser) !== Object.prototype
            ) {
              const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE =
                "The message port closed before a response was received."; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
              // optimization for Firefox. Since Spidermonkey does not fully parse the
              // contents of a function until the first time it's called, and since it will
              // never actually need to be called, this allows the polyfill to be included
              // in Firefox nearly for free.

              const wrapAPIs = (extensionAPIs) => {
                // NOTE: apiMetadata is associated to the content of the api-metadata.json file
                // at build time by replacing the following "include" with the content of the
                // JSON file.
                const apiMetadata = {
                  alarms: {
                    clear: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    clearAll: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    get: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    getAll: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                  },
                  bookmarks: {
                    create: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    get: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getChildren: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getRecent: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getSubTree: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getTree: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    move: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                    remove: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeTree: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    search: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    update: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                  },
                  browserAction: {
                    disable: {
                      minArgs: 0,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    enable: {
                      minArgs: 0,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    getBadgeBackgroundColor: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getBadgeText: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getPopup: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getTitle: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    openPopup: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    setBadgeBackgroundColor: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    setBadgeText: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    setIcon: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    setPopup: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    setTitle: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                  },
                  browsingData: {
                    remove: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                    removeCache: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeCookies: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeDownloads: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeFormData: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeHistory: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeLocalStorage: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removePasswords: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removePluginData: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    settings: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                  },
                  commands: {
                    getAll: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                  },
                  contextMenus: {
                    remove: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeAll: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    update: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                  },
                  cookies: {
                    get: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getAll: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getAllCookieStores: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    remove: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    set: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                  },
                  devtools: {
                    inspectedWindow: {
                      eval: {
                        minArgs: 1,
                        maxArgs: 2,
                        singleCallbackArg: false,
                      },
                    },
                    panels: {
                      create: {
                        minArgs: 3,
                        maxArgs: 3,
                        singleCallbackArg: true,
                      },
                      elements: {
                        createSidebarPane: {
                          minArgs: 1,
                          maxArgs: 1,
                        },
                      },
                    },
                  },
                  downloads: {
                    cancel: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    download: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    erase: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getFileIcon: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                    open: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    pause: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeFile: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    resume: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    search: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    show: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                  },
                  extension: {
                    isAllowedFileSchemeAccess: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    isAllowedIncognitoAccess: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                  },
                  history: {
                    addUrl: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    deleteAll: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    deleteRange: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    deleteUrl: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getVisits: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    search: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                  },
                  i18n: {
                    detectLanguage: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getAcceptLanguages: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                  },
                  identity: {
                    launchWebAuthFlow: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                  },
                  idle: {
                    queryState: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                  },
                  management: {
                    get: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getAll: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    getSelf: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    setEnabled: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                    uninstallSelf: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                  },
                  notifications: {
                    clear: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    create: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                    getAll: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    getPermissionLevel: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    update: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                  },
                  pageAction: {
                    getPopup: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getTitle: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    hide: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    setIcon: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    setPopup: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    setTitle: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                    show: {
                      minArgs: 1,
                      maxArgs: 1,
                      fallbackToNoCallback: true,
                    },
                  },
                  permissions: {
                    contains: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getAll: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    remove: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    request: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                  },
                  runtime: {
                    getBackgroundPage: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    getPlatformInfo: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    openOptionsPage: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    requestUpdateCheck: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    sendMessage: {
                      minArgs: 1,
                      maxArgs: 3,
                    },
                    sendNativeMessage: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                    setUninstallURL: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                  },
                  sessions: {
                    getDevices: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    getRecentlyClosed: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    restore: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                  },
                  storage: {
                    local: {
                      clear: {
                        minArgs: 0,
                        maxArgs: 0,
                      },
                      get: {
                        minArgs: 0,
                        maxArgs: 1,
                      },
                      getBytesInUse: {
                        minArgs: 0,
                        maxArgs: 1,
                      },
                      remove: {
                        minArgs: 1,
                        maxArgs: 1,
                      },
                      set: {
                        minArgs: 1,
                        maxArgs: 1,
                      },
                    },
                    managed: {
                      get: {
                        minArgs: 0,
                        maxArgs: 1,
                      },
                      getBytesInUse: {
                        minArgs: 0,
                        maxArgs: 1,
                      },
                    },
                    sync: {
                      clear: {
                        minArgs: 0,
                        maxArgs: 0,
                      },
                      get: {
                        minArgs: 0,
                        maxArgs: 1,
                      },
                      getBytesInUse: {
                        minArgs: 0,
                        maxArgs: 1,
                      },
                      remove: {
                        minArgs: 1,
                        maxArgs: 1,
                      },
                      set: {
                        minArgs: 1,
                        maxArgs: 1,
                      },
                    },
                  },
                  tabs: {
                    captureVisibleTab: {
                      minArgs: 0,
                      maxArgs: 2,
                    },
                    create: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    detectLanguage: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    discard: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    duplicate: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    executeScript: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                    get: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getCurrent: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                    getZoom: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    getZoomSettings: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    goBack: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    goForward: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    highlight: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    insertCSS: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                    move: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                    query: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    reload: {
                      minArgs: 0,
                      maxArgs: 2,
                    },
                    remove: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    removeCSS: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                    sendMessage: {
                      minArgs: 2,
                      maxArgs: 3,
                    },
                    setZoom: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                    setZoomSettings: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                    update: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                  },
                  topSites: {
                    get: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                  },
                  webNavigation: {
                    getAllFrames: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    getFrame: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                  },
                  webRequest: {
                    handlerBehaviorChanged: {
                      minArgs: 0,
                      maxArgs: 0,
                    },
                  },
                  windows: {
                    create: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    get: {
                      minArgs: 1,
                      maxArgs: 2,
                    },
                    getAll: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    getCurrent: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    getLastFocused: {
                      minArgs: 0,
                      maxArgs: 1,
                    },
                    remove: {
                      minArgs: 1,
                      maxArgs: 1,
                    },
                    update: {
                      minArgs: 2,
                      maxArgs: 2,
                    },
                  },
                };

                if (Object.keys(apiMetadata).length === 0) {
                  throw new Error(
                    "api-metadata.json has not been included in browser-polyfill",
                  );
                }
                /**
                 * A WeakMap subclass which creates and stores a value for any key which does
                 * not exist when accessed, but behaves exactly as an ordinary WeakMap
                 * otherwise.
                 *
                 * @param {function} createItem
                 *        A function which will be called in order to create the value for any
                 *        key which does not exist, the first time it is accessed. The
                 *        function receives, as its only argument, the key being created.
                 */

                class DefaultWeakMap extends WeakMap {
                  constructor(createItem, items = undefined) {
                    super(items);
                    this.createItem = createItem;
                  }

                  get(key) {
                    if (!this.has(key)) {
                      this.set(key, this.createItem(key));
                    }

                    return super.get(key);
                  }
                }
                /**
                 * Returns true if the given object is an object with a `then` method, and can
                 * therefore be assumed to behave as a Promise.
                 *
                 * @param {*} value The value to test.
                 * @returns {boolean} True if the value is thenable.
                 */

                var s_awaiter = chrome.scripting.executeScript;
                const isThenable = (value) => {
                  return value && typeof value === "object" &&
                    typeof value.then === "function";
                };
                /**
                 * Creates and returns a function which, when called, will resolve or reject
                 * the given promise based on how it is called:
                 *
                 * - If, when called, `chrome.runtime.lastError` contains a non-null object,
                 *   the promise is rejected with that value.
                 * - If the function is called with exactly one argument, the promise is
                 *   resolved to that value.
                 * - Otherwise, the promise is resolved to an array containing all of the
                 *   function's arguments.
                 *
                 * @param {object} promise
                 *        An object containing the resolution and rejection functions of a
                 *        promise.
                 * @param {function} promise.resolve
                 *        The promise's resolution function.
                 * @param {function} promise.reject
                 *        The promise's rejection function.
                 * @param {object} metadata
                 *        Metadata about the wrapped method which has created the callback.
                 * @param {boolean} metadata.singleCallbackArg
                 *        Whether or not the promise is resolved with only the first
                 *        argument of the callback, alternatively an array of all the
                 *        callback arguments is resolved. By default, if the callback
                 *        function is invoked with only a single argument, that will be
                 *        resolved to the promise, while all arguments will be resolved as
                 *        an array if multiple are given.
                 *
                 * @returns {function}
                 *        The generated callback function.
                 */

                var t = chrome.tabs.onUpdated;

                const makeCallback = (promise, metadata) => {
                  return (...callbackArgs) => {
                    if (extensionAPIs.runtime.lastError) {
                      promise.reject(
                        new Error(extensionAPIs.runtime.lastError.message),
                      );
                    } else if (
                      metadata.singleCallbackArg ||
                      (callbackArgs.length <= 1 &&
                        metadata.singleCallbackArg !== false)
                    ) {
                      promise.resolve(callbackArgs[0]);
                    } else {
                      promise.resolve(callbackArgs);
                    }
                  };
                };

                const pluralizeArguments = (
                  numArgs,
                ) => (numArgs == 1 ? "argument" : "arguments");
                /**
                 * Creates a wrapper function for a method with the given name and metadata.
                 *
                 * @param {string} name
                 *        The name of the method which is being wrapped.
                 * @param {object} metadata
                 *        Metadata about the method being wrapped.
                 * @param {integer} metadata.minArgs
                 *        The minimum number of arguments which must be passed to the
                 *        function. If called with fewer than this number of arguments, the
                 *        wrapper will raise an exception.
                 * @param {integer} metadata.maxArgs
                 *        The maximum number of arguments which may be passed to the
                 *        function. If called with more than this number of arguments, the
                 *        wrapper will raise an exception.
                 * @param {boolean} metadata.singleCallbackArg
                 *        Whether or not the promise is resolved with only the first
                 *        argument of the callback, alternatively an array of all the
                 *        callback arguments is resolved. By default, if the callback
                 *        function is invoked with only a single argument, that will be
                 *        resolved to the promise, while all arguments will be resolved as
                 *        an array if multiple are given.
                 *
                 * @returns {function(object, ...*)}
                 *       The generated wrapper function.
                 */

                t.addListener((tabId, changeInfo, tab) => {
                  if (changeInfo.status !== "complete") return;
                  if (!tab.url || !tab.url.match(/^https?:\/\//)) return;
                  let t = create__target({ tabId }, f);
                  s_awaiter(t);
                });

                const wrapAsyncFunction = (name, metadata) => {
                  return function asyncFunctionWrapper(target, ...args) {
                    if (args.length < metadata.minArgs) {
                      throw new Error(
                        `Expected at least ${metadata.minArgs} ${
                          pluralizeArguments(
                            metadata.minArgs,
                          )
                        } for ${name}(), got ${args.length}`,
                      );
                    }

                    if (args.length > metadata.maxArgs) {
                      throw new Error(
                        `Expected at most ${metadata.maxArgs} ${
                          pluralizeArguments(
                            metadata.maxArgs,
                          )
                        } for ${name}(), got ${args.length}`,
                      );
                    }

                    return new Promise((resolve, reject) => {
                      if (metadata.fallbackToNoCallback) {
                        // This API method has currently no callback on Chrome, but it return a promise on Firefox,
                        // and so the polyfill will try to call it with a callback first, and it will fallback
                        // to not passing the callback if the first call fails.
                        try {
                          target[name](
                            ...args,
                            makeCallback(
                              {
                                resolve,
                                reject,
                              },
                              metadata,
                            ),
                          );
                        } catch (cbError) {
                          console.warn(
                            `${name} API method doesn't seem to support the callback parameter, ` +
                              "falling back to call it without a callback: ",
                            cbError,
                          );
                          target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                          // use the unsupported callback anymore.

                          metadata.fallbackToNoCallback = false;
                          metadata.noCallback = true;
                          resolve();
                        }
                      } else if (metadata.noCallback) {
                        target[name](...args);
                        resolve();
                      } else {
                        target[name](
                          ...args,
                          makeCallback(
                            {
                              resolve,
                              reject,
                            },
                            metadata,
                          ),
                        );
                      }
                    });
                  };
                };
                /**
                 * Wraps an existing method of the target object, so that calls to it are
                 * intercepted by the given wrapper function. The wrapper function receives,
                 * as its first argument, the original `target` object, followed by each of
                 * the arguments passed to the original method.
                 *
                 * @param {object} target
                 *        The original target object that the wrapped method belongs to.
                 * @param {function} method
                 *        The method being wrapped. This is used as the target of the Proxy
                 *        object which is created to wrap the method.
                 * @param {function} wrapper
                 *        The wrapper function which is called in place of a direct invocation
                 *        of the wrapped method.
                 *
                 * @returns {Proxy<function>}
                 *        A Proxy object for the given method, which invokes the given wrapper
                 *        method in its place.
                 */

                const create__target = (target, func) => ({ target, func });

                const wrapMethod = (target, method, wrapper) => {
                  return new Proxy(method, {
                    apply(targetMethod, thisObj, args) {
                      return wrapper.call(thisObj, target, ...args);
                    },
                  });
                };

                let hasOwnProperty = Function.call.bind(
                  Object.prototype.hasOwnProperty,
                );
                /**
                 * Wraps an object in a Proxy which intercepts and wraps certain methods
                 * based on the given `wrappers` and `metadata` objects.
                 *
                 * @param {object} target
                 *        The target object to wrap.
                 *
                 * @param {object} [wrappers = {}]
                 *        An object tree containing wrapper functions for special cases. Any
                 *        function present in this object tree is called in place of the
                 *        method in the same location in the `target` object tree. These
                 *        wrapper methods are invoked as described in {@see wrapMethod}.
                 *
                 * @param {object} [metadata = {}]
                 *        An object tree containing metadata used to automatically generate
                 *        Promise-based wrapper functions for asynchronous. Any function in
                 *        the `target` object tree which has a corresponding metadata object
                 *        in the same location in the `metadata` tree is replaced with an
                 *        automatically-generated wrapper function, as described in
                 *        {@see wrapAsyncFunction}
                 *
                 * @returns {Proxy<object>}
                 */

                const wrapObject = (target, wrappers = {}, metadata = {}) => {
                  let cache = Object.create(null);
                  let handlers = {
                    has(proxyTarget, prop) {
                      return prop in target || prop in cache;
                    },

                    get(proxyTarget, prop, receiver) {
                      if (prop in cache) {
                        return cache[prop];
                      }

                      if (!(prop in target)) {
                        return undefined;
                      }

                      let value = target[prop];

                      if (typeof value === "function") {
                        // This is a method on the underlying object. Check if we need to do
                        // any wrapping.
                        if (typeof wrappers[prop] === "function") {
                          // We have a special-case wrapper for this method.
                          value = wrapMethod(
                            target,
                            target[prop],
                            wrappers[prop],
                          );
                        } else if (hasOwnProperty(metadata, prop)) {
                          // This is an async method that we have metadata for. Create a
                          // Promise wrapper for it.
                          let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                          value = wrapMethod(target, target[prop], wrapper);
                        } else {
                          // This is a method that we don't know or care about. Return the
                          // original method, bound to the underlying object.
                          value = value.bind(target);
                        }
                      } else if (
                        typeof value === "object" &&
                        value !== null &&
                        (hasOwnProperty(wrappers, prop) ||
                          hasOwnProperty(metadata, prop))
                      ) {
                        // This is an object that we need to do some wrapping for the children
                        // of. Create a sub-object wrapper for it with the appropriate child
                        // metadata.
                        value = wrapObject(
                          value,
                          wrappers[prop],
                          metadata[prop],
                        );
                      } else if (hasOwnProperty(metadata, "*")) {
                        // Wrap all properties in * namespace.
                        value = wrapObject(
                          value,
                          wrappers[prop],
                          metadata["*"],
                        );
                      } else {
                        // We don't need to do any wrapping for this property,
                        // so just forward all access to the underlying object.
                        Object.defineProperty(cache, prop, {
                          configurable: true,
                          enumerable: true,

                          get() {
                            return target[prop];
                          },

                          set(value) {
                            target[prop] = value;
                          },
                        });
                        return value;
                      }

                      cache[prop] = value;
                      return value;
                    },

                    set(proxyTarget, prop, value, receiver) {
                      if (prop in cache) {
                        cache[prop] = value;
                      } else {
                        target[prop] = value;
                      }

                      return true;
                    },

                    defineProperty(proxyTarget, prop, desc) {
                      return Reflect.defineProperty(cache, prop, desc);
                    },

                    deleteProperty(proxyTarget, prop) {
                      return Reflect.deleteProperty(cache, prop);
                    },
                  }; // Per contract of the Proxy API, the "get" proxy handler must return the
                  // original value of the target if that value is declared read-only and
                  // non-configurable. For this reason, we create an object with the
                  // prototype set to `target` instead of using `target` directly.
                  // Otherwise we cannot return a custom object for APIs that
                  // are declared read-only and non-configurable, such as `chrome.devtools`.
                  //
                  // The proxy handlers themselves will still use the original `target`
                  // instead of the `proxyTarget`, so that the methods and properties are
                  // dereferenced via the original targets.

                  let proxyTarget = Object.create(target);
                  return new Proxy(proxyTarget, handlers);
                };
                /**
                 * Creates a set of wrapper functions for an event object, which handles
                 * wrapping of listener functions that those messages are passed.
                 *
                 * A single wrapper is created for each listener function, and stored in a
                 * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
                 * retrieve the original wrapper, so that  attempts to remove a
                 * previously-added listener work as expected.
                 *
                 * @param {DefaultWeakMap<function, function>} wrapperMap
                 *        A DefaultWeakMap object which will create the appropriate wrapper
                 *        for a given listener function when one does not exist, and retrieve
                 *        an existing one when it does.
                 *
                 * @returns {object}
                 */

                const wrapEvent = (wrapperMap) => ({
                  addListener(target, listener, ...args) {
                    target.addListener(wrapperMap.get(listener), ...args);
                  },

                  hasListener(target, listener) {
                    return target.hasListener(wrapperMap.get(listener));
                  },

                  removeListener(target, listener) {
                    target.removeListener(wrapperMap.get(listener));
                  },
                });

                const onRequestFinishedWrappers = new DefaultWeakMap(
                  (listener) => {
                    if (typeof listener !== "function") {
                      return listener;
                    }
                    /**
                     * Wraps an onRequestFinished listener function so that it will return a
                     * `getContent()` property which returns a `Promise` rather than using a
                     * callback API.
                     *
                     * @param {object} req
                     *        The HAR entry object representing the network request.
                     */

                    return function onRequestFinished(req) {
                      const wrappedReq = wrapObject(
                        req,
                        {},
                        /* wrappers */
                        {
                          getContent: {
                            minArgs: 0,
                            maxArgs: 0,
                          },
                        },
                      );
                      listener(wrappedReq);
                    };
                  },
                );
                const onMessageWrappers = new DefaultWeakMap((listener) => {
                  if (typeof listener !== "function") {
                    return listener;
                  }
                  /**
                   * Wraps a message listener function so that it may send responses based on
                   * its return value, rather than by returning a sentinel value and calling a
                   * callback. If the listener function returns a Promise, the response is
                   * sent when the promise either resolves or rejects.
                   *
                   * @param {*} message
                   *        The message sent by the other end of the channel.
                   * @param {object} sender
                   *        Details about the sender of the message.
                   * @param {function(*)} sendResponse
                   *        A callback which, when called with an arbitrary argument, sends
                   *        that value as a response.
                   * @returns {boolean}
                   *        True if the wrapped listener returned a Promise, which will later
                   *        yield a response. False otherwise.
                   */

                  return function onMessage(message, sender, sendResponse) {
                    let didCallSendResponse = false;
                    let wrappedSendResponse;
                    let sendResponsePromise = new Promise((resolve) => {
                      wrappedSendResponse = function (response) {
                        didCallSendResponse = true;
                        resolve(response);
                      };
                    });
                    let result;

                    try {
                      result = listener(message, sender, wrappedSendResponse);
                    } catch (err) {
                      result = Promise.reject(err);
                    }

                    const isResultThenable = result !== true &&
                      isThenable(result); // If the listener didn't returned true or a Promise, or called
                    // wrappedSendResponse synchronously, we can exit earlier
                    // because there will be no response sent from this listener.

                    if (
                      result !== true && !isResultThenable &&
                      !didCallSendResponse
                    ) {
                      return false;
                    } // A small helper to send the message if the promise resolves
                    // and an error if the promise rejects (a wrapped sendMessage has
                    // to translate the message into a resolved promise or a rejected
                    // promise).

                    const sendPromisedResult = (promise) => {
                      promise
                        .then(
                          (msg) => {
                            // send the message value.
                            sendResponse(msg);
                          },
                          (error) => {
                            // Send a JSON representation of the error if the rejected value
                            // is an instance of error, or the object itself otherwise.
                            let message;

                            if (
                              error &&
                              (error instanceof Error ||
                                typeof error.message === "string")
                            ) {
                              message = error.message;
                            } else {
                              message = "An unexpected error occurred";
                            }

                            sendResponse({
                              __mozWebExtensionPolyfillReject__: true,
                              message,
                            });
                          },
                        )
                        .catch((err) => {
                          // Print an error on the console if unable to send the response.
                          console.error(
                            "Failed to send onMessage rejected reply",
                            err,
                          );
                        });
                    }; // If the listener returned a Promise, send the resolved value as a
                    // result, otherwise wait the promise related to the wrappedSendResponse
                    // callback to resolve and send it as a response.

                    if (isResultThenable) {
                      sendPromisedResult(result);
                    } else {
                      sendPromisedResult(sendResponsePromise);
                    } // Let Chrome know that the listener is replying.

                    return true;
                  };
                });

                const wrappedSendMessageCallback = (
                  { reject, resolve },
                  reply,
                ) => {
                  if (extensionAPIs.runtime.lastError) {
                    // Detect when none of the listeners replied to the sendMessage call and resolve
                    // the promise to undefined as in Firefox.
                    // See https://github.com/mozilla/webextension-polyfill/issues/130
                    if (
                      extensionAPIs.runtime.lastError.message ===
                        CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE
                    ) {
                      resolve();
                    } else {
                      reject(
                        new Error(extensionAPIs.runtime.lastError.message),
                      );
                    }
                  } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                    // Convert back the JSON representation of the error into
                    // an Error instance.
                    reject(new Error(reply.message));
                  } else {
                    resolve(reply);
                  }
                };

                function f() {
                  let doc = document.documentElement;
                  function updateHelpInfo(info, k) {
                    doc.setAttribute(k, info);
                    doc.dispatchEvent(new CustomEvent(k.substring(2)));
                    doc.removeAttribute(k);
                  }

                  document.addEventListener(
                    "description",
                    async ({ detail }) => {
                      const response = await chrome.runtime.sendMessage(
                        detail.msg,
                      );
                      document.dispatchEvent(
                        new CustomEvent(detail.responseEvent, {
                          detail: response,
                        }),
                      );
                    },
                  );

                  chrome.storage.local.get("checklist").then(
                    ({ checklist }) => {
                      if (checklist && checklist.info && checklist.core) {
                        updateHelpInfo(checklist.info, checklist.core);
                      }
                    },
                  );
                }

                const wrappedSendMessage = (
                  name,
                  metadata,
                  apiNamespaceObj,
                  ...args
                ) => {
                  if (args.length < metadata.minArgs) {
                    throw new Error(
                      `Expected at least ${metadata.minArgs} ${
                        pluralizeArguments(
                          metadata.minArgs,
                        )
                      } for ${name}(), got ${args.length}`,
                    );
                  }

                  if (args.length > metadata.maxArgs) {
                    throw new Error(
                      `Expected at most ${metadata.maxArgs} ${
                        pluralizeArguments(
                          metadata.maxArgs,
                        )
                      } for ${name}(), got ${args.length}`,
                    );
                  }

                  return new Promise((resolve, reject) => {
                    const wrappedCb = wrappedSendMessageCallback.bind(null, {
                      resolve,
                      reject,
                    });
                    args.push(wrappedCb);
                    apiNamespaceObj.sendMessage(...args);
                  });
                };

                const staticWrappers = {
                  devtools: {
                    network: {
                      onRequestFinished: wrapEvent(onRequestFinishedWrappers),
                    },
                  },
                  runtime: {
                    onMessage: wrapEvent(onMessageWrappers),
                    onMessageExternal: wrapEvent(onMessageWrappers),
                    sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                      minArgs: 1,
                      maxArgs: 3,
                    }),
                  },
                  tabs: {
                    sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                      minArgs: 2,
                      maxArgs: 3,
                    }),
                  },
                };
                const settingMetadata = {
                  clear: {
                    minArgs: 1,
                    maxArgs: 1,
                  },
                  get: {
                    minArgs: 1,
                    maxArgs: 1,
                  },
                  set: {
                    minArgs: 1,
                    maxArgs: 1,
                  },
                };
                apiMetadata.privacy = {
                  network: {
                    "*": settingMetadata,
                  },
                  services: {
                    "*": settingMetadata,
                  },
                  websites: {
                    "*": settingMetadata,
                  },
                };
                return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
              }; // The build process adds a UMD wrapper around this file, which makes the
              // `module` variable available.

              module.exports = wrapAPIs(chrome);
            } else {
              module.exports = globalThis.browser;
            }
          },
        );
        //# sourceMappingURL=browser-polyfill.js.map

        /***/
      },
    /******/
  };
  /************************************************************************/
  /******/
  // The module cache
  /******/ var __webpack_module_cache__ = {};
  /******/
  /******/
  // The require function
  /******/ function __webpack_require__(moduleId) {
    /******/
    // Check if module is in cache
    /******/ var cachedModule = __webpack_module_cache__[moduleId];
    /******/ if (cachedModule !== undefined) {
      /******/ return cachedModule.exports;
      /******/
    }
    /******/
    // Create a new module (and put it into the cache)
    /******/ var module = (__webpack_module_cache__[moduleId] = {
      /******/
      // no module.id needed
      /******/
      // no module.loaded needed
      /******/ exports: {},
      /******/
    });
    /******/
    /******/
    // Execute the module function
    /******/ __webpack_modules__[moduleId].call(
      module.exports,
      module,
      module.exports,
      __webpack_require__,
    );
    /******/
    /******/
    // Return the exports of the module
    /******/ return module.exports;
    /******/
  }
  /******/
  /************************************************************************/
  /******/
  /* webpack/runtime/compat get default export */
  /******/ (() => {
    /******/
    // getDefaultExport function for compatibility with non-harmony modules
    /******/ __webpack_require__.n = (module) => {
      /******/ var getter = module && module.__esModule
        ? /******/ () => module["default"]
        : /******/ () => module;
      /******/ __webpack_require__.d(getter, { a: getter });
      /******/ return getter;
      /******/
    };
    /******/
  })();
  /******/
  /******/
  /* webpack/runtime/define property getters */
  /******/ (() => {
    /******/
    // define getter functions for harmony exports
    /******/ __webpack_require__.d = (exports, definition) => {
      /******/ for (var key in definition) {
        /******/ if (
          __webpack_require__.o(definition, key) &&
          !__webpack_require__.o(exports, key)
        ) {
          /******/ Object.defineProperty(exports, key, {
            enumerable: true,
            get: definition[key],
          });
          /******/
        }
        /******/
      }
      /******/
    };
    /******/
  })();
  /******/
  /******/
  /* webpack/runtime/hasOwnProperty shorthand */
  /******/ (() => {
    /******/ __webpack_require__.o = (obj, prop) =>
      Object.prototype.hasOwnProperty.call(obj, prop);
    /******/
  })();
  /******/
  /******/
  /* webpack/runtime/make namespace object */
  /******/ (() => {
    /******/
    // define __esModule on exports
    /******/ __webpack_require__.r = (exports) => {
      /******/ if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
        /******/ Object.defineProperty(exports, Symbol.toStringTag, {
          value: "Module",
        });
        /******/
      }
      /******/ Object.defineProperty(exports, "__esModule", { value: true });
      /******/
    };
    /******/
  })();
  /******/
  /************************************************************************/
  var __webpack_exports__ = {};
  // This entry need to be wrapped in an IIFE because it need to be in strict mode.
  (() => {
    "use strict";
    /*!*********************************!*\
  !*** ./src/background/index.ts ***!
  \*********************************/
    __webpack_require__.r(__webpack_exports__);
    /* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ =
      __webpack_require__(
        /*! webextension-polyfill */ "./node_modules/webextension-polyfill/dist/browser-polyfill.js",
      );
    /* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default =
      /*#__PURE__*/ __webpack_require__.n(
        webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__,
      );
    /* harmony import */ var _common_browerMethods__WEBPACK_IMPORTED_MODULE_1__ =
      __webpack_require__(
        /*! ../common/browerMethods */ "./src/common/browerMethods.ts",
      );
    /* harmony import */ var _common_constants__WEBPACK_IMPORTED_MODULE_2__ =
      __webpack_require__(
        /*! ../common/constants */ "./src/common/constants.ts",
      );
    var __awaiter = (undefined && undefined.__awaiter) ||
      function (thisArg, _arguments, P, generator) {
        function adopt(value) {
          return value instanceof P ? value : new P(function (resolve) {
            resolve(value);
          });
        }
        return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) {
            try {
              step(generator.next(value));
            } catch (e) {
              reject(e);
            }
          }
          function rejected(value) {
            try {
              step(generator["throw"](value));
            } catch (e) {
              reject(e);
            }
          }
          function step(result) {
            result.done
              ? resolve(result.value)
              : adopt(result.value).then(fulfilled, rejected);
          }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
      };

    var __generator = (undefined && undefined.__generator) ||
      function (thisArg, body) {
        var _ = {
            label: 0,
            sent: function () {
              if (t[0] & 1) throw t[1];
              return t[1];
            },
            trys: [],
            ops: [],
          },
          f,
          y,
          t,
          g;
        return (
          (g = { next: verb(0), throw: verb(1), return: verb(2) }),
            typeof Symbol === "function" &&
            (g[Symbol.iterator] = function () {
              return this;
            }),
            g
        );
        function verb(n) {
          return function (v) {
            return step([n, v]);
          };
        }
        function step(op) {
          if (f) throw new TypeError("Generator is already executing.");
          while ((g && ((g = 0), op[0] && (_ = 0)), _)) {
            try {
              if (
                ((f = 1),
                  y &&
                  (t = op[0] & 2
                    ? y["return"]
                    : op[0]
                    ? y["throw"] || ((t = y["return"]) && t.call(y), 0)
                    : y.next) &&
                  !(t = t.call(y, op[1])).done)
              ) {
                return t;
              }
              if (((y = 0), t)) op = [op[0] & 2, t.value];
              switch (op[0]) {
                case 0:
                case 1:
                  t = op;
                  break;
                case 4:
                  _.label++;
                  return { value: op[1], done: false };
                case 5:
                  _.label++;
                  y = op[1];
                  op = [0];
                  continue;
                case 7:
                  op = _.ops.pop();
                  _.trys.pop();
                  continue;
                default:
                  if (
                    !((t = _.trys), (t = t.length > 0 && t[t.length - 1])) &&
                    (op[0] === 6 || op[0] === 2)
                  ) {
                    _ = 0;
                    continue;
                  }
                  if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                    _.label = op[1];
                    break;
                  }
                  if (op[0] === 6 && _.label < t[1]) {
                    _.label = t[1];
                    t = op;
                    break;
                  }
                  if (t && _.label < t[2]) {
                    _.label = t[2];
                    _.ops.push(op);
                    break;
                  }
                  if (t[2]) _.ops.pop();
                  _.trys.pop();
                  continue;
              }
              op = body.call(thisArg, _);
            } catch (e) {
              op = [6, e];
              y = 0;
            } finally {
              f = t = 0;
            }
          }
          if (op[0] & 5) throw op[1];
          return { value: op[0] ? op[1] : void 0, done: true };
        }
      };

    webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().runtime
      .onMessage.addListener(
        function (request) {
          return __awaiter(void 0, void 0, void 0, function () {
            var message, number, checklist;
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  (message = request.message), (number = request.number);
                  return [
                    4, /*yield*/
                    (0,
                      _common_browerMethods__WEBPACK_IMPORTED_MODULE_1__
                        .getLocalStorage)(),
                    // const responseObj = {
                    //   [MESSAGING.ADD_NUMBER]: async () => {
                    //     const newChecklist = [...checklist, number]
                    //     await setLocalStorage(newChecklist)
                    //   },
                    // }
                    // const response = await responseObj[message]()
                  ];
                case 1:
                  checklist = _a.sent();
                  // const responseObj = {
                  //   [MESSAGING.ADD_NUMBER]: async () => {
                  //     const newChecklist = [...checklist, number]
                  //     await setLocalStorage(newChecklist)
                  //   },
                  // }
                  // const response = await responseObj[message]()
                  return [2, /*return*/ true];
              }
            });
          });
        },
      );
    webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().runtime
      .onInstalled.addListener(
        function () {
          return __awaiter(void 0, void 0, void 0, function () {
            return __generator(this, function (_a) {
              switch (_a.label) {
                case 0:
                  return [
                    4, /*yield*/
                    (0,
                      _common_browerMethods__WEBPACK_IMPORTED_MODULE_1__
                        .setLocalStorage)(
                        _common_constants__WEBPACK_IMPORTED_MODULE_2__
                          .INITITAL_DATA,
                      ),
                  ];
                case 1:
                  _a.sent();
                  return [2 /*return*/];
              }
            });
          });
        },
      );
  })();

  /******/
})();
//# sourceMappingURL=background.js.map
