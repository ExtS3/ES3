const idmFilePattern = /\.^(exe|zip|rar|7z|mp4|mp3|avi|mkv|pdf|docx|xlsx)$/i;

const icon = document.createElement("img");
icon.style.position = "absolute";
icon.style.width = "24px";
icon.style.height = "24px";
icon.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
icon.style.borderRadius = "50%";
icon.style.display = "none";
icon.style.cursor = "pointer";
icon.style.zIndex = "9999";
icon.src = "logo.png";
icon.title = "To learn how to download this using IDM please click here";
document.body.appendChild(icon);

function handleLinkHover(e) {
  const link = e.target;
  const rect = link.getBoundingClientRect();
  icon.style.top = `${window.scrollY + rect.top}px`;
  icon.style.left = `${window.scrollX + rect.left + rect.width + 10}px`;
  icon.style.display = "block";

  icon.onclick = () => {
    chrome.runtime.sendMessage({ type: "open_popup", url: link.href });
  };
}

document.querySelectorAll("a").forEach((link) => {
  if (idmFilePattern.test(link.href)) {
    link.addEventListener("mouseover", handleLinkHover);
    link.addEventListener("mouseout", () => {
      icon.style.display = "none";
    });
  }
});
