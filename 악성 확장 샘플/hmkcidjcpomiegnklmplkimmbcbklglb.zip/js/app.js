// js/app.js
document.addEventListener('DOMContentLoaded', () => {
  const canvas = new fabric.Canvas('editor-canvas');
  const uploadFile = document.getElementById('upload-file');
  const rotateBtn = document.getElementById('rotate-btn');
  const scaleUpBtn = document.getElementById('scale-up-btn');
  const scaleDownBtn = document.getElementById('scale-down-btn');
  const playPauseBtn = document.getElementById('play-pause-btn');
  const downloadBtn = document.getElementById('download-btn');
  const videoContainer = document.getElementById('video-container');
  const videoElement = document.getElementById('editor-video');

  let activeObject = null;
  let isVideo = false;

  // Wgrywanie pliku
  uploadFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      if (file.type.startsWith('image/')) {
        // Obsługa obrazu
        isVideo = false;
        videoContainer.style.display = 'none';
        canvas.clear();
        fabric.Image.fromURL(event.target.result, (img) => {
          img.scaleToWidth(400);
          canvas.add(img);
          canvas.setActiveObject(img);
          activeObject = img;
          enableButtons(true);
        });
      } else if (file.type.startsWith('video/')) {
        // Obsługa wideo
        isVideo = true;
        canvas.clear();
        videoContainer.style.display = 'block';
        videoElement.src = event.target.result;
        enableButtons(false);
        playPauseBtn.disabled = false;
        downloadBtn.disabled = false;
      }
    };
    reader.readAsDataURL(file);
  });

  // Obrót obrazu
  rotateBtn.addEventListener('click', () => {
    if (activeObject && !isVideo) {
      activeObject.rotate(activeObject.angle + 90);
      canvas.renderAll();
    }
  });

  // Skalowanie w górę
  scaleUpBtn.addEventListener('click', () => {
    if (activeObject && !isVideo) {
      activeObject.scale(activeObject.scaleX * 1.1);
      canvas.renderAll();
    }
  });

  // Skalowanie w dół
  scaleDownBtn.addEventListener('click', () => {
    if (activeObject && !isVideo) {
      activeObject.scale(activeObject.scaleX * 0.9);
      canvas.renderAll();
    }
  });

  // Odtwarzanie/pauza wideo
  playPauseBtn.addEventListener('click', () => {
    if (isVideo) {
      if (videoElement.paused) {
        videoElement.play();
        playPauseBtn.textContent = 'Pause Video';
      } else {
        videoElement.pause();
        playPauseBtn.textContent = 'Play Video';
      }
    }
  });

  // Pobieranie wyniku
  downloadBtn.addEventListener('click', () => {
    if (isVideo) {
      const link = document.createElement('a');
      link.href = videoElement.src;
      link.download = 'edited-video.mp4';
      link.click();
    } else {
      const dataURL = canvas.toDataURL({ format: 'png' });
      const link = document.createElement('a');
      link.href = dataURL;
      link.download = 'edited-image.png';
      link.click();
    }
  });

  // Włączanie/wyłączanie przycisków
  function enableButtons(isImage) {
    rotateBtn.disabled = !isImage;
    scaleUpBtn.disabled = !isImage;
    scaleDownBtn.disabled = !isImage;
    playPauseBtn.disabled = isImage;
    downloadBtn.disabled = false;
  }
});