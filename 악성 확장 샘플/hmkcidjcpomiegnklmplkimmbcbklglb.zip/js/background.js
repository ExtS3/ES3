// js/background.js
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.create({ url: chrome.runtime.getURL("app.html") });
});
// Otwieranie app.html po instalacji rozszerzenia
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("thanks.html") });
  }
});