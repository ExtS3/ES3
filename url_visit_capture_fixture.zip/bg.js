// URLVisit Capture Test Fixture — background service worker
//
// GROUND TRUTH for validating the "url_visit" stimulation strategy:
//   TRIGGER: navigation to a URL whose host contains "capture-target"
//            (matched via tabs.onUpdated, status === "complete")
//   ACTION:  chrome.tabs.captureVisibleTab(...)  -> the sensitive API we observe
//
// This is a benign demo. It captures the visible tab and does nothing malicious
// with the result (no exfiltration). Its only purpose is to give the analyzer a
// deterministic url_visit-gated captureVisibleTab call to detect.
//
// The trigger message-chain is INTENTIONALLY absent — there is no popup and no
// runtime message path. The ONLY way to make this extension call captureVisibleTab
// is to actually navigate a tab to the target URL. That is exactly what the
// url_visit stimulation strategy must reproduce.

const TARGET_HOST_SUBSTRING = "capture-target";

function isTargetUrl(url) {
  try {
    const u = new URL(url);
    return u.hostname.includes(TARGET_HOST_SUBSTRING);
  } catch (_) {
    return false;
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Fire only once the navigation has completed and the URL matches the gate.
  if (changeInfo.status !== "complete") return;
  const url = (tab && tab.url) || changeInfo.url || "";
  if (!isTargetUrl(url)) return;

  // TRIGGER MET -> call the sensitive API.
  try {
    chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" }, (dataUrl) => {
      // Benign sink: just log length. No network, no storage exfil.
      if (chrome.runtime.lastError) {
        console.log("[fixture] capture error:", chrome.runtime.lastError.message);
        return;
      }
      console.log("[fixture] captured visible tab, dataUrl length =", (dataUrl || "").length);
    });
  } catch (e) {
    console.log("[fixture] capture threw:", String(e));
  }
});

console.log("[fixture] url_visit capture fixture service worker loaded; gate host substring =", TARGET_HOST_SUBSTRING);
