// Benign dictionary/price-check style extension.
// ONLY two behaviors, by design:
//   (1) read the page title via querySelector + textContent (dom_surveillance anchor)
//   (2) one non-target external version-check fetch on load (external_communication)
// No storage, no cookies, no message relay, no timers, no capture, no exfiltration.

try {
  const el = document.querySelector("title");
  const pageTitle = el ? el.textContent : "";
  console.log("[benign-fixture] page title read:", pageTitle);
} catch (e) {
  console.log("[benign-fixture] title read threw:", String(e));
}

try {
  // One-time version check to a NON-ROUTABLE non-target test host.
  // GET only, no body, response discarded. Nothing is sent or stored.
  fetch("https://version-check.benign-fixture.test/version.json")
    .then((r) => console.log("[benign-fixture] version check status:", r.status))
    .catch((_) => console.log("[benign-fixture] version check failed (expected, test host)"));
} catch (e) {
  console.log("[benign-fixture] fetch threw:", String(e));
}
